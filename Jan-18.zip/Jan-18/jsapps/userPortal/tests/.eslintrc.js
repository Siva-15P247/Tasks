module.exports = {
  env: {
    embertest: true
  }
};
