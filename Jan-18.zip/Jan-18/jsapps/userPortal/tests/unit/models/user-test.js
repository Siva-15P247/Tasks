import { moduleForModel, test } from 'ember-qunit';
//ignorei18n_start
moduleForModel('user', 'Unit | Model | user', {
  // Specify the other units that are required for this test.
  needs: []
});

test('it exists', function(assert) {
  let model = this.subject();
  // let store = this.store();
  assert.ok(!!model);
});
//ignorei18n_end
