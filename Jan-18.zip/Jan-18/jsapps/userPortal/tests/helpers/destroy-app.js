//ignorei18n_start
import { run } from '@ember/runloop';

export default function destroyApp(application) {
  run(application, 'destroy');
}
//ignorei18n_end