import EmberRouter from '@ember/routing/router';
import config from './config/environment';
//ignorei18n_start
const Router = EmberRouter.extend({
  location: config.locationType,
  rootURL: config.rootURL
});

Router.map(function() {
  this.route('applications');
  this.route('loading');
});

export default Router;
//ignorei18n_end
