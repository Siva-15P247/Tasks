//ignorei18n_start
module.exports = {
  //extends: 'recommended',

  rules: {
    'no-bare-strings': true,
    'no-html-comments': true,
    'link-rel-noopener': true,
    'simple-unless': true
  }
}
//ignorei18n_end
