//ignorei18n_start
/* eslint-env node */
'use strict';

const EmberApp = require('ember-cli/lib/broccoli/ember-app');

module.exports = function(defaults) {
  let app = new EmberApp(defaults, {
    minifyCSS: {
      options: {
        processImport: true
      }
    },
    fingerprint: {
      exclude: ['images/appicons']
    }
  });

  app.import("node_modules/bootstrap/dist/js/bootstrap.min.js")
  app.import("node_modules/jquery-ui/ui/unique-id.js")
  app.import("node_modules/jquery-ui/ui/widget.js")
  app.import("node_modules/jquery-ui/ui/widgets/tooltip.js")
  app.import("node_modules/jquery-ui/ui/version.js")
  app.import("node_modules/jquery-ui/ui/position.js")
  app.import("node_modules/jquery-ui/ui/keycode.js")
  app.import("node_modules/moment/min/moment.min.js")
  app.import("node_modules/bootstrap-daterangepicker/daterangepicker.js")
  app.import("node_modules/highcharts/highcharts.js")
  app.import("node_modules/highcharts/modules/data.js")
  app.import("node_modules/highcharts/modules/no-data-to-display.js")
  app.import("node_modules/bxslider/dist/jquery.bxslider.min.js")
  //app.import("vendor/js/tooltipster.bundle.min.js")
  app.import("vendor/js/bootstrap-select.js")
  app.import("vendor/js/jstree.js")
  app.import("vendor/js/jquery.mCustomScrollbar.js")
  app.import("vendor/js/icheck.min.js")
  app.import("vendor/js/FileSaver.js")
  app.import("vendor/js/typeahead.jquery.js")

  // Use `app.import` to add additional libraries to the generated
  // output files.
  //
  // If you need to use different assets in different
  // environments, specify an object as the first parameter. That
  // object's keys should be the environment name and the values
  // should be the asset to use in that environment.
  //
  // If the library that you are including contains AMD or ES6
  // modules that you would like to import into your application
  // please specify an object with the list of modules as keys
  // along with the exports of each module as its value.

  return app.toTree();
};
//ignorei18n_end
