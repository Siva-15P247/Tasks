import idmpodFileUtils from 'admin-portal/utils/idmpod-file-utils';
import { module, test } from 'qunit';
//ignorei18n_start
module('Unit | Utility | idmpod file utils');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = idmpodFileUtils();
  assert.ok(result);
});
//ignorei18n_end
