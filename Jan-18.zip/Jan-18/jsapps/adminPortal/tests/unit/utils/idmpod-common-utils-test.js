import idmpodCommonUtils from 'admin-portal/utils/idmpod-common-utils';
import { module, test } from 'qunit';
//ignorei18n_start
module('Unit | Utility | idmpod common utils');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = idmpodCommonUtils();
  assert.ok(result);
});
//ignorei18n_end
