import Ember from 'ember';

export default function idmpodCommonUtils() {
  return true;
}

export function setDynamicHeight(selector) {
  if (selector) {
    selector.each(function() {
      if (Ember.$(this).attr("data-buffer-height")) {
        Ember.$(this).height(Ember.$(window).height() - parseInt(Ember.$(this).attr("data-buffer-height")));
      } else {
        Ember.$(this).height(Ember.$(this).attr("data-height"));
      }
    })
  } else {
    Ember.$("[data-toggle=dynamic-height]").each(function() {
      if (Ember.$(this).attr("data-buffer-height")) {
        Ember.$(this).height(Ember.$(window).height() - parseInt(Ember.$(this).attr("data-buffer-height")));
      } else {
        Ember.$(this).height(Ember.$(this).attr("data-height"));
      }
    })
  }
}

export function tryParseJSON(string)
{
  try {
        var o = JSON.parse(string);

        // Handle non-exception-throwing cases:
        // Neither JSON.parse(false) or JSON.parse(1234) throw errors, hence the type-checking,
        // but... JSON.parse(null) returns null, and typeof null === "object",
        // so we must check for that, too. Thankfully, null is falsey, so this suffices:
        if (o && typeof o === "object") {
            return o;
        }
    }
    catch (e) { return false; }

    return false;
}
