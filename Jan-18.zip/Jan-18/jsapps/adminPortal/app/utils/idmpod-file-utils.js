export default function idmpodFileUtils() {
  return true;
}
export function saveTextAsFile(text,mimetype,suggestedFilename) {
  var blb=new Blob([text],{type:mimetype});
  saveAs(blb,suggestedFilename);
}
