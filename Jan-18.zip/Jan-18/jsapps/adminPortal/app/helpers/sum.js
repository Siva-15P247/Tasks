import { helper } from '@ember/component/helper';

export function sum(params/*, hash*/) {
  return params.reduce((a, b) => Number(a) + Number(b));
}

export default helper(sum);
