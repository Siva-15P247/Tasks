import { helper } from '@ember/component/helper';

export function i18n(params/*, hash*/) {
  return params;
}

export default helper(i18n);
