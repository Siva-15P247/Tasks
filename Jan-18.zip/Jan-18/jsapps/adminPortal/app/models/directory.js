//ignorei18n_start
import DS from 'ember-data';
import Ember from 'ember';
import {
  memberAction
} from 'ember-api-actions';
import {
  isEmpty
} from '@ember/utils'; //No I18N

export default DS.Model.extend({
  LDAP_SERVER: DS.attr('string', {
    defaultValue: ''
  }),
  LDAP_PORT: DS.attr('string', {
    defaultValue: 636
  }),
  LDAP_SSL: DS.attr('string', {
    defaultValue: 'ldaps'
  }),
  LDAP_CONNECTION_URL: Ember.computed('LDAP_SERVER', 'LDAP_PORT', 'LDAP_SSL', 'BASE_DN_CONNECTION_STRING', function() {
    return `${this.get('LDAP_SSL')}://${this.get('LDAP_SERVER')}${this.get('LDAP_PORT')?':':''}${this.get('LDAP_PORT')}/${this.get('BASE_DN_CONNECTION_STRING')}`;
  }),
  BASE_DOMAIN_NAME: DS.attr('string', {
    defaultValue: ''
  }),
  DIRECTORY_DISPLAY_NAME: DS.attr('string', {
    defaultValue: ''
  }),
  DIRECTORY_NAME: DS.attr('string', {
    defaultValue: ''
  }),
  BASE_DN_CONNECTION_STRING: Ember.computed('BASE_DOMAIN_NAME', function() {
    if (this.get('BASE_DOMAIN_NAME').trim().length > 0) {
      return this.get('BASE_DOMAIN_NAME').split('.').map(function(a) {
        return "dc=" + a
      }).join(',')
    } else {
      return '';
    }
  }),
  SERVER_VALUE: Ember.computed.alias('id'), //No I18N
  CLIENT_VALUE: Ember.computed('DIRECTORY_NAME', 'BASE_DOMAIN_NAME', 'DIRECTORY_DISPLAY_NAME', function() {
    return isEmpty(this.get('DIRECTORY_NAME')) ? (isEmpty(this.get('DIRECTORY_DISPLAY_NAME')) ? this.get('BASE_DOMAIN_NAME') : this.get('DIRECTORY_DISPLAY_NAME')) : this.get('DIRECTORY_NAME');
  }),
  ORGANIZATIONAL_UNITS: DS.hasMany("organizational-unit", {
    inverse: null
  }),
  SERVICE_ACCOUNT_USERNAME: DS.attr(),
  SERVICE_ACCOUNT_PASSWORD: DS.attr(),
  DIRECTORY_TYPE: DS.belongsTo('directory-type'),

  AZURE_AUTH_TOKEN_ID: DS.attr(),
  GSUITE_AUTH_TOKEN_ID: DS.attr(),
  GSUITE_AUTH_TOKEN: DS.belongsTo('gsuite-auth-token'),
  AZURE_AUTH_TOKEN: DS.belongsTo('azure-auth-token'),

  collectSampleData: memberAction({
    path: 'collect',
    type: 'GET'
  }),

  setupSync: memberAction({
    path: 'sync',
    type: 'POST'
  }),
  importUsers: memberAction({
    path: 'import',
    type: 'POST'
  }),
  addUsers: memberAction({
    path: 'add-users',
    type: 'POST'
  }),
  syncNow: memberAction({
    path: 'sync-now',
    type: 'POST'
  }),
  LAST_SYNCHED_STATUS: DS.attr(),
  LAST_SYNC_TIME: DS.attr(),
  SYNCHED_OBJECTS: DS.attr(),
  DAILY_SYNC_TIME_HOUR: DS.attr('string', {
    defaultValue: 0
  }),
  DAILY_SYNC_TIME_MIN: DS.attr('string', {
    defaultValue: 0
  }),
  SYNC_SETUP: DS.attr(),
  SYNC_STATUS: DS.attr(),
  SHOW_AS_RUNNING: Ember.computed('SYNC_STATUS', function() {
    return (this.get('SYNC_STATUS') == 0 || this.get('SYNC_STATUS') == 1);
  })
});
//ignorei18n_end
