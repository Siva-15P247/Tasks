import DS from 'ember-data';

export default DS.Model.extend({
  REPORT_INPUT_TYPE: DS.attr(),
  INPUT_LABEL: DS.attr(),
  INPUT_MODEL: DS.attr(),
  INPUT_FIELD_NAME: DS.attr(),
  CV_KEY: DS.attr(),
  UI_COMPONENT_TYPE: DS.attr(),
  OPTIONS: DS.attr()
});
