import DS from 'ember-data';
import Ember from 'ember';

export default DS.Model.extend({
  EXPIRYTIME: DS.attr(),
  NO_OF_USERS: DS.attr(),
  PLANID: DS.attr(),
  PLANNAME: DS.attr(),
  PLANTYPE: DS.attr(),
  PROFILEID: DS.attr(),
  PRODUCT_BUILD: DS.attr(),
  PRODUCT_VERSION: DS.attr(),
  ACTIVE_USER_COUNT: DS.attr(),
  PAYMENT_URL: DS.attr(),
  IS_REGISTERED: Ember.computed("PLANTYPE",function () {//No I18N
    return this.get('PLANTYPE')=="REGISTERED";//No I18N
  }),
  STATUS: DS.attr(),
  CLOSE_ACCOUNT_REASON: DS.attr(),
  CLOSE_ACCOUNT_COMMENTS: DS.attr()
});
