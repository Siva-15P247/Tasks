import DS from 'ember-data';

export default DS.Model.extend({
  ACS_URL: DS.attr(),
  ISSUER: DS.attr(),
  LOGOUT_URL: DS.attr(),
  NAMEID: DS.attr(),
  PUBLIC_KEY: DS.attr()
});
