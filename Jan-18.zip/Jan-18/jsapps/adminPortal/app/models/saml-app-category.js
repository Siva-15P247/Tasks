import DS from 'ember-data';
import Ember from 'ember';

export default DS.Model.extend({
  CATEGORY_ID: DS.attr(),
  CATEGORY_NAME: DS.attr(),
  DISPLAY_NAME: DS.attr(),
  TEMPLATES: DS.hasMany('saml-app-template'),//No I18N
  TEMPLATES_COUNT:Ember.computed('TEMPLATES', function() {//No I18N
    return this.get('TEMPLATES.length');
  })
});
