import DS from 'ember-data';
import Ember from 'ember';
import {
  memberAction
} from 'ember-api-actions'; //No I18N

export default DS.Model.extend({
  ENTITYID: DS.attr(),
  APP_NAME: DS.attr(),
  DESCRIPTION: DS.attr(),
  ICON: DS.attr(),
  IDP_LOGIN_URL: DS.attr(),
  IDP_LOGOUT_URL: DS.attr(),
  ISSUER: DS.attr(),
  CERTIFICATE: DS.attr(),
  CERTIFICATE_FINGERPRINT: DS.attr(),
  SP_METADATA: DS.attr(),
  METADATA: DS.attr(),
  IS_METADATA_UPLOADED: DS.attr(),
  ENCODED_METADATA: DS.attr(),
  LOGIN_URL: DS.attr(),
  LOGOUT_URL: DS.attr(),
  NAMEID: DS.attr(),
  RELAY_STATE: DS.attr(),
  HOST_IDENTIFIER: DS.attr(),
  CUSTOM_IDENTIFIER: DS.attr(),
  DOMAIN_IDENTIFIER: DS.attr(),
  ACS_URL: DS.attr(),
  MAPPED_USER_COUNT: DS.attr(),
  LOGO: DS.attr(),
  TEMPLATE: DS.belongsTo('saml-app-template'), //No I18N
  ACCESS_URL: DS.attr(),
  CREATED_TIME: DS.attr(),
  MODIFIED_TIME: DS.attr(),
  //SELECTED_FOR_ACTION: DS.attr(),
  IS_ENABLED: DS.attr(),
  assignUsers: memberAction({
    path: 'assign-users', //No I18N
    type: 'POST' //No I18N
  }),
  removeUsers: memberAction({
    path: 'remove-users', //No I18N
    type: 'POST' //No I18N
  }),
  CLIENT_VALUE: Ember.computed.alias('APP_NAME') //No I18N
});
