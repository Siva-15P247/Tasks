import Ember from 'ember';
import DS from 'ember-data';
import {
  memberAction,
  collectionAction
} from 'ember-api-actions'; //No I18N

export default DS.Model.extend({
  COUNTRY: DS.attr(),
  DISPLAY_NAME: DS.attr(),
  EMAIL_ID: DS.attr(),
  FIRST_NAME: DS.attr(),
  GENDER: DS.attr(),
  LANGUAGE: DS.attr(),
  LAST_NAME: DS.attr(),
  ORG_ROLE: DS.attr(),
  LOGIN_NAME: DS.attr(),
  PRIMARY_EMAIL: DS.attr(),
  ROLE: DS.attr(),
  SAML_APPS_COUNT: DS.attr(),
  STATUS: DS.attr(),
  USER_ID: DS.attr(),
  PAYMENT_URL: DS.attr(),
  ZUID: DS.attr(),
  ACCESS_COUNT: DS.attr(),
  LAST_LOGIN: DS.attr(),
  LAST_ACTIVITY_TIMESTAMP: DS.attr(),
  IAM_PROFILE_URL: DS.attr(),
  USER_PHOTO_URL: DS.attr(),
  SHOW_GETTING_STARTED: DS.attr(),
  IS_AA_ADMIN: Ember.computed('ROLE', function() { //No I18N
    return this.get('ROLE') == 'Administrator' || this.get('ROLE') == 'Super Admin'; //No I18N
  }),
  IS_SUPER_ADMIN: Ember.computed('ROLE', function() { //No I18N
    return this.get('ROLE') == 'Super Admin'; //No I18N
  }),
  IS_ACTIVE: Ember.computed('STATUS', function() { //No I18N
    return this.get('STATUS') == 'ACTIVE'; //No I18N
  }),
  assignSamlApps: memberAction({
    path: 'assign-apps', //No I18N
    type: 'POST' //No I18N
  }),
  assignSamlAppsToUsers: collectionAction({
    path: 'assign-apps', //No I18N
    type: 'POST' //No I18N
  }),
  unassignSamlAppsFromUsers: collectionAction({
    path: 'unassign-apps', //No I18N
    type: 'POST' //No I18N
  }),
  CLIENT_VALUE: Ember.computed.alias('DISPLAY_NAME') //No I18N
});
