import DS from 'ember-data';
import Ember from 'ember';

export default DS.Model.extend({
  REPORT_NAME: DS.attr(),
  REPORT_DISPLAY_NAME: DS.attr(),
  REPORT_MODEL: DS.attr(),
  MODEL_ID: DS.attr(),
  MODEL_NAME: DS.attr(),
  HAS_CHART: DS.attr(),
  CHART_ID: DS.attr(),
  CHART: DS.belongsTo("chart", { //No I18N
    inverse: null
  }),
  INPUTS: DS.hasMany("report-input", { //No I18N
    inverse: null
  }),
  HAS_INPUTS: Ember.computed('INPUTS', function() { //No I18N
    return this.get('INPUTS.length') > 0;
  })
});
