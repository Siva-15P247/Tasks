//ignorei18n_start
import DS from 'ember-data';
import {
  collectionAction
} from 'ember-api-actions';

export default DS.Model.extend({
  EMAIL_ID: DS.attr(),
  STATUS: DS.attr(),
  CREATED_TIME: DS.attr(),
  deleteInvitation: collectionAction({
    path: 'delete-invitations',
    type: 'delete',
    urlType: 'destroyRecord'
  })
});
//ignorei18n_end
