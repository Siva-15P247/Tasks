import DS from 'ember-data';

export default DS.Model.extend({
  TYPE_DISPLAY_NAME: DS.attr(),
  CREATION_PATH: DS.attr(),
  MODIFICATION_PATH: DS.attr(),
  LOGO_CLASS: DS.attr(),
  SYNC_CONFIG_PATH: DS.attr(),
  TYPE_HANDLER: DS.attr()
});
