import DS from 'ember-data';

export default DS.Model.extend({
  EMAIL_ID: DS.attr(),
  IS_VALID: DS.attr()
});
