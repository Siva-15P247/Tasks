import DS from 'ember-data';
import Ember from 'ember';

export default DS.Model.extend({
  FIELD_NAME: DS.attr(),
  FIELD_DISPLAY_NAME: DS.attr(),
  FIELD_TYPE: DS.attr(),
  IS_SEARCHABLE: DS.attr(),
  COLUMN_NAME: Ember.computed.alias('FIELD_NAME'), //No I18N
  COLUMN_DISPLAY_NAME: Ember.computed.alias('FIELD_DISPLAY_NAME'), //No I18N
  COLUMN_TYPE: Ember.computed.alias('FIELD_TYPE') //No I18N
});
