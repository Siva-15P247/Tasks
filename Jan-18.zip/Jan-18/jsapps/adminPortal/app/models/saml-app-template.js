import DS from 'ember-data';
import Ember from 'ember';
import translate from 'ember-bundle-i18n/utils/translate';
//ignorei18n_start
export default DS.Model.extend({
  APP_NAME: DS.attr(),
  DISPLAY_NAME: DS.attr(),
  ICON_STYLE: DS.attr(),
  APP_TITLE: DS.attr(),
  DOMAIN_LABEL: DS.attr('string', {
    defaultValue: 'idmp.applications.config.fields.domain_name'
  }),
  CUSTOM_LABEL: DS.attr('string', {
    defaultValue: 'idmp.applications.config.fields.domain_name'
  }),
  DEFAULT_SAML_URL: DS.attr(),
  APP_WARNING_MSG: DS.attr(),
  ATTRIB_REQ_SAML_RESPONSE: DS.attr(),
  EXCLUDE_HOSTNAME: DS.attr(),
  DEFAULT_ACS_URL: DS.attr(),
  DEFAULT_ENTITY_ID: DS.attr(),
  SHA_METHOD: DS.attr(),
  SIGNED_SAML_RESPONSE: DS.attr(),
  ACC_MAPPING_ATTRIBUTE: DS.attr(),
  IS_IDP_INITIATED_FLOW: DS.attr(),
  CATEGORY_ID: DS.attr(),
  CONFIG_BIT: DS.attr('number', {
    defaultValue: 15
  }),
  REQUIRE_SAML_URL: Ember.computed('CONFIG_BIT', 'IS_IDP_INITIATED_FLOW', function() {
    return ((this.get('CONFIG_BIT') & 1) == 1) && !this.get('IS_IDP_INITIATED_FLOW');
  }),
  REQUIRE_DOMAIN_IDENTIFIER: Ember.computed('CONFIG_BIT', 'IS_IDP_INITIATED_FLOW', function() {
    return ((this.get('CONFIG_BIT') & 2) == 2);
  }),
  REQUIRE_ACS_URL: Ember.computed('CONFIG_BIT', 'IS_IDP_INITIATED_FLOW', function() {
    return ((this.get('CONFIG_BIT') & 4) == 4) && this.get('IS_IDP_INITIATED_FLOW');
  }),
  REQUIRE_ENTITY_ID: Ember.computed('CONFIG_BIT', 'IS_IDP_INITIATED_FLOW', function() {
    return ((this.get('CONFIG_BIT') & 8) == 8) && this.get('IS_IDP_INITIATED_FLOW');
  }),
  REQUIRE_CUSTOM_IDENTIFIER: Ember.computed('CONFIG_BIT', 'IS_IDP_INITIATED_FLOW', function() {
    return ((this.get('CONFIG_BIT') & 16) == 16);
  }),
  LOCALE_DISPLAY_NAME: Ember.computed('DISPLAY_NAME', function() {
    return translate(this.get('DISPLAY_NAME'));
  })
});
//ignorei18n_end
