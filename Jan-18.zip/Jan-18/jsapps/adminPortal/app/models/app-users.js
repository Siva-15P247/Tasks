import DS from 'ember-data';
import userModel from 'admin-portal/models/user'

export default userModel.extend({
  ACCESS_COUNT: DS.attr(),
  LAST_LOGIN: DS.attr()
});
