//ignorei18n_start
import DS from 'ember-data';

export default DS.Model.extend({
  NODE_ID: DS.attr(),
  NODE_IDENTIFIER: DS.attr(),
  HAS_CHILDREN: DS.attr(),
  SYNC_ENABLED: DS.attr('boolean'),
  NODE_DISPLAY_NAME: DS.attr(),
  DIRECTORY_ID: DS.attr(),
  PARENT_NODE: DS.attr(),
  PARENT: DS.belongsTo('organizational-unit', {
    inverse: 'CHILDREN'
  }),
  CHILDREN: DS.hasMany('organizational-unit', {
    inverse: 'PARENT'
  }),
  DIRECTORY: DS.belongsTo('directory', {
    inverse: null
  })
});
//ignorei18n_end
