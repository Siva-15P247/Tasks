import DS from 'ember-data';
import Ember from 'ember';

export default DS.Model.extend({
  CLIENT_IP: DS.attr(),
  TIMESTAMP: DS.attr(),
  UNIQUE_ID: DS.attr(),
  USER_AGENT_INFO: DS.attr(),
  USER_ID: DS.attr(),
  USER_NAME: DS.attr(),
  OPERATION_DISPLAY_NAME: DS.attr(),
  RESULT_STATUS: DS.attr(),
  SUBJECT_ID: DS.attr(),
  SUBJECT_TYPE: DS.attr(),
  SUBJECT: Ember.computed(function() {
    if (this.get('SUBJECT_ID')) {
      let model = this.get('SUBJECT_TYPE'),
        id = this.get('SUBJECT_ID');
      if (this.store.hasRecordForId(model, id)) {
        return this.store.peekRecord(model, id);
      } else {
        return this.store.findRecord(model, id);
      }
    } else {
      return;
    }
  }),
  SUBJECT_ATTRIBUTES: DS.attr(),
  REMARKS: DS.attr()
});
