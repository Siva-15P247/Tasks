import DS from 'ember-data';
import Ember from 'ember';

export default DS.Model.extend({
  DIRECTORY_ID: DS.attr(),
  DISTINGUISHED_NAME: DS.attr(),
  FIRST_NAME: DS.attr(),
  LAST_NAME: DS.attr(),
  NODE_ID: DS.attr(),
  SYNCED_USER_ID: DS.attr(),
  SYNC_ID: DS.attr(),
  USER_DISPLAY_NAME: DS.attr(),
  USER_PRINCIPAL_NAME: DS.attr(),
  USER_EMAIL: DS.attr(),
  CLIENT_VALUE: Ember.computed.alias('USER_DISPLAY_NAME')// No I18N
});
