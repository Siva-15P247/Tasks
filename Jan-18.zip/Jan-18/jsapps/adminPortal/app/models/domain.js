import DS from 'ember-data';
//ignorei18n_start
export default DS.Model.extend({
  NODE_ID: DS.attr(),
  NODE_IDENTIFIER: DS.attr(),
  SYNC_ENABLED: DS.attr('boolean'),
  NODE_DISPLAY_NAME: DS.attr(),
  DIRECTORY_ID: DS.attr(),
  DIRECTORY: DS.belongsTo('directory', {
    inverse: null
  })
});
//ignorei18n_end
