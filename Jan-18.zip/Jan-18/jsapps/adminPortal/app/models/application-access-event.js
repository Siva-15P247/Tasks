import DS from 'ember-data';

export default DS.Model.extend({
  APPLICATION_ID: DS.attr(),
  CLIENT_IP: DS.attr(),
  TIMESTAMP: DS.attr(),
  UNIQUE_ID: DS.attr(),
  USER_AGENT_INFO: DS.attr(),
  USER_ID: DS.attr(),
  USER_NAME: DS.attr(),
  APPLICATION_NAME: DS.attr()
});
