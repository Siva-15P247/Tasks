import DS from 'ember-data';
import Ember from 'ember';

export default DS.Model.extend({
  AUTHORIZATION_URL: DS.attr(),
  STATUS: DS.attr(),
  CODE: Ember.computed.alias('ENCRYPTED_CODE'),//No I18N
  ENCRYPTED_CODE: DS.attr(),
  DIRECTORY_NAME: DS.attr()
});
