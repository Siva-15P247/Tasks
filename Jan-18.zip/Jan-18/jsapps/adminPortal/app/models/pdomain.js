import DS from 'ember-data';
import Ember from 'ember';

export default DS.Model.extend({
  DOMAIN_NAME: DS.attr(),
  CREATED_TIMESTAMP: DS.attr(),
  IS_PRIMARY: DS.attr(),
  IS_VERIFIED: DS.attr(),
  IS_VERIFYING: DS.attr(),
  VERIFICATION_CODE: DS.attr(),
  VERIFICATION_URL: DS.attr(),
  VERIFICATION_BY: DS.attr(),
  VERIFICATION_DATE: DS.attr(),
  VERIFICATION_MODE: DS.attr(),
  IS_VERIFIED_PRIMARY: Ember.computed('IS_PRIMARY','IS_VERIFIED',function () { //No I18N
    return this.get('IS_PRIMARY') && this.get('IS_VERIFIED');
  }),
  CNAME: DS.attr()
});
