import DS from 'ember-data';

export default DS.Model.extend({
  ACTIVE_USERS_FOR_LAST_X_DAYS: DS.attr(),
  INACTIVE_USERS_FOR_LAST_X_DAYS: DS.attr(),
  NEVER_LOGGED_IN_USERS: DS.attr(),
  USERS_WITHOUT_APPLICATIONS: DS.attr(),
  CHARTS: DS.hasMany('dashboard-chart') //No I18N
});
