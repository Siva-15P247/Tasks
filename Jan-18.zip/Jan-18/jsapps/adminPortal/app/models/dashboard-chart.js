import DS from 'ember-data';
import chartModel from 'admin-portal/models/chart'
import Ember from 'ember';

export default chartModel.extend({
  WIDTH: DS.attr(),
  CHART_DISPLAY_NAME: DS.attr(),
  DASHBOARD: DS.belongsTo('dashboard'), //No I18N
  CHART_ID: DS.attr(),
  STYLE_CLASS: DS.attr(),
  ZLM: DS.attr(),
  EFFECTIVE_STYLE_CLASS: Ember.computed('STYLE_CLASS', 'ZLM', function() { //No I18N
    return `${this.get('STYLE_CLASS')} ${this.get('ZLM')?'idmp-pl-0':''}`; //No I18N
  })
});
