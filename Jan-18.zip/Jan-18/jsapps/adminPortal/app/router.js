//ignorei18n_start
import EmberRouter from '@ember/routing/router';
import config from './config/environment';

const Router = EmberRouter.extend({
  location: config.locationType,
  rootURL: config.rootURL
});

Router.map(function() {
  this.route('loading');
  this.route('directorySettings', function() {
    this.route('directory', function() {
      this.route('list');
      this.route('add');
      this.route('activeDirectory', function() {
        this.route('add');
        this.route('select-ous', {
          path: '/select-ous/:directory_id'
        }, function() {
          this.route('verifyObjects');
        });
        this.route('modify', {
          path: '/modify/:directory_id'
        });
      });
      this.route('azureActiveDirectory', function() {
        this.route('add');
        this.route('select-domains', {
          path: '/select-domains/:directory_id'
        }, function() {
          this.route('verifyObjects');
        });
        this.route('modify', {
          path: '/modify/:directory_id'
        });
      });

      this.route('gsuite', function() {
        this.route('add');
        this.route('select-domains', {
          path: '/select-domains/:directory_id'
        }, function() {
          this.route('verifyObjects');
        });
        this.route('modify', {
          path: '/modify/:directory_id'
        });
      });
    });
    this.route('users', function() {
      this.route('list');
      this.route('add');
      this.route('invitedUsers');
    });
    this.route('domains', function() {
      this.route('list');
    });
  });
  this.route('applications', function() {
    this.route('add');
    this.route('list');
  });
  this.route('support');
  this.route('reports', function() {
    this.route('view-report', {
      path: '/view-report/:report_id'
    });
  });
  this.route('dashboard');
  this.route('subscription');
});

export default Router;
//ignorei18n_end
