//ignorei18n_start
module.exports = {
  root: true,
  parserOptions: {
    ecmaVersion: 2017,
    sourceType: 'module'
  },
  extends: 'eslint:recommended',
  env: {
    browser: true
  },
  rules: {
    "comma-dangle": ["error", "never"],
    "dot-notation": ["error"]
  },
  globals: {
    moment: true,
    saveAs: true
  }
};
//ignorei18n_end
