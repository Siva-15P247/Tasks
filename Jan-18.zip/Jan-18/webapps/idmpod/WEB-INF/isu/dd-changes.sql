-----------------------------------------------------------
-- File format :
-- <POSTGRES> Postgres version of diff + comments </Postgres>
-- <MYSQL> Mysql version of diff +comments </MYSQL> --Only if DSAdapter!='saspg'
----------------------------------------------------------

<POSTGRES>
</POSTGRES>
------------------- End -----------------------
