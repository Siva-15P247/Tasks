package local.idmp.utils.isu;

import com.adventnet.persistence.MigrationSqlGenerator;
import local.idmp.utils.git.SSHCredentialProvider;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.transport.CredentialsProvider;

import java.io.File;
import java.nio.file.Files;
import java.util.logging.Logger;

//ignorei18n_start
public class MetaMigrationSqlGenerator
{
	private static final Logger LOGGER = Logger.getLogger(MetaMigrationSqlGenerator.class.getName());
	public static final String REMOTE_URL = "git@git.csez.zohocorpin.com:wsm/idmpod.git";
	public static final String RELATIVE_PATH = File.separator + "product_package" + File.separator + "cloud";

	public static void main(String[] args)
	{
		CredentialsProvider allowHosts = new SSHCredentialProvider();

		try
		{
			File lDir = Files.createTempDirectory(null).toFile();
			File lcDir = Files.createTempDirectory(null).toFile();

			LOGGER.info(lDir.getCanonicalPath());
			LOGGER.info(lcDir.getCanonicalPath());

			File lreqDir = new File(lDir, RELATIVE_PATH);
			File lcreqDir = new File(lcDir, RELATIVE_PATH);

			//			System.out.println(lreqDir.getCanonicalPath());
			//			System.out.println(lcreqDir.getCanonicalPath());

			//			Git localzoho = Git.cloneRepository().setURI(REMOTE_URL).setBranch("88ff8371e1c8fc7591e8efa060baa5ca30de3f51").setDirectory(lDir).setCredentialsProvider(allowHosts).call();
			Git localzoho = Git.cloneRepository().setURI(REMOTE_URL).setDirectory(lDir).setCredentialsProvider(allowHosts).call();
			localzoho.checkout().setCreateBranch(true).setName("lz").setStartPoint("88ff8371e1c8fc7591e8efa060baa5ca30de3f51").call();
			Git lzc = Git.cloneRepository().setURI(REMOTE_URL).setBranch("master").setDirectory(lcDir).setCredentialsProvider(allowHosts).call();

			System.setProperty("skip.sas.modules", "true");
			System.setProperty("generate.datadic.diffs", "true");
			System.setProperty("generate.destructive.changes", "true");
			System.setProperty("generate.preinstall.sqls", "false");
			System.setProperty("app.home", lreqDir.getCanonicalPath());
			System.setProperty("server.dir", lreqDir.getCanonicalPath());

			StringBuilder totaldiff = new StringBuilder("-----------------------------------------------------------\n-- File format :\n-- <POSTGRES> Postgres version of diff + comments </Postgres>\n-- <MYSQL> Mysql version of diff +comments </MYSQL> --Only if DSAdapter!='saspg'\n----------------------------------------------------------");
			StringBuilder postgresdiff = MigrationSqlGenerator.getQueries(new String[]{lreqDir.getCanonicalPath(), lcreqDir.getCanonicalPath(), "com.adventnet.sas.upgrade.isu.ISMPostgresSQLGenerator", "saspg"});
			totaldiff.append("\n\n<POSTGRES>\n").append(postgresdiff).append("</POSTGRES>");

			totaldiff.append("\n------------------- End -----------------------\n");

			LOGGER.info(totaldiff.toString());
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
	}
}
//ignorei18n_end