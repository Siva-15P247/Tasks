package local.idmp.utils.isu;

import com.adventnet.iam.security.SecurityUtil;
import com.manageengine.tables.adsf.ADSIAMAPPLICATIONS;
import com.manageengine.tables.adsf.ADSIAMAPPLICATIONSPROPS;
import local.idmp.utils.git.SSHCredentialProvider;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.transport.CredentialsProvider;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.nio.file.Files;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DataMigrationSqlGenerator
{
	private static final Logger LOGGER = Logger.getLogger(DataMigrationSqlGenerator.class.getName());
	public static final String REMOTE_URL = "git@git.csez.zohocorpin.com:wsm/idmpod.git";
	public static final String RELATIVE_PATH = File.separator + "product_package" + File.separator + "cloud" + File.separator + "conf" + File.separator + "adsf" + File.separator + "IAMApplications.xml";//No I18N

	public static void main(String[] args)
	{
		CredentialsProvider allowHosts = new SSHCredentialProvider();

		try
		{
			File lcDir = Files.createTempDirectory(null).toFile();


			Git lzc = Git.cloneRepository().setURI(REMOTE_URL).setBranch("apps_verification").setDirectory(lcDir).setCredentialsProvider(allowHosts).call();//No I18N

			File lcreqDir = new File(lcDir, RELATIVE_PATH);

			try
			{
				File A = new File("/Users/rakesh-3889/Documents/idmpod/master/idmpod/product_package/cloud/conf/adsf/IAMApplications.xml");
				File B = new File("/Users/rakesh-3889/Documents/idmpod/master/idmpod-docs/resources/Dev/IAMApplications.xml");
				//				File B = new File(lcreqDir.getCanonicalPath());

				String AStr = SecurityUtil.getFileAsString(A);
				String BStr = SecurityUtil.getFileAsString(B);

				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();

				Document docA = builder.parse(new ByteArrayInputStream(AStr.getBytes("UTF-8")));//No I18N
				Document docB = builder.parse(new ByteArrayInputStream(BStr.getBytes("UTF-8")));//No I18N

				XPath xPath = XPathFactory.newInstance().newXPath();

				String appsExp = "/IAMApplications/IAMApplicationsContainer/ADSIAMApplications";//No I18N

				NodeList appsList = (NodeList) xPath.compile(appsExp).evaluate(docA, XPathConstants.NODESET);

				int eqNodeCount = 0;
				int modifiedNodeCount = 0;

				String[] columns = new String[]{ADSIAMAPPLICATIONSPROPS.SUPPORTED_OPERATIONS_BIT, ADSIAMAPPLICATIONSPROPS.CONFIG_BIT, ADSIAMAPPLICATIONSPROPS.APP_TITLE, ADSIAMAPPLICATIONSPROPS.DOMAIN_LABEL, ADSIAMAPPLICATIONSPROPS.CUSTOM_LABEL, ADSIAMAPPLICATIONSPROPS.DEFAULT_LOGIN_URL, ADSIAMAPPLICATIONSPROPS.DEFAULT_LOGOUT_URL, ADSIAMAPPLICATIONSPROPS.APP_WARNING_MSG, ADSIAMAPPLICATIONSPROPS.ATTRIB_REQ_SAML_RESPONSE, ADSIAMAPPLICATIONSPROPS.EXCLUDE_HOSTNAME, ADSIAMAPPLICATIONSPROPS.DEFAULT_ACS_URL, ADSIAMAPPLICATIONSPROPS.DEFAULT_ENTITY_ID, ADSIAMAPPLICATIONSPROPS.SHA_METHOD, ADSIAMAPPLICATIONSPROPS.SIGNED_SAML_RESPONSE, ADSIAMAPPLICATIONSPROPS.ACC_MAPPING_ATTRIBUTE, ADSIAMAPPLICATIONSPROPS.IS_IDP_INITIATED_FLOW};

				StringBuilder resSQL = new StringBuilder("\n");//No I18N

				for (int i = 0; i < appsList.getLength(); i++)
				{
					Node app = appsList.item(i);
					String app_id = app.getAttributes().getNamedItem(ADSIAMAPPLICATIONS.APP_ID).getNodeValue();
					String app_name = app.getAttributes().getNamedItem(ADSIAMAPPLICATIONS.APP_NAME).getNodeValue();

					String appPropExp = "/IAMApplications/IAMAppPropContainer/ADSIAMApplicationsProps[@APP_ID='" + app_id + "']";//No I18N

					XPathExpression xPathExpression = xPath.compile(appPropExp);
					Node oldAppProp = (Node) xPathExpression.evaluate(docA, XPathConstants.NODE);
					Node newAppProp = (Node) xPathExpression.evaluate(docB, XPathConstants.NODE);
					boolean equalNode = oldAppProp.isEqualNode(newAppProp);
					if (equalNode)
					{
						eqNodeCount++;
					}
					else
					{
						modifiedNodeCount++;
						StringBuilder sqlSb = new StringBuilder("UPDATE " + ADSIAMAPPLICATIONSPROPS.TABLE + " SET ");//No I18N
						int updateColCount = 0;
						for (String column : columns)
						{
							Node oldItem = oldAppProp.getAttributes().getNamedItem(column);
							Node newItem = newAppProp.getAttributes().getNamedItem(column);
							String oldValue = oldItem != null ? oldItem.getNodeValue() : null;
							String newValue = newItem != null ? newItem.getNodeValue() : null;
							boolean updateColumn = true;
							if (oldValue == null && newValue == null)
							{
								updateColumn = false;
							}
							else if (oldValue != null && newValue != null && oldValue.equals(newValue))
							{
								updateColumn = false;
							}
							if (updateColumn)
							{
								//LOGGER.info(oldValue + "::" + newValue);
								if (updateColCount > 0)
								{
									sqlSb.append(",");
								}
								sqlSb.append(column + "=" + (newValue != null ? ("'" + newValue + "'") : "null") + " ");
								updateColCount++;
							}
						}
						sqlSb.append("FROM " + ADSIAMAPPLICATIONS.TABLE + " WHERE " + ADSIAMAPPLICATIONS.APP_NAME + "='" + app_name + "' and " + ADSIAMAPPLICATIONSPROPS.TABLE + "." + ADSIAMAPPLICATIONSPROPS.APP_ID + " = " + ADSIAMAPPLICATIONS.TABLE + "." + ADSIAMAPPLICATIONS.APP_ID + "\n");//No I18N
						resSQL.append(sqlSb);
						//Diff SQL construction
					}
				}

				LOGGER.info("Total apps:" + appsList.getLength());
				LOGGER.info("Unchanged apps:" + eqNodeCount);
				LOGGER.info("Modified apps:" + modifiedNodeCount);
				LOGGER.info("Update SQL:" + resSQL.toString());
			}
			catch (Exception e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
	}
}
