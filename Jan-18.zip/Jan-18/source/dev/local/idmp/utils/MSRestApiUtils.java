package local.idmp.utils;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.manageengine.idmpod.server.utils.HttpUtils;
import com.microsoft.aad.adal4j.AuthenticationContext;
import com.microsoft.aad.adal4j.AuthenticationResult;
import com.microsoft.aad.adal4j.ClientCredential;
import com.microsoft.azure.AzureEnvironment;
import com.microsoft.azure.credentials.UserTokenCredentials;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import org.apache.http.client.methods.HttpGet;
import org.json.JSONArray;
import org.json.JSONObject;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.logging.Logger;

public class MSRestApiUtils
{
	private static final Logger LOGGER = Logger.getLogger(MSRestApiUtils.class.getName());
	public static final String CLIENT_ID = "fcf0851e-4315-45c9-9ae3-f63cc75a471b"; // No I18N
	public static final String CLIENT_SECRET = "JcBPjE4wS6LMwiOPcqB5wbKXLPXn+5JkSfaMgmPqa5o="; // No I18N

	public static ClientCredential credential = new ClientCredential(CLIENT_ID, CLIENT_SECRET);

	public static void main(String[] args)
	{
		try
		{
			String baseDomainName = "zohocorpadmgrplus.onmicrosoft.com"; // No I18N
			AzureEnvironment environment = AzureEnvironment.AZURE;
			String graphUrl = environment.graphEndpoint();
			String refreshToken = "AQABAAAAAAC5una0EUFgTIF8ElaxtWjT7UQLBNME98g7q2EQZHjZ5cTqvbbSoWBPGJAYScqOtVfTbSkq2EYQ-VPnF-kwHX7IaxOPjWtpIODeNzrv9E3qlpv9tJtnKY6jQRXr25Pe3HYeGqaFjAsrop-QMITtmbDwyuXG-mxQmb2Yj5geMFOPmXiyUD11yhkg0idn8OykGwZE-GetRHOUo1MclAersaNFbcfeQ65IRl9Ed3YzucpMnvep2lL7a0pd-Ey0ymSWUNeBX0F3wobqB7UjAY0u848i5-gNiqGOdv8tXePUmvsxnP6yT391SB9xYDhxnU5og_VESLVhP8IaJ58mQG9-kj_OTtZfZl-BVDiknlqOPDJvsVbFhxdXePMyYHf0bzjmt1_HiNhLFR_6gIh1kQKPRfD2digVmYtfjjsS1WFbKGSdGVwr3fx0yxXcZ5nsLLTnpdfxdOyD-VUBBSM1aVUWCiw9tMQgYjcpYAHCNkoRQhLuynyl7jlSeJoBGSL0K-d6OSzwVwM2f25R-HhaLFNi8fikPLcKpFjjQWBtq1IRMzwgS7fhldjCJ6xcb2oGWzSe4tJgBy2XPKSwR0WJkiGCitkBcj6XkskIfBfFiED5kVCw6tc0ODSBCKf0VgOiNlkvbM6ThEbYDw399ECU-CVwJM7HQYq79qwkGWf6sNA9AiTKWSH9iPyZJerTV3ccyeQUD2LNrZiFT1JWrEJKapGmB_E5ewQKmAUM1iNuztOczjQnenpJGqD4gGJu-1yyYq9jVSQKJpT19_-PNU8I0EG8JDQC0MntnyDSPCibz6frjO24dSAA"; // No I18N
			AuthenticationContext context = null;
			AuthenticationResult result = null;
			ExecutorService exeService = null;
			exeService = Executors.newFixedThreadPool(1);
			context = new AuthenticationContext(environment.activeDirectoryEndpoint() + baseDomainName, false, exeService);
			Future<AuthenticationResult> future = context.acquireTokenByRefreshToken(refreshToken, credential, null);
			result = future.get();
			exeService.shutdown();

			String urlString = graphUrl + baseDomainName + "/domains/" + "?api-version=1.6";//No I18N
			HttpGet hg = new HttpGet(urlString);
			hg.setHeader("Authorization", result.getAccessTokenType() + " " + result.getAccessToken()); // No I18N
			hg.setHeader("Accept", "application/json"); // No I18N
			hg.setHeader("Content-Type", "application/json"); // No I18N

			HttpUtils.HttpResult httpResponse = HttpUtils.getHttpResponse(hg);
			//			System.out.println(httpResponse.toString());

			JsonParser parser = new JsonParser();
			JsonObject appResponse = parser.parse(httpResponse.getContent()).getAsJsonObject();
			JSONObject oresponse = new JSONObject(appResponse.toString());
			JSONArray domains = oresponse.getJSONArray("value");//No I18N

			//			System.out.println(domains.toString(4));

		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
	}

	public static Map<String, List<String>> splitQuery(URL url) throws UnsupportedEncodingException
	{
		final Map<String, List<String>> query_pairs = new LinkedHashMap<String, List<String>>();
		final String[] pairs = url.getQuery().split("&");
		for (String pair : pairs)
		{
			final int idx = pair.indexOf("=");
			final String key = idx > 0 ? URLDecoder.decode(pair.substring(0, idx), "UTF-8") : pair;
			if (!query_pairs.containsKey(key))
			{
				query_pairs.put(key, new LinkedList<String>());
			}
			final String value = idx > 0 && pair.length() > idx + 1 ? URLDecoder.decode(pair.substring(idx + 1), "UTF-8") : null;
			query_pairs.get(key).add(value);
		}
		return query_pairs;
	}

	private static void getUsers() throws Exception
	{
		try
		{
			//			String userName = "o365team@zohocorpadmgrplus.onmicrosoft.com";
			//			String password = "Office@365";
			String userName = "ompteam@zohowsmomp.onmicrosoft.com";
			String password = "Office@365";

			String baseDN = userName.substring(userName.indexOf('@') + 1);

			AzureEnvironment environment = AzureEnvironment.AZURE;//No I18N

			UserTokenCredentials userTokenCredentials = new UserTokenCredentials("1950a258-227b-4e31-a9cf-717495945fc2", baseDN, userName, password, environment);// No I18N

			String graphEndpoint = environment.graphEndpoint();

			URL baseURL = new URL(graphEndpoint + baseDN + "/");

			String urlString = graphEndpoint + baseDN + "/users/";

			String authToken = userTokenCredentials.getToken(graphEndpoint);

			Map<String, String> headers = new HashMap<>();
			headers.put("authorization", "Bearer " + authToken);
			headers.put("Accept", "application/json");
			headers.put("Content-Type", "application/json");

			OkHttpClient httpClient = new OkHttpClient().newBuilder().build();
			Retrofit retrofit = new Retrofit.Builder().baseUrl(urlString).client(httpClient).addCallAdapterFactory(RxJavaCallAdapterFactory.create()).addConverterFactory(GsonConverterFactory.create()).build();
			MSRestApiInterface service = retrofit.create(MSRestApiInterface.class);
			String skipToken = null;
			String deltaToken = null;
			JsonParser parser = new JsonParser();
			long count = 0l;

			long startTime = System.currentTimeMillis();

			do
			{
				Map<String, String> query = new HashMap<>();
				query.put("api-version", "1.6");
				if (skipToken != null)
				{
					query.put("$skiptoken", skipToken);
				}
				Call<ResponseBody> call3 = service.getRawjson(urlString, query, headers);
				Response<ResponseBody> response = call3.execute();

				System.out.println(response.code());
				if (response.code() == 200)
				{
					JsonObject appResponse = parser.parse(response.body().string()).getAsJsonObject();
					JSONObject respObj = new JSONObject(appResponse.toString());
					if (respObj.has("odata.nextLink"))
					{
						URL nextUrl = new URL(baseURL, respObj.getString("odata.nextLink"));
						skipToken = splitQuery(nextUrl).get("$skiptoken").get(0);
					}
					else
					{
						skipToken = null;
					}
					JSONArray users = respObj.getJSONArray("value");
					for (int i = 0; i < users.length(); i++)
					{
						JSONObject user = users.getJSONObject(i);
						count++;
					}
					System.out.println(respObj.toString(4));
				}
			} while (skipToken != null);
			long endTime = System.currentTimeMillis();

			System.out.println("Count:" + count);
			System.out.println("Start:" + startTime);
			System.out.println("End:" + endTime);
		}
		catch (IOException ioe)
		{
			System.out.println(getRootCause(ioe).getMessage());
		}

	}

	public static Throwable getRootCause(Throwable e)
	{
		if (e.getCause() == null)
		{
			return e;
		}
		else
		{
			return getRootCause(e.getCause());
		}
	}

	public static void getDomains() throws Exception
	{
		String userName = "o365team@zohocorpadmgrplus.onmicrosoft.com";
		String password = "Office@365";
		UserTokenCredentials userTokenCredentials;

		AzureEnvironment environment = AzureEnvironment.AZURE;//No I18N


		userTokenCredentials = new UserTokenCredentials("1950a258-227b-4e31-a9cf-717495945fc2", "zohocorpadmgrplus.onmicrosoft.com", userName, password, environment);// No I18N

		String graphEndpoint = environment.graphEndpoint();

		String urlString = graphEndpoint + "zohocorpadmgrplus.onmicrosoft.com" + "/domains/";

		String authToken = userTokenCredentials.getToken(graphEndpoint);

		Map<String, String> headers = new HashMap<>();
		headers.put("authorization", "Bearer " + authToken);
		headers.put("Accept", "application/json");
		headers.put("Content-Type", "application/json");

		OkHttpClient httpClient = new OkHttpClient().newBuilder().build();
		Retrofit retrofit = new Retrofit.Builder().baseUrl(urlString).client(httpClient).addCallAdapterFactory(RxJavaCallAdapterFactory.create()).addConverterFactory(GsonConverterFactory.create()).build();
		MSRestApiInterface service = retrofit.create(MSRestApiInterface.class);
		Map<String, String> query = new HashMap<>();
		query.put("api-version", "1.6");
		Call<ResponseBody> call3 = service.getRawjson(urlString, query, headers);
		Response<ResponseBody> response = call3.execute();

		System.out.println(response.code());
		if (response.code() == 200)
		{
			JsonParser parser = new JsonParser();
			JsonObject appResponse = parser.parse(response.body().string()).getAsJsonObject();
			JSONObject oresponse = new JSONObject(appResponse.toString());
			JSONArray domains = oresponse.getJSONArray("value");
			for (int i = 0; i < domains.length(); i++)
			{
				JSONObject domain = domains.getJSONObject(i);
				if (domain.getBoolean("isVerified"))
				{
					System.out.println(domain.toString(4));
				}
			}
		}
	}
}
