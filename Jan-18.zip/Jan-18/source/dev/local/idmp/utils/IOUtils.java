package local.idmp.utils;

import java.io.BufferedInputStream;
import java.util.Scanner;

public class IOUtils {
    public static String getInput()
    {
        /*
         * System.out.println("Input:\n"); String input = ""; Scanner stdin =
         * new Scanner(new BufferedInputStream(System.in));
         * System.out.println(); while (stdin.hasNext()) { String nextLine =
         * stdin.nextLine(); if (nextLine.equalsIgnoreCase(".")) {
         * stdin.close(); break; }
         *
         * input = input + "\n" + nextLine; }
         * System.out.println("Sucessfully read input.");
         */
        return getInputs(1)[0];
    }

    public static String[] getInputs(int l)
    {
        Scanner stdin = new Scanner(new BufferedInputStream(System.in));
        String[] inputs = new String[l];
        for (int i = 0; i < l; i++)
        {
            String input = "";

            while (stdin.hasNext())
            {
                String nextLine = stdin.nextLine();
                if (nextLine.equalsIgnoreCase("."))
                {
                    break;
                }

                input = input + "\n" + nextLine;//NO I18N
            }
            inputs[i] = input;
        }
        stdin.close();
        return inputs;
    }
}
