package local.idmp.utils;

import com.manageengine.idmpod.server.iam.samlapps.SamlAppsHandler;
import com.manageengine.idmpod.server.iam.samlapps.SamlMetaDataUtil;
import org.apache.commons.codec.binary.Base64;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.opensaml.DefaultBootstrap;
import org.opensaml.common.xml.SAMLConstants;
import org.opensaml.saml2.metadata.*;
import org.opensaml.saml2.metadata.provider.DOMMetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.parse.BasicParserPool;
import org.opensaml.xml.security.credential.UsageType;
import org.opensaml.xml.security.keyinfo.KeyInfoHelper;
import org.opensaml.xml.signature.X509Certificate;
import org.opensaml.xml.signature.X509Data;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.*;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.adventnet.iam.security.SecurityUtil.getFileAsString;

//ignorei18n_start
public class XMLUtils
{
	private static final Logger LOGGER = Logger.getLogger(XMLUtils.class.getName());

	public static void main(String args[])
	{
		try
		{
			DefaultBootstrap.bootstrap();
		}
		catch (ConfigurationException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		try
		{
			compareDuplicateApps();
			//identifyDupicateApps();
			//removeDuplicateApps();
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
	}

	private static void compareDuplicateApps() throws IOException, SAXException, ParserConfigurationException, XPathExpressionException
	{
		String filePath = "/Users/rakesh-3889/Documents/idmpod/master/idmpod/product_package/cloud/conf/adsf/IAMApplications.xml";

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(new File(filePath));

		XPath xPath = XPathFactory.newInstance().newXPath();

		List<String[]> appNames = new ArrayList<>();

		appNames.add(new String[]{"15five"});
		appNames.add(new String[]{"aha"});
		appNames.add(new String[]{"bime"});
		appNames.add(new String[]{"bonusly"});
		appNames.add(new String[]{"clarizen"});
		appNames.add(new String[]{"concur"});
		appNames.add(new String[]{"domo"});
		appNames.add(new String[]{"evernote"});
		appNames.add(new String[]{"flatter_files"});
		appNames.add(new String[]{"fresh_desk"});
		appNames.add(new String[]{"fresh_service"});
		appNames.add(new String[]{"hosted_graphite"});
		appNames.add(new String[]{"knowledgeowl"});
		appNames.add(new String[]{"mango_apps"});
		appNames.add(new String[]{"netsuite"});
		appNames.add(new String[]{"new_relic"});
		appNames.add(new String[]{"park_my_cloud"});
		appNames.add(new String[]{"pingboard"});
		appNames.add(new String[]{"prodpad"});
		appNames.add(new String[]{"purelyhr"});
		appNames.add(new String[]{"quandora"});
		appNames.add(new String[]{"rollbar"});
		appNames.add(new String[]{"samanage"});
		appNames.add(new String[]{"slack"});
		appNames.add(new String[]{"spotinst"});
		appNames.add(new String[]{"status_cast"});
		appNames.add(new String[]{"sugarcrm"});
		appNames.add(new String[]{"sumologic"});
		appNames.add(new String[]{"syncplicity"});
		appNames.add(new String[]{"thousand_eyes"});
		appNames.add(new String[]{"trello"});
		appNames.add(new String[]{"weekdone"});
		appNames.add(new String[]{"workday"});
		appNames.add(new String[]{"canvas_lms", "instructure"});
		appNames.add(new String[]{"citrix_sharefile", "sharefile"});
		appNames.add(new String[]{"egynte", "egnyte"});
		appNames.add(new String[]{"gotomeeting", "gotoassist"});
		appNames.add(new String[]{"honeyis", "honey"});
		appNames.add(new String[]{"people", "peopleweb"});
		appNames.add(new String[]{"proxy_click", "proxyclick"});
		appNames.add(new String[]{"robin", "robinpowered"});
		appNames.add(new String[]{"screensteps", "screensteps-live"});
		appNames.add(new String[]{"tableau", "tableau_server"});
		appNames.add(new String[]{"target_process", "tpondemand"});
		appNames.add(new String[]{"small-improvements", "small_improvements"});

		for (String[] appNamec : appNames)
		{
			StringBuilder xExpBuilder = new StringBuilder("");
			StringBuilder predicateB = new StringBuilder("[");

			predicateB.append("@APP_NAME=\"");
			predicateB.append(appNamec[0]);
			predicateB.append("\"");

			//Alternate names(w/o _)
			if (appNamec[0].contains("_"))
			{
				String altAppName = appNamec[0].replaceAll("_", "");
				predicateB.append(" or ");
				predicateB.append("@APP_NAME=\"");
				predicateB.append(altAppName);
				predicateB.append("\"");
			}

			//Alternate name - manual
			if (appNamec.length > 1)
			{
				predicateB.append(" or ");
				predicateB.append("@APP_NAME=\"");
				predicateB.append(appNamec[1]);
				predicateB.append("\"");
			}

			predicateB.append("]");
			xExpBuilder.append("/IAMApplications/IAMApplicationsContainer/ADSIAMApplications");
			xExpBuilder.append(predicateB.toString());

			//System.out.println(xExpBuilder.toString());

			NodeList nodeList = (NodeList) xPath.compile(xExpBuilder.toString()).evaluate(doc, XPathConstants.NODESET);

			System.out.println("- APP_NAME:" + appNamec[0]);
			int nodeListLength = nodeList.getLength();
			if (nodeListLength == 0)
			{
				System.err.println("No apps found for Name: " + appNamec[0]);
			}
			else if (nodeListLength == 1)
			{
				System.err.println("Need manual id of duplicate: " + appNamec[0]);
			}
			else
			{
				Node aNode = nodeList.item(0);
				Element aNodeEl = (Element) aNode;

				String aAppId = aNodeEl.getAttribute("APP_ID");

				Node bNode = nodeList.item(1);
				Element bNodeEl = (Element) bNode;

				String bAppId = bNodeEl.getAttribute("APP_ID");
				System.out.println("- " + aAppId + " vs " + bAppId);
			}
			System.out.println();
			System.out.println();
		}
	}

	private static void identifyDupicateApps() throws IOException, SAXException, ParserConfigurationException, XPathExpressionException
	{
		String filePath = "/Users/rakesh-3889/Documents/idmpod/master/idmpod/product_package/cloud/conf/adsf/IAMApplications.xml";

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(new File(filePath));

		XPath xPath = XPathFactory.newInstance().newXPath();

		List<String> suspectedAppNames = new ArrayList<String>();

		suspectedAppNames.add("15five");
		suspectedAppNames.add("aha");
		suspectedAppNames.add("bime");
		suspectedAppNames.add("bonusly");
		suspectedAppNames.add("canvas_lms");
		suspectedAppNames.add("citrix_sharefile");
		suspectedAppNames.add("clarizen");
		suspectedAppNames.add("concur");
		suspectedAppNames.add("domo");
		suspectedAppNames.add("egynte");
		suspectedAppNames.add("evernote");
		suspectedAppNames.add("flatter_files");
		suspectedAppNames.add("fresh_desk");
		suspectedAppNames.add("fresh_service");
		suspectedAppNames.add("gotomeeting");
		suspectedAppNames.add("honeyis");
		suspectedAppNames.add("hosted_graphite");
		suspectedAppNames.add("knowledgeowl");
		suspectedAppNames.add("mango_apps");
		suspectedAppNames.add("netsuite");
		suspectedAppNames.add("new_relic");
		suspectedAppNames.add("park_my_cloud");
		suspectedAppNames.add("people");
		suspectedAppNames.add("pingboard");
		suspectedAppNames.add("prodpad");
		suspectedAppNames.add("proxyclick");
		suspectedAppNames.add("purelyhr");
		suspectedAppNames.add("quandora");
		suspectedAppNames.add("robin");
		suspectedAppNames.add("rollbar");
		suspectedAppNames.add("samanage");
		suspectedAppNames.add("screensteps");
		suspectedAppNames.add("slack");
		suspectedAppNames.add("small_impprovements");
		suspectedAppNames.add("spotinst");
		suspectedAppNames.add("status_cast");
		suspectedAppNames.add("sugarcrm");
		suspectedAppNames.add("sumologic");
		suspectedAppNames.add("syncplicity");
		suspectedAppNames.add("tableau");
		suspectedAppNames.add("target_process");
		suspectedAppNames.add("thousand_eyes");
		suspectedAppNames.add("trello");
		suspectedAppNames.add("user_echo");
		suspectedAppNames.add("weekdone");
		suspectedAppNames.add("workday");


		for (String appName : suspectedAppNames)
		{
			StringBuilder xExpBuilder = new StringBuilder("");
			StringBuilder predicateB = new StringBuilder("[");

			predicateB.append("@APP_NAME=\"");
			predicateB.append(appName);
			predicateB.append("\"");

			//Alternate names(w/o _)
			if (appName.contains("_"))
			{
				String altAppName = appName.replaceAll("_", "");
				predicateB.append(" or ");
				predicateB.append("@APP_NAME=\"");
				predicateB.append(altAppName);
				predicateB.append("\"");
			}

			predicateB.append("]");
			xExpBuilder.append("/IAMApplications/IAMApplicationsContainer/ADSIAMApplications");
			xExpBuilder.append(predicateB.toString());

			//System.out.println(xExpBuilder.toString());

			NodeList nodeList = (NodeList) xPath.compile(xExpBuilder.toString()).evaluate(doc, XPathConstants.NODESET);

			System.out.println("APP_NAME:" + appName);
			int nodeListLength = nodeList.getLength();
			System.out.println(nodeListLength);
			if (nodeListLength == 0)
			{
				System.err.println("No apps found for Name: " + appName);
			}
			else if (nodeListLength == 1)
			{
				System.err.println("Need manual id of duplicate: " + appName);
			}
			else
			{
				System.out.println("Duplicates successfully ided: " + appName);
			}
			System.out.println();
		}


	}

	private static void removeDuplicateApps() throws ParserConfigurationException, IOException, SAXException, XPathExpressionException
	{
		String filePath = "/Users/rakesh-3889/Documents/idmpod/master/idmpod/product_package/cloud/conf/adsf/IAMApplications.xml";

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(new File(filePath));

		List<String> ids = new ArrayList<String>();

		ids.add("ADSIAMApplications:APP_ID:441");//15five
		ids.add("ADSIAMApplications:APP_ID:452");//aha
		ids.add("ADSIAMApplications:APP_ID:471");//bime
		ids.add("ADSIAMApplications:APP_ID:475");//bonusly
		ids.add("ADSIAMApplications:APP_ID:175");//canvas_lms
		ids.add("ADSIAMApplications:APP_ID:186");//citrix_sharefile
		ids.add("ADSIAMApplications:APP_ID:187");//Clarizen
		ids.add("ADSIAMApplications:APP_ID:490");//Concur
		ids.add("ADSIAMApplications:APP_ID:499");//Domo
		ids.add("ADSIAMApplications:APP_ID:502");//Egynte
		ids.add("ADSIAMApplications:APP_ID:506");//evernote
		ids.add("ADSIAMApplications:APP_ID:436");//flatter_files
		ids.add("ADSIAMApplications:APP_ID:432");//fresh_desk
		ids.add("ADSIAMApplications:APP_ID:431");//fresh_service
		ids.add("ADSIAMApplications:APP_ID:214");//gotomeeting
		ids.add("ADSIAMApplications:APP_ID:141");//honey.is
		ids.add("ADSIAMApplications:APP_ID:218");//hosted_graphite
		ids.add("ADSIAMApplications:APP_ID:243");//knowledgeowl
		ids.add("ADSIAMApplications:APP_ID:402");//mango_apps
		ids.add("ADSIAMApplications:APP_ID:262");//netsuite
		ids.add("ADSIAMApplications:APP_ID:392");//new_relic
		ids.add("ADSIAMApplications:APP_ID:386");//park_my_cloud
		ids.add("ADSIAMApplications:APP_ID:275");//people
		ids.add("ADSIAMApplications:APP_ID:277");//pingboard
		ids.add("ADSIAMApplications:APP_ID:382");//prodpad
		ids.add("ADSIAMApplications:APP_ID:281");//proxyclick
		ids.add("ADSIAMApplications:APP_ID:282");//purelyhr
		ids.add("ADSIAMApplications:APP_ID:380");//quandora
		ids.add("ADSIAMApplications:APP_ID:376");//robin
		ids.add("ADSIAMApplications:APP_ID:375");//rollbar
		ids.add("ADSIAMApplications:APP_ID:371");//samanage
		ids.add("ADSIAMApplications:APP_ID:370");//screensteps
		ids.add("ADSIAMApplications:APP_ID:360");//slack
		ids.add("ADSIAMApplications:APP_ID:358");//small_impprovements
		ids.add("ADSIAMApplications:APP_ID:355");//spotinst
		ids.add("ADSIAMApplications:APP_ID:351");//status_cast
		ids.add("ADSIAMApplications:APP_ID:350");//sugarcrm
		ids.add("ADSIAMApplications:APP_ID:349");//sumologic
		ids.add("ADSIAMApplications:APP_ID:346");//syncplicity
		ids.add("ADSIAMApplications:APP_ID:317");//tableau
		ids.add("ADSIAMApplications:APP_ID:345");//target_process
		ids.add("ADSIAMApplications:APP_ID:343");//thousand_eyes
		ids.add("ADSIAMApplications:APP_ID:323");//trello
		ids.add("ADSIAMApplications:APP_ID:340");//user_echo
		ids.add("ADSIAMApplications:APP_ID:331");//weekdone
		ids.add("ADSIAMApplications:APP_ID:333");//workday


		removeAppsById(doc, ids);
	}

	private static void removeAppsByDisplayName() throws ParserConfigurationException, IOException, SAXException, XPathExpressionException
	{
		String filePath = "/Users/rakesh-3889/Documents/idmpod/master/idmpod/product_package/cloud/conf/adsf/IAMApplications.xml";

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder.parse(new File(filePath));

		List<String> appDispNames = new ArrayList<String>();

		appDispNames.add("idmp.applications.template.confluence_saml_sso_by_microsoft.name");
		appDispNames.add("idmp.applications.template.jira_saml_sso_by_microsoft.name");
		appDispNames.add("idmp.applications.template.kantega_sso_for_bamboo.name");
		appDispNames.add("idmp.applications.template.kantega_sso_for_bitbucket.name");
		appDispNames.add("idmp.applications.template.kantega_sso_for_confluence.name");
		appDispNames.add("idmp.applications.template.kantega_sso_for_fisheye.name");
		appDispNames.add("idmp.applications.template.kantega_sso_for_jira.name");
		appDispNames.add("idmp.applications.template.saml_sso_for_bamboo_by_resolution_gmbh.name");
		appDispNames.add("idmp.applications.template.saml_sso_for_bitbucket_by_resolution_gmbh.name");
		appDispNames.add("idmp.applications.template.saml_sso_for_confluence_by_resolution_gmbh.name");
		appDispNames.add("idmp.applications.template.saml_sso_for_jira_by_resolution_gmbh.name");

		//Step 1: Get app ids fpr the appDispNames
		List<String> ids = getAppIdsByDispNames(doc, appDispNames);

		//Step 2: Find all entries related to the appids
		removeAppsById(doc, ids);
	}

	private static void removeAppsById(Document doc, List<String> ids) throws XPathExpressionException
	{
		XPath xPath = XPathFactory.newInstance().newXPath();

		StringBuilder xExpBuilder = new StringBuilder("");

		StringBuilder predicateB = new StringBuilder("[");
		boolean first = true;
		for (String id : ids)
		{
			if (!first)
			{
				predicateB.append(" or ");
			}
			predicateB.append("@APP_ID=\"");
			predicateB.append(id);
			predicateB.append("\"");

			if (first)
			{
				first = false;
			}
		}
		predicateB.append("]");

		xExpBuilder.append("/IAMApplications/IAMApplicationsContainer/ADSIAMApplications");
		xExpBuilder.append(predicateB.toString());
		xExpBuilder.append(" | ");
		xExpBuilder.append("/IAMApplications/IAMAPIsContainer/ADSIAMAppAPIs");
		xExpBuilder.append(predicateB.toString());
		xExpBuilder.append(" | ");
		xExpBuilder.append("/IAMApplications/IAMAppPropContainer/ADSIAMApplicationsProps");
		xExpBuilder.append(predicateB.toString());

		//System.out.println(xExpBuilder.toString());

		NodeList nodeList = (NodeList) xPath.compile(xExpBuilder.toString()).evaluate(doc, XPathConstants.NODESET);

		for (int i = 0; i < nodeList.getLength(); i++)
		{
			Node nNode = nodeList.item(i);
			Element nodeEl = (Element) nNode;

			//String appId = nodeEl.getAttribute("APP_ID");

			doc.getElementsByTagName(nNode.getParentNode().getNodeName()).item(0).removeChild(nNode);
			//System.out.println(nodeEl.getTagName());
		}
		//System.out.println(getStringFromDocument(doc));
	}

	private static List<String> getAppIdsByDispNames(Document doc, List<String> appDispNames) throws XPathExpressionException
	{
		List<String> appids = new ArrayList<String>();
		XPath xPath = XPathFactory.newInstance().newXPath();

		String srcRowsExp = "/IAMApplications/IAMApplicationsContainer/ADSIAMApplications";

		StringBuilder predicateB = new StringBuilder("[");
		boolean first = true;
		for (String appDispName : appDispNames)
		{
			if (!first)
			{
				predicateB.append(" or ");
			}
			predicateB.append("@DISPLAY_NAME=\"");
			predicateB.append(appDispName);
			predicateB.append("\"");

			if (first)
			{
				first = false;
			}
		}
		predicateB.append("]");

		srcRowsExp = srcRowsExp + predicateB.toString();

		//System.out.println(srcRowsExp);

		NodeList nodeList = (NodeList) xPath.compile(srcRowsExp).evaluate(doc, XPathConstants.NODESET);

		for (int i = 0; i < nodeList.getLength(); i++)
		{
			Node nNode = nodeList.item(i);
			Element nodeEl = (Element) nNode;

			String appId = nodeEl.getAttribute("APP_ID");
			appids.add(appId);
			//System.out.println(appId);
		}

		return appids;
	}

	public static JSONObject parseSPMetadataFile(String file) throws JSONException
	{
		if (file == null)
		{
			return null;
		}
		JSONObject json = new JSONObject();
		DOMMetadataProvider spMetaDataProvider = null;
		String acs_url = null;
		String logout_url = null;
		String certString = null;
		String nameId = null;

		try
		{
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			documentBuilderFactory.setNamespaceAware(true);
			Document doc = documentBuilderFactory.newDocumentBuilder().parse(new InputSource(new StringReader(file)));


			//			DocumentBuilder builder = SecurityUtil.getDocumentBuilder(false, false);
			//			Document doc = builder.parse(new InputSource(new StringReader(file)));

			Element docElement = doc.getDocumentElement();

			spMetaDataProvider = new DOMMetadataProvider(docElement);
			spMetaDataProvider.setRequireValidMetadata(true); //Enable validation
			spMetaDataProvider.setParserPool(new BasicParserPool());
			spMetaDataProvider.initialize();

			String entityId = docElement.getAttribute("entityID"); // NO I18N

			EntityDescriptor entityDescriptor = spMetaDataProvider.getEntityDescriptor(entityId);
			SPSSODescriptor descriptor = entityDescriptor.getSPSSODescriptor(SAMLConstants.SAML20P_NS);
			if (descriptor == null)
			{
				return null;
			}
			nameId = "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress"; // NO I18N
			if (!descriptor.getNameIDFormats().isEmpty())
			{
				descriptor.getNameIDFormats().get(0).getFormat();
			}

			if (descriptor.getSingleLogoutServices().size() > 0)
			{
				logout_url = descriptor.getSingleLogoutServices().get(0).getLocation();
			}

			if (!descriptor.getAssertionConsumerServices().isEmpty())
			{
				for (AssertionConsumerService acs : descriptor.getAssertionConsumerServices())
				{
					if (acs.getBinding().equals(SAMLConstants.SAML2_POST_BINDING_URI))
					{
						acs_url = acs.getLocation();
					}
				}
			}

			java.util.List<KeyDescriptor> keyDescriptors = descriptor.getKeyDescriptors();
			KeyDescriptor keyDesc = null;

			for (KeyDescriptor kd : keyDescriptors)
			{
				if (kd.getUse() == UsageType.SIGNING)
				{
					keyDesc = kd;
					break;
				}
			}

			if (keyDesc != null)
			{
				X509Data x509Data = (X509Data) keyDesc.getKeyInfo().getX509Datas().get(0);
				X509Certificate certificate = (X509Certificate) x509Data.getX509Certificates().get(0);
				java.security.cert.X509Certificate cert = KeyInfoHelper.getCertificate(certificate);
				certString = convertToPem(cert);
			}

			List<AttributeConsumingService> atrCS = descriptor.getAttributeConsumingServices();
			if (!atrCS.isEmpty())
			{
				JSONArray jsonAttr = new JSONArray();
				AttributeConsumingService atcs = atrCS.get(0);
				List<RequestedAttribute> attrs = atcs.getRequestAttributes();
				for (RequestedAttribute attribute : attrs)
				{
					String name = attribute.getName();
					if (SamlMetaDataUtil.NameIDType.getNameIdType(name) != null)
					{
						JSONObject obj = new JSONObject();
						obj.put("name", attribute.getFriendlyName()); //No I18N
						obj.put("value", name); //No I18N
						jsonAttr.put(obj);
					}
				}
				json.put("ATTRIBUTES", jsonAttr); //No I18N
			}
			json.put("ACS_URL", acs_url); //No I18N
			json.put("LOGOUT_URL", logout_url); //No I18N
			json.put("PUBLIC_KEY", certString); //No I18N
			json.put("ISSUER", entityId); //No I18N
			//json.put(APIConstants.OPSTATUS, APIConstants.SUCCESS);
			json.put("NAMEID", SamlAppsHandler.NameId.NAMEID_EMAIL_ADDRESS.getStringConstant());
		}
		catch (CertificateException ex)
		{
			LOGGER.log(Level.SEVERE, null, ex);
		}
		catch (SAXException ex)
		{
			LOGGER.log(Level.SEVERE, null, ex);
		}
		catch (IOException ex)
		{
			LOGGER.log(Level.SEVERE, null, ex);
		}
		catch (MetadataProviderException mepe)
		{
			LOGGER.log(Level.SEVERE, "Exception while saving metadata to db", mepe);
		}
		catch (ParserConfigurationException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		finally
		{
			if (spMetaDataProvider != null)
			{
				spMetaDataProvider.destroy();
			}
		}
		return json;
	}

	/**
	 * Convert an X509 certification to pem encoded string
	 *
	 * @param x509cert
	 * @return
	 * @throws CertificateEncodingException
	 */
	protected static String convertToPem(java.security.cert.X509Certificate x509cert) throws CertificateEncodingException
	{
		Base64 encoder = new Base64(64);
		String cert_begin = "-----BEGIN CERTIFICATE-----\n";// NO I18N
		String end_cert = "-----END CERTIFICATE-----"; // NO I18N
		byte[] derCert = x509cert.getEncoded();
		String pemCertPre = new String(encoder.encode(derCert));
		String pemCert = cert_begin + pemCertPre + end_cert;
		return pemCert;
	}

	private static void addSeqColumn() throws IOException, ParserConfigurationException, SAXException, XPathExpressionException
	{
		String srcConfFilePath = "/Users/rakesh-3889/Documents/idmpod/master/idmpod/product_package/cloud/conf/adsf/IAMApplications.xml";

		File srcConfFile = new File(srcConfFilePath);

		String srcConfXML = getFileAsString(srcConfFile);

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();

		Document doc = builder.parse(new ByteArrayInputStream(srcConfXML.getBytes("UTF-8")));

		XPath xPath = XPathFactory.newInstance().newXPath();

		String srcRowsExp = "/IAMApplications/IAMAppPropContainer/ADSIAMApplicationsProps";
		NodeList nodeList = (NodeList) xPath.compile(srcRowsExp).evaluate(doc, XPathConstants.NODESET);

		int count = 1;
		for (int i = 0; i < nodeList.getLength(); i++)
		{
			Node nNode = nodeList.item(i);
			Element destNodeEl = (Element) nNode;

			destNodeEl.setAttribute("APP_PROP_ID", "ADSIAMApplicationsProps:APP_PROP_ID:" + count);
			count++;
		}
		//System.out.println(getStringFromDocument(doc));

		//storeStringAsFile(srcConfXML, srcConfFilePath + "_tmpA");
	}

	private static void convertDDtoDD(String designDef)
	{
		String tableName = null;
		String pkColumn = null;
		String[] lines = designDef.split("\n");

		String tableNameRegex = "#+ (\\w+)";
		Pattern tableNamePattern = Pattern.compile(tableNameRegex);

		String columnDetRegex = "- (\\w+) (\\w+)";
		Pattern columnDetPattern = Pattern.compile(columnDetRegex);

		StringBuffer dictDef = new StringBuffer("<table name=\"");

		for (String line : lines)
		{
			if (line.trim().length() > 0)
			{
				if (tableName == null)
				{
					Matcher tableNameMatcher = tableNamePattern.matcher(line);
					if (tableNameMatcher.matches())
					{
						tableName = tableNameMatcher.group(1);
						dictDef = dictDef.append(tableName).append("\">\n");
						dictDef = dictDef.append("<columns>\n");
					}
				}
				else
				{
					Matcher columnDetMatcher = columnDetPattern.matcher(line);
					if (columnDetMatcher.matches())
					{
						String colName = columnDetMatcher.group(1).trim();
						String colDataType = columnDetMatcher.group(2).trim();

						dictDef = dictDef.append("<column name=\"").append(colName).append("\">\n");
						dictDef = dictDef.append("<data-type>").append(colDataType).append("</data-type>\n");

						if (pkColumn == null && colDataType.equalsIgnoreCase("BIGINT"))
						{
							pkColumn = colName;
							dictDef = dictDef.append("<uniquevalue-generation>\n");
							dictDef = dictDef.append("<generator-name>").append(tableName).append(".").append(colName).append("</generator-name>\n");
							dictDef = dictDef.append("</uniquevalue-generation>\n");
						}
						else
						{
							if (colDataType.equalsIgnoreCase("CHAR"))
							{
								dictDef = dictDef.append("<max-size>200</max-size>");
							}
						}
						dictDef = dictDef.append("</column>\n");
					}
				}
			}
		}
		dictDef = dictDef.append("</columns>\n");

		dictDef = dictDef.append("<primary-key name=\"").append(tableName).append("_PK\">\n");
		dictDef = dictDef.append("<primary-key-column>").append(pkColumn).append("</primary-key-column>\n");
		dictDef = dictDef.append("</primary-key>\n");

		dictDef = dictDef.append("</table>\n");
	}

	private static void moveColumnConf() throws IOException, ParserConfigurationException, SAXException, XPathExpressionException
	{
		String srcTable = "ADSIAMApplicationsProps";
		String destTable = "ADSIAMApplications";
		String srcMapCol = "APP_ID";
		String destMapCol = "APP_ID";
		String[] srcCols = {"CATEGORY_ID"};
		String[] destCols = {"CATEGORY_ID"};
		String srcConfFilePath = "/Users/rakesh-3889/Documents/idmpod/master/idmpod/product_package/cloud/conf/adsf/IAMApplications.xml";

		File srcConfFile = new File(srcConfFilePath);

		String srcConfXML = getFileAsString(srcConfFile);

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();

		Document doc = builder.parse(new ByteArrayInputStream(srcConfXML.getBytes("UTF-8")));

		XPath xPath = XPathFactory.newInstance().newXPath();

		String srcRowsExp = "/IAMApplications/IAMAppPropContainer/ADSIAMApplicationsProps";
		NodeList nodeList = (NodeList) xPath.compile(srcRowsExp).evaluate(doc, XPathConstants.NODESET);
		for (int i = 0; i < nodeList.getLength(); i++)
		{
			Node nNode = nodeList.item(i);
			String id = nNode.getAttributes().getNamedItem(srcMapCol).getNodeValue();
			String colValue = nNode.getAttributes().getNamedItem("CATEGORY_ID") != null ? nNode.getAttributes().getNamedItem("CATEGORY_ID").getNodeValue() : null;
			//System.out.println(id + "," + colValue);
			String destRowExp = "/IAMApplications/IAMApplicationsContainer/ADSIAMApplications[@APP_ID='" + id + "']";
			NodeList destNodeList = (NodeList) xPath.compile(destRowExp).evaluate(doc, XPathConstants.NODESET);
			Node destNode = destNodeList.item(0);
			Element destNodeEl = (Element) destNode;
			if (colValue != null)
			{
				destNodeEl.setAttribute("CATEGORY_ID", colValue);
				nNode.getAttributes().removeNamedItem("CATEGORY_ID");
			}
		}
		//System.out.println(getStringFromDocument(doc));

		//storeStringAsFile(srcConfXML, srcConfFilePath + "_tmpA");
	}

	public static String getStringFromDocument(Document doc)
	{
		try
		{
			DOMSource domSource = new DOMSource(doc);
			StringWriter writer = new StringWriter();
			StreamResult result = new StreamResult(writer);
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer transformer = tf.newTransformer();
			transformer.transform(domSource, result);
			return writer.toString();
		}
		catch (TransformerException ex)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, ex.getMessage(), ex);
			return null;
		}
	}

	public static boolean storeStringAsFile(String str, String fileAbsPath)
	{

		boolean status = true;
		File file = new File(fileAbsPath);
		//System.out.println("Saving to file:" + fileAbsPath);
		try
		{
			if (!file.exists())
			{
				file.createNewFile();
			}
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(str);
			bw.flush();
			bw.close();
		}
		catch (Exception e)
		{
			status = false;
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		return status;
	}
}
//ignorei18n_end
