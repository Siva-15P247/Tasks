package local.idmp.utils;

import com.google.gson.JsonObject;
import okhttp3.ResponseBody;
import org.json.JSONObject;
import retrofit2.Call;
import retrofit2.http.*;

import java.util.Map;

public interface MSRestApiInterface
{
	@POST()
	Call post(@Body JSONObject data);

	@POST
	Call<ResponseBody> post(@Body JsonObject data, @Url String url, @QueryMap(encoded = true) Map<String, String> query, @HeaderMap Map<String, String> headers);

	@POST
	Call<ResponseBody> post(@Url String url, @QueryMap(encoded = true) Map<String, String> query, @HeaderMap Map<String, String> headers);

	@FormUrlEncoded
	@POST
	Call<ResponseBody> post(@Url String url, @QueryMap(encoded = true) Map<String, String> query, @HeaderMap Map<String, String> headers, @FieldMap Map<String, String> fields);

	@PATCH
	Call<ResponseBody> patch(@Body JsonObject data, @Url String url, @QueryMap(encoded = true) Map<String, String> query, @HeaderMap Map<String, String> headers);

	@PATCH
	Call<ResponseBody> patch(@Url String url, @QueryMap(encoded = true) Map<String, String> query, @HeaderMap Map<String, String> headers);

	@GET
	Call<ResponseBody> getRaw(@Body JsonObject data, @Url String url, @QueryMap(encoded = true) Map<String, String> query, @HeaderMap Map<String, String> headers);

	@GET
	Call<ResponseBody> getRawjson(@Url String url, @QueryMap(encoded = true) Map<String, String> query, @HeaderMap Map<String, String> headers);
}
