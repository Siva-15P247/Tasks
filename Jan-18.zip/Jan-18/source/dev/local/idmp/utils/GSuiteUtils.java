package local.idmp.utils;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.admin.directory.Directory;
import com.google.api.services.admin.directory.DirectoryScopes;
import com.google.api.services.admin.directory.model.Domains;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;
//ignorei18n_start
public class GSuiteUtils
{
	private static final String APPLICATION_NAME = "Google Admin SDK Directory API Java Quickstart";
	private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
	private static final String CREDENTIALS_FOLDER = "credentials"; // Directory to store user credentials.

	/**
	 * Global instance of the scopes required by this quickstart.
	 * If modifying these scopes, delete your previously saved credentials folder at /secret.
	 */
	private static final List<String> SCOPES = new ArrayList<>();

	static
	{
		SCOPES.add(DirectoryScopes.ADMIN_DIRECTORY_USER_READONLY);
		SCOPES.add(DirectoryScopes.ADMIN_DIRECTORY_DOMAIN_READONLY);
	}
	//	private static final List<String> SCOPES = Collections.singletonList(DirectoryScopes.ADMIN_DIRECTORY_USER);
	private static final String CLIENT_SECRET_DIR = "client_secret.json";

	/**
	 * Creates an authorized Credential object.
	 *
	 * @param netHttpTransport The network HTTP Transport.
	 * @return An authorized Credential object.
	 * @throws IOException If there is no client_secret.
	 */
	private static Credential getCredentials(NetHttpTransport netHttpTransport) throws IOException
	{
		// Load client secrets.
		InputStream in = GSuiteUtils.class.getResourceAsStream(CLIENT_SECRET_DIR);
		GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

		// Build flow and trigger user authorization request.
		GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(netHttpTransport, JSON_FACTORY, clientSecrets, SCOPES).setDataStoreFactory(new CustomGSuiteDataStoreFactory()).
				setAccessType("offline").build();
		return new CustomAuthCodeApp(flow, new LocalServerReceiver()).authorize("user");
	}

	public static void main(String... args) throws IOException, GeneralSecurityException
	{
		// Build a new authorized API client service.
		final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
		Directory directory = new Directory.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT)).setApplicationName(APPLICATION_NAME).build();

		// Print the first 10 users in the domain.
		//		Users result = directory.users().list().setCustomer("my_customer").setMaxResults(10).setOrderBy("email").execute();
		//		List<User> users = result.getUsers();
		//		if (users == null || users.size() == 0)
		//		{
		//			System.out.println("No users found.");
		//		}
		//		else
		//		{
		//			System.out.println("Users:");
		//			for (User user : users)
		//			{
		//				System.out.println(user.getName().getFullName());
		//				System.out.println(user.getPrimaryEmail());
		//			}
		//		}
		List<Domains> list = directory.domains().list("my_customer").execute().getDomains();
		//		if (list == null || list.size() == 0)
		//		{
		//			// System.out.println("No users found.");
		//		}
		//		else
		//		{
		//			// System.out.println("Users:");
		//			for (Domains domain : list)
		//			{
		//				// System.out.println(domain.getDomainName());
		//			}
		//		}
	}
}
//ignorei18n_end
