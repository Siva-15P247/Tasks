package local.idmp.utils;

import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import org.json.JSONArray;
import org.json.JSONObject;

import javax.naming.*;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.*;
import java.io.IOException;
import java.util.Hashtable;
import java.util.logging.Logger;
import java.util.regex.Pattern;

//ignorei18n_start
public class LdapUtils
{
	private static final Logger LOGGER = Logger.getLogger(LdapUtils.class.getName());

	public static void main(String[] args)
	{
		getLdapUserPaged();
	}

	private static void getLdapUserPaged()
	{

		String username = "CN=Administrator,CN=Users,DC=omp,DC=local";
		String password = "Laptop@135";

		Hashtable<String, String> env = new Hashtable<>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, "ldap://omp.local/dc=omp,dc=local");
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, username); // replace with user DN
		env.put(Context.SECURITY_CREDENTIALS, password);
		env.put(Context.REFERRAL, "follow");

		try
		{
			LdapContext ctx = new InitialLdapContext(env, null);

			// Activate paged results
			int pageSize = 25;
			byte[] cookie = null;
			ctx.setRequestControls(new Control[]{new PagedResultsControl(pageSize, Control.CRITICAL)});
			int total;
			SearchControls searchControls = new SearchControls();
			searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);

			do
			{
				/* perform the search */
				NamingEnumeration results = ctx.search("OU=OU-B", "(&(objectClass=user)(objectCategory=person))", searchControls);//(ou:=OU-A)

				/* for each entry print out name + all attrs and values */
				while (results != null && results.hasMore())
				{
					SearchResult entry = (SearchResult) results.next();
					// System.out.println(entry.getAttributes().get("userPrincipalName"));
					// System.out.println(entry.getAttributes().get("distinguishedName"));
					// System.out.println(entry.getAttributes().get("sAMAccountName"));
					// System.out.println(entry.getAttributes().get("mail"));
					// System.out.println(entry.getAttributes().get("displayName"));
					// System.out.println(entry.getAttributes().get("givenName"));
					// System.out.println(entry.getAttributes().get("middleName"));
					// System.out.println(entry.getAttributes().get("sn"));
					// System.out.println("--------------------------------------------------------");
				}

				// Examine the paged results control response
				Control[] controls = ctx.getResponseControls();
				if (controls != null)
				{
					for (int i = 0; i < controls.length; i++)
					{
						if (controls[i] instanceof PagedResultsResponseControl)
						{
							//System.out.println("#########################################PRRC_FOUND#############################################" + controls.length);
							PagedResultsResponseControl prrc = (PagedResultsResponseControl) controls[i];
							total = prrc.getResultSize();
							if (total != 0)
							{
								//System.out.println("***************** END-OF-PAGE " + "(total : " + total + ") *****************\n");
							}
							else
							{
								//System.out.println("***************** END-OF-PAGE " + "(total: unknown) ***************\n");
							}
							cookie = prrc.getCookie();
						}
					}
				}
				else
				{
					//System.out.println("No controls were sent from the server");
				}
				// Re-activate paged results
				ctx.setRequestControls(new Control[]{new PagedResultsControl(pageSize, cookie, Control.CRITICAL)});

			} while (cookie != null);

			ctx.close();

		}
		catch (NamingException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (IOException ie)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, ie.getMessage(), ie);
		}

	}

	private static void listOUHierarchy()
	{
		String username = "CN=Administrator,CN=Users,DC=omp,DC=local";
		String password = "Laptop@135";

		Hashtable<String, String> env = new Hashtable<>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, "ldap://172.21.11.156:3268/dc=omp,dc=local");
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, username); // replace with user DN
		env.put(Context.SECURITY_CREDENTIALS, password);

		DirContext ctx = null;
		try
		{
			ctx = new InitialDirContext(env);

			SearchControls controls = new SearchControls();
			controls.setSearchScope(SearchControls.ONELEVEL_SCOPE);
			//			NamingEnumeration<SearchResult> results = ctx.search("CN=Administrator,CN=Users", "(objectclass=person)", controls);
			NamingEnumeration<SearchResult> results = ctx.search("", "(objectclass=organizationalUnit)", controls);

			JSONArray hier = new JSONArray();

			while (results.hasMore())
			{
				SearchResult sr = results.next();
				String ouDN = (String) sr.getAttributes().get("distinguishedname").get();
				String ctxName = calcCtxName(ouDN, "omp.local");

				JSONObject ou = new JSONObject();
				ou.put("DISTINGUISHED_NAME", ouDN);
				JSONObject rel = new JSONObject();
				//ou.put("CONTEXT_NAME", ctxName);
				JSONArray childOUs = getChildOUs(ctx, ouDN);
				if (childOUs != null)
				{
					rel.put("CHILD_OUS", JsonApiHandler.getResourceObject(childOUs));
					ou.put("HAS_CHILDREN", true);
				}
				else
				{
					ou.put("HAS_CHILDREN", false);
				}
				hier.put(JsonApiHandler.getResourceObject("organizational-unit", ouDN, ou, rel));
			}
			//System.out.println(JsonApiHandler.getResourceObject(hier).toString(4));
		}
		catch (AuthenticationException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (NameNotFoundException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			// The base context was not found.
			// Just clean up and exit.
		}
		catch (NamingException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			// handle
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		finally
		{
			if (ctx != null)
			{
				try
				{
					ctx.close();
				}
				catch (NamingException e)
				{
					LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
				}
			}
		}
	}

	private static JSONArray getChildOUs(DirContext ctx, String parentDN) throws NamingException
	{
		JSONArray res = null;
		SearchControls controls = new SearchControls();
		controls.setSearchScope(SearchControls.ONELEVEL_SCOPE);
		String ctxName = calcCtxName(parentDN, "omp.local");
		NamingEnumeration<SearchResult> results = ctx.search(ctxName, "(objectclass=organizationalUnit)", controls);
		while (results != null && results.hasMore())
		{
			SearchResult sr = results.next();
			String ouDN = (String) sr.getAttributes().get("distinguishedname").get();
			String ctxNameS = calcCtxName(ouDN, "omp.local");

			JSONObject ou = new JSONObject();
			JSONObject rel = new JSONObject();
			ou.put("DISTINGUISHED_NAME", ouDN);
			rel.put("parent", JsonApiHandler.getResourceIdentifierObject("organization-unit", parentDN));
			//ou.put("CONTEXT_NAME", ctxName);
			JSONArray childOUs = getChildOUs(ctx, ctxNameS);
			if (childOUs != null)
			{
				rel.put("CHILD_OUS", JsonApiHandler.getResourceObject(childOUs));
				ou.put("HAS_CHILDREN", true);
			}
			else
			{
				ou.put("HAS_CHILDREN", false);
			}
			if (res == null)
			{
				res = new JSONArray();
			}
			res.put(JsonApiHandler.getResourceObject("organizational-unit", ouDN, ou, rel));
		}
		return res;
	}

	public static String calcCtxName(String dn, String ctxBase)
	{
		String[] domComps = ctxBase.split(Pattern.quote("."));

		for (String domComp : domComps)
		{
			dn = dn.replaceAll("(^|,)DC=" + domComp, "");
		}
		return dn;

	}

	public static boolean verifyCreds()
	{
		boolean verified = false;

		String username = "CN=Administrator,CN=Users,DC=omp,DC=local";
		String password = "Laptop@135";

		Hashtable<String, String> env = new Hashtable<>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, "ldap://172.21.11.156:3268/dc=omp,dc=local");
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, username); // replace with user DN
		env.put(Context.SECURITY_CREDENTIALS, password);

		DirContext ctx;
		try
		{
			ctx = new InitialDirContext(env);

			Object lookupres = ctx.lookup("CN=Administrator,CN=Users");
			//System.out.println(lookupres);

			SearchControls controls = new SearchControls();
			controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
			//			NamingEnumeration<SearchResult> results = ctx.search("CN=Administrator,CN=Users", "(objectclass=person)", controls);
			NamingEnumeration<SearchResult> results = ctx.search("", "(objectclass=organizationalUnit)", controls);
			while (results.hasMore())
			{
				SearchResult sr = results.next();
				//System.out.println(sr);
				//System.out.println(sr.getAttributes().get("ou").get());
				//System.out.println(sr.getAttributes().get("name").get());
			}
		}
		catch (AuthenticationException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (NameNotFoundException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			// The base context was not found.
			// Just clean up and exit.
		}
		catch (NamingException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			// handle
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}


		return verified;
	}
}
//ignorei18n_end
