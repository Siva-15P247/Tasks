package local.idmp.utils.jetty;

import org.mortbay.jetty.Request;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.handler.AbstractHandler;
import org.mortbay.util.Attributes;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Enumeration;
import java.util.logging.Logger;

public class TestServer
{
	private static final Logger LOGGER = Logger.getLogger(TestServer.class.getName());

	public static void main(String[] args) throws Exception
	{
		Server server = new Server(8081);
		server.setHandler(new AbstractHandler()
		{
			@Override
			public void handle(String s, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, int i) throws IOException, ServletException
			{
				httpServletResponse.setContentType("text/html;charset=utf-8");
				httpServletResponse.setStatus(HttpServletResponse.SC_OK);
				Request baseRequest = (Request) httpServletRequest;
				baseRequest.setHandled(true);
				httpServletResponse.getWriter().println("<h1>Hello World</h1>");

				LOGGER.info("Req at:" + httpServletRequest.getRequestURI());

				LOGGER.info("Attributes:");
				Attributes attributes = ((Request) httpServletRequest).getAttributes();
				Enumeration<String> attributeNames = attributes.getAttributeNames();
				while (attributeNames.hasMoreElements())
				{
					String attrName = attributeNames.nextElement();
					LOGGER.info(attrName + ":" + attributes.getAttribute(attrName));
				}

				LOGGER.info("Parameters:");
				Enumeration<String> parameterNames = httpServletRequest.getParameterNames();
				while (parameterNames.hasMoreElements())
				{
					String paramName = parameterNames.nextElement();
					LOGGER.info(paramName + ":" + httpServletRequest.getParameter(paramName));
				}
			}
		});
		server.start();
		server.join();
	}
}
