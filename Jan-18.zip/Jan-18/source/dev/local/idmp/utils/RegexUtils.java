package local.idmp.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexUtils
{
	public static Matcher getMatcher(String regex, String input)
	{
		return getMatcher(regex, input, true);
	}

	public static Matcher getMatcher(String regex, String input, boolean multi)
	{
		Pattern pat = multi ? Pattern.compile(regex, Pattern.DOTALL) : Pattern.compile(regex);
		Matcher m = pat.matcher(input);

		return m;
	}
}
