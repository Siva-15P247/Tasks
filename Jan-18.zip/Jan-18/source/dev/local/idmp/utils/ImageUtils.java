package local.idmp.utils;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.math.NumberUtils;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ImageUtils
{
	private static final Logger LOGGER = Logger.getLogger(ImageUtils.class.getName());

	public static void main(String[] args)
	{
		merge();
	}

	public static void split()
	{
		String spritePath = "/Users/rakesh-3889/Documents/idmpod/master/idmpod/jsapps/adminPortal/public/images/iamapps-sprite.png";//NO I18N
		String outputDir = "/Users/rakesh-3889/Documents/idmpod/master/idmpod/jsapps/adminPortal/public/images/appicons/";//NO I18N
		try
		{
			BufferedImage sprite = ImageIO.read(new File(spritePath));
			final int width = 50;
			final int height = 50;
			final int rows = 45;
			final int cols = 12;
			final int buffer = 5;

			BufferedImage[] sprites = new BufferedImage[rows * cols];

			for (int i = 0; i < rows; i++)
			{
				for (int j = 0; j < cols; j++)
				{
					sprites[(i * cols) + j] = sprite.getSubimage(j * (width + buffer), i * (height + buffer), width, height);
				}
			}

			for (int i = 0; i < sprites.length; i++)
			{
				BufferedImage spriteI = sprites[i];
				File outputFile = new File(outputDir + i + ".png");
				if (!outputFile.getParentFile().exists())
				{
					outputFile.getParentFile().mkdirs();
				}
				ImageIO.write(spriteI, "png", outputFile);//NO I18N
			}
		}
		catch (IOException e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
	}

	public static void merge()
	{
		String emberAppDir = "/Users/rakesh-3889/Documents/idmpod/master/idmpod/jsapps/adminPortal/";//NO I18N
		String spriteIconsDirPath = emberAppDir + "public/images/appicons/";//NO I18N
		String spritePath = emberAppDir + "public/images/apps-sprite.png";//NO I18N
		String cssFilePath = emberAppDir + "app/styles/appicons.css";//NO I18N
		StringBuilder cssString = new StringBuilder();

		final int iconsPerRow = 12;
		final int width = 50;
		final int height = 50;
		final int buffer = 5;

		File spriteIconsDir = new File(spriteIconsDirPath);
		File[] imageFiles = spriteIconsDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".png"));//NO I18N

		//Calc resultant file size - Begin
		int resWidth = 0;
		int resHeight = 0;
		int cols = 0;
		int rows = 0;

		if (imageFiles.length <= iconsPerRow)
		{
			rows = 1;
			cols = imageFiles.length;
		}
		else
		{
			float rowsExact = (float) imageFiles.length / (float) iconsPerRow;
			rows = new BigDecimal(String.valueOf(rowsExact)).setScale(0, RoundingMode.CEILING).intValue();
			cols = iconsPerRow;
		}
		resWidth = (width + buffer) * (cols - 1) + width;
		resHeight = (height + buffer) * (rows - 1) + height;
		//Calc resultant file size - End

		BufferedImage result = new BufferedImage(resWidth, resHeight, BufferedImage.TYPE_INT_ARGB);
		Graphics g = result.getGraphics();

		int x = 0, y = 0;


		double ratio = 18d / 50d;
		double nwidth = ratio * resWidth;
		double nheight = ratio * resHeight;

		nwidth = new BigDecimal(String.valueOf(nwidth)).setScale(3, RoundingMode.HALF_UP).doubleValue();
		nheight = new BigDecimal(String.valueOf(nheight)).setScale(3, RoundingMode.HALF_UP).doubleValue();

		cssString.append(".idmp-app-icon-sm {\n" + "  width: 18px;\n" + "  height: 18px;\n" + "  line-height: 18px;\n" + "  background-image: url(\"../images/apps-sprite.png\");\n" + "  background-size: " + nwidth + "px " + nheight + "px;\n" + "}\n");//NO I18N

		for (File imageFile : imageFiles)
		{
			BufferedImage bi = null;
			try
			{
				bi = ImageIO.read(imageFile);
				g.drawImage(bi, x, y, null);
				cssString.append(getCssForIcon(FilenameUtils.removeExtension(imageFile.getName()), x, y, resWidth, resHeight, width, height));
				x += width + buffer;
				if (x > result.getWidth())
				{
					x = 0;
					y += height + buffer;
				}
			}
			catch (IOException e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
		}

		try
		{
			ImageIO.write(result, "png", new File(spritePath));//NO I18N
			XMLUtils.storeStringAsFile(cssString.toString(), cssFilePath);
		}
		catch (IOException e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}

		LOGGER.info(rows + "x" + cols);
		LOGGER.info(resWidth + "x" + resHeight);
	}

	private static String getCssForIcon(String name, int x, int y, int resWidth, int resHeight, int width, int height)
	{
		StringBuilder cssString = new StringBuilder();

		if (NumberUtils.isDigits(name))
		{
			name = "icn-" + name;//NO I18N
		}

		double percentX = 0D, percentY = 0D;

		percentX = ((double) x / (resWidth - width)) * 100;
		percentY = ((double) y / (resHeight - height)) * 100;

		percentX = new BigDecimal(String.valueOf(percentX)).setScale(3, RoundingMode.HALF_UP).doubleValue();
		percentY = new BigDecimal(String.valueOf(percentY)).setScale(3, RoundingMode.HALF_UP).doubleValue();

		cssString.append("." + name + " {" + "\n");
		cssString.append("\tbackground-position: " + percentX + "% " + percentY + "%;\n");//NO I18N
		cssString.append("}\n");//NO I18N

		return cssString.toString();
	}
}
