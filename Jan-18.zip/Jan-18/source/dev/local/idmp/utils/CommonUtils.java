package local.idmp.utils;

import org.apache.commons.io.IOUtils;

import javax.xml.bind.DatatypeConverter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Enumeration;
import java.util.Properties;
import java.util.logging.Logger;

public class CommonUtils
{
	private static final Logger LOGGER = Logger.getLogger(CommonUtils.class.getName());

	public static void main(String[] args) throws Exception
	{
		//		double width = 655, height = 2600;
		//		double ratio = 18d / 50d;
		//		double nwidth = ratio * width;
		//		double nheight = ratio * height;
		//		LOGGER.info(nwidth + "::" + nheight);
		// ---
		//		String[] appids = new String[]{"a", "b", "c"};
		//		StringBuilder remSb = new StringBuilder();
		//		for (int i = 0; i < appids.length; i++)
		//		{
		//			String appid = appids[i];
		//			remSb.append(appid);
		//			if (i == appids.length - 2)
		//			{
		//				remSb.append(" and ");
		//			}
		//			else if (i < appids.length - 1)
		//			{
		//				remSb.append(", ");
		//			}
		//		}
		//		LOGGER.info(remSb.toString());
		// ---
		//		String[] auditActions = new String[]{"assignSamlAppsToUser", "updateUser", "deleteUser", "deleteInvitations", "addSamlApp", "updateSamlApp", "deleteSamlApp", "assignUsersToSamlApp", "removeUsersFromSamlApp", "addDirectory", "updateDirectory", "deleteDirectory", "importDirectoryUsers", "addUsersToDirectory", "updateOrganizationalUnit", "setupDirectorySync", "createAuthToken"};//No I18N
		//LOGGER.info(auditActions.length + "");
		//for (String action : auditActions)
		{
			//			System.out.println(StringUtils.formatAsIDPattern(action) + "::" + StringUtils.formatAsUniqueName(action) + "::" + StringUtils.formatAsI18nKey(action));
			//System.out.println("<IdmpodAuditOperationTypes OPERATION_TYPE_ID=\"IdmpodAuditOperationTypes:OPERATION_TYPE_ID:" + StringUtils.formatAsIDPattern(action) + "\" OPERATION_NAME=\"" + StringUtils.formatAsUniqueName(action) + "\" OPERATION_DISPLAY_NAME=\"idmpod.reports.audit.op_display_name." + StringUtils.formatAsI18nKey(action) + "\"/>");
			//			System.out.println("idmpod.reports.audit.op_display_name." + StringUtils.formatAsI18nKey(action) + "=");
			//			System.out.println("public static final String OP_" + StringUtils.formatAsIDPattern(action) + "=\"" + StringUtils.formatAsUniqueName(action) + "\";//No I18N");
		}
		//System.out.println(Configuration.checkAndDecrypt("1C923340C0CA081DE1B1A541D02ABECA"));
	}

	private static void certToFingerprint() throws NoSuchAlgorithmException, CertificateException, IOException
	{
		MessageDigest md = null;
		md = MessageDigest.getInstance("SHA1");
		String certString = "-----BEGIN CERTIFICATE-----\n" + "MIICkTCCAXkCBgFi/cTNoDANBgkqhkiG9w0BAQUFADAMMQowCAYDVQQDEwFBMB4XDTE4MDQyNDE3MDU1NVoXDTIxMDQyNDE3MDU1NVowDDEKMAgGA1UEAxMBQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANvcyzmTQiR90PEpk+5HZ8FYIPuoyFuOoLcM/4T0/21rpV4A45BYZ369qqUA59LtGRYwjJZa0GgkzXdlbQtFfHsahY79Y+RHRf0R6NtKuL85sbQbEX7TmYVw4yYNTADRsVMRrIWX3LW6+I2WGSEqoVmE1rCsZtczitI172eZP72tCQJZrbe/nPsIJ6IYRvfbYrPGKd4BGH8Hqrs/b6td6p9YRXCzh+NYZ+bdv5YsCOKDlzW1I5iVhtXZjQ49esGmFX7ICK6UDj/NpVoNFlAgkRAWt7Q/6RjK0Fjm/lOdDF/BKkMWcpmrcNyv1RkX80KzfqARhYK1Nu8xSQA9yQH362cCAwEAATANBgkqhkiG9w0BAQUFAAOCAQEAFAeGJeLfj1ESt9IiOwidTUaI8fdkhWmuhOhKvDB+lP7fzCbXicFQdRWJMCNO1NauiimZHYOvha3p2omfdDv0jipD2dwSRT3izOtmDXxeXiqBIeMaLCy9FovjABsqRoB12JsMNMimcO6Hu6kYcIsBmK43WS0i9Kaw6tzQ4Uwo9362obEogjv/U/twey5c3xxOtaOorBbNMU4wMIE2uKzfsUhIW3KjWrcwPhO+b2LfVcoErIQqfTUXhWuMvgANHBaY1MRga+lYcLG1n1x9fkJxdj2EVMjdW/wKmAfginJB/td63yc3EyPAjkzjWqfbW+TY7ZD5GYU8ModhvMcpeMHStw==\n" + "-----END CERTIFICATE-----";//No I18N
		CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
		X509Certificate cert = (X509Certificate) certificateFactory.generateCertificate(IOUtils.toInputStream(certString, "UTF-8"));//No I18N

		byte[] der = cert.getEncoded();
		md.update(der);
		byte[] digest = md.digest();
		// System.out.println(new String(digest));
		String res = DatatypeConverter.printHexBinary(digest);
		res = res.replaceAll("(.{2})", "$1 ").trim();
		res = res.replaceAll(" ", ":");
		//System.out.println(res);
	}


	public static void mergerProperties() throws IOException
	{
		FileOutputStream fileOut = null;
		try
		{
			String sourceFilePath = "/Users/rakesh-3889/Documents/adssp/HEAD/adssp/product_package/ancillary/en_US/resources/adssp/ApplicationResources_en_US.properties";//No I18N
			String destFilePath = "/Users/rakesh-3889/Documents/idmpod/master/idmpod/jsapps/adminPortal/app/i18n/en/applications-temp.properties";//No I18N

			File sourceFile = new File(sourceFilePath);
			File destFile = new File(destFilePath);

			Properties src = new Properties();
			src.load(new FileInputStream(sourceFile));

			Properties dest = new Properties();
			dest.load(new FileInputStream(destFile));

			Enumeration<String> destKeys = (Enumeration<String>) dest.propertyNames();
			while (destKeys.hasMoreElements())
			{
				String key = destKeys.nextElement();
				if (src.getProperty(key) != null)
				{
					dest.setProperty(key, src.getProperty(key));
				}
			}
			fileOut = new FileOutputStream(destFile);
			dest.store(fileOut, "");
			fileOut.close();
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		finally
		{
			if (fileOut != null)
			{
				fileOut.close();
			}
		}
	}
}
