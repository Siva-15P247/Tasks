package local.idmp.utils;

public class StringUtils
{
	public static String formatAsIDPattern(String str)
	{
		return separateWordsBy(str, '_').toUpperCase();
	}

	public static String formatAsUniqueName(String str)
	{
		char ch[] = str.toCharArray();
		if (ch[0] >= 'a' && ch[0] <= 'z')
		{
			// Convert into Upper-case
			ch[0] = (char) (ch[0] - 'a' + 'A');
		}
		return new String(ch);
	}

	public static String formatAsI18nKey(String str)
	{
		return separateWordsBy(str, '_').toLowerCase();
	}

	static String separateWordsBy(String str, char c)
	{
		String newString = str.replaceAll("[A-Z]", c + "$0");//No I18N
		return newString;
	}
}
