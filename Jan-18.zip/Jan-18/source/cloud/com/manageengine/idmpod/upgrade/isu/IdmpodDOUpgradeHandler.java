package com.manageengine.idmpod.upgrade.isu;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.*;
import com.adventnet.persistence.xml.Xml2DoConverter;
import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.sas.upgrade.isu.ISMDefaultUpgradeHandler;
import com.manageengine.tables.adsf.ADSIAMAPPAPIS;
import com.manageengine.tables.adsf.ADSIAMAPPLICATIONS;
import com.manageengine.tables.adsf.ADSIAMAPPLICATIONSCATEGORY;
import com.manageengine.tables.adsf.ADSIAMAPPLICATIONSPROPS;
import com.zoho.conf.Configuration;

import javax.transaction.Status;
import javax.transaction.TransactionManager;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

public class IdmpodDOUpgradeHandler extends ISMDefaultUpgradeHandler
{

	private static final Logger LOGGER = Logger.getLogger(IdmpodDOUpgradeHandler.class.getName());

	private static void dropUVHforTable(String tableName, Persistence persistence) throws DataAccessException
	{
		Criteria uvhDeleteCriteria = new Criteria(Column.getColumn(UVHVALUES.TABLE, UVHVALUES.PATTERN), tableName + ":", QueryConstants.STARTS_WITH);
		DataObject dataObject = persistence.get(UVHVALUES.TABLE, (Criteria) uvhDeleteCriteria);
		dataObject.deleteRows(UVHVALUES.TABLE, (Criteria) null);
		persistence.update(dataObject);
	}

	@Override
	public void handleCustomerDataUpdates(long oldVersion, boolean isReverting) throws Exception
	{
		try
		{
			if (!isReverting)
			{
				String loginName = SASThreadLocal.getLoginName();
				Persistence persistence;
				if (loginName == null)
				{
					persistence = (Persistence) BeanUtil.lookup("Persistence");
				}
				else
				{
					persistence = (Persistence) BeanUtil.lookup("Persistence", loginName);
				}

				String[] tables = {ADSIAMAPPLICATIONSCATEGORY.TABLE, ADSIAMAPPLICATIONS.TABLE, ADSIAMAPPLICATIONSPROPS.TABLE, ADSIAMAPPAPIS.TABLE};

				//drop table data and UVH values
				for (String table : tables)
				{
					//drop table data
					DataObject dataObject = persistence.get(table, (Criteria) null);
					dataObject.deleteRows(table, (Criteria) null);
					persistence.update(dataObject);
					//drop UVH values
					dropUVHforTable(table, persistence);
				}


				String confFile = Configuration.getString("app.home") + File.separator + "isu" + File.separator + "conf-files.xml";//No I18N
				if (!(new File(confFile)).exists())
				{
					Exception ex = new FileNotFoundException("unable to find the conf file " + confFile);//No I18N
					LOGGER.log(Level.SEVERE, "", ex);
					return;
					//					throw ex;
				}
				populateXmlData(confFile);
			}
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Exception while doing data upgrade : " + e);
			//throw e;
		}
	}

	private void populateXmlData(String confFile) throws Exception
	{
		DataObject confDobj = Xml2DoConverter.transform(confFile);
		String xmlFile = null;
		Iterator iterator = confDobj.get("ConfFile", "URL");
		TransactionManager tm = DataAccess.getTransactionManager();
		boolean newTransaction = false;
		try
		{
			if (tm.getStatus() != Status.STATUS_ACTIVE)
			{
				newTransaction = true;
				tm.begin();
			}
			while (iterator.hasNext())
			{
				xmlFile = (String) iterator.next();
				LOGGER.log(Level.INFO, "Parsing the xml file : " + xmlFile);
				String url = Configuration.getString("app.home") + File.separator + "isu" + File.separator + xmlFile;//No I18N
				if (!(new File(url)).exists())
				{
					Exception ex = new FileNotFoundException("unable to find the file " + url);//No I18N
					LOGGER.log(Level.SEVERE, "", ex);
					throw ex;
				}
				DataObject xmlDobj = Xml2DoConverter.transform(url);
				Persistence persistence = (Persistence) BeanUtil.lookup("Persistence", SASThreadLocal.getLoginName());
				persistence.add(xmlDobj);
			}
			if (newTransaction)
			{
				tm.commit();
			}
		}
		catch (Exception e)
		{
			if (newTransaction)
			{
				tm.rollback();
			}
			LOGGER.log(Level.SEVERE, "Exception while populating the xml file : " + xmlFile, e);
			throw e;
		}
	}
}
