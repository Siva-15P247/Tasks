package com.manageengine.idmpod.client.reports;

import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.reports.GraphHandler;
import org.json.JSONObject;

import java.util.logging.Logger;

public class GraphApi
{
	private static final Logger LOGGER = Logger.getLogger(GraphApi.class.getName());

	private static GraphApi instance = null;

	public static synchronized GraphApi getInstance()
	{
		if (instance == null)
		{
			instance = new GraphApi();
		}
		return instance;
	}

	public static JSONObject getChart(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		resp.put(JsonApiConstants.DATA, GraphHandler.getChart(request));

		// LOGGER.info(request.toString(4));

		return resp;
	}
}
