package com.manageengine.idmpod.client.iam;

import com.adventnet.iam.IAMException;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.iam.IdmpodIAMUtil;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.logging.Logger;

@WebServlet("/api/create-organization")//No I18N
public class OrgCreationServlet extends HttpServlet
{
	private static final Logger LOGGER = Logger.getLogger(OrgCreationServlet.class.getName());

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		req.setCharacterEncoding("UTF-8");// NO I18N
		JSONObject request = JsonApiHandler.processRequest(req);
		try
		{
			IdmpodIAMUtil.createOrg(request.getString("ORGANIZATION_NAME"));
		}
		catch (IAMException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			throw new ServletException(e);
		}
		// LOGGER.info(request.toString(4));
		resp.setStatus(HttpServletResponse.SC_OK);
		JsonApiHandler.setResponseJSON(resp, request);
	}
}
