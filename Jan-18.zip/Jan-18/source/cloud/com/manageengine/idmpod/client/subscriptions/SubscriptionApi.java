package com.manageengine.idmpod.client.subscriptions;

import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.utils.AuditUtil;
import com.manageengine.idmpod.server.utils.IdmpodThreadLocal;
import com.manageengine.idmpod.server.utils.IdmpodUtils;
import com.manageengine.idmpod.server.zstore.LicenseUtil;
import com.manageengine.tables.idmpod.IDMPODSUBSCRIPTIONS;
import org.json.JSONObject;

import java.util.logging.Level;
import java.util.logging.Logger;

public class SubscriptionApi
{
	private static final Logger LOGGER = Logger.getLogger(SubscriptionApi.class.getName());

	private static SubscriptionApi instance = null;

	public static synchronized SubscriptionApi getInstance()
	{
		if (instance == null)
		{
			instance = new SubscriptionApi();
		}
		return instance;
	}

	public static JSONObject getCurrentSubscription(JSONObject request)
	{
		final String TYPE = JsonApiHandler.ResourceType.SUBSCRIPTION.getResType();
		JSONObject resp = new JSONObject();
		JSONObject data = new JSONObject();
		data.put(JsonApiConstants.TYPE, TYPE);
		JSONObject subsAttrs = LicenseUtil.getCurrentSubscriptionDetails();
		subsAttrs.put("PRODUCT_VERSION", IdmpodUtils.getProductVersion());
		subsAttrs.put("PRODUCT_BUILD", IdmpodUtils.getProductBuild());
		//		#############################################################
		String paymentURL = IdmpodUtils.getProperty("payment.server");
		paymentURL += "/html/store/index.html#subscription?serviceId=" + IdmpodUtils.getProperty("payment.service.id");//No I18N
		String customid = IdmpodThreadLocal.getAppId();
		//			try
		//			{
		//				customid = CryptoUtil.encrypt("STOREHANDLER", customid);//No I18N
		//			}
		//			catch (Exception e)
		//			{
		//				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		//			}
		paymentURL += "&customId=" + customid + "&serviceurl=" + IdmpodUtils.getProperty("serviceurl");//No I18N
		subsAttrs.put("PAYMENT_URL", paymentURL);
		//		#############################################################
		data.put(JsonApiConstants.ID, subsAttrs.optLong(IDMPODSUBSCRIPTIONS.SUBS_ID));
		data.put(JsonApiConstants.ATTRIBUTES, subsAttrs);
		resp.put(JsonApiConstants.DATA, data);
		return resp;
	}

	public static JSONObject updateSubscription(JSONObject request)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		if (attributes.has("STATUS"))
		{
			String status = attributes.getString("STATUS");
			try
			{
				if (status.equalsIgnoreCase("CLOSED"))
				{
					IdmpodUtils.setOrgPreference(DBUtils.getAAPersistence(IdmpodThreadLocal.getAppId()), "STATUS", status);//No I18N
					IdmpodUtils.setOrgPreference(DBUtils.getAAPersistence(IdmpodThreadLocal.getAppId()), "ACCOUNT_CLOSE_TIME", String.valueOf(System.currentTimeMillis()));//No I18N
				}
				else
				{
					IdmpodUtils.setOrgPreference(DBUtils.getAAPersistence(IdmpodThreadLocal.getAppId()), "STATUS", "OPEN");//No I18N
					IdmpodUtils.setOrgPreference(DBUtils.getAAPersistence(IdmpodThreadLocal.getAppId()), "ACCOUNT_REOPEN_TIME", String.valueOf(System.currentTimeMillis()));//No I18N
				}
			}
			catch (Exception e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
		}

		JSONObject resp = getCurrentSubscription(request);

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.UPDATE_SUBSCRIPTION);

		return resp;
	}
}
