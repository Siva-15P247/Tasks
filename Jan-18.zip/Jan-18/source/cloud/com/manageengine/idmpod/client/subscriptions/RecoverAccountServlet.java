package com.manageengine.idmpod.client.subscriptions;

import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/api/recover-account")//No I18N
public class RecoverAccountServlet extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		JSONObject request=new JSONObject();
		JSONObject data=new JSONObject();
		JSONObject attribs=new JSONObject();
		attribs.put("STATUS","OPEN");
		data.put(JsonApiConstants.ATTRIBUTES,attribs);
		request.put(JsonApiConstants.DATA,data);
		SubscriptionApi.updateSubscription(request);
	}
}
