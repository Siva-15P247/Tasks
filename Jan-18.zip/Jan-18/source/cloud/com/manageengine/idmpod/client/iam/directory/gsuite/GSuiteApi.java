package com.manageengine.idmpod.client.iam.directory.gsuite;

import com.adventnet.i18n.I18N;
import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.iam.directory.gsuite.GSuiteHandler;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.logging.Logger;
import java.util.logging.Level;

public class GSuiteApi
{
	private static final Logger LOGGER = Logger.getLogger(GSuiteApi.class.getName());

	private static GSuiteApi instance = null;

	public static synchronized GSuiteApi getInstance()
	{
		if (instance == null)
		{
			instance = new GSuiteApi();
		}
		return instance;
	}

	public static JSONObject createAuthToken(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);
		
		String directoryName = null;
		directoryName = attributes.optString("DIRECTORY_NAME"); //No I18N
		
		if (directoryName == null || directoryName.trim().length() == 0)
		{
			JSONArray errorsArray = new JSONArray();
			try
			{
				errorsArray.put(JsonApiHandler.getBaseErrorObject(I18N.getMsg("idmpod.directory.add_directory.error.directory_name")));
			}
			catch (Exception e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
			resp.put(JsonApiConstants.ERRORS, errorsArray);
			return resp;
		}

		final String TYPE = JsonApiHandler.ResourceType.GSUITE_AUTH_TOKEN.getResType();

		String id = GSuiteHandler.createAuthToken();

		attributes.put("AUTHORIZATION_URL", GSuiteHandler.getAuthorizationUrl().setState(id).build());

		resp.put(JsonApiConstants.DATA, JsonApiHandler.getResourceObject(TYPE, id, attributes));

		return resp;
	}

	public static JSONObject getAuthToken(JSONObject request)
	{
		JSONObject resp = new JSONObject();
		resp.put(JsonApiConstants.DATA, GSuiteHandler.getAuthToken(request.getJSONObject(JsonApiConstants.DATA).optString(JsonApiConstants.ID)));
		return resp;
	}


}
