package com.manageengine.idmpod.client.subscriptions;

import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.utils.IdmpodUtils;
import org.json.JSONObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

@WebServlet("/api/start-trial")//No I18N
public class StartTrialServlet extends HttpServlet
{
	private static final Logger LOGGER = Logger.getLogger(StartTrialServlet.class.getName());

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		req.setCharacterEncoding("UTF-8");// NO I18N
		JSONObject request = JsonApiHandler.processRequest(req);

		try
		{
			IdmpodUtils.handleFirstTimeLogin();
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}

		resp.setStatus(HttpServletResponse.SC_OK);
		JsonApiHandler.setResponseJSON(resp, request);
	}
}
