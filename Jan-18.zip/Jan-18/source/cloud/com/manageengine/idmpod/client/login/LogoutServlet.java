package com.manageengine.idmpod.client.login;

import com.manageengine.idmpod.server.iam.IdmpodIAMUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/logout")//No I18N
public class LogoutServlet extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String logoutRedirectUrl = IdmpodIAMUtil.getLogoutRedirectUrl();
		req.getSession().invalidate();
		resp.sendRedirect(logoutRedirectUrl);
	}
}
