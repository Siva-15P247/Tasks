package com.manageengine.idmpod.client.iam;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.i18n.I18N;
import com.adventnet.iam.IAMException;
import com.adventnet.iam.IAMProxy;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.User;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.iam.AppAccountUtils;
import com.manageengine.idmpod.server.iam.IdmpodUserRole;
import com.manageengine.idmpod.server.iam.UserUtils;
import com.manageengine.idmpod.server.iam.samlapps.SamlAppsHandler;
import com.manageengine.idmpod.server.utils.AuditUtil;
import com.manageengine.idmpod.server.utils.IdmpodThreadLocal;
import com.manageengine.idmpod.server.utils.IdmpodUtils;
import com.manageengine.tables.idmpod.IDMPODTECHNICIAN;
import com.zoho.accounts.AccountsProto;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class UsersApi
{
	private static final Logger LOGGER = Logger.getLogger(UsersApi.class.getName());

	private static UsersApi instance = null;

	public static synchronized UsersApi getInstance()
	{
		if (instance == null)
		{
			instance = new UsersApi();
		}
		return instance;
	}

	public static JSONObject getCurrentUser(JSONObject request)
	{
		final String TYPE = JsonApiHandler.ResourceType.USER.getResType();
		JSONObject resp = new JSONObject();

		User cUser = IAMUtil.getCurrentUser();
		JSONObject userAttrs = new JSONObject();

		userAttrs.put("COUNTRY", cUser.getCountry());
		userAttrs.put("DISPLAY_NAME", cUser.getDisplayName());
		userAttrs.put("FIRST_NAME", cUser.getFirstName());
		userAttrs.put("GENDER", cUser.getGender());
		userAttrs.put("LANGUAGE", cUser.getLanguage());
		userAttrs.put("LAST_NAME", cUser.getLastName());
		userAttrs.put("PRIMARY_EMAIL", cUser.getPrimaryEmail());
		userAttrs.put("IAM_PROFILE_URL", IAMProxy.getIAMServerURL() + "/u/h#profile/personal");
		userAttrs.put("USER_PHOTO_URL", IAMProxy.getContactsServerURL(true) + "/file?ID=" + cUser.getZUID() + "&fs=thumb&exp=1200");
		userAttrs.put("SHOW_GETTING_STARTED", UserUtils.getShowGettingStarted());
		IdmpodUserRole role = null;
		try
		{
			role = UserUtils.getUserRole();
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		userAttrs.put("ROLE", IdmpodUserRole.getString(role));
		if (role == IdmpodUserRole.SUPER_ADMIN)
		{
			String paymentURL = IdmpodUtils.getProperty("payment.server");
			paymentURL += "/html/store/index.html#subscription?serviceId=" + IdmpodUtils.getProperty("payment.service.id");//No I18N
			String customid = IdmpodThreadLocal.getAppId();
			//			try
			//			{
			//				customid = CryptoUtil.encrypt("STOREHANDLER", customid);//No I18N
			//			}
			//			catch (Exception e)
			//			{
			//				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			//			}
			paymentURL += "&customId=" + customid + "&serviceurl=" + IdmpodUtils.getProperty("serviceurl");//No I18N
			userAttrs.put("PAYMENT_URL", paymentURL);
		}

		JSONObject user = new JSONObject();
		user.put(JsonApiConstants.ID, cUser.getZUID());
		user.put(JsonApiConstants.TYPE, TYPE);
		user.put(JsonApiConstants.ATTRIBUTES, userAttrs);
		resp.put(JsonApiConstants.DATA, user);
		return resp;
	}

	public static JSONObject getUsers(JSONObject request)
	{
		// LOGGER.info(request.toString(4));
		if (request.optBoolean("AAU"))
		{
			JSONArray filterArray = null;
			if (request.has(JsonApiConstants.FILTER))
			{
				filterArray = new JSONArray(request.getString(JsonApiConstants.FILTER));
			}
			return UserUtils.getAppUsers(request.optInt("PAGE_SIZE", 25), request.optInt("PAGE_NUMBER", 1), filterArray);//No I18N
		}
		else
		{
			return UserUtils.getOrgUsers(request.optInt("PAGE_SIZE", 25), request.optInt("PAGE_NUMBER", 1));//No I18N
		}
	}

	public static JSONObject getAppUsers(JSONObject request)
	{
		// LOGGER.info(request.toString(4));
		try
		{
			JSONArray filterArray = null;
			if (request.has(JsonApiConstants.FILTER))
			{
				filterArray = new JSONArray(request.getString(JsonApiConstants.FILTER));
			}
			if (request.has("APP_ID"))
			{
				return SamlAppsHandler.getMappedUsers(request.getLong("APP_ID"), filterArray);//No I18N
			}
			else
			{
				return UserUtils.getAppUsersWithStats(request.optInt("PAGE_SIZE", 25), request.optInt("PAGE_NUMBER", 1), filterArray);//No I18N
			}
		}
		catch (IAMException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		return request;
	}

	public static JSONObject assignSamlAppsToUser(JSONObject request)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		String[] remarks = null;

		try
		{
			remarks = SamlAppsHandler.assignSamlappsToUser(data.getLong(JsonApiConstants.ID), request.getJSONArray("SAML_APPLICATIONS"));//No I18N
		}
		catch (IAMException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		JSONObject resp = getAAUser(request);

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.ASSIGN_SAML_APPS_TO_USER, remarks);
		return resp;
	}

	public static JSONObject updateUser(JSONObject request)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		try
		{
			UserUtils.updateAAUser(data.getLong(JsonApiConstants.ID), data.getJSONObject(JsonApiConstants.ATTRIBUTES));
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		JSONObject resp = getAAUser(request);
		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.UPDATE_USER);
		return resp;
	}

	public static JSONObject deleteUser(JSONObject request)
	{
		JSONObject resp = new JSONObject();
		String userName = null;

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		try
		{
			userName = UserUtils.deleteUser(data.getLong(JsonApiConstants.ID));
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (IAMException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.DELETE_USER, userName);

		return resp;
	}

	public static JSONObject getAAUser(JSONObject request)
	{
		JSONObject resp = new JSONObject();
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		try
		{
			resp.put(JsonApiConstants.DATA, UserUtils.getAAUser(data.getLong(JsonApiConstants.ID)));
		}
		catch (IAMException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return resp;
	}

	public static JSONObject getInvitedUsers(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		List<AccountsProto.Account.Invitation.InvitationDetails> invitationsList = AppAccountUtils.getSentInvitations();

		JSONArray invitations = new JSONArray();
		if (invitationsList != null)
		{
			for (AccountsProto.Account.Invitation.InvitationDetails invitationEl : invitationsList)
			{
				invitations.put(convertInvitationDetailsToJson(invitationEl));
			}
		}

		resp.put(JsonApiConstants.DATA, invitations);

		return resp;
	}

	private static JSONObject convertInvitationDetailsToJson(AccountsProto.Account.Invitation.InvitationDetails invitation)
	{
		final String TYPE = JsonApiHandler.ResourceType.INVITED_USER.getResType();

		JSONObject user = new JSONObject();
		JSONObject userAttrs = new JSONObject();

		userAttrs.put("EMAIL_ID", invitation.getParent().getEmailId());
		userAttrs.put("APP_NAME", invitation.getAppName());
		userAttrs.put("CREATED_TIME", invitation.getCreatedTime());
		//userAttrs.put("INVITED_BY", invitation.getInvitedBy());
		//userAttrs.put("MODIFIED_TIME", invitation.getModifiedTime());
		userAttrs.put("ORG_ROLE", invitation.getOrgRole());
		userAttrs.put("ROLE_NAME", invitation.getRoleName());
		userAttrs.put("STATUS", invitation.getStatus());

		user.put(JsonApiConstants.ID, invitation.getParent().getEmailId());
		user.put(JsonApiConstants.TYPE, TYPE);
		user.put(JsonApiConstants.ATTRIBUTES, userAttrs);

		return user;
	}

	public static JSONObject deleteInvitations(JSONObject request)
	{
		JSONArray email_ids = request.getJSONArray("email_ids");//No I18N

		StringBuilder remSb = new StringBuilder();
		for (int i = 0; i < email_ids.length(); i++)
		{
			String emailId = email_ids.getString(i);
			remSb.append(emailId);
			if (i == email_ids.length() - 2)
			{
				try
				{
					remSb.append(I18N.getMsg("idmpod.common.conj.and"));
				}
				catch (Exception e)
				{
					LOGGER.log(Level.SEVERE, e.getMessage(), e);
				}
			}
			else if (i < email_ids.length() - 1)
			{
				remSb.append(", ");
			}
		}

		for (int i = 0; i < email_ids.length(); i++)
		{
			AppAccountUtils.deleteInvitation(email_ids.getString(i));
		}
		JSONObject resp = new JSONObject();

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.DELETE_INVITATIONS, remSb.toString());
		return resp;
	}

	public static JSONObject assignSamlAppsToUsers(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		JSONArray users = request.getJSONArray("USERS");//No I18N
		JSONArray applications = request.getJSONArray("APPLICATIONS");//No I18N

		List<String> userids = users.toList().stream().map(Object::toString).collect(Collectors.toList());
		List<String> zuidsList = new ArrayList<String>();
		String[] zuids = null;
		try
		{
			Criteria cr = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.USER_ID), userids.toArray(new String[userids.size()]), QueryConstants.IN);
			DataObject usersDO = DBUtils.getOrgPersistence().get(IDMPODTECHNICIAN.TABLE, cr);
			Iterator<Row> usersItr = usersDO.getRows(IDMPODTECHNICIAN.TABLE);
			while (usersItr.hasNext())
			{
				Row user = usersItr.next();
				zuidsList.add(user.get(IDMPODTECHNICIAN.ZUID).toString());
			}
			zuids = zuidsList.toArray(new String[0]);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		List<String> appidsList = applications.toList().stream().map(Object::toString).collect(Collectors.toList());
		String[] appids = appidsList.toArray(new String[0]);

		String[] rems = null;
		try
		{
			rems = SamlAppsHandler.assignSamlappsToUsers(appids, zuids);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.ASSIGN_SAML_APPS_TO_USERS, rems);

		return resp;
	}

	public static JSONObject unassignSamlAppsFromUsers(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		JSONArray users = request.getJSONArray("USERS");//No I18N
		JSONArray applications = request.getJSONArray("APPLICATIONS");//No I18N

		List<String> userids = users.toList().stream().map(Object::toString).collect(Collectors.toList());
		List<String> zuidsList = new ArrayList<String>();
		String[] zuids = null;
		try
		{
			Criteria cr = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.USER_ID), userids.toArray(new String[userids.size()]), QueryConstants.IN);
			DataObject usersDO = DBUtils.getOrgPersistence().get(IDMPODTECHNICIAN.TABLE, cr);
			Iterator<Row> usersItr = usersDO.getRows(IDMPODTECHNICIAN.TABLE);
			while (usersItr.hasNext())
			{
				Row user = usersItr.next();
				zuidsList.add(user.get(IDMPODTECHNICIAN.ZUID).toString());
			}
			zuids = zuidsList.toArray(new String[0]);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		List<String> appidsList = applications.toList().stream().map(Object::toString).collect(Collectors.toList());
		String[] appids = appidsList.toArray(new String[0]);

		String[] rems = null;
		try
		{
			rems = SamlAppsHandler.unassignSamlappsFromUsers(appids, zuids);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.UNASSIGN_SAML_APPS_FROM_USERS, rems);

		return resp;
	}
}
