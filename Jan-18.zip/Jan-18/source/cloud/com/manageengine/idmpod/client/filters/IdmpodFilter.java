package com.manageengine.idmpod.client.filters;

import com.adventnet.iam.IAMUtil;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.error.ErrorCode;
import com.manageengine.idmpod.server.error.IdmpodException;
import com.manageengine.idmpod.server.utils.AuditUtil;
import com.manageengine.idmpod.server.utils.IdmpodThreadLocal;
import com.manageengine.idmpod.server.utils.IdmpodUtils;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import static com.manageengine.idmpod.server.iam.IdmpodIAMUtil.handleFirstTimeUserAccount;

@WebFilter(filterName = "IdmpodFilter", urlPatterns = "*", dispatcherTypes = DispatcherType.REQUEST)//No I18n
public class IdmpodFilter implements Filter
{
	private static final Logger LOGGER = Logger.getLogger(IdmpodFilter.class.getName());

	private Pattern excludePattern = null;

	@Override
	public void init(FilterConfig fc) throws ServletException
	{
		try
		{
			String exclude = fc.getInitParameter("exclude"); // No I18N
			if (exclude != null && exclude.length() > 0)
			{
				excludePattern = Pattern.compile(exclude);
			}
		}
		catch (Exception e)
		{
			throw new ServletException("Exception initializing IdmpodFilter", e);
		}
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain fc) throws IOException, ServletException
	{
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) res;
		try
		{
			String uri = request.getRequestURI();
			String path = uri.substring(request.getContextPath().length());
			String dispatcherType = request.getDispatcherType().name();

			//LOGGER.info("uri:" + uri + "\npath:" + path + "\ndispatcherType:" + dispatcherType);

			if (IdmpodThreadLocal.getAppId(true) == null)
			{
				if (IAMUtil.getCurrentUserOrg() != null && IAMUtil.getCurrentUser().isOrgAdmin())
				{
					try
					{
						if (!path.equals("/start") && !(isCommonSkipPath(path) || isResourcePath(path)))
						{
							response.sendRedirect("/start");//No I18N
							return;
						}
						//IdmpodUtils.handleFirstTimeLogin();
					}
					catch (Exception e)
					{
						LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
					}
				}
				else if (IAMUtil.getCurrentUserOrg() == null && IAMUtil.getCurrentUser() != null)
				{
					//Create new Org
					if (!path.equals("/createOrg") && !(isCommonSkipPath(path) || isResourcePath(path)))
					{
						response.sendRedirect("/createOrg");//No I18N
						return;
					}
				}
				else if (IAMUtil.getCurrentUser() != null)
				{
					//Only org admin can start subscription
					if (!path.startsWith("/debug"))
					{
						LOGGER.log(java.util.logging.Level.SEVERE, "User is part of org, but is not org admin");
						throw new IdmpodException(ErrorCode.USER_ACCESS_DENIED);
					}
				}
			}
			else
			{
				try
				{
					String status = IdmpodUtils.getOrgPreference(DBUtils.getReadOnlyAAPersistence(IdmpodThreadLocal.getAppId()), "STATUS");//No I18N
					if (status != null && status.equalsIgnoreCase("CLOSED") & (!path.equals("/restore") && !(isCommonSkipPath(path) || isResourcePath(path))))
					{
						response.sendRedirect("/restore");//No I18N
						return;
					}
					else
					{
						handleFirstTimeUserAccount();
					}
				}
				catch (Exception e)
				{
					LOGGER.log(Level.SEVERE, e.getMessage(), e);
				}
			}

			if (excludePattern != null && excludePattern.matcher(uri).matches())
			{
				fc.doFilter(req, res);
			}
			else
			{
				IdmpodThreadLocal.setRequestDetails(request, response);

				if ((path.equals("/admin") || path.startsWith("/admin/")))
				{
					if (isResourcePath(path))
					{
						// LOGGER.info("Forwarding resource request");
						request.getRequestDispatcher("/adminPortalAssets/" + path.substring(7)).forward(request, response);// No I18N
					}
					else if (path.endsWith(".woff") || path.endsWith(".woff2"))
					{
						//TODO: Workaround
						request.getRequestDispatcher("/adminPortalAssets/index.html").forward(request, response);// No I18N
					}
					else
					{
						// LOGGER.info("Forwarding request");
						AuditUtil.auditClientAccess(AuditUtil.OperationType.ACCESS_ADMIN_PORTAL, request);
						request.getRequestDispatcher("/adminPortalAssets/index.html").forward(request, response);// No I18N
					}
				}
				else if ((path.equals("/user") || path.startsWith("/user/")))
				{
					if (isResourcePath(path))
					{
						// LOGGER.info("Forwarding resource request");
						request.getRequestDispatcher("/userPortalAssets/" + path.substring(6)).forward(request, response);// No I18N
					}
					else if (path.endsWith(".woff") || path.endsWith(".woff2"))
					{
						//TODO: Workaround
						request.getRequestDispatcher("/userPortalAssets/index.html").forward(request, response);// No I18N
					}
					else
					{
						// LOGGER.info("Forwarding request");
						AuditUtil.auditClientAccess(AuditUtil.OperationType.ACCESS_USER_PORTAL, request);
						request.getRequestDispatcher("/userPortalAssets/index.html").forward(request, response);// No I18N
					}
				}
				else
				{
					fc.doFilter(request, response);
				}
			}


		}
		finally
		{
			IdmpodThreadLocal.clean();
		}
	}

	private boolean isResourcePath(String path)
	{
		boolean isRes = false;
		if (path.endsWith(".css") || path.endsWith(".js") || path.endsWith(".png") || path.endsWith(".gif") || path.endsWith(".ttf") || path.endsWith(".ico"))
		{
			isRes = true;
		}
		return isRes;
	}

	private boolean isCommonSkipPath(String path)
	{
		boolean isCommonSkip = false;
		if (path.startsWith("/debug") || path.startsWith("/api/") || path.startsWith("/_store/"))
		{
			isCommonSkip = true;
		}
		return isCommonSkip;
	}

	@Override
	public void destroy()
	{

	}

}
