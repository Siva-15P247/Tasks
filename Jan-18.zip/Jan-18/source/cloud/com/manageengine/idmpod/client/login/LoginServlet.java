package com.manageengine.idmpod.client.login;

import com.manageengine.idmpod.server.iam.IdmpodIAMUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.logging.Logger;

@WebServlet("/login")//No I18N
public class LoginServlet extends HttpServlet
{
	private static final Logger LOGGER = Logger.getLogger(LoginServlet.class.getName());

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String serviceurl = req.getParameter("serviceurl");
		String loginRedirectUrl = IdmpodIAMUtil.getLoginRedirectUrl(serviceurl);
		resp.sendRedirect(loginRedirectUrl);
	}
}
