package com.manageengine.idmpod.client.login;

import com.adventnet.persistence.DataAccessException;
import com.manageengine.idmpod.server.iam.IdmpodUserRole;
import com.manageengine.idmpod.server.iam.UserUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.logging.Logger;

public class HomeServlet extends HttpServlet
{
	private static final Logger LOGGER = Logger.getLogger(HomeServlet.class.getName());

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String uri = req.getRequestURI();
		String path = uri.substring(req.getContextPath().length());
		String dispatcherType = req.getDispatcherType().name();

		// LOGGER.info("HomeServlet get request hit");

		// LOGGER.info("uri:" + uri + "\npath:" + path + "\ndispatcherType:" + dispatcherType);

		try
		{
			if (UserUtils.getUserRole() == IdmpodUserRole.ADMINISTRATOR || UserUtils.getUserRole() == IdmpodUserRole.SUPER_ADMIN)
			{
				resp.sendRedirect("/admin");//No I18N
			}
			else
			{
				resp.sendRedirect("/user");//No I18N
			}
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
	}
}
