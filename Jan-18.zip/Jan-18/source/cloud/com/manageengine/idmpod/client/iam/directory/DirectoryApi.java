package com.manageengine.idmpod.client.iam.directory;

import com.adventnet.ds.query.QueryConstructionException;
import com.adventnet.iam.*;
import com.adventnet.persistence.DataAccessException;
import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.error.IdmpodException;
import com.manageengine.idmpod.server.iam.directory.DirectoryHandler;
import com.manageengine.idmpod.server.iam.directory.azure.AzureHandler;
import com.manageengine.idmpod.server.iam.directory.gsuite.GSuiteHandler;
import com.manageengine.idmpod.server.utils.AuditUtil;
import com.manageengine.tables.idmpod.IDMPODDIRECTORYTYPES;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DirectoryApi
{
	private static DirectoryApi instance = null;

	private static final Logger LOGGER = Logger.getLogger(DirectoryApi.class.getName());

	public static synchronized DirectoryApi getInstance()
	{
		if (instance == null)
		{
			instance = new DirectoryApi();
		}
		return instance;
	}

	public static JSONObject getDirectoryTypes(JSONObject request)
	{
		JSONObject resp = new JSONObject();
		resp.put(JsonApiConstants.DATA, DirectoryHandler.getDirectoryTypes());
		return resp;
	}

	public static JSONObject getDirectories(JSONObject request)
	{
		JSONObject resp = new JSONObject();
		resp.put(JsonApiConstants.DATA, DirectoryHandler.getDirectories());
		return resp;
	}

	public static JSONObject addDirectory(JSONObject request)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		JSONObject relationships = data.getJSONObject(JsonApiConstants.RELATIONSHIPS);
		JSONObject directoryTypeInfo = relationships.getJSONObject("directory-type").getJSONObject(JsonApiConstants.DATA);
		if (!directoryTypeInfo.has(JsonApiConstants.ATTRIBUTES))
		{
			directoryTypeInfo = DirectoryHandler.getDirectoryType(relationships.getJSONObject("directory-type").getJSONObject(JsonApiConstants.DATA).getLong(JsonApiConstants.ID));
		}
		JSONObject typeAttrs = directoryTypeInfo.getJSONObject(JsonApiConstants.ATTRIBUTES);
		JSONObject resp = null;
		if (typeAttrs.getString(IDMPODDIRECTORYTYPES.TYPE_HANDLER).equalsIgnoreCase("ActiveDirectory"))
		{
			resp = addActiveDirectory(request);
		}
		else if (typeAttrs.getString(IDMPODDIRECTORYTYPES.TYPE_HANDLER).equalsIgnoreCase("AzureActiveDirectory"))
		{
			resp = addAzureActiveDirectory(request);
		}
		else if (typeAttrs.getString(IDMPODDIRECTORYTYPES.TYPE_HANDLER).equalsIgnoreCase("GSuite"))
		{
			resp = addGSuiteDirectory(request);
		}

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.ADD_DIRECTORY);

		return resp;
	}

	private static JSONObject addGSuiteDirectory(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		JSONArray errorsArray = new JSONArray();

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		if (!attributes.has("DIRECTORY_DISPLAY_NAME") || !(attributes.getString("DIRECTORY_DISPLAY_NAME").trim().length() > 0))
		{
			errorsArray.put(JsonApiHandler.getErrorObject("DIRECTORY_DISPLAY_NAME", "Directory display name is mandatory"));
		}

		if (errorsArray != null && errorsArray.length() > 0)
		{
			errorsArray.put(JsonApiHandler.getBaseErrorObject("Please fix the error(s) and try again."));
			resp.put(JsonApiConstants.ERRORS, errorsArray);
		}
		else
		{
			GSuiteHandler.addDirectory(request, resp);
		}

		return resp;
	}

	public static JSONObject addAzureActiveDirectory(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		JSONArray errorsArray = new JSONArray();

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		if (!attributes.has("BASE_DOMAIN_NAME") || !(attributes.getString("BASE_DOMAIN_NAME").trim().length() > 0))
		{
			errorsArray.put(JsonApiHandler.getErrorObject("BASE_DOMAIN_NAME", "Directory domain name is mandatory"));
		}

		if (errorsArray != null && errorsArray.length() > 0)
		{
			errorsArray.put(JsonApiHandler.getBaseErrorObject("Please fix the error(s) and try again."));
			resp.put(JsonApiConstants.ERRORS, errorsArray);
		}
		else
		{
			AzureHandler.addDirectory(request, resp);
		}

		return resp;
	}

	public static JSONObject addActiveDirectory(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		JSONArray errorsArray = new JSONArray();

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		if (!attributes.has("LDAP_SERVER") || !(attributes.getString("LDAP_SERVER").trim().length() > 0))
		{
			errorsArray.put(JsonApiHandler.getErrorObject("LDAP_SERVER", "LDAP server name/ip is mandatory"));
		}
		if (!attributes.has("BASE_DOMAIN_NAME") || !(attributes.getString("BASE_DOMAIN_NAME").trim().length() > 0))
		{
			errorsArray.put(JsonApiHandler.getErrorObject("BASE_DOMAIN_NAME", "Base domain information is mandatory"));
		}
		if (!attributes.has("SERVICE_ACCOUNT_USERNAME") || !(attributes.getString("SERVICE_ACCOUNT_USERNAME").trim().length() > 0))
		{
			errorsArray.put(JsonApiHandler.getErrorObject("SERVICE_ACCOUNT_USERNAME", "Please provide Distinguished name of a service account"));
		}
		if (!attributes.has("SERVICE_ACCOUNT_PASSWORD") || !(attributes.getString("SERVICE_ACCOUNT_PASSWORD").trim().length() > 0))
		{
			errorsArray.put(JsonApiHandler.getErrorObject("SERVICE_ACCOUNT_PASSWORD", "Service account password is mandatory"));
		}


		if (errorsArray != null && errorsArray.length() > 0)
		{
			errorsArray.put(JsonApiHandler.getBaseErrorObject("Please fix the error(s) and try again."));
			resp.put(JsonApiConstants.ERRORS, errorsArray);
		}
		else
		{
			/////Calculate computed properties/////////
			StringBuffer ldapConnUrlB = new StringBuffer();
			ldapConnUrlB.append(attributes.getString("LDAP_SSL"));
			ldapConnUrlB.append("://");
			ldapConnUrlB.append(attributes.getString("LDAP_SERVER"));
			if (attributes.has("LDAP_PORT") && attributes.getString("LDAP_PORT").trim().length() > 0)
			{
				ldapConnUrlB.append(":");
				ldapConnUrlB.append(attributes.getString("LDAP_PORT"));
			}
			ldapConnUrlB.append("/");
			String baseDN = attributes.getString("BASE_DOMAIN_NAME");
			baseDN = String.join(",", Arrays.stream(baseDN.split(Pattern.quote("."))).map(s -> "dc=" + s).toArray(String[]::new));

			ldapConnUrlB.append(baseDN);
			String ldapConnectionUrl = ldapConnUrlB.toString();
			attributes.put("LDAP_CONNECTION_URL", ldapConnectionUrl);

			String serviceAccCtxName = attributes.getString("SERVICE_ACCOUNT_USERNAME");

			String[] domComps = attributes.getString("BASE_DOMAIN_NAME").split(Pattern.quote("."));

			for (String domComp : domComps)
			{
				serviceAccCtxName = serviceAccCtxName.replaceAll("(^|,)DC=" + domComp, "");//NO I18N
			}
			attributes.put("SERVICE_ACCOUNT_CONTEXT_NAME", serviceAccCtxName);
			/////Computed properties calculation ends//
			DirectoryHandler.verifyAndAddActiveDirectory(request, resp);
			//			if (DirectoryHandler.verifyLdapCredentials(request, resp))
			//			{
			//				resp.put(JsonApiConstants.DATA, DirectoryHandler.addDirectory(data));
			//			}
		}

		return resp;
	}

	public static JSONObject updateOrganizationalUnit(JSONObject request)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		JSONObject attributes = data.has(JsonApiConstants.ATTRIBUTES) ? data.getJSONObject(JsonApiConstants.ATTRIBUTES) : new JSONObject();
		DirectoryHandler.updateOrganizationUnit(data.getLong(JsonApiConstants.ID), attributes);

		return request;
	}

	public static JSONObject getOrganizationalUnits(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		resp.put(JsonApiConstants.DATA, DirectoryHandler.getOrganizationalUnits(request.getLong("directory")));

		return resp;
	}

	public static JSONObject getDomains(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		resp.put(JsonApiConstants.DATA, DirectoryHandler.getDomains(request.getLong("directory")));

		return resp;
	}

	public static JSONObject fetchSampleData(JSONObject request)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		try
		{
			// LOGGER.info(request.toString(4));
			Long jobid = DirectoryHandler.fetchSampleData(data.getLong(JsonApiConstants.ID));
			data.put(JsonApiConstants.ATTRIBUTES, new JSONObject().put("JOB_ID", jobid));
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (QueryConstructionException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return request;
	}

	public static JSONObject getDirectory(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		resp.put(JsonApiConstants.DATA, DirectoryHandler.getDirectory(data.getLong(JsonApiConstants.ID)));

		return resp;
	}

	public static JSONObject getSynchedObjects(JSONObject request) throws DataAccessException
	{
		List<Long> nodes = request.has("NODES") ? Stream.of(request.getString("NODES").split(",")).map(Long::parseLong).collect(Collectors.toList()) : null;//No I18N
		Long[] nodesArray = nodes != null ? nodes.toArray(new Long[nodes.size()]) : null;
		return DirectoryHandler.getSynchedObjects(request.getLong("DIRECTORY_ID"), request.optLong("JOB_ID"), nodesArray, request.optInt("PAGE_SIZE", 25), request.optInt("PAGE_NUMBER", 1));//No I18N
	}

	public static JSONObject setupDirectorySync(JSONObject request)
	{
		return DirectoryHandler.setupDirectorySync(request);
	}

	public static JSONObject deleteDirectory(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		JSONObject attributes = DirectoryHandler.getDirectory(data.getLong(JsonApiConstants.ID)).getJSONObject(JsonApiConstants.ATTRIBUTES);
		String dispName = attributes.has("DIRECTORY_DISPLAY_NAME") && attributes.getString("DIRECTORY_DISPLAY_NAME").trim().length() > 0 ? attributes.getString("DIRECTORY_DISPLAY_NAME") : attributes.getString("BASE_DOMAIN_NAME");//NO I18N
		DirectoryHandler.deleteDirectory(data.getLong(JsonApiConstants.ID));

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.DELETE_DIRECTORY, dispName);

		return resp;
	}

	public static JSONObject updateDirectory(JSONObject request)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		JSONObject attributes = data.has(JsonApiConstants.ATTRIBUTES) ? data.getJSONObject(JsonApiConstants.ATTRIBUTES) : new JSONObject();

		JSONObject resp = null;

		if (attributes.has("DAILY_SYNC_TIME_HOUR") || attributes.has("DAILY_SYNC_TIME_MIN"))
		{
			Long directoryId = data.getLong(JsonApiConstants.ID);
			DirectoryHandler.updateSchedule(directoryId, attributes.optString("DAILY_SYNC_TIME_HOUR", null), attributes.optString("DAILY_SYNC_TIME_MIN", null));//No I18N
			resp = getDirectory(request);
		}
		else
		{

			JSONObject relationships = data.getJSONObject(JsonApiConstants.RELATIONSHIPS);
			JSONObject directoryTypeInfo = relationships.getJSONObject("directory-type").getJSONObject(JsonApiConstants.DATA);
			if (!directoryTypeInfo.has(JsonApiConstants.ATTRIBUTES))
			{
				directoryTypeInfo = DirectoryHandler.getDirectoryType(relationships.getJSONObject("directory-type").getJSONObject(JsonApiConstants.DATA).getLong(JsonApiConstants.ID));
			}
			JSONObject typeAttrs = directoryTypeInfo.getJSONObject(JsonApiConstants.ATTRIBUTES);

			if (typeAttrs.getString(IDMPODDIRECTORYTYPES.TYPE_HANDLER).equalsIgnoreCase("ActiveDirectory"))
			{
				resp = updateActiveDirectory(request);
			}
			else if (typeAttrs.getString(IDMPODDIRECTORYTYPES.TYPE_HANDLER).equalsIgnoreCase("AzureActiveDirectory"))
			{
				resp = updateAzureActiveDirectory(request);
			}
			else if (typeAttrs.getString(IDMPODDIRECTORYTYPES.TYPE_HANDLER).equalsIgnoreCase("GSuite"))
			{
				resp = updateGSuiteDirectory(request);
			}
		}

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.UPDATE_DIRECTORY);
		return resp;

	}

	private static JSONObject updateActiveDirectory(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		JSONArray errorsArray = new JSONArray();

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		Long directoryId = data.getLong(JsonApiConstants.ID);

		JSONObject newattributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		JSONObject attributes = getDirectory(request).getJSONObject(JsonApiConstants.DATA).getJSONObject(JsonApiConstants.ATTRIBUTES);

		for (String key : newattributes.keySet())
		{
			attributes.put(key, newattributes.get(key));
		}
		data.put(JsonApiConstants.ATTRIBUTES, attributes);

		if (!attributes.has("LDAP_SERVER") || !(attributes.getString("LDAP_SERVER").trim().length() > 0))
		{
			errorsArray.put(JsonApiHandler.getErrorObject("LDAP_SERVER", "LDAP server name/ip is mandatory"));
		}
		if (!attributes.has("BASE_DOMAIN_NAME") || !(attributes.getString("BASE_DOMAIN_NAME").trim().length() > 0))
		{
			errorsArray.put(JsonApiHandler.getErrorObject("BASE_DOMAIN_NAME", "Base domain information is mandatory"));
		}
		if (!attributes.has("SERVICE_ACCOUNT_USERNAME") || !(attributes.getString("SERVICE_ACCOUNT_USERNAME").trim().length() > 0))
		{
			errorsArray.put(JsonApiHandler.getErrorObject("SERVICE_ACCOUNT_USERNAME", "Please provide Distinguished name of a service account"));
		}
		if (!attributes.has("SERVICE_ACCOUNT_PASSWORD") || !(attributes.getString("SERVICE_ACCOUNT_PASSWORD").trim().length() > 0))
		{
			errorsArray.put(JsonApiHandler.getErrorObject("SERVICE_ACCOUNT_PASSWORD", "Service account password is mandatory"));
		}


		if (errorsArray != null && errorsArray.length() > 0)
		{
			errorsArray.put(JsonApiHandler.getBaseErrorObject("Please fix the error(s) and try again."));
			resp.put(JsonApiConstants.ERRORS, errorsArray);
		}
		else
		{
			/////Calculate computed properties/////////
			StringBuffer ldapConnUrlB = new StringBuffer();
			ldapConnUrlB.append(attributes.getString("LDAP_SSL"));
			ldapConnUrlB.append("://");
			ldapConnUrlB.append(attributes.getString("LDAP_SERVER"));
			if (attributes.has("LDAP_PORT") && attributes.getString("LDAP_PORT").trim().length() > 0)
			{
				ldapConnUrlB.append(":");
				ldapConnUrlB.append(attributes.getString("LDAP_PORT"));
			}
			ldapConnUrlB.append("/");
			String baseDN = attributes.getString("BASE_DOMAIN_NAME");
			baseDN = String.join(",", Arrays.stream(baseDN.split(Pattern.quote("."))).map(s -> "dc=" + s).toArray(String[]::new));

			ldapConnUrlB.append(baseDN);
			String ldapConnectionUrl = ldapConnUrlB.toString();
			attributes.put("LDAP_CONNECTION_URL", ldapConnectionUrl);

			String serviceAccCtxName = attributes.getString("SERVICE_ACCOUNT_USERNAME");

			String[] domComps = attributes.getString("BASE_DOMAIN_NAME").split(Pattern.quote("."));

			for (String domComp : domComps)
			{
				serviceAccCtxName = serviceAccCtxName.replaceAll("(^|,)DC=" + domComp, "");//NO I18N
			}
			attributes.put("SERVICE_ACCOUNT_CONTEXT_NAME", serviceAccCtxName);
			/////Computed properties calculation ends//
			DirectoryHandler.verifyAndUpdateActiveDirectory(directoryId, request, resp);
			//			if (DirectoryHandler.verifyLdapCredentials(request, resp))
			//			{
			//				resp.put(JsonApiConstants.DATA, DirectoryHandler.addDirectory(data));
			//			}
		}

		return resp;
	}

	private static JSONObject updateGSuiteDirectory(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		Long directoryId = data.getLong(JsonApiConstants.ID);

		JSONObject newattributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		JSONObject attributes = getDirectory(request).getJSONObject(JsonApiConstants.DATA).getJSONObject(JsonApiConstants.ATTRIBUTES);

		for (String key : newattributes.keySet())
		{
			attributes.put(key, newattributes.get(key));
		}
		data.put(JsonApiConstants.ATTRIBUTES, attributes);

		GSuiteHandler.updateDirectory(request, resp);

		return resp;
	}

	private static JSONObject updateAzureActiveDirectory(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		Long directoryId = data.getLong(JsonApiConstants.ID);

		JSONObject newattributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		JSONObject attributes = getDirectory(request).getJSONObject(JsonApiConstants.DATA).getJSONObject(JsonApiConstants.ATTRIBUTES);

		for (String key : newattributes.keySet())
		{
			attributes.put(key, newattributes.get(key));
		}
		data.put(JsonApiConstants.ATTRIBUTES, attributes);

		AzureHandler.updateDirectory(request, resp);

		return resp;
	}

	public static JSONObject importDirectoryUsers(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		String[] remarks = null;

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		Long directoryId = data.getLong(JsonApiConstants.ID);

		JSONArray userids = request.getJSONArray("USERS");//NO I18N

		JSONObject status = DirectoryHandler.importDirectoryUsers(directoryId, userids);
		remarks = (String[]) status.opt("REMARKS");//NO I18N
		if (status.has("ERRORS"))
		{
			resp.put(JsonApiConstants.ERRORS, status.getJSONArray("ERRORS"));
		}

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.IMPORT_DIRECTORY_USERS, remarks);

		return resp;
	}

	public static JSONObject addUsersToDirectory(JSONObject request)
	{
		String remarks = null;
		JSONObject resp = new JSONObject();

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		Long directoryId = data.getLong(JsonApiConstants.ID);

		JSONArray emailIds = request.getJSONArray("EMAILS");//NO I18N

		if (directoryId == 0L)
		{
			JSONObject status = DirectoryHandler.addUsersToIAM(emailIds);
			remarks = status.optString("REMARKS", null);//NO I18N
			if (status.has("ERRORS"))
			{
				resp.put(JsonApiConstants.ERRORS, status.getJSONArray("ERRORS"));
			}
		}

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.ADD_USERS_TO_DIRECTORY, remarks);

		return resp;
	}

	public static JSONObject syncNow(JSONObject request)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		try
		{
			Long jobid = DirectoryHandler.syncNow(data.getLong(JsonApiConstants.ID));
			data.put(JsonApiConstants.ATTRIBUTES, new JSONObject().put("JOB_ID", jobid));
		}
		catch (DataAccessException | QueryConstructionException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return request;
	}

	public static JSONObject addPublicDomain(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		JSONArray errorsArray = new JSONArray();

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		if (!attributes.has("DOMAIN_NAME") || !(attributes.getString("DOMAIN_NAME").trim().length() > 0))
		{
			errorsArray.put(JsonApiHandler.getErrorObject("DOMAIN_NAME", "Please enter the domain name"));
		}

		if (errorsArray != null && errorsArray.length() > 0)
		{
			errorsArray.put(JsonApiHandler.getBaseErrorObject("Please fix the error(s) and try again."));
			resp.put(JsonApiConstants.ERRORS, errorsArray);
		}
		else
		{
			resp = DirectoryHandler.addPublicDomain(request, resp);
		}

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.ADD_PUBLIC_DOMAIN);

		return resp;
	}

	public static JSONObject getPublicDomains(JSONObject request)
	{
		JSONObject resp = new JSONObject();
		JSONArray domains = new JSONArray();

		OrgAPI orgAPI = IAMProxy.getInstance().getOrgAPI();
		long zoid = IAMUtil.getCurrentUser().getZOID();
		try
		{
			List<OrgDomain> domainlist = orgAPI.getAllOrgDomain(zoid);
			if (domainlist != null)
			{
				for (OrgDomain domain : domainlist)
				{
					domains.put(DirectoryHandler.getPublicDomainAsJSON(domain));
				}
			}
		}
		catch (IAMException e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		resp.put(JsonApiConstants.DATA, domains);
		return resp;
	}

	public static JSONObject updatePublicDomain(JSONObject request)
	{
		JSONObject resp = new JSONObject();
		JSONArray errorsArray = new JSONArray();

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);
		String domainName = data.getString(JsonApiConstants.ID);
		if (attributes.optBoolean("IS_VERIFYING"))
		{
			int verificationMode = attributes.optInt("VERIFICATION_MODE", OrgDomain.HTML_VERIFICATION_MODE);//No I18N
			try
			{
				DirectoryHandler.verifyDomain(domainName, verificationMode);
			}
			catch (IAMException e)
			{
				String error = IdmpodException.getErrorMessageForIAMException(e);
				errorsArray.put(JsonApiHandler.getBaseErrorObject(error));
			}
			catch (IdmpodException ie)
			{
				LOGGER.log(Level.SEVERE, ie.getErrorCode().getMessage());
				String error = ie.getErrorCode().getI18nMsg();
				errorsArray.put(JsonApiHandler.getBaseErrorObject(error));
			}
		}

		if (errorsArray.length() > 0)
		{
			resp.put(JsonApiConstants.ERRORS, errorsArray);
			return resp;
		}
		else
		{
			resp = DirectoryHandler.getPublicDomain(domainName);
		}

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.UPDATE_PUBLIC_DOMAIN);

		return resp;
	}

	public static JSONObject deletePublicDomain(JSONObject request)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		String domainName = data.getString(JsonApiConstants.ID);
		DirectoryHandler.deletePublicDomain(domainName);
		AuditUtil.auditAdminOperation(request, null, AuditUtil.OperationType.DELETE_PUBLIC_DOMAIN, domainName);
		return null;
	}

}
