package com.manageengine.idmpod.client.iam.directory.azure;

import com.adventnet.i18n.I18N;
import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.iam.directory.azure.AzureHandler;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AzureApi
{
	private static final Logger LOGGER = Logger.getLogger(AzureApi.class.getName());

	private static AzureApi instance = null;

	public static synchronized AzureApi getInstance()
	{
		if (instance == null)
		{
			instance = new AzureApi();
		}
		return instance;
	}

	public static JSONObject createAuthToken(JSONObject request) throws JSONException, IOException
	{
		JSONObject resp = new JSONObject();

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		String tenantId = null;
		tenantId = attributes.optString("TENANT_ID"); //No I18N

		if (tenantId == null || tenantId.trim().length() == 0)
		{
			JSONArray errorsArray = new JSONArray();
			try
			{
				errorsArray.put(JsonApiHandler.getBaseErrorObject(I18N.getMsg("idmpod.directory.add_directory.error.tenant_identifier")));
			}
			catch (Exception e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
			resp.put(JsonApiConstants.ERRORS, errorsArray);
			return resp;
		}

		final String TYPE = JsonApiHandler.ResourceType.AZURE_AUTH_TOKEN.getResType();

		JSONObject respAttributes = new JSONObject();

		String id = AzureHandler.createAuthToken();

		respAttributes.put("AUTHORIZATION_URL", AzureHandler.ACTIVE_DIRECTORY_ENDPOINT_URL + tenantId + "/oauth2/authorize?client_id=" + AzureHandler.CLIENT_ID + "&response_type=code&redirect_uri=" + AzureHandler.getRedirectUrl() + "&prompt=admin_consent&state=" + id); // NO I18N

		resp.put(JsonApiConstants.DATA, JsonApiHandler.getResourceObject(TYPE, id, respAttributes));

		return resp;
	}

	public static JSONObject getAuthToken(JSONObject request)
	{
		JSONObject resp = new JSONObject();
		resp.put(JsonApiConstants.DATA, AzureHandler.getAuthToken(request.getJSONObject(JsonApiConstants.DATA).optString(JsonApiConstants.ID)));
		return resp;
	}

}
