package com.manageengine.idmpod.client.reports;

import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.utils.AuditUtil;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.logging.Logger;

public class AuditApi
{
	private static final Logger LOGGER = Logger.getLogger(AuditApi.class.getName());

	private static AuditApi instance = null;

	public static synchronized AuditApi getInstance()
	{
		if (instance == null)
		{
			instance = new AuditApi();
		}
		return instance;
	}

	public static JSONObject getAppAccessEvents(JSONObject request)
	{
		JSONArray filterArray = null;
		if (request.has(JsonApiConstants.FILTER))
		{
			filterArray = new JSONArray(request.getString(JsonApiConstants.FILTER));
		}
		return AuditUtil.getAppAccessEvents(request.optInt("PAGE_SIZE", 25), request.optInt("PAGE_NUMBER", 1), filterArray);//No I18N
	}

	public static JSONObject getAdminAuditEvents(JSONObject request)
	{
		JSONArray filterArray = null;
		if (request.has(JsonApiConstants.FILTER))
		{
			filterArray = new JSONArray(request.getString(JsonApiConstants.FILTER));
		}
		JSONArray searchArray = null;
		if (request.has(JsonApiConstants.SEARCH))
		{
			searchArray = new JSONArray(request.getString(JsonApiConstants.SEARCH));
		}
		return AuditUtil.getAdminAuditEvents(request.optInt("PAGE_SIZE", 25), request.optInt("PAGE_NUMBER", 1), filterArray, searchArray);//No I18N
	}

}
