package com.manageengine.idmpod.client.reports;

import com.manageengine.idmpod.server.reports.DashboardHandler;
import org.json.JSONObject;

import java.util.logging.Logger;

public class DashboardApi
{
	private static final Logger LOGGER = Logger.getLogger(DashboardApi.class.getName());

	private static DashboardApi instance = null;

	public static synchronized DashboardApi getInstance()
	{
		if (instance == null)
		{
			instance = new DashboardApi();
		}
		return instance;
	}

	public static JSONObject getCurrentDashboard(JSONObject request)
	{
		return DashboardHandler.getCurrentDashboard();
	}
}
