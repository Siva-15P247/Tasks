package com.manageengine.idmpod.client.reports;

import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.reports.ReportsHandler;
import com.manageengine.tables.idmpod.IDMPODREPORTS;
import org.json.JSONObject;

import java.util.logging.Logger;

public class ReportsApi
{
	private static final Logger LOGGER = Logger.getLogger(ReportsApi.class.getName());

	private static ReportsApi instance = null;

	public static synchronized ReportsApi getInstance()
	{
		if (instance == null)
		{
			instance = new ReportsApi();
		}
		return instance;
	}

	public static JSONObject getReports(JSONObject request)
	{
		return ReportsHandler.getReports();
	}

	public static JSONObject getReportFields(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		resp.put(JsonApiConstants.DATA, ReportsHandler.getReportFields(request.getLong(IDMPODREPORTS.REPORT_ID)));

		return resp;
	}
}
