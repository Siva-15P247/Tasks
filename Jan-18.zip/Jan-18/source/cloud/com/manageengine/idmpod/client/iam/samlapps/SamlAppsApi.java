package com.manageengine.idmpod.client.iam.samlapps;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMException;
import com.adventnet.iam.IAMProxy;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.OrgAPI;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.error.ErrorCode;
import com.manageengine.idmpod.server.error.IdmpodException;
import com.manageengine.idmpod.server.iam.IdmpodIAMUtil;
import com.manageengine.idmpod.server.iam.samlapps.SamlAppsHandler;
import com.manageengine.idmpod.server.iam.samlapps.SamlMetaDataUtil;
import com.manageengine.idmpod.server.utils.AuditUtil;
import com.manageengine.tables.idmpod.IDMPODTECHNICIAN;
import com.zoho.accounts.AccountsProto;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.routines.UrlValidator;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class SamlAppsApi
{
	private static final Logger LOGGER = Logger.getLogger(SamlAppsApi.class.getName());

	private static SamlAppsApi instance = null;

	private static UrlValidator urlValidator = new UrlValidator();

	public static synchronized SamlAppsApi getInstance()
	{
		if (instance == null)
		{
			instance = new SamlAppsApi();
		}
		return instance;
	}

	public static JSONObject getSamlAppTemplates(JSONObject request)
	{
		JSONObject resp = new JSONObject();
		resp.put(JsonApiConstants.DATA, SamlAppsHandler.getSamlAppTemplates());
		return resp;
	}

	public static JSONObject getSamlAppTemplate(JSONObject request)
	{
		JSONObject resp = new JSONObject();
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		resp.put(JsonApiConstants.DATA, SamlAppsHandler.getSamlAppTemplate(data.getLong(JsonApiConstants.ID)));
		return resp;
	}

	public static JSONObject getConfiguredSamlApps(JSONObject request)
	{
		JSONObject resp = new JSONObject();
		try
		{
			JSONArray configuredSamlApps = new JSONArray();
			List<AccountsProto.Account.SAMLApp> samlApps = null;
			if (request.has("USER_ID"))
			{
				String user_id = request.getString("USER_ID");
				String zuid = null;
				DataObject dataobj = null;
				try
				{
					Criteria c = new Criteria(new Column(IDMPODTECHNICIAN.TABLE, "USER_ID"), Long.parseLong(user_id), QueryConstants.EQUAL);
					dataobj = DBUtils.getOrgPersistence().get(IDMPODTECHNICIAN.TABLE, c);
					Row r = dataobj.getRow(IDMPODTECHNICIAN.TABLE);
					zuid = r.get(IDMPODTECHNICIAN.ZUID).toString();

				}
				catch (Exception e)
				{
					LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
				}
				OrgAPI orgAPI = IAMProxy.getInstance().getOrgAPI();
				samlApps = orgAPI.getSamlAppsofUser(zuid);
			}
			else
			{
				samlApps = SamlAppsHandler.getAllSAMLApps();
			}
			String zoid = IdmpodIAMUtil.getZOID().toString();
			if (!request.has("PAGE_SIZE") && !request.has("PAGE_NUMBER"))
			{
				if (samlApps != null)
				{
					for (AccountsProto.Account.SAMLApp samlApp : samlApps)
					{
						configuredSamlApps.put(SamlAppsHandler.getSAMLAppAsJSONObject(samlApp, zoid));
					}
				}
			}
			else
			{
				if (request.has(JsonApiConstants.SEARCH))
				{
					JSONArray searchArray = new JSONArray(request.getString(JsonApiConstants.SEARCH));
					for (int i = 0; i < searchArray.length(); i++)
					{
						JSONObject searchObj = searchArray.getJSONObject(i);
						Iterator<String> keys = searchObj.keys();
						while (keys.hasNext())
						{
							String key = keys.next();
							if (key.equalsIgnoreCase("APP_NAME"))
							{
								String searchString = searchObj.getString(key);
								samlApps = samlApps.stream().filter(app -> StringUtils.containsIgnoreCase(app.getAppName(), searchString)).collect(Collectors.toList());
							}
						}
					}
				}
				JSONObject meta = new JSONObject();
				Integer totalCount = samlApps.size();
				Integer page_number = request.optInt("PAGE_NUMBER", 1); //No I18N
				Integer page_size = request.optInt("PAGE_SIZE", 25); //No I18N
				Boolean atLastPage = (page_number * page_size) >= totalCount;

				meta.put("FIRST", 1);
				meta.put("NEXT", atLastPage ? null : page_number + 1);
				meta.put("PREV", page_number > 1 ? page_number - 1 : null);
				meta.put("LAST", Math.ceil(totalCount.doubleValue() / page_size.doubleValue()));
				meta.put("TOTAL", totalCount);
				meta.put("START_INDEX", (page_number - 1) * page_size + 1);
				meta.put("END_INDEX", (page_number * page_size) > totalCount ? totalCount : (page_number * page_size));

				resp.put(JsonApiConstants.META, meta);

				for (int i = meta.getInt("START_INDEX") - 1; i < meta.getInt("END_INDEX"); i++)
				{
					AccountsProto.Account.SAMLApp samlApp = samlApps.get(i);
					configuredSamlApps.put(SamlAppsHandler.getSAMLAppAsJSONObject(samlApp, zoid));
				}
			}
			resp.put(JsonApiConstants.DATA, configuredSamlApps);
		}
		catch (IAMException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return resp;
	}

	public static JSONObject getConfiguredSamlApp(JSONObject request)
	{
		JSONObject resp = new JSONObject();
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		JSONObject configuredSamlApp = null;
		try
		{
			AccountsProto.Account.SAMLApp samlApp = SamlAppsHandler.getSAMLApp(data.optString(JsonApiConstants.ID));
			String zoid = IdmpodIAMUtil.getZOID().toString();
			configuredSamlApp = SamlAppsHandler.getSAMLAppAsJSONObject(samlApp, zoid);
			resp.put(JsonApiConstants.DATA, configuredSamlApp);
		}
		catch (IAMException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		finally
		{
			if (configuredSamlApp == null)
			{
				throw new IdmpodException(ErrorCode.API_RESOURCE_NOT_EXIST);
			}
		}
		return resp;
	}

	public static JSONObject addSamlApp(JSONObject request)
	{
		// LOGGER.log(Level.INFO, "Add SAML app request:" + request.toString(4));
		JSONObject resp = null;

		JSONArray errorsArray = new JSONArray();

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		if (!attributes.has("APP_NAME") || !(attributes.getString("APP_NAME").trim().length() > 0))
		{
			errorsArray.put(JsonApiHandler.getErrorObject("APP_NAME", "Application name is mandatory"));
		}

		JSONObject template = data.has(JsonApiConstants.RELATIONSHIPS) ? data.getJSONObject(JsonApiConstants.RELATIONSHIPS).optJSONObject("template") : null;//No I18N

		//		if (template == null || template.isNull(JsonApiConstants.DATA))
		//		{
		//			errorsArray.put(JsonApiHandler.getBaseErrorObject("Please select a application type."));
		//		}

		if (errorsArray != null && errorsArray.length() > 0)
		{
			request.put(JsonApiConstants.ERRORS, errorsArray);
		}

		if (template != null && !template.isNull(JsonApiConstants.DATA))
		{
			//TODO: Template specific validations handling
			if (attributes.has("IS_METADATA_UPLOADED") && attributes.getBoolean("IS_METADATA_UPLOADED"))
			{
				SamlAppsHandler.addSamlAppFromMetadata(request, request);
			}
			else
			{
				SamlAppsHandler.addTemplateApp(request, request);
			}
		}
		else
		{
			if (!attributes.has("LOGIN_URL") || !(attributes.getString("LOGIN_URL").trim().length() > 0))
			{
				errorsArray.put(JsonApiHandler.getErrorObject("LOGIN_URL", "SSO URL is mandatory"));
			}
			if (!attributes.has("ACS_URL") || !(attributes.getString("ACS_URL").trim().length() > 0))
			{
				errorsArray.put(JsonApiHandler.getErrorObject("ACS_URL", "ACS URL is mandatory"));
			}
			if (!attributes.has("ENTITYID") || !(attributes.getString("ENTITYID").trim().length() > 0))
			{
				errorsArray.put(JsonApiHandler.getErrorObject("ENTITYID", "Entity ID is mandatory"));
			}
			SamlAppsHandler.addCustomApp(request, request);
		}

		if (request.has(JsonApiConstants.ERRORS))
		{
			errorsArray = request.getJSONArray(JsonApiConstants.ERRORS);

			if (errorsArray.length() > 0)
			{
				errorsArray.put(JsonApiHandler.getBaseErrorObject("Please fix the error(s) and submit again."));
			}
			resp = request;
		}
		else
		{
			resp = getConfiguredSamlApp(request);
		}
		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.ADD_SAML_APP);
		return resp;
	}

	public static JSONObject getSamlAppCategories(JSONObject request)
	{
		JSONObject resp = new JSONObject();
		resp.put(JsonApiConstants.DATA, SamlAppsHandler.getSamlAppCategories());
		return resp;
	}

	public static JSONObject getSamlAppConfigurationDetails(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		// LOGGER.info(request.toString(4));

		return resp;
	}

	public static JSONObject updateSamlApp(JSONObject request)
	{
		JSONObject resp = null;
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		try
		{
			JSONObject attributes = data.has(JsonApiConstants.ATTRIBUTES) ? data.getJSONObject(JsonApiConstants.ATTRIBUTES) : new JSONObject();
			resp = SamlAppsHandler.updateSamlApp(data.getLong(JsonApiConstants.ID), attributes);
		}
		catch (IAMException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			resp = getConfiguredSamlApp(request);
		}
		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.UPDATE_SAML_APP);
		return resp;
	}

	public static JSONObject assignUsersToSamlApp(JSONObject request)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		String remarks[] = null;

		try
		{
			remarks = SamlAppsHandler.assignUsersToSAMLApp(data.getLong(JsonApiConstants.ID), request.getJSONArray("USERS"));//No I18N
		}
		catch (IAMException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}

		JSONObject resp = getConfiguredSamlApp(request);

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.ASSIGN_USERS_TO_SAML_APP, remarks);

		return resp;
	}

	public static JSONObject removeUsersFromSamlApp(JSONObject request)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		String[] remarks = null;

		try
		{
			if (request.has("USERS"))
			{
				remarks = SamlAppsHandler.removeUsersFromSAMLApp(data.getLong(JsonApiConstants.ID), request.getJSONArray("USERS"));//No I18N
			}
			else if (request.has("USER"))
			{
				JSONArray userIds = request.getJSONArray("USER"); //No I18N
				String[] userids = userIds.toList().toArray(new String[0]);
				String user_id = userids[0];
				DataObject dataobj = null;
				JSONArray ja = new JSONArray();
				try
				{
					Criteria c = new Criteria(new Column(IDMPODTECHNICIAN.TABLE, "USER_ID"), Long.parseLong(user_id), QueryConstants.EQUAL); //No I18N
					dataobj = DBUtils.getOrgPersistence().get(IDMPODTECHNICIAN.TABLE, c);
					Row r = dataobj.getRow(IDMPODTECHNICIAN.TABLE);
					ja.put(r.get(IDMPODTECHNICIAN.ZUID));
				}
				catch (Exception e)
				{
					LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
				}
				remarks = SamlAppsHandler.removeUsersFromSAMLApp(data.getLong(JsonApiConstants.ID), ja);
			}
		}
		catch (IAMException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}

		JSONObject resp = getConfiguredSamlApp(request);

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.REMOVE_USERS_FROM_SAML_APP, remarks);

		return resp;
	}


	public static JSONObject deleteSamlApp(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		String dispName = null;
		try
		{
			dispName = SamlAppsHandler.getSAMLApp(data.optString(JsonApiConstants.ID)).getAppName();
		}
		catch (IAMException e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		SamlAppsHandler.deleteSAMLApp(data.getLong(JsonApiConstants.ID));

		AuditUtil.auditAdminOperation(request, resp, AuditUtil.OperationType.DELETE_SAML_APP, dispName);

		return resp;
	}

	public static JSONObject getUserSamlApps(JSONObject request)
	{
		JSONObject resp = new JSONObject();
		try
		{
			JSONArray configuredSamlApps = new JSONArray();
			List<AccountsProto.Account.SAMLApp> samlApps = SamlAppsHandler.getUserSamlApps(IAMUtil.getCurrentUser().getZUID());
			String zoid = IdmpodIAMUtil.getZOID().toString();
			if (samlApps != null)
			{
				for (AccountsProto.Account.SAMLApp samlApp : samlApps)
				{
					configuredSamlApps.put(SamlAppsHandler.getSAMLAppAsJSONObject(samlApp, zoid, "user-saml-apps"));
				}
			}
			resp.put(JsonApiConstants.DATA, configuredSamlApps);
		}
		catch (IAMException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return resp;
	}

	public static JSONObject parseSPMetadata(JSONObject request)
	{
		JSONObject resp = new JSONObject();

		String sp_metadata = request.getString("SP_METADATA");

		// LOGGER.info("\n" + sp_metadata + "\n");

		JSONObject parsedSPmetadata = SamlMetaDataUtil.parseSPMetadataFile(sp_metadata);
		resp.put(JsonApiConstants.DATA, JsonApiHandler.getResourceObject("parsed-sp-metadata", "0", parsedSPmetadata));

		return resp;
	}

}
