package com.manageengine.idmpod.client.login;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.logging.Logger;

@WebServlet("/invitationaccept")//No I18N
public class InvitationAcceptServlet extends HttpServlet
{
	private static final Logger LOGGER = Logger.getLogger(InvitationAcceptServlet.class.getName());

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String uri = req.getRequestURI();
		String path = uri.substring(req.getContextPath().length());
		String dispatcherType = req.getDispatcherType().name();

		// LOGGER.info("InvitationAcceptServlet get request hit");

		// LOGGER.info("uri:" + uri + "\npath:" + path + "\ndispatcherType:" + dispatcherType);

		try
		{
			resp.sendRedirect("/");//No I18N
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
	}
}
