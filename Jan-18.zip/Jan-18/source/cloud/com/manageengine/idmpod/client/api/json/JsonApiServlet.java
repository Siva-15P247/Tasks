package com.manageengine.idmpod.client.api.json;

import com.manageengine.idmpod.server.api.json.JsonApiHandler;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.logging.Logger;

@WebServlet("/api/json/*")
public class JsonApiServlet extends HttpServlet
{
	private static final Logger LOGGER = Logger.getLogger(JsonApiServlet.class.getName());

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		String method = req.getMethod();

		switch (method)
		{
			case "GET":
			case "HEAD":
			case "POST":
			case "PUT":
			case "DELETE":
			case "OPTIONS":
			case "TRACE":
			case "PATCH":
				processRequest(req, resp);
		}

	}

	/*
	 * Request URI should be in the following pattern: URI = /api/json/object
	 */
	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		try
		{
			request.setCharacterEncoding("UTF-8");// NO I18N
			int errCode = JsonApiHandler.getInstance().execute(request, response);
			if (errCode != HttpServletResponse.SC_OK && errCode != HttpServletResponse.SC_NO_CONTENT)
			{
				if (errCode != JsonApiHandler.UNPROCESSABLE_ENTITY)
				{
					response.sendError(errCode);
				}
			}
		}
		catch (Exception ex)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, ex.getMessage(), ex);
		}
	}
}
