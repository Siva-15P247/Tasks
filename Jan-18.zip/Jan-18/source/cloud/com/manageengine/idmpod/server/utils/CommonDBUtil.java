package com.manageengine.idmpod.server.utils;


import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.Org;
import com.adventnet.iam.User;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.*;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.error.ErrorCode;
import com.manageengine.idmpod.server.error.IdmpodException;
import com.manageengine.idmpod.server.iam.InviteUtils;
import com.manageengine.idmpod.server.iam.UserUtils;
import com.manageengine.tables.idmpod.IDMPODAUDITPREFERENCES;
import com.manageengine.tables.idmpod.IDMPODJOBSVSORG;
import com.manageengine.tables.idmpod.IDMPODORG;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;


public class CommonDBUtil
{

	private static final Logger LOGGER = Logger.getLogger(CommonDBUtil.class.getName());

	public static final String IDMPODADMIN = "IdmpodAdmin"; //No I18N
	public static final String BEAN_PERSISTENCE = "Persistence";//No I18N
	public static final String BEAN_RO_PERSISTENCE = "PureReadOnlyPersistence";//No I18N

	private static Persistence commonPersistence = null;
	private static ReadOnlyPersistence readOnlyCommonPersistence = null;

	public static Persistence getPersistance() throws Exception
	{
		if (commonPersistence == null)
		{
			CollaborationUtils.reserveSpace(IDMPODADMIN);
			commonPersistence = (Persistence) BeanUtil.lookup(BEAN_PERSISTENCE, IDMPODADMIN);
		}
		return commonPersistence;
	}

	public static ReadOnlyPersistence getReadOnlyPersistance() throws Exception
	{
		if (readOnlyCommonPersistence == null)
		{
			CollaborationUtils.reserveSpace(IDMPODADMIN);
			readOnlyCommonPersistence = (ReadOnlyPersistence) BeanUtil.lookup(BEAN_RO_PERSISTENCE, IDMPODADMIN);
		}
		return readOnlyCommonPersistence;
	}

	public static void addJobInCommonDB(Long jobid) throws Exception
	{
		Org org = IAMUtil.getCurrentUserOrg();
		long zoid = org.getZOID();

		Persistence persistence = getPersistance();
		Criteria crit = new Criteria(new Column(IDMPODORG.TABLE, IDMPODORG.ZOID), zoid, QueryConstants.EQUAL);
		DataObject orgDO = persistence.get(IDMPODORG.TABLE, crit);
		Row row = orgDO.getRow(IDMPODORG.TABLE);
		if (row == null)
		{
			return;
		}
		Row r = new Row(IDMPODJOBSVSORG.TABLE);
		r.set(IDMPODJOBSVSORG.JOB_ID, jobid);
		r.set(IDMPODJOBSVSORG.ORG_ID, row.get(IDMPODORG.ORG_ID));
		orgDO.addRow(r);
		persistence.update(orgDO);
	}

	public static Row getOrgRowForJob(Long jobid) throws Exception
	{
		Row r = null;

		Persistence persistence = getPersistance();

		Criteria crit = new Criteria(new Column(IDMPODJOBSVSORG.TABLE, IDMPODJOBSVSORG.JOB_ID), jobid, QueryConstants.EQUAL);

		ArrayList<String> tablesList = new ArrayList<String>();
		tablesList.add(IDMPODORG.TABLE);
		tablesList.add(IDMPODJOBSVSORG.TABLE);

		boolean[] isLeftJoins = new boolean[tablesList.size()];
		Arrays.fill(isLeftJoins, true);

		SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, crit);

		DataObject orgInfoDO = persistence.get(query);

		if (orgInfoDO.containsTable(IDMPODORG.TABLE))
		{
			r = orgInfoDO.getRow(IDMPODORG.TABLE);
		}
		return r;
	}

	public static Long addOrgInCommonDb(long zoid, String orgName, String zaid, String zaaid) throws Exception
	{
		Long orgId = -1l;
		Persistence persistence = getPersistance();
		Criteria crit = new Criteria(new Column(IDMPODORG.TABLE, IDMPODORG.ZOID), zoid, QueryConstants.EQUAL);
		DataObject orgDO = persistence.get(IDMPODORG.TABLE, crit);
		Row row = orgDO.getRow(IDMPODORG.TABLE);
		if (row == null)
		{
			row = new Row(IDMPODORG.TABLE);
			row.set(IDMPODORG.CREATEDTIME, System.currentTimeMillis());
			orgDO.addRow(row);
		}
		row.set(IDMPODORG.ZOID, zoid);
		row.set(IDMPODORG.NAME, orgName);
		row.set(IDMPODORG.ZAID, zaid);
		row.set(IDMPODORG.ZAAID, zaaid);
		persistence.update(orgDO);
		orgId = (Long) (row.get(IDMPODORG.ORG_ID));
		return orgId;
	}


	/**
	 * Most of the persistence call depends on this method indirectly through IdmpodFilter
	 * null denotes, space is not reserved.
	 */
	public static String getZaaid()
	{
		return getZaaid(false);
	}

	public static String getZaaid(boolean nullSafe) throws IdmpodException
	{
		try
		{
			User currentUser = IAMUtil.getCurrentUser();
			if (currentUser == null && nullSafe)
			{
				return null;
			}
			Long zoid = currentUser.getZOID();
			Criteria crit = new Criteria(new Column(IDMPODORG.TABLE, IDMPODORG.ZOID), zoid, QueryConstants.EQUAL);
			DataObject dobj = CommonDBUtil.getPersistance().get(IDMPODORG.TABLE, crit);
			Row row = dobj.getRow(IDMPODORG.TABLE);
			String zaaid;
			if (row == null)
			{
				if (nullSafe)
				{
					zaaid = null;
				}
				else
				{
					throw new IdmpodException(ErrorCode.DBSPACE_NOT_RESERVED);
				}
			}
			else
			{
				zaaid = row.get(IDMPODORG.ZAAID).toString();
				//check user have access
				Persistence persistence = DBUtils.getAAPersistence(zaaid);

				if (!(currentUser.isOrgSuperAdmin() || UserUtils.isUserActive(persistence) || InviteUtils.isUserInvited(persistence)))
				{
					LOGGER.warning("currentUser.isOrgSuperAdmin():" + currentUser.isOrgSuperAdmin());
					LOGGER.warning("UserUtils.isUserActive(persistence):" + UserUtils.isUserActive(persistence));
					LOGGER.warning("InviteUtils.isUserInvited(persistence):" + InviteUtils.isUserInvited(persistence));
					throw new IdmpodException(ErrorCode.USER_ACCESS_DENIED);
				}
			}

			return zaaid;
		}
		catch (IdmpodException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	public static String getZaaid(User user)
	{
		Long zoid = user.getZOID();
		return getZaaid(zoid);
	}

	public static String getZaaid(Long zoid)
	{
		String zaaid = null;
		try
		{
			Criteria crit = new Criteria(new Column(IDMPODORG.TABLE, IDMPODORG.ZOID), zoid, QueryConstants.EQUAL);
			DataObject dobj = CommonDBUtil.getPersistance().get(IDMPODORG.TABLE, crit);
			Row row = dobj.getRow(IDMPODORG.TABLE);
			if (row == null)
			{
				zaaid = null;
			}
			else
			{
				zaaid = row.get(IDMPODORG.ZAAID).toString();
			}
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		return zaaid;
	}

	/**
	 * to check space reserved for the current user's org
	 *
	 * @return
	 */
	public static boolean checkSpace()
	{
		return CommonDBUtil.getZaaid(true) != null;
	}

	public static Row getAAOrgRow(String zaaid) throws Exception
	{
		Row r = null;

		Persistence persistence = getPersistance();

		DataObject orgInfoDO = persistence.get(IDMPODORG.TABLE, new Criteria(Column.getColumn(IDMPODORG.TABLE, IDMPODORG.ZAAID), zaaid, QueryConstants.EQUAL, false));

		if (orgInfoDO.containsTable(IDMPODORG.TABLE))
		{
			r = orgInfoDO.getRow(IDMPODORG.TABLE);
		}
		return r;
	}

	public static String getOrgName(String zaaid) throws Exception
	{
		String orgName = "";
		try
		{
			Row orgRow = getAAOrgRow(zaaid);
			orgName = orgRow.get(IDMPODORG.NAME).toString();
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Unable to fetch Org name for zaaid:" + zaaid, e);
		}

		return orgName;
	}

	public static String getAuditPreference(String key) throws Exception
	{
		DataObject dobj = getReadOnlyPersistance().get(IDMPODAUDITPREFERENCES.TABLE, new Criteria(Column.getColumn(IDMPODAUDITPREFERENCES.TABLE, IDMPODAUDITPREFERENCES.KEY), key, QueryConstants.EQUAL, false));
		if (dobj.containsTable(IDMPODAUDITPREFERENCES.TABLE))
		{
			Row prefRow = dobj.getFirstRow(IDMPODAUDITPREFERENCES.TABLE);
			if (prefRow != null)
			{
				return prefRow.get(IDMPODAUDITPREFERENCES.VALUE).toString();
			}
		}
		return null;
	}

	public static void setAuditPreference(String key, String value) throws Exception
	{
		DataObject dobj = getPersistance().get(IDMPODAUDITPREFERENCES.TABLE, new Criteria(Column.getColumn(IDMPODAUDITPREFERENCES.TABLE, IDMPODAUDITPREFERENCES.KEY), key, QueryConstants.EQUAL, false));
		if (dobj.containsTable(IDMPODAUDITPREFERENCES.TABLE))
		{
			Row prefRow = dobj.getFirstRow(IDMPODAUDITPREFERENCES.TABLE);
			if (prefRow != null)
			{
				prefRow.set(IDMPODAUDITPREFERENCES.VALUE, value);
				dobj.updateRow(prefRow);
				getPersistance().update(dobj);
			}
		}
		else
		{
			Row prefRow = new Row(IDMPODAUDITPREFERENCES.TABLE);
			prefRow.set(IDMPODAUDITPREFERENCES.KEY, key);
			prefRow.set(IDMPODAUDITPREFERENCES.VALUE, value);
			dobj.addRow(prefRow);
			getPersistance().add(dobj);
		}
	}

	public static String getOrgCountryCode() throws Exception
	{
		User currentUser = IAMUtil.getCurrentUser();
		String zaaid = getZaaid(currentUser.getZOID());
		return IdmpodUtils.getOrgPreference(DBUtils.getReadOnlyAAPersistence(zaaid), "COUNTRY_CODE");//No I18N
	}
}
