package com.manageengine.idmpod.server.iam.directory.jobs;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.iam.IAMProxy;
import com.adventnet.iam.UserAPI;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Persistence;
import com.adventnet.persistence.QueryConstructor;
import com.adventnet.persistence.Row;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.iam.directory.DirectoryHandler;
import com.manageengine.idmpod.server.iam.directory.azure.AzureHandler;
import com.manageengine.idmpod.server.utils.CommonDBUtil;
import com.manageengine.idmpod.server.utils.HttpUtils;
import com.manageengine.idmpod.server.utils.IdmpodThreadLocal;
import com.manageengine.tables.idmpod.*;
import com.microsoft.aad.adal4j.AuthenticationResult;
import com.microsoft.azure.AzureEnvironment;
import com.zoho.scheduler.RunnableJob;
import org.apache.http.client.methods.HttpGet;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.manageengine.idmpod.server.iam.directory.DirectoryHandler.handleSyncDirectoryUser;

public class AzureActiveDirectorySyncJob extends DirectorySyncJob
{
	public static final Logger LOGGER = Logger.getLogger(AzureActiveDirectorySyncJob.class.getName());

	public AzureActiveDirectorySyncJob()
	{
		super();
	}

	public AzureActiveDirectorySyncJob(Long jobId)
	{
		super(jobId);
	}

	@Override
	public void run(long jobId) throws Exception
	{
		LOGGER.log(Level.INFO, "Starting AzureActiveDirectorySyncJob job {0}", jobId); // No I18N
		Row orgRow = CommonDBUtil.getOrgRowForJob(jobId);
		IdmpodThreadLocal.setAppId(orgRow.get(IDMPODORG.ZAAID).toString());

		ArrayList<String> tablesList = new ArrayList<String>();
		tablesList.add(IDMPODDIRECTORYJOBS.TABLE);
		tablesList.add(IDMPODDIRECTORIES.TABLE);
		tablesList.add(IDMPODDIRECTORYNODES.TABLE);
		tablesList.add(IDMPODDIRECTORYPARAMS.TABLE);


		boolean[] isLeftJoins = new boolean[tablesList.size()];
		Arrays.fill(isLeftJoins, true);

		SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, new Criteria(Column.getColumn(IDMPODDIRECTORYJOBS.TABLE, IDMPODDIRECTORYJOBS.JOB_ID), jobId, QueryConstants.EQUAL));

		Persistence orgPersistence = DBUtils.getOrgPersistence();

		DataObject syncDO = orgPersistence.get(query);

		Row jobRow = syncDO.getFirstRow(IDMPODDIRECTORYJOBS.TABLE);

		Boolean isFullFetch = ((Long) jobRow.get(IDMPODDIRECTORYJOBS.SYNC_TYPE)).equals(DirectoryHandler.SYNC_TYPE.FETCH_ONLY);

		LOGGER.info("Is full fetch:" + isFullFetch);

		if (syncDO.containsTable(IDMPODDIRECTORIES.TABLE))
		{
			Row directoryRow = syncDO.getFirstRow(IDMPODDIRECTORIES.TABLE);
			Long directoryId = (Long) directoryRow.get(IDMPODDIRECTORIES.DIRECTORY_ID);

			Row syncDetailsRow = new Row(IDMPODDIRECTORYSYNCDETAILS.TABLE);

			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.JOB_ID, jobId);
			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.DIRECTORY_ID, directoryId);
			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.SYNC_TYPE, jobRow.get(IDMPODDIRECTORYJOBS.SYNC_TYPE));
			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.SYNC_STATUS, DirectoryHandler.SYNC_STATUS.RUNNING);
			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.SYNC_START_TIME, System.currentTimeMillis());

			syncDO.addRow(syncDetailsRow);

			Criteria syncEnabledNodesCrit = isFullFetch ? null : new Criteria(Column.getColumn(IDMPODDIRECTORYNODES.TABLE, IDMPODDIRECTORYNODES.SYNC_ENABLED), Boolean.TRUE, QueryConstants.EQUAL);

			Iterator<Row> syncEnabledNodes = syncDO.getRows(IDMPODDIRECTORYNODES.TABLE, syncEnabledNodesCrit);

			JSONArray domains = new JSONArray();

			while (syncEnabledNodes.hasNext())
			{
				LOGGER.info("syncEnabledNode found");
				Row syncEnabledNode = syncEnabledNodes.next();

				domains.put(DBUtils.rowToJson(syncEnabledNode));

				Row synchedNode = new Row(IDMPODSYNCHEDNODES.TABLE);
				synchedNode.set(IDMPODSYNCHEDNODES.DIRECTORY_ID, directoryId);
				synchedNode.set(IDMPODSYNCHEDNODES.SYNC_ID, syncDetailsRow.get(IDMPODDIRECTORYSYNCDETAILS.SYNC_ID));
				synchedNode.set(IDMPODSYNCHEDNODES.NODE_ID, syncEnabledNode.get(IDMPODDIRECTORYNODES.NODE_ID));

				syncDO.addRow(synchedNode);
			}
			orgPersistence.update(syncDO);

			// LOGGER.info("Domains:" + domains.toString(4));

			if (syncDO.containsTable(IDMPODDIRECTORYPARAMS.TABLE))
			{
				JSONObject directoryAttrs = new JSONObject();
				for (Iterator<Row> pit = syncDO.getRows(IDMPODDIRECTORYPARAMS.TABLE); pit.hasNext(); )
				{
					Row pr = pit.next();
					directoryAttrs.put((String) pr.get(IDMPODDIRECTORYPARAMS.PARAM_NAME), pr.get(IDMPODDIRECTORYPARAMS.ENCRYPTED_PARAM_VALUE));
				}

				String domain = directoryAttrs.getString("BASE_DOMAIN_NAME");
				String refreshTokenId = directoryAttrs.getString("AZURE_AUTH_TOKEN_ID");
				try
				{
					LOGGER.info("Domains to sync:" + domains.length());
					//TODO: Construct Domain criteria
					//					JSONObject domainObj = domains.getJSONObject(domainId);
					//					String currentDomainName = domainObj.getString(IDMPODDIRECTORYNODES.NODE_IDENTIFIER);
					//					Long nodeId = domainObj.getLong(IDMPODDIRECTORYNODES.NODE_ID);

					AzureEnvironment environment = AzureEnvironment.AZURE;
					String graphEndpoint = environment.graphEndpoint();

					URL baseURL = new URL(graphEndpoint + domain + "/");

					String urlString = graphEndpoint + domain + "/users/";
					AuthenticationResult authentication = AzureHandler.getAuthentication(refreshTokenId, environment.activeDirectoryEndpoint());

					JsonParser parser = new JsonParser();

					String skipToken = null;
					do
					{
						String[] qParams = null;
						if (skipToken != null)
						{
							qParams = new String[]{"api-version", "1.6", "$skiptoken", skipToken};//NO I18N
						}
						else
						{
							qParams = new String[]{"api-version", "1.6"};//NO I18N
						}
						HttpGet hg = new HttpGet(HttpUtils.constructUrl(urlString, qParams));
						hg.setHeader("Authorization", authentication.getAccessTokenType() + " " + authentication.getAccessToken());//NO I18N
						hg.setHeader("Accept", "application/json");//NO I18N
						hg.setHeader("Content-Type", "application/json");//NO I18N

						HttpUtils.HttpResult httpResponse = HttpUtils.getHttpResponse(hg);

						if (httpResponse.getStatus() == 200)
						{
							DataObject dataObject = DBUtils.getOrgPersistence().constructDataObject();

							JsonObject appResponse = parser.parse(httpResponse.getContent()).getAsJsonObject();
							JSONObject respObj = new JSONObject(appResponse.toString());
							if (respObj.has("odata.nextLink"))
							{
								URL nextUrl = new URL(baseURL, respObj.getString("odata.nextLink"));
								skipToken = HttpUtils.splitQuery(nextUrl).get("$skiptoken").get(0);
							}
							else
							{
								skipToken = null;
							}
							JSONArray users = respObj.getJSONArray("value");
							for (int i = 0; i < users.length(); i++)
							{
								JSONObject user = users.getJSONObject(i);
								try
								{
									Row userRow = new Row(IDMPODSYNCHEDUSERS.TABLE);
									userRow.set(IDMPODSYNCHEDUSERS.SYNC_ID, syncDetailsRow.get(IDMPODDIRECTORYSYNCDETAILS.SYNC_ID));
									userRow.set(IDMPODSYNCHEDUSERS.DIRECTORY_ID, directoryId);

									if (user.has("givenName") && !user.isNull("givenName"))
									{
										userRow.set(IDMPODSYNCHEDUSERS.FIRST_NAME, user.getString("givenName"));// No I18N
									}
									if (user.has("objectId") && !user.isNull("objectId"))
									{
										userRow.set(IDMPODSYNCHEDUSERS.USER_IDENTIFIER, user.getString("objectId"));
									}
									if (user.has("surname") && !user.isNull("surname"))
									{
										userRow.set(IDMPODSYNCHEDUSERS.LAST_NAME, user.getString("surname"));// No I18N
									}
									if (user.has("displayName") && !user.isNull("displayName"))
									{
										userRow.set(IDMPODSYNCHEDUSERS.USER_DISPLAY_NAME, user.getString("displayName"));// No I18N
									}
									if (user.has("userPrincipalName") && !user.isNull("userPrincipalName"))
									{
										userRow.set(IDMPODSYNCHEDUSERS.USER_PRINCIPAL_NAME, user.getString("userPrincipalName"));// No I18N
									}
									if (user.has("mail") && !user.isNull("mail"))
									{
										userRow.set(IDMPODSYNCHEDUSERS.USER_EMAIL, user.getString("mail"));// No I18N
									}

									dataObject.addRow(userRow);
								}
								catch (Exception e)
								{
									LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
									// LOGGER.info(user.toString(4));
								}
							}
							handleFetchAndIAM(orgRow, jobRow, dataObject);
						}
					} while (skipToken != null);
				}
				catch (Exception e)
				{
					LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
				}

				syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.SYNC_END_TIME, System.currentTimeMillis());
				syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.SYNC_STATUS, DirectoryHandler.SYNC_STATUS.SUCCESS);
				syncDO.updateRow(syncDetailsRow);
				orgPersistence.update(syncDO);
			}

			LOGGER.log(Level.INFO, "Finishing AzureActiveDirectorySyncJob job {0}", jobId); // No I18N
		}
	}
}
