package com.manageengine.idmpod.server.reports;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.*;
import com.adventnet.iam.IAMProxy;
import com.adventnet.iam.OrgAPI;
import com.adventnet.iam.UserAPI;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.tables.idmpod.IDMPODAPPLICATIONACCESSAUDIT;
import com.manageengine.tables.idmpod.IDMPODCLIENTACCESSAUDIT;
import com.manageengine.tables.idmpod.IDMPODDASHBOARDCHARTS;
import com.manageengine.tables.idmpod.IDMPODTECHNICIAN;
import com.zoho.accounts.AccountsProto;
import org.json.JSONArray;
import org.json.JSONObject;

import java.sql.Connection;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

import static com.manageengine.idmpod.server.db.DBUtils.datasetToJson;

public class DashboardHandler
{
	private static final Logger LOGGER = Logger.getLogger(DashboardHandler.class.getName());

	public static JSONObject getCurrentDashboard()
	{
		JSONObject resp = new JSONObject();

		final String TYPE = JsonApiHandler.ResourceType.DASHBOARD.getResType();
		final String ID = "current";//NO I18N

		JSONObject dashboardAttrs = new JSONObject();

		dashboardAttrs.put("ACTIVE_USERS_FOR_LAST_X_DAYS", getActiveUsersCountForXDays(30));
		dashboardAttrs.put("INACTIVE_USERS_FOR_LAST_X_DAYS", getInactiveUsersCountForXDays(30));
		dashboardAttrs.put("NEVER_LOGGED_IN_USERS", getNeverLoggedInUsersCount());
		dashboardAttrs.put("USERS_WITHOUT_APPLICATIONS", getUsersWithoutApplicationsCount());

		JSONObject relationships = new JSONObject();
		//relationships.put("charts", JsonApiHandler.getResourceObject(JsonApiHandler.getResourceIdentifierObject("dashboard-chart", "test")));
		JSONArray dashboardCharts = getDashboardCharts();
		relationships.put("charts", JsonApiHandler.getResourceObject(dashboardCharts));

		JSONObject dashboard = new JSONObject();
		dashboard.put(JsonApiConstants.ID, ID);
		dashboard.put(JsonApiConstants.TYPE, TYPE);
		dashboard.put(JsonApiConstants.ATTRIBUTES, dashboardAttrs);
		dashboard.put(JsonApiConstants.RELATIONSHIPS, relationships);

		resp.put(JsonApiConstants.DATA, dashboard);
		resp.put(JsonApiConstants.INCLUDED, dashboardCharts);

		return resp;
	}

	private static JSONArray getDashboardCharts()
	{
		final String TYPE = JsonApiHandler.ResourceType.DASHBOARD_CHART.getResType();
		JSONArray charts = new JSONArray();
		int sumOfWidths = 0;
		try
		{
			DataObject dataObject = DBUtils.getOrgPersistence().get(IDMPODDASHBOARDCHARTS.TABLE, (Criteria) null);
			if (dataObject.containsTable(IDMPODDASHBOARDCHARTS.TABLE))
			{
				Iterator<Row> rows = dataObject.getRows(IDMPODDASHBOARDCHARTS.TABLE);
				while (rows.hasNext())
				{
					Row row = rows.next();
					JSONObject chart = new JSONObject();
					JSONObject chartAttrs = DBUtils.rowToJson(row);
					int width = chartAttrs.optInt(IDMPODDASHBOARDCHARTS.WIDTH, 50);
					if (width == 100)
					{
						chartAttrs.put("STYLE_CLASS", "span_12");
					}
					else if (width == 50)
					{
						chartAttrs.put("STYLE_CLASS", "span_6");
					}
					else
					{
						chartAttrs.put("STYLE_CLASS", "span_4");
					}

					sumOfWidths = sumOfWidths + width;

					if (sumOfWidths > 100 || charts.length() == 0)
					{
						sumOfWidths = width;
						chartAttrs.put("ZLM", true);
					}

					chart.put(JsonApiConstants.ID, chartAttrs.get(IDMPODDASHBOARDCHARTS.DASHBOARD_CHART_ID));
					chart.put(JsonApiConstants.TYPE, TYPE);
					chart.put(JsonApiConstants.ATTRIBUTES, chartAttrs);
					charts.put(chart);
				}
			}
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		return charts;
	}

	private static long getUsersWithoutApplicationsCount()
	{
		Long usersWithoutAppsCount = 0L;

		SelectQuery query = new SelectQueryImpl(Table.getTable(IDMPODTECHNICIAN.TABLE));

		query.setCriteria(new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.STATUS), "ACTIVE", QueryConstants.EQUAL, false));

		query.addSelectColumn(Column.getColumn(IDMPODTECHNICIAN.TABLE, "*"));

		Connection connection = null;
		DataSet dataSet = null;
		try
		{
			RelationalAPI relationalAPI = DBUtils.getOrgRelationalApi();
			connection = relationalAPI.getConnection();
			dataSet = relationalAPI.executeQuery(query, connection);

			OrgAPI orgAPI = IAMProxy.getInstance().getOrgAPI();
			UserAPI userAPI = IAMProxy.getInstance().getUserAPI();

			while (dataSet.next())
			{
				JSONObject userAttrs = datasetToJson(dataSet);
				List<AccountsProto.Account.SAMLApp> samlAppsofUser = orgAPI.getSamlAppsofUser(userAttrs.optString(IDMPODTECHNICIAN.ZUID));
				if (samlAppsofUser != null && samlAppsofUser.size() > 0)
				{
					continue;
				}
				else
				{
					usersWithoutAppsCount++;
				}
			}

			// LOGGER.info(relationalAPI.getSelectSQL(query));
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		finally
		{
			DBUtils.safeClose(connection, dataSet);
		}

		return usersWithoutAppsCount;
	}

	private static int getNeverLoggedInUsersCount()
	{
		int count = 0;

		SelectQuery subQuery = new SelectQueryImpl(Table.getTable(IDMPODCLIENTACCESSAUDIT.TABLE));

		subQuery.addSelectColumn(Column.getColumn(IDMPODCLIENTACCESSAUDIT.TABLE, IDMPODCLIENTACCESSAUDIT.USER_ID));

		DerivedColumn auditUserIdCol = new DerivedColumn(IDMPODCLIENTACCESSAUDIT.USER_ID, subQuery);

		SelectQuery query = new SelectQueryImpl(Table.getTable(IDMPODTECHNICIAN.TABLE));

		Criteria activeUsersCrit = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ZUID), auditUserIdCol, QueryConstants.NOT_IN);
		activeUsersCrit = activeUsersCrit.and(new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.STATUS), "ACTIVE", QueryConstants.EQUAL, false));

		query.setCriteria(activeUsersCrit);

		query.addSelectColumn(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.USER_ID).count());

		Connection connection = null;
		DataSet dataSet = null;
		try
		{
			RelationalAPI relationalAPI = DBUtils.getOrgRelationalApi();
			connection = relationalAPI.getConnection();
			dataSet = relationalAPI.executeQuery(query, connection);

			while (dataSet.next())
			{
				count = (Integer) dataSet.getValue(1);
			}

			// LOGGER.info(relationalAPI.getSelectSQL(query));
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		finally
		{
			DBUtils.safeClose(connection, dataSet);
		}
		return count;
	}

	private static int getInactiveUsersCountForXDays(long x)
	{
		int count = 0;

		SelectQuery subQuery = new SelectQueryImpl(Table.getTable(IDMPODCLIENTACCESSAUDIT.TABLE));

		Long startTimestamp = System.currentTimeMillis() - (x * 24 * 60 * 60 * 1000);
		Long endTimestamp = System.currentTimeMillis();

		Criteria lastXdaysCrit = new Criteria(Column.getColumn(IDMPODCLIENTACCESSAUDIT.TABLE, IDMPODCLIENTACCESSAUDIT.TIMESTAMP), new Long[]{startTimestamp, endTimestamp}, QueryConstants.BETWEEN);

		subQuery.setCriteria(lastXdaysCrit);

		subQuery.addSelectColumn(Column.getColumn(IDMPODCLIENTACCESSAUDIT.TABLE, IDMPODCLIENTACCESSAUDIT.USER_ID));

		DerivedColumn auditUserIdCol = new DerivedColumn(IDMPODCLIENTACCESSAUDIT.USER_ID, subQuery);

		SelectQuery query = new SelectQueryImpl(Table.getTable(IDMPODTECHNICIAN.TABLE));

		Criteria activeUsersCrit = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ZUID), auditUserIdCol, QueryConstants.NOT_IN);
		activeUsersCrit = activeUsersCrit.and(new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.STATUS), "ACTIVE", QueryConstants.EQUAL, false));

		query.setCriteria(activeUsersCrit);

		query.addSelectColumn(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.USER_ID).count());

		Connection connection = null;
		DataSet dataSet = null;
		try
		{
			RelationalAPI relationalAPI = DBUtils.getOrgRelationalApi();
			connection = relationalAPI.getConnection();
			dataSet = relationalAPI.executeQuery(query, connection);

			while (dataSet.next())
			{
				count = (Integer) dataSet.getValue(1);
			}

			// LOGGER.info(relationalAPI.getSelectSQL(query));
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		finally
		{
			DBUtils.safeClose(connection, dataSet);
		}
		return count;
	}

	private static int getActiveUsersCountForXDays(long x)
	{
		int count = 0;

		SelectQuery subQuery = new SelectQueryImpl(Table.getTable(IDMPODCLIENTACCESSAUDIT.TABLE));

		Long startTimestamp = System.currentTimeMillis() - (x * 24 * 60 * 60 * 1000);
		Long endTimestamp = System.currentTimeMillis();

		Criteria lastXdaysCrit = new Criteria(Column.getColumn(IDMPODCLIENTACCESSAUDIT.TABLE, IDMPODCLIENTACCESSAUDIT.TIMESTAMP), new Long[]{startTimestamp, endTimestamp}, QueryConstants.BETWEEN);

		subQuery.setCriteria(lastXdaysCrit);

		subQuery.addSelectColumn(Column.getColumn(IDMPODCLIENTACCESSAUDIT.TABLE, IDMPODCLIENTACCESSAUDIT.USER_ID));

		DerivedColumn auditUserIdCol = new DerivedColumn(IDMPODCLIENTACCESSAUDIT.USER_ID, subQuery);

		SelectQuery query = new SelectQueryImpl(Table.getTable(IDMPODTECHNICIAN.TABLE));

		Criteria activeUsersCrit = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ZUID), auditUserIdCol, QueryConstants.IN);
		activeUsersCrit = activeUsersCrit.and(new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.STATUS), "ACTIVE", QueryConstants.EQUAL, false));

		query.setCriteria(activeUsersCrit);

		query.addSelectColumn(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.USER_ID).count());

		Connection connection = null;
		DataSet dataSet = null;
		try
		{
			RelationalAPI relationalAPI = DBUtils.getOrgRelationalApi();
			connection = relationalAPI.getConnection();
			dataSet = relationalAPI.executeQuery(query, connection);

			while (dataSet.next())
			{
				count = (Integer) dataSet.getValue(1);
			}

			// LOGGER.info(relationalAPI.getSelectSQL(query));
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		finally
		{
			DBUtils.safeClose(connection, dataSet);
		}
		return count;
	}
}
