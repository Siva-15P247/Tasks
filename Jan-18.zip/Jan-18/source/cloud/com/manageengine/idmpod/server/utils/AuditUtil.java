package com.manageengine.idmpod.server.utils;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.*;
import com.adventnet.i18n.I18N;
import com.adventnet.iam.*;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.iam.IdmpodIAMUtil;
import com.manageengine.tables.idmpod.IDMPODAPPLICATIONACCESSAUDIT;
import com.manageengine.tables.idmpod.IDMPODAUDITOPERATIONTYPES;
import com.manageengine.tables.idmpod.IDMPODCLIENTACCESSAUDIT;
import com.manageengine.tables.idmpod.IDMPODGENERALADMINAUDITLOGS;
import com.zoho.accounts.AccountsProto;
import org.json.JSONArray;
import org.json.JSONObject;

import javax.servlet.http.HttpServletRequest;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import static com.manageengine.idmpod.server.db.DBUtils.datasetToJson;

public class AuditUtil
{
	private static final Logger LOGGER = Logger.getLogger(AuditUtil.class.getName());

	public static boolean getIPAuditForOrg(Long zoid)
	{
		String zaaid = CommonDBUtil.getZaaid(zoid);
		try
		{
			String log_ip = IdmpodUtils.getOrgPreference(DBUtils.getReadOnlyAAPersistence(zaaid), "LOG_IP");//NO I18N
			if (log_ip != null && log_ip.equalsIgnoreCase("DISABLED"))
			{
				return false;
			}
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		return true;
	}

	public static boolean getIPAuditForCountry(String countryCode)
	{
		try
		{
			if (countryCode != null)
			{
				String log_ip = CommonDBUtil.getAuditPreference("LOG_IP_" + countryCode.toUpperCase());//NO I18N
				if (log_ip != null && log_ip.equalsIgnoreCase("DISABLED"))
				{
					return false;
				}
			}
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		return true;
	}

	public static void setIPAuditForOrg(Long zoid, Boolean ipConfig)
	{
		String zaaid = CommonDBUtil.getZaaid(zoid);
		try
		{
			IdmpodUtils.setOrgPreference(DBUtils.getAAPersistence(zaaid), "LOG_IP", ipConfig ? "ENABLED" : "DISABLED");//NO I18N
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
	}

	public static void setIPAuditForCountry(String countryCode, Boolean ipConfig)
	{
		try
		{
			CommonDBUtil.setAuditPreference("LOG_IP_" + countryCode.toUpperCase(), ipConfig ? "ENABLED" : "DISABLED");//NO I18N
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
	}

	public static enum OperationType
	{
		//User Ops
		ACCESS_APPLICATION("AccessApplication", null, null), // NO I18N
		LOGOUT_FROM_APPLICATION("LogoutFromApplication", null, null), //No I18N
		//Admin Ops
		ASSIGN_SAML_APPS_TO_USER("AssignSamlAppsToUser", JsonApiHandler.ResourceType.USER, "POST", "idmpod.admin_audit.remarks.assign_saml_apps_to_user"), // NO I18N
		UPDATE_USER("UpdateUser", JsonApiHandler.ResourceType.USER, "PATCH"), // NO I18N
		DELETE_USER("DeleteUser", JsonApiHandler.ResourceType.USER, "DELETE", "idmpod.admin_audit.remarks.remove_user.success"), // NO I18N
		DELETE_INVITATIONS("DeleteInvitations", JsonApiHandler.ResourceType.INVITED_USER, "DELETE", "idmpod.admin_audit.remarks.delete_invitation.success"), // NO I18N
		ADD_SAML_APP("AddSamlApp", JsonApiHandler.ResourceType.SAML_APP, "POST"), // NO I18N
		UPDATE_SAML_APP("UpdateSamlApp", JsonApiHandler.ResourceType.SAML_APP, "PATCH"), // NO I18N
		DELETE_SAML_APP("DeleteSamlApp", JsonApiHandler.ResourceType.SAML_APP, "DELETE", "idmpod.admin_audit.remarks.delete.success"), // NO I18N
		ASSIGN_USERS_TO_SAML_APP("AssignUsersToSamlApp", JsonApiHandler.ResourceType.SAML_APP, "POST", "idmpod.admin_audit.remarks.assign_users_to_saml_app"), // NO I18N
		REMOVE_USERS_FROM_SAML_APP("RemoveUsersFromSamlApp", JsonApiHandler.ResourceType.SAML_APP, "POST", "idmpod.admin_audit.remarks.remove_users_from_saml_app"), // NO I18N
		ADD_DIRECTORY("AddDirectory", JsonApiHandler.ResourceType.DIRECTORY, "POST"), // NO I18N
		UPDATE_DIRECTORY("UpdateDirectory", JsonApiHandler.ResourceType.DIRECTORY, "PATCH"), // NO I18N
		DELETE_DIRECTORY("DeleteDirectory", JsonApiHandler.ResourceType.DIRECTORY, "DELETE", "idmpod.admin_audit.remarks.delete.success"), // NO I18N
		IMPORT_DIRECTORY_USERS("ImportDirectoryUsers", JsonApiHandler.ResourceType.DIRECTORY, "POST", "idmpod.admin_audit.remarks.import_directory_users"), // NO I18N
		ADD_USERS_TO_DIRECTORY("AddUsersToDirectory", JsonApiHandler.ResourceType.DIRECTORY, "POST", "idmpod.admin_audit.remarks.add_users_to_directory"), // NO I18N
		UPDATE_ORGANIZATIONAL_UNIT("UpdateOrganizationalUnit", null, null), // NO I18N
		SETUP_DIRECTORY_SYNC("SetupDirectorySync", null, null), // NO I18N
		CREATE_AUTH_TOKEN("CreateAuthToken", null, null), // NO I18N
		UPDATE_SUBSCRIPTION("UpdateSubscription", JsonApiHandler.ResourceType.SUBSCRIPTION, "PATCH"),// NO I18N
		ADD_PUBLIC_DOMAIN("AddPublicDomain", JsonApiHandler.ResourceType.PDOMAIN, "POST"),// NO I18N
		UPDATE_PUBLIC_DOMAIN("UpdatePublicDomain", JsonApiHandler.ResourceType.PDOMAIN, "PATCH"),// NO I18N
		DELETE_PUBLIC_DOMAIN("DeletePublicDomain", JsonApiHandler.ResourceType.PDOMAIN, "DELETE", "idmpod.admin_audit.remarks.delete.success"),// NO I18N
		ASSIGN_SAML_APPS_TO_USERS("AssignSamlAppsToUsers", JsonApiHandler.ResourceType.USER, "POST", "idmpod.admin_audit.remarks.assign_saml_apps_to_users"), // NO I18N
		UNASSIGN_SAML_APPS_FROM_USERS("UnassignSamlAppsFromUsers", JsonApiHandler.ResourceType.USER, "POST", "idmpod.admin_audit.remarks.unassign_saml_apps_from_users"), // NO I18N

		//Client Access Ops
		ACCESS_USER_PORTAL("AccessUserPortal", null, null), // NO I18N

		ACCESS_ADMIN_PORTAL("AccessAdminPortal", null, null); // NO I18N

		private final String opType;
		private final JsonApiHandler.ResourceType resourceType;
		private final String method;
		private final String remarksTemplate;

		private OperationType(String ot, JsonApiHandler.ResourceType rt, String httpMethod)
		{
			this(ot, rt, httpMethod, null);
		}

		private OperationType(String ot, JsonApiHandler.ResourceType rt, String httpMethod, String rmsTemplate)
		{
			if (httpMethod != null && httpMethod.equalsIgnoreCase("DELETE") && rmsTemplate == null)
			{
				throw new IllegalArgumentException("Remarks template is mandatory for DELETE method.");//No I18N
			}
			opType = ot;
			resourceType = rt;
			method = httpMethod;
			remarksTemplate = rmsTemplate;
		}

		public String getOpType()
		{
			return opType;
		}

		public String getResourceType()
		{
			return resourceType.getResType();
		}

		public String getMethod()
		{
			return method;
		}

		public String getRemarksTemplate()
		{
			return remarksTemplate;
		}
	}

	public static void auditApplicationAccess(HttpServletRequest request)
	{
		try
		{
			OrgAPI orgAPI = IAMProxy.getInstance().getOrgAPI();
			Long userId = IAMUtil.getCurrentUser().getZUID();
			Long appId = Long.parseLong(request.getParameter("appid"));
			AccountsProto.Account.SAMLApp samlApp = null;
			try
			{
				samlApp = orgAPI.getSamlApp(IdmpodIAMUtil.getZAID(), appId.toString());
			}
			catch (IAMException iae)
			{
				if (iae.getErrorCode().equalsIgnoreCase(IAMErrorCode.SAML102))
				{
					LOGGER.info("Saml login accessed with unknown app id; Not logging");
					return;
				}
				else
				{
					LOGGER.log(Level.SEVERE, iae.getMessage(), iae);
				}
			}

			final AccountsProto.Account.SAMLApp cSamlApp = samlApp;

			List<AccountsProto.Account.SAMLApp> samlAppsofUser = orgAPI.getSamlAppsofUser(userId.toString());

			List<AccountsProto.Account.SAMLApp> matchingApps = samlAppsofUser.stream().filter(app -> cSamlApp.getAppId().equals(app.getAppId())).collect(Collectors.toList());

			if (matchingApps.size() == 0)
			{
				// LOGGER.info("App not assigned to user; Logging as definite failure");
				auditAppAccess(userId, appId, false, "NotUserApp", request);//No I18N
			}
			// LOGGER.info("Logging as inconclusive --> Request might fail at IAM side");

			auditAppAccess(userId, appId, null, null, request);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

	}

	public static void auditApplicationLogout(HttpServletRequest request)
	{
		OperationType operationType = OperationType.LOGOUT_FROM_APPLICATION;

		try
		{
			DataObject dataObject = DBUtils.getOrgPersistence().get(IDMPODAUDITOPERATIONTYPES.TABLE, new Criteria(Column.getColumn(IDMPODAUDITOPERATIONTYPES.TABLE, IDMPODAUDITOPERATIONTYPES.OPERATION_NAME), operationType.getOpType(), QueryConstants.EQUAL, false));
			if (dataObject.containsTable(IDMPODAUDITOPERATIONTYPES.TABLE))
			{
				Long userId = IAMUtil.getCurrentUser().getZUID();
				Long appId = Long.parseLong(request.getParameter("appid"));

				Row opTypeRow = dataObject.getFirstRow(IDMPODAUDITOPERATIONTYPES.TABLE);
				Row auditRow = new Row(IDMPODAPPLICATIONACCESSAUDIT.TABLE);

				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.APPLICATION_ID, appId);
				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.USER_ID, userId);
				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.TIMESTAMP, System.currentTimeMillis());
				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.REMARKS, null);
				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.RESULT_STATUS, true);

				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.CLIENT_IP, getClientIp(request));
				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.USER_AGENT_INFO, HttpUtils.getUserAgentInfo(request));
				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.OPERATION_TYPE_ID, opTypeRow.get(IDMPODAUDITOPERATIONTYPES.OPERATION_TYPE_ID));

				dataObject.addRow(auditRow);

				DBUtils.getOrgPersistence().update(dataObject);
			}
			else
			{
				throw new UnsupportedOperationException("Unable to find operation type definition for " + operationType.getOpType());// No I18N
			}
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
	}

	private static void auditAppAccess(Long userId, Long appId, Boolean resultStatus, String remarks, HttpServletRequest request)
	{
		try
		{
			OperationType operationType = OperationType.ACCESS_APPLICATION;

			DataObject dataObject = DBUtils.getOrgPersistence().get(IDMPODAUDITOPERATIONTYPES.TABLE, new Criteria(Column.getColumn(IDMPODAUDITOPERATIONTYPES.TABLE, IDMPODAUDITOPERATIONTYPES.OPERATION_NAME), operationType.getOpType(), QueryConstants.EQUAL, false));

			if (dataObject.containsTable(IDMPODAUDITOPERATIONTYPES.TABLE))
			{
				Row opTypeRow = dataObject.getFirstRow(IDMPODAUDITOPERATIONTYPES.TABLE);
				Row auditRow = new Row(IDMPODAPPLICATIONACCESSAUDIT.TABLE);

				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.APPLICATION_ID, appId);
				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.USER_ID, userId);
				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.TIMESTAMP, System.currentTimeMillis());
				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.REMARKS, remarks);
				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.RESULT_STATUS, resultStatus);

				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.CLIENT_IP, getClientIp(request));
				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.USER_AGENT_INFO, HttpUtils.getUserAgentInfo(request));
				auditRow.set(IDMPODAPPLICATIONACCESSAUDIT.OPERATION_TYPE_ID, opTypeRow.get(IDMPODAUDITOPERATIONTYPES.OPERATION_TYPE_ID));

				dataObject.addRow(auditRow);

				DBUtils.getOrgPersistence().update(dataObject);
			}
			else
			{
				throw new UnsupportedOperationException("Unable to find operation type definition for " + operationType.getOpType());// No I18N
			}
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
	}

	public static void auditClientAccess(OperationType operationType, HttpServletRequest request)
	{
		try
		{
			if (!(operationType == OperationType.ACCESS_ADMIN_PORTAL || operationType == OperationType.ACCESS_USER_PORTAL))
			{
				throw new IllegalArgumentException("Wrong operation type for audit client access;" + operationType.getOpType());// No I18N
			}
			Long userId = IAMUtil.getCurrentUser().getZUID();

			DataObject dataObject = DBUtils.getOrgPersistence().get(IDMPODAUDITOPERATIONTYPES.TABLE, new Criteria(Column.getColumn(IDMPODAUDITOPERATIONTYPES.TABLE, IDMPODAUDITOPERATIONTYPES.OPERATION_NAME), operationType.getOpType(), QueryConstants.EQUAL, false));
			if (dataObject.containsTable(IDMPODAUDITOPERATIONTYPES.TABLE))
			{
				Row opTypeRow = dataObject.getFirstRow(IDMPODAUDITOPERATIONTYPES.TABLE);
				Row auditRow = new Row(IDMPODCLIENTACCESSAUDIT.TABLE);

				auditRow.set(IDMPODCLIENTACCESSAUDIT.USER_ID, userId);
				auditRow.set(IDMPODCLIENTACCESSAUDIT.TIMESTAMP, System.currentTimeMillis());
				auditRow.set(IDMPODCLIENTACCESSAUDIT.OPERATION_TYPE_ID, opTypeRow.get(IDMPODAUDITOPERATIONTYPES.OPERATION_TYPE_ID));

				auditRow.set(IDMPODCLIENTACCESSAUDIT.REMARKS, null);
				auditRow.set(IDMPODCLIENTACCESSAUDIT.RESULT_STATUS, true);

				auditRow.set(IDMPODCLIENTACCESSAUDIT.CLIENT_IP, getClientIp(request));
				auditRow.set(IDMPODCLIENTACCESSAUDIT.USER_AGENT_INFO, HttpUtils.getUserAgentInfo(request));

				dataObject.addRow(auditRow);

				DBUtils.getOrgPersistence().update(dataObject);
			}
			else
			{
				throw new UnsupportedOperationException("Unable to find operation type definition for " + operationType.getOpType());// No I18N
			}
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
	}

	public static JSONObject getAppAccessEvents(Integer page_size, Integer page_number, JSONArray filterArray)
	{
		final String TYPE = JsonApiHandler.ResourceType.APPLICATION_ACCESS_EVENT.getResType();
		JSONObject resp = new JSONObject();
		JSONObject meta = new JSONObject();
		JSONArray events = new JSONArray();
		try
		{
			SelectQuery query = new SelectQueryImpl(Table.getTable(IDMPODAPPLICATIONACCESSAUDIT.TABLE));

			query.addSelectColumn(Column.getColumn(IDMPODAPPLICATIONACCESSAUDIT.TABLE, "*"));

			if (filterArray != null)
			{
				Criteria filterCrit = null;
				for (int i = 0; i < filterArray.length(); i++)
				{
					JSONObject filterObj = filterArray.getJSONObject(i);
					Iterator<String> keys = filterObj.keys();
					while (keys.hasNext())
					{
						String key = keys.next();
						if (key.equalsIgnoreCase(IDMPODAPPLICATIONACCESSAUDIT.TIMESTAMP))
						{
							JSONArray dateRange = filterObj.getJSONArray(key);
							Criteria daterangeCrit = new Criteria(Column.getColumn(IDMPODAPPLICATIONACCESSAUDIT.TABLE, IDMPODAPPLICATIONACCESSAUDIT.TIMESTAMP), dateRange.toList().toArray(), QueryConstants.BETWEEN);
							if (filterCrit == null)
							{
								filterCrit = daterangeCrit;
							}
							else
							{
								filterCrit = filterCrit.and(daterangeCrit);
							}
						}
					}
				}
				if (filterCrit != null)
				{
					query.setCriteria(filterCrit);
				}
			}

			Range range = DBUtils.constructRange(page_number, page_size);

			Integer totalCount = DBUtils.getUnmodifiedQueryCount(query);
			Boolean atLastPage = (page_number * page_size) >= totalCount;

			meta.put("FIRST", 1);
			meta.put("NEXT", atLastPage ? null : page_number + 1);
			meta.put("PREV", page_number > 1 ? page_number - 1 : null);
			meta.put("LAST", Math.ceil(totalCount.doubleValue() / page_size.doubleValue()));
			meta.put("TOTAL", totalCount);
			meta.put("START_INDEX", (page_number - 1) * page_size + 1);
			meta.put("END_INDEX", (page_number * page_size) > totalCount ? totalCount : (page_number * page_size));

			query.setRange(range);

			Connection connection = null;
			DataSet dataSet = null;
			try
			{
				RelationalAPI relationalAPI = DBUtils.getOrgRelationalApi();
				connection = relationalAPI.getConnection();
				dataSet = relationalAPI.executeQuery(query, connection);

				OrgAPI orgAPI = IAMProxy.getInstance().getOrgAPI();
				UserAPI userAPI = IAMProxy.getInstance().getUserAPI();

				while (dataSet.next())
				{
					JSONObject eventAttrs = datasetToJson(dataSet);
					JSONObject event = new JSONObject();
					eventAttrs.put("USER_NAME", userAPI.getUser(eventAttrs.getLong(IDMPODAPPLICATIONACCESSAUDIT.USER_ID)).getDisplayName());
					eventAttrs.put("APPLICATION_NAME", orgAPI.getSamlApp(IdmpodIAMUtil.getZAID(), eventAttrs.optString(IDMPODAPPLICATIONACCESSAUDIT.APPLICATION_ID)).getAppName());
					event.put(JsonApiConstants.ID, eventAttrs.get(IDMPODAPPLICATIONACCESSAUDIT.UNIQUE_ID));
					event.put(JsonApiConstants.TYPE, TYPE);
					event.put(JsonApiConstants.ATTRIBUTES, eventAttrs);
					events.put(event);
				}

				// LOGGER.info(relationalAPI.getSelectSQL(query));
			}
			catch (Exception e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
			finally
			{
				DBUtils.safeClose(connection, dataSet);
			}

			resp.put(JsonApiConstants.DATA, events);
			resp.put(JsonApiConstants.META, meta);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return resp;
	}

	public static JSONObject getAdminAuditEvents(Integer page_size, Integer page_number, JSONArray filterArray, JSONArray searchArray)
	{
		final String TYPE = JsonApiHandler.ResourceType.ADMIN_AUDIT_EVENT.getResType();
		JSONObject resp = new JSONObject();
		JSONObject meta = new JSONObject();
		JSONArray events = new JSONArray();
		try
		{
			SelectQuery query = new SelectQueryImpl(Table.getTable(IDMPODGENERALADMINAUDITLOGS.TABLE));

			query.addJoin(new Join(IDMPODGENERALADMINAUDITLOGS.TABLE, IDMPODAUDITOPERATIONTYPES.TABLE, new String[]{IDMPODGENERALADMINAUDITLOGS.OPERATION_TYPE_ID}, new String[]{IDMPODAUDITOPERATIONTYPES.OPERATION_TYPE_ID}, Join.INNER_JOIN));

			query.addSelectColumn(Column.getColumn(IDMPODGENERALADMINAUDITLOGS.TABLE, "*"));
			query.addSelectColumn(Column.getColumn(IDMPODAUDITOPERATIONTYPES.TABLE, "*"));

			Criteria queryCrit = null;

			if (filterArray != null)
			{
				Criteria filterCrit = null;
				for (int i = 0; i < filterArray.length(); i++)
				{
					JSONObject filterObj = filterArray.getJSONObject(i);
					Iterator<String> keys = filterObj.keys();
					while (keys.hasNext())
					{
						String key = keys.next();
						if (key.equalsIgnoreCase(IDMPODGENERALADMINAUDITLOGS.TIMESTAMP))
						{
							JSONArray dateRange = filterObj.getJSONArray(key);
							Criteria daterangeCrit = new Criteria(Column.getColumn(IDMPODGENERALADMINAUDITLOGS.TABLE, IDMPODGENERALADMINAUDITLOGS.TIMESTAMP), dateRange.toList().toArray(), QueryConstants.BETWEEN);
							if (filterCrit == null)
							{
								filterCrit = daterangeCrit;
							}
							else
							{
								filterCrit = filterCrit.and(daterangeCrit);
							}
						}
					}
				}
				if (filterCrit != null)
				{
					queryCrit = filterCrit;
				}
			}

			if (searchArray != null)
			{
				Criteria searchCrit = null;
				for (int i = 0; i < searchArray.length(); i++)
				{
					JSONObject searchObj = searchArray.getJSONObject(i);
					Iterator<String> keys = searchObj.keys();
					while (keys.hasNext())
					{
						String key = keys.next();
						if (key.equalsIgnoreCase("OPERATION_DISPLAY_NAME"))
						{
							String searchString = searchObj.getString(key);
							Criteria opNameCrit = constructOpNameCrit(searchString);
							if (searchCrit == null)
							{
								searchCrit = opNameCrit;
							}
							else
							{
								searchCrit = searchCrit.and(opNameCrit);
							}
						}
					}
				}
				if (searchCrit != null)
				{
					queryCrit = searchCrit;
				}
			}

			query.setCriteria(queryCrit);

			Range range = DBUtils.constructRange(page_number, page_size);

			Integer totalCount = DBUtils.getUnmodifiedQueryCount(query);
			Boolean atLastPage = (page_number * page_size) >= totalCount;

			meta.put("FIRST", 1);
			meta.put("NEXT", atLastPage ? null : page_number + 1);
			meta.put("PREV", page_number > 1 ? page_number - 1 : null);
			meta.put("LAST", Math.ceil(totalCount.doubleValue() / page_size.doubleValue()));
			meta.put("TOTAL", totalCount);
			meta.put("START_INDEX", (page_number - 1) * page_size + 1);
			meta.put("END_INDEX", (page_number * page_size) > totalCount ? totalCount : (page_number * page_size));

			query.setRange(range);

			Connection connection = null;
			DataSet dataSet = null;
			try
			{
				RelationalAPI relationalAPI = DBUtils.getOrgRelationalApi();
				connection = relationalAPI.getConnection();
				dataSet = relationalAPI.executeQuery(query, connection);

				OrgAPI orgAPI = IAMProxy.getInstance().getOrgAPI();
				UserAPI userAPI = IAMProxy.getInstance().getUserAPI();

				while (dataSet.next())
				{
					JSONObject eventAttrs = datasetToJson(dataSet);
					JSONObject event = new JSONObject();
					eventAttrs.put("USER_NAME", userAPI.getUser(eventAttrs.getLong(IDMPODGENERALADMINAUDITLOGS.USER_ID)).getDisplayName());
					eventAttrs.put(IDMPODAUDITOPERATIONTYPES.OPERATION_DISPLAY_NAME, I18N.getMsg(eventAttrs.getString(IDMPODAUDITOPERATIONTYPES.OPERATION_DISPLAY_NAME)));
					event.put(JsonApiConstants.ID, eventAttrs.get(IDMPODGENERALADMINAUDITLOGS.UNIQUE_ID));
					event.put(JsonApiConstants.TYPE, TYPE);
					event.put(JsonApiConstants.ATTRIBUTES, eventAttrs);
					events.put(event);
				}

				//				LOGGER.info(relationalAPI.getSelectSQL(query));
			}
			catch (Exception e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
			finally
			{
				DBUtils.safeClose(connection, dataSet);
			}

			resp.put(JsonApiConstants.DATA, events);
			resp.put(JsonApiConstants.META, meta);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return resp;
	}

	private static Criteria constructOpNameCrit(String searchString)
	{
		List<String> keys = new ArrayList<>();
		searchString = searchString.toLowerCase();

		String[] possibles = new String[]{"idmpod.reports.audit.op_display_name.access_application", "idmpod.reports.audit.op_display_name.logout_from_application", "idmpod.reports.audit.op_display_name.assign_saml_apps_to_user", "idmpod.reports.audit.op_display_name.update_user", "idmpod.reports.audit.op_display_name.delete_user", "idmpod.reports.audit.op_display_name.delete_invitations", "idmpod.reports.audit.op_display_name.add_saml_app", "idmpod.reports.audit.op_display_name.update_saml_app", "idmpod.reports.audit.op_display_name.delete_saml_app", "idmpod.reports.audit.op_display_name.assign_users_to_saml_app", "idmpod.reports.audit.op_display_name.remove_users_from_saml_app", "idmpod.reports.audit.op_display_name.add_directory", "idmpod.reports.audit.op_display_name.update_directory", "idmpod.reports.audit.op_display_name.delete_directory", "idmpod.reports.audit.op_display_name.import_directory_users", "idmpod.reports.audit.op_display_name.add_users_to_directory", "idmpod.reports.audit.op_display_name.update_organizational_unit", "idmpod.reports.audit.op_display_name.setup_directory_sync", "idmpod.reports.audit.op_display_name.create_auth_token", "idmpod.reports.audit.op_display_name.update_subscription", "idmpod.reports.audit.op_display_name.add_public_domain", "idmpod.reports.audit.op_display_name.update_public_domain", "idmpod.reports.audit.op_display_name.delete_public_domain", "idmpod.reports.audit.op_display_name.access_user_portal", "idmpod.reports.audit.op_display_name.access_admin_portal",};//No I18N

		for (String possible : possibles)
		{
			try
			{
				if (I18N.getMsg(possible).toLowerCase().contains(searchString))
				{
					keys.add(possible);
				}
			}
			catch (Exception e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
		}
		return new Criteria(Column.getColumn(IDMPODAUDITOPERATIONTYPES.TABLE, IDMPODAUDITOPERATIONTYPES.OPERATION_DISPLAY_NAME), keys.toArray(new String[keys.size()]), QueryConstants.IN, false);
	}

	public static void auditAdminOperation(JSONObject requestJson, JSONObject respJson, OperationType operationType)
	{
		auditAdminOperation(requestJson, respJson, operationType, null);
	}

	public static void auditAdminOperation(JSONObject requestJson, JSONObject respJson, OperationType operationType, String... remarkParams)
	{
		try
		{
			Criteria opTypeCrit = new Criteria(Column.getColumn(IDMPODAUDITOPERATIONTYPES.TABLE, IDMPODAUDITOPERATIONTYPES.OPERATION_NAME), operationType.getOpType(), QueryConstants.EQUAL, false);
			DataObject dataObject = DBUtils.getOrgPersistence().get(IDMPODAUDITOPERATIONTYPES.TABLE, opTypeCrit);
			if (dataObject.containsTable(IDMPODAUDITOPERATIONTYPES.TABLE))
			{
				HttpServletRequest request = IdmpodThreadLocal.getRequest();
				Long userId = IAMUtil.getCurrentUser().getZUID();

				Row opTypeRow = dataObject.getFirstRow(IDMPODAUDITOPERATIONTYPES.TABLE);
				Row auditRow = new Row(IDMPODGENERALADMINAUDITLOGS.TABLE);

				JSONObject subjectInfo = getSubjectDetails(requestJson, respJson, operationType);
				Long subjId = subjectInfo.has(IDMPODGENERALADMINAUDITLOGS.SUBJECT_ID) ? subjectInfo.getLong(IDMPODGENERALADMINAUDITLOGS.SUBJECT_ID) : null;
				auditRow.set(IDMPODGENERALADMINAUDITLOGS.SUBJECT_ID, subjId);
				auditRow.set(IDMPODGENERALADMINAUDITLOGS.SUBJECT_TYPE, subjectInfo.get(IDMPODGENERALADMINAUDITLOGS.SUBJECT_TYPE));
				auditRow.set(IDMPODGENERALADMINAUDITLOGS.USER_ID, userId);
				auditRow.set(IDMPODGENERALADMINAUDITLOGS.TIMESTAMP, System.currentTimeMillis());
				auditRow.set(IDMPODGENERALADMINAUDITLOGS.OPERATION_TYPE_ID, opTypeRow.get(IDMPODAUDITOPERATIONTYPES.OPERATION_TYPE_ID));
				auditRow.set(IDMPODGENERALADMINAUDITLOGS.SUBJECT_ATTRIBUTES, subjectInfo.has(IDMPODGENERALADMINAUDITLOGS.SUBJECT_ATTRIBUTES) ? subjectInfo.get(IDMPODGENERALADMINAUDITLOGS.SUBJECT_ATTRIBUTES).toString() : null);

				auditRow.set(IDMPODGENERALADMINAUDITLOGS.REMARKS, getRemarks(respJson, operationType, remarkParams));
				auditRow.set(IDMPODGENERALADMINAUDITLOGS.RESULT_STATUS, getResultStatus(respJson));

				auditRow.set(IDMPODGENERALADMINAUDITLOGS.CLIENT_IP, getClientIp(request));
				auditRow.set(IDMPODGENERALADMINAUDITLOGS.USER_AGENT_INFO, HttpUtils.getUserAgentInfo(request));

				dataObject.addRow(auditRow);

				DBUtils.getOrgPersistence().update(dataObject);
			}
			else
			{
				throw new UnsupportedOperationException("Unable to find operation type definition for " + operationType.getOpType());// No I18N
			}
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Exception while logging admin operation.", e);
		}
	}

	private static String getRemarks(JSONObject respJson, OperationType opType, String... remarkParams)
	{
		String remarks = null;
		if (respJson.has(JsonApiConstants.ERRORS))
		{
			remarks = respJson.getJSONArray(JsonApiConstants.ERRORS).toString();
		}
		else if (opType == OperationType.ASSIGN_SAML_APPS_TO_USER || opType == OperationType.ASSIGN_USERS_TO_SAML_APP || opType == OperationType.REMOVE_USERS_FROM_SAML_APP || opType == OperationType.IMPORT_DIRECTORY_USERS || opType == OperationType.ADD_USERS_TO_DIRECTORY || opType == OperationType.ASSIGN_SAML_APPS_TO_USERS || opType == OperationType.UNASSIGN_SAML_APPS_FROM_USERS)
		{
			try
			{
				remarks = I18N.getMsg(opType.getRemarksTemplate(), remarkParams);
			}
			catch (Exception e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
		}
		else if (opType.getMethod().equalsIgnoreCase("DELETE") && remarkParams != null)
		{
			try
			{
				remarks = I18N.getMsg(opType.getRemarksTemplate(), remarkParams);
			}
			catch (Exception e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
		}
		return remarks;
	}

	private static boolean getResultStatus(JSONObject respJson)
	{
		boolean resultStatus = true;
		if (respJson.has(JsonApiConstants.ERRORS) && respJson.getJSONArray(JsonApiConstants.ERRORS).length() > 0)
		{
			resultStatus = false;
		}
		return resultStatus;
	}

	private static JSONObject getSubjectDetails(JSONObject requestJson, JSONObject respJson, OperationType operationType)
	{
		JSONObject subjDetails = new JSONObject();
		Long id = JsonApiHandler.getResourceId(requestJson, respJson);
		subjDetails.put(IDMPODGENERALADMINAUDITLOGS.SUBJECT_ID, id);
		subjDetails.put(IDMPODGENERALADMINAUDITLOGS.SUBJECT_TYPE, operationType.getResourceType());
		if (requestJson.has(JsonApiConstants.DATA))
		{
			JSONObject data = requestJson.getJSONObject(JsonApiConstants.DATA);
			subjDetails.put(IDMPODGENERALADMINAUDITLOGS.SUBJECT_ATTRIBUTES, data.has(JsonApiConstants.ATTRIBUTES) ? data.get(JsonApiConstants.ATTRIBUTES) : null);
		}
		else
		{
			subjDetails.put(IDMPODGENERALADMINAUDITLOGS.SUBJECT_ATTRIBUTES, (Object) null);
		}
		return subjDetails;
	}

	public static String getClientIp(HttpServletRequest request)
	{
		if (getIPAuditForCountry(IdmpodThreadLocal.getOrgCountryCode()) && getIPAuditForOrg(IdmpodIAMUtil.getZOID()))
		{
			String xForwardedForHeader = request.getHeader("X-Forwarded-For");
			if (xForwardedForHeader == null)
			{
				return request.getRemoteAddr();
			}
			else
			{
				// As of https://en.wikipedia.org/wiki/X-Forwarded-For
				// The general format of the field is: X-Forwarded-For: client, proxy1, proxy2 ...
				// we only want the client
				return new StringTokenizer(xForwardedForHeader, ",").nextToken().trim();
			}
		}
		else
		{
			return null;
		}
	}
}
