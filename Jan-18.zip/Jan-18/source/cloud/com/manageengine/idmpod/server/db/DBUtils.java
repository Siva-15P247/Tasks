package com.manageengine.idmpod.server.db;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.*;
import com.adventnet.mfw.bean.BeanUtil;
import com.adventnet.persistence.*;
import com.adventnet.sas.ds.SASThreadLocal;
import com.manageengine.idmpod.server.error.IdmpodException;
import com.manageengine.idmpod.server.iam.IdmpodUserRole;
import com.manageengine.idmpod.server.utils.IdmpodThreadLocal;
import com.manageengine.tables.idmpod.IDMPODINVITEDUSERS;
import com.manageengine.tables.idmpod.IDMPODTECHNICIAN;
import com.manageengine.tables.idmpod.IDMPODUSERRESOURCEVIEW;
import org.apache.commons.io.IOUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBUtils
{

	private static final Logger LOGGER = Logger.getLogger(DBUtils.class.getName());

	public static Persistence getOrgPersistence() throws IdmpodException
	{
		try
		{
			String zaaid = IdmpodThreadLocal.getAppId();
			Persistence result = getAAPersistence(zaaid);
			return result;
		}
		catch (IdmpodException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	public static ReadOnlyPersistence getReadOnlyOrgPersistence()
	{
		String zaaid = IdmpodThreadLocal.getAppId();
		try
		{
			return getReadOnlyAAPersistence(zaaid);
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	public static ReadOnlyPersistence getReadOnlyAAPersistence(String zaaid) throws Exception
	{
		return (ReadOnlyPersistence) BeanUtil.lookup("PureReadOnlyPersistence", zaaid);
	}

	public static RelationalAPI getOrgRelationalApi() throws IdmpodException
	{
		try
		{
			String zaaid = IdmpodThreadLocal.getAppId();
			return getAARelationalApi(zaaid);
		}
		catch (IdmpodException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	public static RelationalAPI getAARelationalApi(String zaaid) throws IdmpodException
	{
		try
		{
			IdmpodRelationalApi relationalAPI = (IdmpodRelationalApi) BeanUtil.lookup("IdmpodRelationalApi", zaaid);
			return relationalAPI.getContextualApi();
		}
		catch (IdmpodException e)
		{
			throw e;
		}
		catch (Exception e)
		{
			throw new RuntimeException(e);
		}
	}

	public static Persistence getAAPersistence(String zaaid) throws Exception
	{
		return (Persistence) BeanUtil.lookup("Persistence", zaaid);
	}

	public static boolean checkIfNewUser(String emailId) throws Exception
	{
		Object res = getRowFromTable(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.EMAIL_ID, emailId);
		return (res == null) ? true : false;
	}

	public static Object getRowFromTable(String tableName, String criteriaCol, Object critVal) throws IdmpodException, DataAccessException
	{
		Criteria crit = new Criteria(Column.getColumn(tableName, criteriaCol), critVal, QueryConstants.EQUAL);
		DataObject dobj = (DataObject) (getOrgPersistence().get(tableName, crit));
		return (dobj.isEmpty()) ? null : dobj.getFirstRow(tableName);
	}

	public static DataObject getRowsFromTable(String tableName, String criteriaCol, Object critVal) throws IdmpodException, DataAccessException
	{
		Criteria crit = null;
		if (criteriaCol != null)
		{
			crit = new Criteria(Column.getColumn(tableName, criteriaCol), critVal, QueryConstants.EQUAL);
		}
		DataObject dobj = (DataObject) (getOrgPersistence().get(tableName, crit));
		return dobj;
	}

	public static long addInvitedUserEntry(String firstName, String lastName, String emailid, IdmpodUserRole role, String selGroups) throws IdmpodException, DataAccessException
	{
		WritableDataObject wdo = (WritableDataObject) getOrgPersistence().constructDataObject();
		Row r = new Row(IDMPODINVITEDUSERS.TABLE);
		r.set(IDMPODINVITEDUSERS.FIRST_NAME, firstName);
		r.set(IDMPODINVITEDUSERS.LAST_NAME, lastName);
		r.set(IDMPODINVITEDUSERS.EMAIL_ID, emailid);
		r.set(IDMPODINVITEDUSERS.ROLE, IdmpodUserRole.getString(role));
		if (role == IdmpodUserRole.ADMINISTRATOR)
		{
			r.set(IDMPODINVITEDUSERS.VIEW_RESOURCE, "1=1");
		}
		else
		{
			r.set(IDMPODINVITEDUSERS.VIEW_RESOURCE, selGroups);
		}
		wdo.addRow(r);
		getOrgPersistence().update(wdo);
		return (long) r.get(IDMPODINVITEDUSERS.ID);
	}

	public static void updateInvitedUsersTable(String email) throws IdmpodException, DataAccessException
	{
		Row r = (Row) getRowFromTable(IDMPODINVITEDUSERS.TABLE, IDMPODINVITEDUSERS.EMAIL_ID, email);
		r.set(IDMPODINVITEDUSERS.STATUS, "REINVITED");//NO I18N
		Persistence persistence = getOrgPersistence();
		DataObject dobj = persistence.get(IDMPODINVITEDUSERS.TABLE, (Criteria) null);
		dobj.updateRow(r);
		persistence.update(dobj);
	}

	public static void removeInvitedUser(String email) throws IdmpodException, DataAccessException
	{
		Row r = (Row) getRowFromTable(IDMPODINVITEDUSERS.TABLE, IDMPODINVITEDUSERS.EMAIL_ID, email);
		Criteria c = null;
		DataObject dobj = getOrgPersistence().get(IDMPODINVITEDUSERS.TABLE, c);
		dobj.deleteRow(r);
		getOrgPersistence().update(dobj);
	}

	public static void removeTechnician(long zuid) throws IdmpodException, DataAccessException
	{
		// LOGGER.log(Level.FINER, "removing technician : {0}", zuid);
		Criteria crit = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ZUID), zuid, QueryConstants.EQUAL);
		DataObject dobj = getOrgPersistence().get(IDMPODTECHNICIAN.TABLE, crit);
		Row r = dobj.getRow(IDMPODTECHNICIAN.TABLE);
		dobj.deleteRow(r);
		getOrgPersistence().update(dobj);
	}

	public static void changeStatus(long zuid, String status) throws IdmpodException, DataAccessException
	{
		// LOGGER.log(Level.FINER, "changeStatus as {0} for zuid {1}", new Object[]{status, zuid});
		Criteria crit = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ZUID), zuid, QueryConstants.EQUAL);
		DataObject dobj = getOrgPersistence().get(IDMPODTECHNICIAN.TABLE, crit);
		Row r = dobj.getRow(IDMPODTECHNICIAN.TABLE);
		r.set(IDMPODTECHNICIAN.STATUS, status);
		dobj.updateRow(r);
		getOrgPersistence().update(dobj);
	}

	public static boolean checkIfModified(IdmpodUserRole role, long zuid) throws IdmpodException, DataAccessException
	{
		Row r = (Row) getRowFromTable(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ZUID, zuid);
		String oldRoleString = r.get(IDMPODTECHNICIAN.ROLE).toString();
		IdmpodUserRole oldRole = IdmpodUserRole.getRole(oldRoleString);
		return role != oldRole;
	}

	public static long changeRoleInLocalDb(long zuid, IdmpodUserRole role)
	{
		// LOGGER.log(Level.INFO, "DBUtils:changeRoleInLocalDb going to change the role in service database as - {0} for user - {1}", new Object[]{role, zuid});
		long userId = 0l;
		try
		{
			Criteria crit = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ZUID), zuid, QueryConstants.EQUAL);
			DataObject dobj = getOrgPersistence().get(IDMPODTECHNICIAN.TABLE, crit);
			Row r = dobj.getRow(IDMPODTECHNICIAN.TABLE);
			String roleString = IdmpodUserRole.getString(role);
			r.set(IDMPODTECHNICIAN.ROLE, roleString);
			dobj.updateRow(r);
			getOrgPersistence().update(dobj);
			userId = (Long) r.get(IDMPODTECHNICIAN.USER_ID);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		return userId;
	}

	public static void updateResourceView(IdmpodUserRole role, String groups, long userId, long zuid)
	{
		// LOGGER.log(Level.INFO, "DBUtils:updateResourceView going to update resources in resource view table for user with ID -{0}, groups - {1}", new Object[]{userId, groups});
		try
		{
			if (userId == 0)
			{
				Row tempRow = (Row) getRowFromTable(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ZUID, zuid);
				userId = (Long) tempRow.get(IDMPODTECHNICIAN.USER_ID);
			}
			Criteria crit = new Criteria(Column.getColumn(IDMPODUSERRESOURCEVIEW.TABLE, IDMPODUSERRESOURCEVIEW.USER_ID), userId, QueryConstants.EQUAL);
			DataObject dobj = getOrgPersistence().get(IDMPODUSERRESOURCEVIEW.TABLE, crit);
			Row r = dobj.getRow(IDMPODUSERRESOURCEVIEW.TABLE);
			if (r == null)
			{
				r = new Row(IDMPODUSERRESOURCEVIEW.TABLE);
				r.set(IDMPODUSERRESOURCEVIEW.USER_ID, userId);
				dobj.addRow(r);
			}
			if (role == IdmpodUserRole.ADMINISTRATOR)
			{
				r.set(IDMPODUSERRESOURCEVIEW.VIEW_RESOURCE, "1=1");
			}
			else
			{
				r.set(IDMPODUSERRESOURCEVIEW.VIEW_RESOURCE, groups.substring(0, groups.length() - 1));
			}
			dobj.updateRow(r);
			getOrgPersistence().update(dobj);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "updateResourceView", e);
		}
	}

	public static JSONObject rowToJson(Row row) throws JSONException
	{
		JSONObject json = new JSONObject();
		List values = row.getValues();
		List columns = row.getColumns();

		for (int i = 0; i < values.size(); ++i)
		{
			if (values.get(i) != null)
			{
				json.put(columns.get(i).toString(), values.get(i));
			}
		}
		return json.length() == 0 ? null : json;
	}

	public static void rowToJson(Row row, JSONObject jsonObject) throws JSONException
	{
		List values = row.getValues();
		List columns = row.getColumns();
		for (int i = 0; i < values.size(); ++i)
		{
			if (values.get(i) != null)
			{
				jsonObject.put(columns.get(i).toString(), values.get(i));
			}
		}
	}

	public static JSONObject datasetToJson(DataSet ds) throws SQLException
	{
		return datasetToJson(ds, new JSONObject());
	}

	public static JSONObject datasetToJson(DataSet ds, JSONObject json) throws SQLException
	{
		for (int i = 1; i <= ds.getColumnCount(); i++)
		{
			String columnName = ds.getColumnName(i);
			Object columnValue = ds.getValue(i);
			if (columnValue instanceof ByteArrayInputStream)
			{
				try
				{
					columnValue = IOUtils.toString((InputStream) columnValue, StandardCharsets.UTF_8);
				}
				catch (IOException e)
				{
					LOGGER.log(Level.SEVERE, e.getMessage(), e);
				}
			}
			json.put(columnName, columnValue);
		}
		return json;
	}

	public static void safeClose(Connection connection, DataSet... dataSets)
	{
		safeClose(connection);
		for (DataSet dataSet : dataSets)
		{
			safeClose(dataSet);
		}
	}

	public static void safeClose(ResultSet rs, Statement stmt, Connection con)
	{
		safeClose(rs, null, stmt, null, con);

	}

	public static void safeClose(ResultSet rs, DataSet ds, Statement stmt, PreparedStatement pStmt, Connection con)
	{
		safeClose(rs);
		safeClose(stmt);
		safeClose(pStmt);
		safeClose(con);
		safeClose(ds);
	}

	public static void safeClose(AutoCloseable closeable)
	{
		if (closeable != null)
		{
			try
			{
				closeable.close();
			}
			catch (Exception e)
			{
				closeable = null;
			}
		}
	}

	public static void safeClose(Closeable closeable)
	{
		if (closeable != null)
		{
			try
			{
				closeable.close();
			}
			catch (Exception e)
			{
				closeable = null;
			}
		}
	}

	public static void safeClose(DataSet closeable)
	{

		if (closeable != null)
		{
			try
			{
				closeable.close();
			}
			catch (Exception e)
			{
				closeable = null;
			}
		}

	}

	public static Range constructRange(Integer page_number, Integer page_size)
	{
		Integer startIndex = (page_number - 1) * page_size + 1;
		return new Range(startIndex.intValue(), page_size.intValue());
	}

	public static Integer getCount(String tableName, Criteria crit)
	{
		Connection connection = null;
		DataSet dataSet = null;
		Integer count = 0;
		try
		{
			SelectQuery sq = new SelectQueryImpl(Table.getTable(tableName));
			Column countColumn = Column.getColumn(null, "*");
			sq.addSelectColumn(countColumn.count());
			sq.setCriteria(crit);

			RelationalAPI relationalAPI = getOrgRelationalApi();
			connection = relationalAPI.getConnection();

			dataSet = relationalAPI.executeQuery(sq, connection);
			while (dataSet.next())
			{
				count = (Integer) dataSet.getValue(1);
			}
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		finally
		{
			safeClose(connection, dataSet);
		}
		return count;
	}

	public static Integer getCount(String tableName, Criteria crit, String zaaid)
	{
		Connection connection = null;
		DataSet dataSet = null;
		Integer count = 0;
		try
		{
			SASThreadLocal.setThreadLocalForDomain(zaaid);
			SelectQuery sq = new SelectQueryImpl(Table.getTable(tableName));
			Column countColumn = Column.getColumn(null, "*");
			sq.addSelectColumn(countColumn.count());
			sq.setCriteria(crit);

			RelationalAPI relationalAPI = getAARelationalApi(zaaid);
			connection = relationalAPI.getConnection();

			dataSet = relationalAPI.executeQuery(sq, connection);
			while (dataSet.next())
			{
				count = (Integer) dataSet.getValue(1);
			}
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		finally
		{
			safeClose(connection, dataSet);
		}
		return count;
	}

	public static int getQueryResultCount(SelectQuery query)
	{
		int count = 0;
		DataSet dataSet = null;
		Connection connection = null;
		try
		{
			RelationalAPI relationalAPI = RelationalAPI.getInstance();
			connection = relationalAPI.getConnection();
			SelectQuery sq = new SelectQueryImpl((Table) (query.getTableList().get(0)));
			for (Join j : (List<Join>) query.getJoins())
			{
				sq.addJoin(j);
			}
			sq.setCriteria(query.getCriteria());


			Column countColumn = new Column(null, "*");
			countColumn.setColumnAlias("COUNT_COLUMN");
			sq.addSelectColumn(countColumn.count());
			dataSet = relationalAPI.executeQuery(sq, connection);
			while (dataSet.next())
			{
				count = (Integer) dataSet.getValue(1);
			}
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		finally
		{
			safeClose(connection, dataSet);
		}
		return count;
	}

	public static int getUnmodifiedQueryCount(SelectQuery query)
	{
		int count = 0;
		DataSet dataSet = null;
		Connection connection = null;
		try
		{
			SelectQuery select = (SelectQuery) query.clone();
			List list = select.getSortColumns();
			for (Iterator<SortColumn> iterator = list.iterator(); iterator.hasNext(); )
			{
				SortColumn sortColumn = iterator.next();
				select.removeSortColumn(sortColumn);
			}
			DerivedTable derivedTable = new DerivedTable("COUNT_TABLE", select);//No I18N
			RelationalAPI relationalAPI = RelationalAPI.getInstance();
			connection = relationalAPI.getConnection();
			SelectQuery sq = new SelectQueryImpl(derivedTable);
			Column countColumn = new Column(null, "*");
			countColumn.setColumnAlias("COUNT_COLUMN");
			sq.addSelectColumn(countColumn.count());
			dataSet = relationalAPI.executeQuery(sq, connection);
			while (dataSet.next())
			{
				count = (Integer) dataSet.getValue(1);
			}
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		finally
		{
			safeClose(connection, dataSet);
		}
		return count;
	}

}
