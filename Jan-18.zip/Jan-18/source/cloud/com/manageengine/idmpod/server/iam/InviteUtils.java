package com.manageengine.idmpod.server.iam;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.User;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Persistence;
import com.adventnet.persistence.Row;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.tables.idmpod.IDMPODINVITEDUSERS;

import java.util.logging.Logger;

public class InviteUtils
{

	private static final Logger LOGGER = Logger.getLogger(IdmpodUserRole.class.getName());

	/**
	 * @return null- if user not invited
	 * @throws DataAccessException
	 */
	public static IdmpodUserRole getInvitedUserRole() throws DataAccessException
	{
		Row row = getInvitedUserRow();
		IdmpodUserRole toReturn = null;
		if (row != null)
		{
			String roleString = (String) row.get(IDMPODINVITEDUSERS.ROLE);
			toReturn = IdmpodUserRole.getRole(roleString);
		}
		return toReturn;
	}

	public static String getViewResource() throws DataAccessException
	{
		Row row = getInvitedUserRow();
		return (String) row.get(IDMPODINVITEDUSERS.VIEW_RESOURCE);
	}

	public static boolean isUserInvited(Persistence persistence) throws DataAccessException
	{
		Row row = getInvitedUserRow(persistence);
		return row != null;
	}

	private static Row getInvitedUserRow() throws DataAccessException
	{
		Persistence persistence = DBUtils.getOrgPersistence();
		return getInvitedUserRow(persistence);
	}

	private static Row getInvitedUserRow(Persistence persistence) throws DataAccessException
	{
		User user = IAMUtil.getCurrentUser();
		return getInvitedUserRow(persistence, user);
	}

	private static Row getInvitedUserRow(Persistence persistence, User user) throws DataAccessException
	{
		String userMail = user.getPrimaryEmail();
		Column emailColumn = Column.getColumn(IDMPODINVITEDUSERS.TABLE, IDMPODINVITEDUSERS.EMAIL_ID);
		Criteria emailCriteria = new Criteria(emailColumn, userMail, QueryConstants.EQUAL, false);
		DataObject dataObject = persistence.get(IDMPODINVITEDUSERS.TABLE, emailCriteria);
		return dataObject.getRow(IDMPODINVITEDUSERS.TABLE);
	}

	public static boolean isUserInvited(Persistence persistence, User user) throws DataAccessException
	{
		Row row = getInvitedUserRow(persistence, user);
		return row != null;
	}
}
