package com.manageengine.idmpod.server.utils;

import com.zoho.conf.Configuration;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.*;
import java.util.logging.Logger;

public class HttpUtils
{

	private static final String DEFAULT_HTTP_SCHEME = "https";//No I18N

	public static String getWebUrl(HttpServletRequest request)
	{
		String scheme = DEFAULT_HTTP_SCHEME;
		if (!Configuration.getBoolean("production"))
		{
			scheme = request.getScheme();
		}
		return new StringBuilder().append(scheme).append("://").append(request.getServerName()).append(":").append(request.getServerPort()).toString();
	}

	public static String getWebUrl()
	{
		HttpServletRequest request = IdmpodThreadLocal.getRequest();
		return getWebUrl(request);
	}

	public static Map<String, List<String>> splitQuery(URL url) throws UnsupportedEncodingException
	{
		final Map<String, List<String>> query_pairs = new LinkedHashMap<String, List<String>>();
		final String[] pairs = url.getQuery().split("&");
		for (String pair : pairs)
		{
			final int idx = pair.indexOf("=");
			final String key = idx > 0 ? URLDecoder.decode(pair.substring(0, idx), "UTF-8") : pair;
			if (!query_pairs.containsKey(key))
			{
				query_pairs.put(key, new LinkedList<String>());
			}
			final String value = idx > 0 && pair.length() > idx + 1 ? URLDecoder.decode(pair.substring(idx + 1), "UTF-8") : null;
			query_pairs.get(key).add(value);
		}
		return query_pairs;
	}

	public static String getClientIp(HttpServletRequest request)
	{
		String xForwardedForHeader = request.getHeader("X-Forwarded-For");
		if (xForwardedForHeader == null)
		{
			return request.getRemoteAddr();
		}
		else
		{
			// As of https://en.wikipedia.org/wiki/X-Forwarded-For
			// The general format of the field is: X-Forwarded-For: client, proxy1, proxy2 ...
			// we only want the client
			return new StringTokenizer(xForwardedForHeader, ",").nextToken().trim();
		}
	}

	public static String getUserAgentInfo(HttpServletRequest request)
	{
		return request.getHeader(HttpHeaders.USER_AGENT);
	}

	public static class HttpResult
	{

		private final String content;
		private final int status;
		private final String contentType;

		public HttpResult(int status, String content, String contentType)
		{
			this.content = content;
			this.status = status;
			this.contentType = contentType;
		}

		@Override
		public String toString()
		{
			return "status:" + this.status + ",content:" + content;//No I18N
		}

		public String getContent()
		{
			return this.content;
		}

		public String getContentType()
		{
			return this.contentType;
		}

		public int getStatus()
		{
			return this.status;
		}

		public boolean isSuccess()
		{
			return this.status >= 200 && this.status < 300;
		}

	}

	private static final Logger LOGGER = Logger.getLogger(HttpUtils.class.getName());
	public static final String UTF8 = "UTF-8";//No I18N

	private static final int CLIENT_TIMEOUT = 10 * 1000;

	private static HttpClient httpClient;

	private static synchronized HttpClient getProxyClient()
	{
		if (httpClient == null)
		{
			RequestConfig config = RequestConfig.custom().
					setConnectTimeout(CLIENT_TIMEOUT).
					setConnectionRequestTimeout(CLIENT_TIMEOUT).
					setSocketTimeout(CLIENT_TIMEOUT).
					build();
			httpClient = HttpClientBuilder.create().
					setDefaultRequestConfig(config).
					useSystemProperties().
					build();
		}
		return httpClient;
	}

	public static String constructUrl(String path, String... paramKeyAndValues) throws UnsupportedEncodingException
	{
		StringBuilder urlBuilder = new StringBuilder(path).append("?");
		boolean isKey = true;
		String del = "";
		String sep = "";
		for (String keyOrValue : paramKeyAndValues)
		{
			urlBuilder.append(isKey ? del : sep).append(URLEncoder.encode(keyOrValue, UTF8));
			del = "&";
			sep = "=";
			isKey = !isKey;
		}
		return urlBuilder.toString();
	}

	public static HttpResult getHttpResponse(HttpRequestBase request) throws IOException
	{
		HttpClient client = getProxyClient();
		HttpResponse response = client.execute(request);
		HttpEntity entity = response.getEntity();
		int status = response.getStatusLine().getStatusCode();
		String content = IOUtils.toString(entity.getContent());
		ContentType contentType = ContentType.get(entity);
		EntityUtils.consumeQuietly(response.getEntity());
		return new HttpResult(status, content, (contentType) != null ? contentType.toString() : ContentType.APPLICATION_JSON.toString());
	}

	public static HttpResult getHttpResponse(String path, String... paramKeyAndValues) throws Exception
	{
		String url = constructUrl(path, paramKeyAndValues);
		// LOGGER.log(Level.INFO, " gettingHttpResponseUrl: {0}", url);
		HttpGet getMethod = new HttpGet(url);
		return getHttpResponse(getMethod);
	}

	public static HttpResult postHttpResponse(String path, String... paramKeyAndValues) throws Exception
	{
		String url = constructUrl(path, paramKeyAndValues);
		// LOGGER.log(Level.INFO, " postHttpResponseUrl: {0}", url);
		HttpPost postMethod = new HttpPost(url);
		return getHttpResponse(postMethod);
	}


}
