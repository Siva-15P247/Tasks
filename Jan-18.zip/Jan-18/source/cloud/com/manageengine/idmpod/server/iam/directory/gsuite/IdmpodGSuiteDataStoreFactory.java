package com.manageengine.idmpod.server.iam.directory.gsuite;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.google.api.client.util.IOUtils;
import com.google.api.client.util.Preconditions;
import com.google.api.client.util.store.AbstractDataStoreFactory;
import com.google.api.client.util.store.DataStore;
import com.google.api.client.util.store.DataStoreFactory;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.tables.idmpod.IDMPODGOOGLEDATASTORE;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.*;
import java.util.logging.Logger;

public class IdmpodGSuiteDataStoreFactory extends AbstractDataStoreFactory
{
	private static final Logger LOGGER = Logger.getLogger(IdmpodGSuiteDataStoreFactory.class.getName());

	@Override
	protected <V extends Serializable> DataStore<V> createDataStore(String id) throws IOException
	{
		return new IdmpodGSuiteDataStoreFactory.IdmpodGSuiteDataStore(this, id);
	}

	static class IdmpodGSuiteDataStore<V extends Serializable> implements DataStore<V>
	{
		private final DataStoreFactory dataStoreFactory;
		private final String id;

		protected IdmpodGSuiteDataStore(IdmpodGSuiteDataStoreFactory dataStoreFactory, String id)
		{
			this.dataStoreFactory = (IdmpodGSuiteDataStoreFactory) Preconditions.checkNotNull(dataStoreFactory);
			this.id = (String) Preconditions.checkNotNull(id);
		}

		@Override
		public DataStoreFactory getDataStoreFactory()
		{
			return this.dataStoreFactory;
		}

		@Override
		public String getId()
		{
			return id;
		}

		@Override
		public int size() throws IOException
		{
			return DBUtils.getCount(IDMPODGOOGLEDATASTORE.TABLE, null);
		}

		@Override
		public boolean isEmpty() throws IOException
		{
			return this.size() == 0;
		}

		@Override
		public boolean containsKey(String s) throws IOException
		{
			return DBUtils.getCount(IDMPODGOOGLEDATASTORE.TABLE, new Criteria(Column.getColumn(IDMPODGOOGLEDATASTORE.TABLE, IDMPODGOOGLEDATASTORE.UNIQUE_ID), s, QueryConstants.EQUAL)) != 0;
		}

		@Override
		public boolean containsValue(V v) throws IOException
		{
			if (v == null)
			{
				return false;
			}

			ByteArrayInputStream inputStream = new ByteArrayInputStream(IOUtils.serialize(v));
			return DBUtils.getCount(IDMPODGOOGLEDATASTORE.TABLE, new Criteria(Column.getColumn(IDMPODGOOGLEDATASTORE.TABLE, IDMPODGOOGLEDATASTORE.DATA), inputStream, QueryConstants.EQUAL)) != 0;
		}

		@Override
		public Set<String> keySet() throws IOException
		{
			Set<String> keySet = new HashSet<>();
			try
			{
				DataObject dataObject = DBUtils.getOrgPersistence().get(IDMPODGOOGLEDATASTORE.TABLE, (Criteria) null);
				if (dataObject.containsTable(IDMPODGOOGLEDATASTORE.TABLE))
				{
					Iterator<Row> rows = dataObject.getRows(IDMPODGOOGLEDATASTORE.TABLE);
					while (rows.hasNext())
					{
						Row row = rows.next();
						keySet.add(row.get(IDMPODGOOGLEDATASTORE.UNIQUE_ID).toString());
					}
				}
			}
			catch (DataAccessException e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
			return keySet;
		}

		@Override
		public Collection<V> values() throws IOException
		{
			Collection<V> collection = new ArrayList<>();
			try
			{
				DataObject dataObject = DBUtils.getOrgPersistence().get(IDMPODGOOGLEDATASTORE.TABLE, (Criteria) null);
				if (dataObject.containsTable(IDMPODGOOGLEDATASTORE.TABLE))
				{
					Iterator<Row> rows = dataObject.getRows(IDMPODGOOGLEDATASTORE.TABLE);
					while (rows.hasNext())
					{
						Row row = rows.next();
						collection.add(IOUtils.deserialize((InputStream) row.get(IDMPODGOOGLEDATASTORE.DATA)));
					}
				}
			}
			catch (DataAccessException e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
			return collection;
		}

		@Override
		public V get(String s) throws IOException
		{
			try
			{
				DataObject dataObject = DBUtils.getOrgPersistence().get(IDMPODGOOGLEDATASTORE.TABLE, new Criteria(Column.getColumn(IDMPODGOOGLEDATASTORE.TABLE, IDMPODGOOGLEDATASTORE.UNIQUE_ID), s, QueryConstants.EQUAL));
				if (dataObject.containsTable(IDMPODGOOGLEDATASTORE.TABLE))
				{
					Row row = dataObject.getFirstRow(IDMPODGOOGLEDATASTORE.TABLE);
					return IOUtils.deserialize((InputStream) row.get(IDMPODGOOGLEDATASTORE.DATA));
				}
			}
			catch (DataAccessException e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}

			return null;
		}

		@Override
		public DataStore<V> set(String s, V v) throws IOException
		{
			try
			{
				DataObject dataObject = DBUtils.getOrgPersistence().get(IDMPODGOOGLEDATASTORE.TABLE, new Criteria(Column.getColumn(IDMPODGOOGLEDATASTORE.TABLE, IDMPODGOOGLEDATASTORE.UNIQUE_ID), s, QueryConstants.EQUAL));
				if (dataObject.containsTable(IDMPODGOOGLEDATASTORE.TABLE))
				{
					Row row = dataObject.getFirstRow(IDMPODGOOGLEDATASTORE.TABLE);
					row.set(IDMPODGOOGLEDATASTORE.DATA, new ByteArrayInputStream(IOUtils.serialize(v)));
					dataObject.updateRow(row);
				}
				else
				{
					Row row = new Row(IDMPODGOOGLEDATASTORE.TABLE);
					row.set(IDMPODGOOGLEDATASTORE.UNIQUE_ID, Long.parseLong(s));
					row.set(IDMPODGOOGLEDATASTORE.DATA, new ByteArrayInputStream(IOUtils.serialize(v)));
					dataObject.addRow(row);
				}
				DBUtils.getOrgPersistence().update(dataObject);
			}
			catch (DataAccessException e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}

			return this;
		}

		@Override
		public DataStore<V> clear() throws IOException
		{
			//TODO: What cases does clear occur?
			return this;
		}

		@Override
		public DataStore<V> delete(String s) throws IOException
		{
			//TODO: What cases does delete occur?
			return this;
		}
	}
}
