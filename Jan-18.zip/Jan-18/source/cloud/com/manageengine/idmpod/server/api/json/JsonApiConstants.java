package com.manageengine.idmpod.server.api.json;

public class JsonApiConstants
{
	//ignorei18n_start
	public static final String JSON_CONTENT_TYPE = "application/vnd.api+json";
	public final static String BASE_PATH = "/api/json/";
	public final static String CLASS_INSTANCE = "CLASS_INSTANCE";
	public final static String METHOD_INSTANCE = "METHOD_INSTANCE";
	public final static String GET_INSTANCE_METHOD = "getInstance";

	public static final String DATA = "data";
	public static final String META = "meta";
	public static final String ATTRIBUTES = "attributes";
	public static final String TYPE = "type";
	public static final String ID = "id";
	public static final String ERRORS = "errors";
	public static final String DETAIL = "detail";
	public static final String SOURCE = "source";
	public static final String POINTER = "pointer";

	public static final String DATA_PATH = new StringBuffer().append(DATA).append('/').toString();
	public static final String DATA_ATTRIBUTES_PATH = new StringBuffer().append(DATA).append('/').append(ATTRIBUTES).append('/').toString();
	public static final String RELATIONSHIPS = "relationships";
	public static final String INCLUDED = "included";

	public static final String FILTER = "filter";
	public static final String SEARCH = "search";
	//ignorei18n_end
}
