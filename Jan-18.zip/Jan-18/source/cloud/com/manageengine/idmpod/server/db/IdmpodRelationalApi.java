package com.manageengine.idmpod.server.db;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.QueryConstructionException;
import com.adventnet.ds.query.SelectQuery;

import java.sql.Connection;
import java.sql.SQLException;

public interface IdmpodRelationalApi
{
	public RelationalAPI getContextualApi();

	public DataSet executeQuery(SelectQuery query, Connection connection) throws QueryConstructionException, SQLException;
}
