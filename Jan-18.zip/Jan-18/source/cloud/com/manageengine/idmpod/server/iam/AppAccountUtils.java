package com.manageengine.idmpod.server.iam;

import com.adventnet.iam.*;
import com.manageengine.idmpod.server.utils.IdmpodThreadLocal;
import com.manageengine.idmpod.server.utils.IdmpodUtils;
import com.zoho.accounts.*;
import com.zoho.accounts.Accounts.UserURI;
import com.zoho.accounts.AccountsProto.Account.AppAccount;
import com.zoho.accounts.AccountsProto.Account.AppAccount.AppAccountService.AccountMember;
import com.zoho.accounts.AccountsProto.Account.Invitation.InvitationDetails;
import com.zoho.accounts.AppResourceProto.App;
import com.zoho.resource.Criteria;
import com.zoho.resource.Criteria.Comparator;
import com.zoho.resource.ResourceException;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.manageengine.idmpod.server.iam.IdmpodIAMUtil.IDMPOD_ORG_TYPE;

public class AppAccountUtils
{
	private static final Logger LOGGER = Logger.getLogger(AppAccountUtils.class.getName());
	public static final int STATUS_ACTIVE = 1;
	public static final int STATUS_INACTIVE = 0;
	public static final String IDMPOD = System.getProperty("service.name", "idmpod");//NO I18N
	public static final String DISPLAY_NAME = "Identity Manager Plus";//NO I18N
	public static final String APPUSER = "user";//NO I18N

	public static final String SUPERADMIN = "SuperAdmin";//No I18N
	public static final String ADMIN = "Admin";//No I18N
	public static final String USER = "User";//No I18N

	public static AccountsProto.Account.User[] searchAccountUsers(String searchKey, String zuidStr)
	{
		try
		{
			Criteria C = new com.zoho.resource.Criteria(Accounts.RESOURCE.USER.ZUID, Comparator.NOT_IN, zuidStr);
			Criteria C1 = C.and(new Criteria(Accounts.RESOURCE.USER.DISPLAY_NAME, Comparator.LIKE, "*" + searchKey + "*").or(new Criteria(Accounts.RESOURCE.USER.FIRST_NAME, Comparator.LIKE, "*" + searchKey + "*")));
			return AppAccountUtils.getAccountUsers(C1);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Exception Trace: ", e);
		}
		return null;
	}

	public static AccountsProto.Account.User[] getAccountUsers(Criteria criteria) throws ResourceException
	{
		return getAccountUsers(criteria, -1, -1);
	}

	public static AccountsProto.Account.User[] getAccountUsers(Criteria criteria, int startIndex, int noOfResults) throws ResourceException
	{
		UserURI userURI = Accounts.getUserURI(IdmpodIAMUtil.getZAID());
		if (criteria != null)
		{
			userURI.getQueryString().setCriteria(criteria.and(new Criteria(Accounts.RESOURCE.USER.USER_STATUS, Comparator.EQUALS, User.ACTIVE)));
		}
		else
		{
			userURI.getQueryString().setCriteria(new Criteria(Accounts.RESOURCE.USER.USER_STATUS, Comparator.EQUALS, User.ACTIVE));
		}
		userURI.getQueryString().setOrderBy(Accounts.RESOURCE.USER.DISPLAY_NAME.name(), true);
		if (startIndex != -1 && noOfResults != -1)
		{
			userURI.getQueryString().setLimit(startIndex, noOfResults);
		}
		userURI.addSubResource(Accounts.RESOURCE.USEREMAIL.table());
		AccountsProto.Account.User[] users = userURI.GETS();
		return users;
	}

	public static com.zoho.accounts.AccountsProto.Account.User getAcountUser(long zuid) throws ResourceException
	{
		AccountsProto.Account.User[] users = AppAccountUtils.getAccountUsers(new Criteria(Accounts.RESOURCE.USER.ZUID, Comparator.EQUALS, zuid));
		if (users != null)
		{
			return (AccountsProto.Account.User) users[0];
		}
		return null;
	}

	public static AccountsProto.Account.User[] getAccountUsers() throws ResourceException
	{
		return AppAccountUtils.getAccountUsers(null);
	}


	public static String sendInvitation(String email) throws IAMException
	{
		return sendInvitation(email, AccountsConstants.IdentityProvider.ZOHO.dbValue());
	}

	public static String sendAzureInvitation(String email) throws IAMException
	{
		return sendInvitation(email, AccountsConstants.IdentityProvider.AZURE.dbValue());
	}

	public static String sendGAppsInvitation(String email) throws IAMException
	{
		return sendInvitation(email, AccountsConstants.IdentityProvider.GAPPS.dbValue());
	}

	static final String SERVICE_URL = IdmpodUtils.getProperty("serviceurl");

	static final String KEY_LABEL = IdmpodIAMUtil.getServiceName() + "_secret";//NO I18N

	public static String sendInvitation(String email, int idp) throws IAMException
	{
		//		if (AccountsUtil.getCurrentUser().isOrgAdmin())
		//		{
		Long zaaid = IdmpodThreadLocal.getAppIdLong();
		try
		{
			AppAccountAPI appAccountAPI = IAMProxy.getInstance().getAppAccountAPI();
			String id = CryptoUtil.encrypt(KEY_LABEL, email);
			String acceptURL = SERVICE_URL + "/invitationaccept?id=" + id;//NO I18N
			String rejectURL = "";//TODO
			String ipAddress = "";
			String firstName = "";
			String lastName = "";
			Boolean success = appAccountAPI.inviteUserToAppAccount(IDMPOD_ORG_TYPE.getType(), zaaid, email, firstName, lastName, AppAccountUtils.IDMPOD, USER, ipAddress, acceptURL, rejectURL, idp);
			return null;
		}
		catch (IAMException ie)
		{
			LOGGER.log(Level.SEVERE, "Exception Trace: ", ie);
			throw ie;
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Exception Trace: ", e);
		}
		//		}
		return null;
	}

	public static boolean deleteInvitation(String email)
	{
		//		if (AccountsUtil.getCurrentUser().isOrgAdmin())
		//		{
		try
		{
			AppAccountAPI appAccountAPI = IAMProxy.getInstance().getAppAccountAPI();
			return appAccountAPI.deleteInvitation(IDMPOD_ORG_TYPE.getType(), IdmpodThreadLocal.getAppIdLong(), email, AppAccountUtils.IDMPOD);
		}
		catch (IAMException e)
		{
			LOGGER.log(Level.SEVERE, "Exception Trace: ", e);
			return false;
		}
		//		}
		//		return false;
	}

	public static List<InvitationDetails> getSentInvitations()
	{
		try
		{
			AppAccountAPI appAccountAPI = IAMProxy.getInstance().getAppAccountAPI();
			List<InvitationDetails> invitation = appAccountAPI.getInvitaions(IDMPOD_ORG_TYPE.getType(), IdmpodThreadLocal.getAppIdLong(), AppAccountUtils.IDMPOD);
			return invitation;
		}
		catch (IAMException e)
		{
			LOGGER.log(Level.SEVERE, "Exception trace:", e);
			return null;
		}
	}

	public static int getSentInvitationsCount()
	{
		int invitCount = 0;
		List<InvitationDetails> invitation = getSentInvitations();
		if (invitation != null)
		{
			invitCount = invitation.size();
		}
		return invitCount;
	}

	/**
	 * To create a user in IAM if the domain is verified
	 *
	 * @param zoid
	 * @param userName
	 * @param password
	 * @param email
	 * @return
	 * @throws IAMException
	 */
	public static long addUserToIAM(long zoid, String userName, String password, String email, Boolean isConfirmed, Boolean isOTP) throws IAMException
	{
		long zuid = -1l;
		UserAPI uapi = IAMProxy.getInstance().getUserAPI();
		// LOGGER.log(Level.INFO, "Adding new User with config: {0} ", new String[]{email});
		String result = uapi.addUserToOrg(zoid, email, password, isConfirmed, isOTP);
		String[] res_zuid = result.split(":"); // No I18N
		if (res_zuid[0].equals("SUCCESS"))
		{
			String userZUID = res_zuid[1];
			zuid = Long.valueOf(userZUID);
		}

		return zuid;
	}

	public static long addUserToIAM(long zoid, String userName, String password, String email, Boolean isConfirmed) throws IAMException
	{
		return addUserToIAM(zoid, userName, password, email, isConfirmed, false);
	}

	public static long addUserToIAM(long zoid, String userName, String password, String email) throws IAMException
	{
		return addUserToIAM(zoid, userName, password, email, true, false);
	}

	public static AppAccount getIdmpodAppAccount(String zaid)
	{
		try
		{
			AppAccountAPI aaAPI = IAMProxy.getInstance().getAppAccountAPI();
			return aaAPI.getAppAccountByScreenName(IDMPOD_ORG_TYPE.getType(), Long.parseLong(zaid), IDMPOD, IDMPOD);
		}
		catch (IAMException e)
		{
			LOGGER.log(Level.SEVERE, "Exception while getting app account for zaid : " + zaid, e);
			return null;
		}
	}

	public static AppAccount getIdmpodAppAccount(Long zaaid)
	{
		try
		{
			AppAccountAPI aaAPI = IAMProxy.getInstance().getAppAccountAPI();
			return aaAPI.getAppAccount(IDMPOD_ORG_TYPE.getType(), zaaid);
		}
		catch (IAMException e)
		{
			LOGGER.log(Level.SEVERE, "Exception while getting app account for zaaid : " + zaaid, e);
			return null;
		}
	}

	public static AppAccount createIdmpodAppAccount(String zaid, String zuid) throws IAMException, ResourceException
	{
		AppAccountAPI aaAPI = IAMProxy.getInstance().getAppAccountAPI();
		String zarid = UserUtils.getZARID(SUPERADMIN);
		if (zarid == null)
		{
			App.Role role = AppResource.getRoleURI(IDMPOD).POST(App.Role.newBuilder().setRoleName(SUPERADMIN).build()).GET();
			zarid = role.getZarid();
		}
		Long zaaid = aaAPI.createAppAccount(IDMPOD_ORG_TYPE.getType(), zaid, Long.parseLong(zuid), IDMPOD, IDMPOD, DISPLAY_NAME, true, zarid);
		return getIdmpodAppAccount(zaaid);
	}

	public static int getAppAccountMemberCount(String zaaid, int status) throws IAMException
	{
		AppAccountAPI aaAPI = IAMProxy.getInstance().getAppAccountAPI();
		return (int) aaAPI.getAccountMemeberCount(IDMPOD_ORG_TYPE.getType(), Long.parseLong(zaaid), IDMPOD, status);
	}

	public static Map<String, AccountMember> getIdmpodAppAccountMember(String zaaid, String[] zids) throws IAMException
	{
		AppAccountAPI aaAPI = IAMProxy.getInstance().getAppAccountAPI();
		Map<String, AccountMember> record = new HashMap<String, AccountMember>();
		for (int i = 0; i < zids.length; i++)
		{
			AccountMember accMember = aaAPI.getAccountMember(IDMPOD_ORG_TYPE.getType(), Long.parseLong(zaaid), Long.parseLong(zids[i]), IDMPOD);
			record.put(accMember.getZid(), accMember);
		}
		return record;
	}

	public static Iterator<AccountMember> getAccountMemberIterator(String zaaid, int status) throws IAMException
	{
		AppAccountAPI aaAPI = IAMProxy.getInstance().getAppAccountAPI();
		return aaAPI.getAccountMemberIterator(IDMPOD_ORG_TYPE.getType(), Long.parseLong(zaaid), IDMPOD, status);
	}

	public static AccountMember getIdmpodAppAccountMember(Object zaaid, Object zid) throws IAMException
	{
		AppAccountAPI appAccountAPI = IAMProxy.getInstance().getAppAccountAPI();
		return appAccountAPI.getAccountMember(IDMPOD_ORG_TYPE.getType(), Long.parseLong("" + zaaid), Long.parseLong("" + zid), IDMPOD);
	}

	public static AccountMember addAppAccountMember(Object zid, int status)
	{
		return AppAccountUtils.addAppAccountMember(zid, status, USER);
	}

	public static AccountMember addAppAccountMember(Object zid, int status, String role)
	{
		return addAppAccountMember(IdmpodThreadLocal.getAppId(), zid, status, role);
	}

	public static AccountMember addAppAccountMember(String zaaid, Object zid, int status, String role)
	{
		try
		{
			AppAccountAPI aaAPI = IAMProxy.getInstance().getAppAccountAPI();
			AccountMember appMember = AppAccountUtils.getIdmpodAppAccountMember(zaaid, zid);
			if (appMember != null)
			{
				if (appMember.getIsActive() != status)
				{
					aaAPI.changeAccountMemberStatus(IDMPOD_ORG_TYPE.getType(), Long.parseLong(zaaid), Long.parseLong("" + zid), IDMPOD, status);
				}
				if (!(appMember.getZarid().equals(UserUtils.getZARID(role))))
				{
					aaAPI.changeAccountMemberRole(IDMPOD_ORG_TYPE.getType(), Long.parseLong(zaaid), Long.parseLong("" + zid), IDMPOD, UserUtils.getZARID(role));
				}
				appMember = AppAccountUtils.getIdmpodAppAccountMember(zaaid, zid);
				return appMember;
			}
			else
			{
				AccountMember.Builder accountmember = AccountMember.newBuilder().setZidType(AppAccountUtils.APPUSER).setZid("" + zid).setZarid(UserUtils.getZARID(role)).setIsActive(status);
				aaAPI.addAccountMember(IDMPOD_ORG_TYPE.getType(), Long.parseLong(zaaid), IDMPOD, accountmember.build());
				return AppAccountUtils.getIdmpodAppAccountMember(zaaid, zid);
			}
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Exception trace: ", e);
			return null;
		}
	}

	public static boolean updateIdmpodAppAccountMemberStatus(String zaaid, String zid, int status) throws IAMException
	{

		AccountMember appMember = AppAccountUtils.getIdmpodAppAccountMember(zaaid, zid);
		AppAccountAPI aaAPI = IAMProxy.getInstance().getAppAccountAPI();
		if (appMember != null)
		{
			if (appMember.getIsActive() != status)
			{
				aaAPI.changeAccountMemberStatus(IDMPOD_ORG_TYPE.getType(), Long.parseLong(zaaid), Long.parseLong(zid), IDMPOD, status);
				appMember = AppAccountUtils.getIdmpodAppAccountMember(zaaid, zid);
			}
			return true;
		}
		else
		{
			AppAccountUtils.addAppAccountMember(zaaid, zid, status, USER);
			return true;
		}
	}

	public static boolean updateIdmpodAppAccountMemberStatus(String zaaid, ArrayList<Object> zid, int status)
	{
		try
		{
			String[] zids = zid.toArray(new String[zid.size()]);
			for (int i = 0; i < zids.length; i++)
			{
				AccountMember appMember = AppAccountUtils.getIdmpodAppAccountMember(zaaid, zids[i]);
				if (appMember != null)
				{
					updateIdmpodAppAccountMemberStatus(zaaid, appMember.getZid(), status);
				}
			}
			return true;
		}
		catch (IAMException e)
		{
			LOGGER.log(Level.SEVERE, "Problem in update AppAccountMember status", e);
			return false;
		}
	}

	public static AccountMember associateIdmpodAppAccountMember(String zaaid, String zid) throws IAMException
	{
		//		if (AccountsUtil.getCurrentUser().isOrgAdmin())
		//		{
		AppAccountUtils.addAppAccountMember(zid, AppAccountUtils.STATUS_ACTIVE);
		return AppAccountUtils.getIdmpodAppAccountMember(zaaid, zid);
		//		}
		//		return null;
	}

	public static boolean disassociateIdmpodAppAccountMember(String zaaid, String zid)
	{
		//		if (AccountsUtil.getCurrentUser().isOrgAdmin())
		//		{
		try
		{
			AppAccountAPI aaAPI = IAMProxy.getInstance().getAppAccountAPI();
			aaAPI.removeAccountMember(IDMPOD_ORG_TYPE.getType(), Long.parseLong(zaaid), Long.parseLong(zid), IDMPOD);
			return true;
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Exception trace", e);
		}
		//		}
		return false;
	}

	/*
	 * Change AppMember role in IAM
	 */
	public static boolean updateAppMemberRole(String zaaid, String zid, String role)
	{
		try
		{
			AppAccountAPI aaAPI = IAMProxy.getInstance().getAppAccountAPI();
			AccountMember appMember = AppAccountUtils.getIdmpodAppAccountMember(zaaid, zid);
			if (appMember != null)
			{
				aaAPI.changeAccountMemberRole(IDMPOD_ORG_TYPE.getType(), Long.parseLong(zaaid), Long.parseLong(zid), IDMPOD, UserUtils.getZARID(role));
				aaAPI.changeOrgUserRole(IDMPOD_ORG_TYPE.getType(), Long.parseLong(zaaid), Long.parseLong(zid), IDMPOD);
			}
		}
		catch (IAMException e)
		{
			LOGGER.log(Level.SEVERE, "Error in updating user role in AppMember ZUID: {0} ROLE: {1} | {2}", new Object[]{zid, role, e});
			return false;
		}
		return true;
	}

	public static String[] getAccepatableRolesForCurrentUser()
	{
		ArrayList<String> acceptableRoles = new ArrayList<>();
		String aa_member_role = AccountsUtil.getCurrentUserRole();
		if (aa_member_role.equalsIgnoreCase(AccountsConstants.Role.SUPER_ADMIN))
		{
			acceptableRoles.add(AccountsConstants.Role.SUPER_ADMIN);
			acceptableRoles.add(AccountsConstants.Role.ADMIN);
			acceptableRoles.add(AccountsConstants.Role.USER);
		}
		else if (aa_member_role.equalsIgnoreCase(AccountsConstants.Role.ADMIN))
		{
			acceptableRoles.add(AccountsConstants.Role.ADMIN);
			acceptableRoles.add(AccountsConstants.Role.USER);
		}
		else
		{
			acceptableRoles.add(AccountsConstants.Role.USER);
		}
		return acceptableRoles.toArray(new String[acceptableRoles.size()]);
	}

	public static void setAppAccountStatus(Long zaaid, boolean status)
	{
		AppAccountAPI appAccountAPI = IAMProxy.getInstance().getAppAccountAPI();
		try
		{
			appAccountAPI.changeAppAccountStatus(IdmpodIAMUtil.IDMPOD_ORG_TYPE.getType(), zaaid, IDMPOD, status ? AccountsConstants.AppAccountStatus.ACTIVE : AccountsConstants.AppAccountStatus.CLOSED);
			appAccountAPI.changeAppAccountServiceStatus(IdmpodIAMUtil.IDMPOD_ORG_TYPE.getType(), zaaid, IDMPOD, status ? AccountsConstants.AppAccountStatus.ACTIVE : AccountsConstants.AppAccountStatus.CLOSED);
		}
		catch (IAMException e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
	}

/*    public static boolean updateIAMUserRole(String zaid, String zuid, int role){
		try{
    		AppAccountAPI appAccountAPI = IAMProxy.getInstance().getAppAccountAPI();
	        UserURI userURI = Accounts.getUserURI(zaid, zuid);
	        userURI.getQueryString().setCriteria(new Criteria(Accounts.RESOURCE.USER.USER_STATUS, Comparator.EQUALS, com.adventnet.iam.User.ACTIVE));
	        Account.User userToBeModified = userURI.GET();
	        if (userToBeModified != null) {
	            userURI.PUT(userToBeModified.toBuilder().setUserRole(role).build());
	            return true;
	        }
    	}catch(ResourceException e){
    		LOGGER.log(Level.SEVERE, "Error in updating user role in IAM ZUID: {0} ROLE: {1} | {2}", new Object[]{zuid, role, e});
    	}
    	return false;
    }*/
}
