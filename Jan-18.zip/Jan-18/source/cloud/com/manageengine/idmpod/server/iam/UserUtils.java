package com.manageengine.idmpod.server.iam;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.*;
import com.adventnet.iam.*;
import com.adventnet.persistence.*;
import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.error.IdmpodException;
import com.manageengine.idmpod.server.utils.IdmpodThreadLocal;
import com.manageengine.idmpod.server.zstore.LicenseUtil;
import com.manageengine.tables.idmpod.*;
import com.zoho.accounts.*;
import com.zoho.resource.ResourceException;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.sql.Connection;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import static com.manageengine.idmpod.server.db.DBUtils.datasetToJson;
import static com.manageengine.idmpod.server.db.DBUtils.getOrgPersistence;
import static com.manageengine.idmpod.server.iam.AppAccountUtils.IDMPOD;
import static com.manageengine.idmpod.server.iam.IdmpodIAMUtil.IDMPOD_ORG_TYPE;

public class UserUtils
{

	public static final String RESOURCE_VIEW_ALL = "1=1";

	private static final Logger LOGGER = Logger.getLogger(UserUtils.class.getName());

	/**
	 * Sets user role in both IAM and org DB.
	 *
	 * @throws DataAccessException
	 * @throws IAMException
	 */
	public static void setUserRole(IdmpodUserRole userRole) throws DataAccessException, IAMException
	{
		User user = IAMUtil.getCurrentUser();
		setUserRole(userRole, user);
	}

	public static void setUserRole(IdmpodUserRole userRole, User user, Boolean... flags) throws DataAccessException, IAMException
	{
		long zuid = user.getZUID();

		Boolean throwEx = flags != null && flags.length > 0 && flags[0];

		Column colZuid = Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ZUID);
		Criteria userCriteria = new Criteria(colZuid, zuid, QueryConstants.EQUAL);
		Persistence persistence = DBUtils.getOrgPersistence();
		DataObject dataObject = persistence.get(IDMPODTECHNICIAN.TABLE, userCriteria);
		Row row = dataObject.getRow(IDMPODTECHNICIAN.TABLE);

		String aaRole = getAppAccountRole(userRole);
		String zarid = UserUtils.getZARID(aaRole);

		boolean isIAMUpdateNeeded = true;
		if (row != null)
		{
			AccountsProto.Account.AppAccount.AppAccountService.AccountMember appAccountMember = AppAccountUtils.getIdmpodAppAccountMember(IdmpodThreadLocal.getAppId(), zuid);
			if (zarid.equalsIgnoreCase(appAccountMember.getZarid()))
			{
				isIAMUpdateNeeded = false;
			}
			if (!isUserActive(persistence, row))
			{
				isIAMUpdateNeeded = true;
			}
		}

		//update role in IAM
		if (isIAMUpdateNeeded)
		{
			AppAccountAPI aaApi = IAMProxy.getInstance().getAppAccountAPI();
			long zaaid = IdmpodThreadLocal.getAppIdLong();
			String serviceName = IdmpodIAMUtil.getServiceName();
			AccountsProto.Account.AppAccount.AppAccountService.AccountMember member = aaApi.getAccountMember(IDMPOD_ORG_TYPE.getType(), zaaid, zuid, serviceName);
			if (member == null && LicenseUtil.allowAddUsers(1, throwEx))
			{
				aaApi.addAccountMember(IDMPOD_ORG_TYPE.getType(), zaaid, zuid, serviceName, zarid);
			}
			else
			{
				aaApi.changeAccountMemberRole(IDMPOD_ORG_TYPE.getType(), zaaid, zuid, serviceName, zarid);
				aaApi.changeOrgUserRole(IDMPOD_ORG_TYPE.getType(), zaaid, zuid, serviceName);
				aaApi.changeAccountMemberStatus(IDMPOD_ORG_TYPE.getType(), zaaid, zuid, serviceName, AccountsConstants.AppAccountMemberStatus.ACTIVE);
			}
		}

		//update role in DB
		if (row == null && LicenseUtil.allowAddUsers(1, throwEx))
		{
			row = new Row(IDMPODTECHNICIAN.TABLE);
			dataObject.addRow(row);
		}
		row.set(IDMPODTECHNICIAN.FIRST_NAME, user.getFirstName());
		row.set(IDMPODTECHNICIAN.LAST_NAME, user.getLastName());
		row.set(IDMPODTECHNICIAN.EMAIL_ID, user.getPrimaryEmail());
		row.set(IDMPODTECHNICIAN.ZUID, zuid);
		row.set(IDMPODTECHNICIAN.STATUS, "ACTIVE");//NO I18N
		row.set(IDMPODTECHNICIAN.ROLE, IdmpodUserRole.getString(userRole));//here user role is our internal role
		row.set(IDMPODTECHNICIAN.ORG_ROLE, user.getUserRole());//here user role is our role
		dataObject.updateRow(row);
		persistence.update(dataObject);
	}

	private static String getAppAccountRole(IdmpodUserRole userRole)
	{
		String role;
		if (userRole == IdmpodUserRole.SUPER_ADMIN)
		{
			role = AccountsConstants.Role.SUPER_ADMIN;
		}
		else if (userRole == IdmpodUserRole.ADMINISTRATOR)
		{
			role = AccountsConstants.Role.ADMIN;
		}
		else
		{
			role = AccountsConstants.Role.USER;
		}
		return role;
	}

	/**
	 * @return null - if user not in db.
	 * @throws DataAccessException
	 */
	public static IdmpodUserRole getUserRole() throws DataAccessException
	{
		Persistence persistence = DBUtils.getOrgPersistence();
		User user = IAMUtil.getCurrentUser();
		long zuid = user.getZUID();
		return getUserRole(persistence, zuid);
	}

	public static String getUserRoleString() throws IdmpodException
	{
		IdmpodUserRole userRole = null;
		try
		{
			userRole = getUserRole();
			return IdmpodUserRole.getString(userRole);
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			//throw new IdmpodException(ErrorCode.HANDLER_EXCEPTION, e);
		}
		return null;
	}

	public static IdmpodUserRole getUserRole(Persistence persistence, long zuid) throws DataAccessException
	{
		Row row = getUserRow(persistence, zuid);
		IdmpodUserRole result = null;
		if (row != null)
		{
			String role = (String) row.get(IDMPODTECHNICIAN.ROLE);
			result = IdmpodUserRole.getRole(role);
		}
		return result;
	}

	public static boolean isUserActive(Persistence persistence, User user) throws DataAccessException
	{
		Row userRow = getUserRow(persistence, user.getZUID());
		return isUserActive(persistence, userRow);
	}

	/**
	 * @return
	 */
	public static boolean isUserActive(Persistence persistence) throws DataAccessException
	{
		Row userRow = getUserRow(persistence);
		return isUserActive(persistence, userRow);
	}

	private static boolean isUserActive(Persistence persistence, Row userRow) throws DataAccessException
	{
		boolean userActive = false;
		if (userRow != null)
		{
			String status = (String) userRow.get(IDMPODTECHNICIAN.STATUS);
			userActive = status.equalsIgnoreCase("ACTIVE");
		}
		return userActive;
	}

	public static Row getInternalUserRow(long userid) throws DataAccessException
	{
		Persistence persistence = DBUtils.getOrgPersistence();
		return getInternalUserRow(persistence, userid);
	}

	public static Row getInternalUserRow(Persistence persistence, long userid) throws DataAccessException
	{
		Column coluserid = Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.USER_ID);
		Criteria userCriteria = new Criteria(coluserid, userid, QueryConstants.EQUAL);
		DataObject dataObject = persistence.get(IDMPODTECHNICIAN.TABLE, userCriteria);
		return dataObject.getRow(IDMPODTECHNICIAN.TABLE);
	}

	private static Row getUserRow(Persistence persistence) throws DataAccessException
	{
		User user = IAMUtil.getCurrentUser();
		long zuid = user.getZUID();
		return getUserRow(persistence, zuid);
	}

	private static Row getUserRow(long zuid) throws DataAccessException
	{
		Persistence persistence = DBUtils.getOrgPersistence();
		return getUserRow(persistence, zuid);
	}

	private static Row getUserRow(Persistence persistence, long zuid) throws DataAccessException
	{
		Column colZuid = Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ZUID);
		Criteria userCriteria = new Criteria(colZuid, zuid, QueryConstants.EQUAL);
		DataObject dataObject = persistence.get(IDMPODTECHNICIAN.TABLE, userCriteria);
		return dataObject.getRow(IDMPODTECHNICIAN.TABLE);
	}

	public static void setViewResource(String viewResource) throws DataAccessException
	{
		User user = IAMUtil.getCurrentUser();
		long zuid = user.getZUID();
		setViewResource(viewResource, zuid);
	}

	public static void setViewResource(String viewResource, long zuid) throws DataAccessException
	{
		Row userRow = getUserRow(zuid);
		long techId = (long) userRow.get(IDMPODTECHNICIAN.USER_ID);
		Column techIdColumn = Column.getColumn(IDMPODUSERRESOURCEVIEW.TABLE, IDMPODUSERRESOURCEVIEW.USER_ID);
		Criteria techIdCriteria = new Criteria(techIdColumn, techId, QueryConstants.EQUAL);
		Persistence persistence = DBUtils.getOrgPersistence();
		DataObject dataObject = persistence.get(IDMPODUSERRESOURCEVIEW.TABLE, techIdCriteria);
		Row viewRow = dataObject.getRow(IDMPODUSERRESOURCEVIEW.TABLE);
		if (viewRow == null)
		{
			viewRow = new Row(IDMPODUSERRESOURCEVIEW.TABLE);
			viewRow.set(IDMPODUSERRESOURCEVIEW.USER_ID, techId);
			dataObject.addRow(viewRow);
		}
		viewRow.set(IDMPODUSERRESOURCEVIEW.VIEW_RESOURCE, viewResource);
		dataObject.updateRow(viewRow);
		persistence.update(dataObject);
	}

	public static JSONObject getOrgUsers(Integer page_size, Integer page_number)
	{
		final String TYPE = JsonApiHandler.ResourceType.USER.getResType();

		JSONObject resp = new JSONObject();
		JSONObject meta = new JSONObject();

		JSONArray users = new JSONArray();

		final OrgAPI ORGAPI = IAMProxy.getInstance().getOrgAPI();

		try
		{
			Long totalCount = ORGAPI.getOrgUsersCount(IdmpodIAMUtil.getZOID());
			Boolean atLastPage = (page_number * page_size) >= totalCount;
			meta.put("FIRST", 1);
			meta.put("NEXT", atLastPage ? null : page_number + 1);
			meta.put("PREV", page_number > 1 ? page_number - 1 : null);
			meta.put("LAST", Math.ceil(totalCount.doubleValue() / page_size.doubleValue()));
			meta.put("TOTAL", totalCount);
			meta.put("START_INDEX", (page_number - 1) * page_size + 1);
			meta.put("END_INDEX", (page_number * page_size) > totalCount ? totalCount : (page_number * page_size));

			Collection<User> orgUsers = ORGAPI.getOrgUsers(IdmpodIAMUtil.getZOID(), (page_number - 1) * page_size + 1, page_size);

			for (User orgUser : orgUsers)
			{
				users.put(convertUserToJson(orgUser));
			}

			resp.put(JsonApiConstants.DATA, users);
			resp.put(JsonApiConstants.META, meta);
		}
		catch (IAMException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return resp;
	}

	private static JSONObject convertUserToJson(User orgUser)
	{
		final String TYPE = JsonApiHandler.ResourceType.USER.getResType();

		JSONObject user = new JSONObject();
		JSONObject userAttrs = new JSONObject();

		userAttrs.put("COUNTRY", orgUser.getCountry());
		userAttrs.put("DISPLAY_NAME", orgUser.getDisplayName());
		userAttrs.put("FIRST_NAME", orgUser.getFirstName());
		userAttrs.put("GENDER", orgUser.getGender());
		userAttrs.put("LANGUAGE", orgUser.getLanguage());
		userAttrs.put("LAST_NAME", orgUser.getLastName());
		userAttrs.put("PRIMARY_EMAIL", orgUser.getPrimaryEmail());

		user.put(JsonApiConstants.ID, orgUser.getZUID());
		user.put(JsonApiConstants.TYPE, TYPE);
		user.put(JsonApiConstants.ATTRIBUTES, userAttrs);

		return user;
	}

	public static String getToCreateOrgName() throws IAMException
	{
		String organizationName = null;

		if (IAMProxy.getInstance().getUserAPI().getUserWorkAddress(IAMUtil.getCurrentUser().getZUID()) != null && IAMProxy.getInstance().getUserAPI().getUserWorkAddress(IAMUtil.getCurrentUser().getZUID()).getAddress() != null)
		{
			organizationName = IAMProxy.getInstance().getUserAPI().getUserWorkAddress(IAMUtil.getCurrentUser().getZUID()).getAddress().getCompanyName();
		}

		return organizationName;
	}

	public static String getZARID(String roleName)
	{
		try
		{
			String roleID = AccountsUtil.getZARID(roleName);
			if (roleID == null)
			{
				com.zoho.accounts.AppResourceProto.App.Role roleObj = com.zoho.accounts.AppResourceProto.App.Role.newBuilder().setRoleName(roleName).build();
				AppResource.RoleURI roleURI = AppResource.getRoleURI(IdmpodIAMUtil.getServiceName()).POST(roleObj);
				return roleURI.GET().getZarid();
			}
			return roleID;
		}
		catch (ResourceException e)
		{
			if (e.getErrorCode().toString().equals("Z102"))
			{
				try
				{
					return AppResource.getRoleURI(IdmpodIAMUtil.getServiceName(), roleName).GET().getZarid();
				}
				catch (ResourceException e1)
				{
					LOGGER.log(java.util.logging.Level.SEVERE, e1.getMessage(), e1);
				}
			}
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		return null;
	}

	public static JSONObject getAppUsers(Integer page_size, Integer page_number, JSONArray filterArray)
	{
		final String TYPE = JsonApiHandler.ResourceType.USER.getResType();
		JSONObject resp = new JSONObject();
		JSONObject meta = new JSONObject();
		JSONArray users = new JSONArray();
		try
		{
			String dispNameFilter = null;
			String lastActivityFilter = null;
			if (filterArray != null)
			{
				for (int i = 0; i < filterArray.length(); i++)
				{
					JSONObject filterObj = filterArray.getJSONObject(i);
					if (filterObj.has("DISPLAY_NAME"))
					{
						dispNameFilter = filterObj.getString("DISPLAY_NAME");
					}
					if (filterObj.has("LAST_ACTIVITY"))
					{
						lastActivityFilter = filterObj.getString("LAST_ACTIVITY");
					}
				}
			}

			Criteria searchCrit = null;
			if (!StringUtils.isBlank(dispNameFilter))
			{
				com.zoho.resource.Criteria zResCrit = null;
				if (!StringUtils.isBlank(dispNameFilter))
				{
					zResCrit = new com.zoho.resource.Criteria(Accounts.RESOURCE.USER.DISPLAY_NAME, com.zoho.resource.Criteria.Comparator.LIKE, "*" + dispNameFilter + "*");
				}
				AccountsProto.Account.User[] accountUsers = AppAccountUtils.getAccountUsers(zResCrit);
				// LOGGER.log(Level.INFO, "" + (accountUsers != null ? accountUsers.length : "null"));
				List<String> zuids = accountUsers != null ? Arrays.asList(accountUsers).stream().map(aau -> aau.getZuid()).collect(Collectors.toList()) : new ArrayList<>();
				searchCrit = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ZUID), zuids.toArray(new String[zuids.size()]), QueryConstants.IN);
			}
			if (!StringUtils.isBlank(lastActivityFilter))
			{
				if (lastActivityFilter.equalsIgnoreCase("never"))
				{
					SelectQuery subQuery = new SelectQueryImpl(Table.getTable(IDMPODCLIENTACCESSAUDIT.TABLE));

					Column usersWithAccess = Column.getColumn(IDMPODCLIENTACCESSAUDIT.TABLE, IDMPODCLIENTACCESSAUDIT.USER_ID).distinct();
					usersWithAccess.setColumnAlias("ACCESSED_USER_ID");

					subQuery.addSelectColumn(usersWithAccess);

					DerivedColumn lastAccessCol = new DerivedColumn("ACCESSED_USER_ID", subQuery);//No I18n
					Criteria lastActivityCrit = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ZUID), lastAccessCol, QueryConstants.NOT_IN);
					if (searchCrit == null)
					{
						searchCrit = lastActivityCrit;
					}
					else
					{
						searchCrit = searchCrit.and(lastActivityCrit);
					}
				}
			}


			SelectQuery query = new SelectQueryImpl(Table.getTable(IDMPODTECHNICIAN.TABLE));

			Criteria userCrit = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.STATUS), "DELETED", QueryConstants.NOT_EQUAL, false);

			if (searchCrit != null)
			{
				userCrit = userCrit.and(searchCrit);
			}

			query.setCriteria(userCrit);

			query.addSelectColumn(Column.getColumn(IDMPODTECHNICIAN.TABLE, "*"));


			SelectQuery subQuery = new SelectQueryImpl(Table.getTable(IDMPODCLIENTACCESSAUDIT.TABLE));

			subQuery.setCriteria(new Criteria(Column.getColumn(IDMPODCLIENTACCESSAUDIT.TABLE, IDMPODCLIENTACCESSAUDIT.USER_ID), Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ZUID), QueryConstants.EQUAL));

			Column maxCol = Column.getColumn(IDMPODCLIENTACCESSAUDIT.TABLE, IDMPODCLIENTACCESSAUDIT.TIMESTAMP).maximum();
			maxCol.setColumnAlias("LAST_ACTIVITY_TIMESTAMP");

			subQuery.addSelectColumn(maxCol);

			DerivedColumn lastAccessCol = new DerivedColumn("LAST_ACTIVITY_TIMESTAMP", subQuery);//No I18n
			query.addSelectColumn(lastAccessCol);

			Range range = DBUtils.constructRange(page_number, page_size);

			Integer totalCount = DBUtils.getUnmodifiedQueryCount(query);
			Boolean atLastPage = (page_number * page_size) >= totalCount;

			meta.put("FIRST", 1);
			meta.put("NEXT", atLastPage ? null : page_number + 1);
			meta.put("PREV", page_number > 1 ? page_number - 1 : null);
			meta.put("LAST", Math.ceil(totalCount.doubleValue() / page_size.doubleValue()));
			meta.put("TOTAL", totalCount);
			meta.put("START_INDEX", (page_number - 1) * page_size + 1);
			meta.put("END_INDEX", (page_number * page_size) > totalCount ? totalCount : (page_number * page_size));

			query.setRange(range);

			Connection connection = null;
			DataSet dataSet = null;
			try
			{
				RelationalAPI relationalAPI = DBUtils.getOrgRelationalApi();
				connection = relationalAPI.getConnection();
				dataSet = relationalAPI.executeQuery(query, connection);

				OrgAPI orgAPI = IAMProxy.getInstance().getOrgAPI();
				UserAPI userAPI = IAMProxy.getInstance().getUserAPI();

				while (dataSet.next())
				{
					JSONObject userAttrs = datasetToJson(dataSet);

					User orgUser = userAPI.getUser(userAttrs.getLong(IDMPODTECHNICIAN.ZUID));
					userAttrs.put("COUNTRY", orgUser.getCountry());
					userAttrs.put("DISPLAY_NAME", orgUser.getDisplayName());
					userAttrs.put("FIRST_NAME", orgUser.getFirstName());
					userAttrs.put("GENDER", orgUser.getGender());
					userAttrs.put("LANGUAGE", orgUser.getLanguage());
					userAttrs.put("LAST_NAME", orgUser.getLastName());
					userAttrs.put("PRIMARY_EMAIL", orgUser.getPrimaryEmail());

					List<AccountsProto.Account.SAMLApp> samlAppsofUser = orgAPI.getSamlAppsofUser(userAttrs.optString(IDMPODTECHNICIAN.ZUID));

					userAttrs.put("SAML_APPS_COUNT", samlAppsofUser != null ? samlAppsofUser.size() : 0);

					JSONObject user = new JSONObject();
					user.put(JsonApiConstants.ID, userAttrs.get(IDMPODTECHNICIAN.USER_ID));
					user.put(JsonApiConstants.TYPE, TYPE);
					user.put(JsonApiConstants.ATTRIBUTES, userAttrs);
					users.put(user);
				}

				// LOGGER.info(relationalAPI.getSelectSQL(query));
			}
			catch (Exception e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
			finally
			{
				DBUtils.safeClose(connection, dataSet);
			}

			resp.put(JsonApiConstants.DATA, users);
			resp.put(JsonApiConstants.META, meta);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return resp;
	}

	public static JSONObject getAppUsersWithStats(Integer page_size, Integer page_number, JSONArray filterArray)
	{
		final String TYPE = JsonApiHandler.ResourceType.USER.getResType();
		JSONObject resp = new JSONObject();
		JSONObject meta = new JSONObject();
		JSONArray users = new JSONArray();
		try
		{
			SelectQuery query = new SelectQueryImpl(Table.getTable(IDMPODTECHNICIAN.TABLE));
			query.addJoin(new Join(Table.getTable(IDMPODTECHNICIAN.TABLE), Table.getTable(IDMPODAPPLICATIONACCESSAUDIT.TABLE), new String[]{IDMPODTECHNICIAN.ZUID}, new String[]{IDMPODAPPLICATIONACCESSAUDIT.USER_ID}, Join.LEFT_JOIN));

			Criteria filterCrit = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.STATUS), "ACTIVE", QueryConstants.EQUAL, false);

			if (filterArray != null)
			{
				for (int i = 0; i < filterArray.length(); i++)
				{
					JSONObject filterObj = filterArray.getJSONObject(i);
					Iterator<String> keys = filterObj.keys();
					while (keys.hasNext())
					{
						String key = keys.next();
						if (key.equalsIgnoreCase(IDMPODAPPLICATIONACCESSAUDIT.TIMESTAMP))
						{
							JSONArray dateRange = filterObj.getJSONArray(key);
							Criteria daterangeCrit = new Criteria(Column.getColumn(IDMPODAPPLICATIONACCESSAUDIT.TABLE, IDMPODAPPLICATIONACCESSAUDIT.TIMESTAMP), dateRange.toList().toArray(), QueryConstants.BETWEEN);
							if (filterCrit == null)
							{
								filterCrit = daterangeCrit;
							}
							else
							{
								filterCrit = filterCrit.and(daterangeCrit);
							}
						}
						else if (key.equalsIgnoreCase(IDMPODAPPLICATIONACCESSAUDIT.APPLICATION_ID))
						{
							Criteria appCrit = new Criteria(Column.getColumn(IDMPODAPPLICATIONACCESSAUDIT.TABLE, IDMPODAPPLICATIONACCESSAUDIT.APPLICATION_ID), filterObj.get(key), QueryConstants.EQUAL);
							if (filterCrit == null)
							{
								filterCrit = appCrit;
							}
							else
							{
								filterCrit = filterCrit.and(appCrit);
							}
						}
					}
				}
			}
			if (filterCrit != null)
			{
				query.setCriteria(filterCrit);
			}

			query.addSelectColumn(Column.getColumn(IDMPODTECHNICIAN.TABLE, "*"));

			Column accessCount = Column.getColumn(IDMPODAPPLICATIONACCESSAUDIT.TABLE, IDMPODAPPLICATIONACCESSAUDIT.USER_ID).count();
			accessCount.setColumnAlias("ACCESS_COUNT");

			query.addSelectColumn(accessCount);

			Column lastLogin = Column.getColumn(IDMPODAPPLICATIONACCESSAUDIT.TABLE, IDMPODAPPLICATIONACCESSAUDIT.TIMESTAMP).maximum();
			lastLogin.setColumnAlias("LAST_LOGIN");

			query.addSelectColumn(lastLogin);

			List<Column> groupByCols = new ArrayList<>();
			groupByCols.add(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.USER_ID));

			GroupByClause gbc = new GroupByClause(groupByCols);
			query.setGroupByClause(gbc);

			Range range = DBUtils.constructRange(page_number, page_size);

			Integer totalCount = DBUtils.getUnmodifiedQueryCount(query);
			Boolean atLastPage = (page_number * page_size) >= totalCount;

			meta.put("FIRST", 1);
			meta.put("NEXT", atLastPage ? null : page_number + 1);
			meta.put("PREV", page_number > 1 ? page_number - 1 : null);
			meta.put("LAST", Math.ceil(totalCount.doubleValue() / page_size.doubleValue()));
			meta.put("TOTAL", totalCount);
			meta.put("START_INDEX", (page_number - 1) * page_size + 1);
			meta.put("END_INDEX", (page_number * page_size) > totalCount ? totalCount : (page_number * page_size));

			query.setRange(range);

			Connection connection = null;
			DataSet dataSet = null;
			try
			{
				RelationalAPI relationalAPI = DBUtils.getOrgRelationalApi();
				connection = relationalAPI.getConnection();

				// LOGGER.info(relationalAPI.getSelectSQL(query));

				dataSet = relationalAPI.executeQuery(query, connection);

				//				OrgAPI orgAPI = IAMProxy.getInstance().getOrgAPI();
				UserAPI userAPI = IAMProxy.getInstance().getUserAPI();

				while (dataSet.next())
				{
					JSONObject userAttrs = datasetToJson(dataSet);

					User orgUser = userAPI.getUser(userAttrs.getLong(IDMPODTECHNICIAN.ZUID));
					userAttrs.put("COUNTRY", orgUser.getCountry());
					userAttrs.put("DISPLAY_NAME", orgUser.getDisplayName());
					userAttrs.put("FIRST_NAME", orgUser.getFirstName());
					userAttrs.put("GENDER", orgUser.getGender());
					userAttrs.put("LANGUAGE", orgUser.getLanguage());
					userAttrs.put("LAST_NAME", orgUser.getLastName());
					userAttrs.put("PRIMARY_EMAIL", orgUser.getPrimaryEmail());

					//					List<AccountsProto.Account.SAMLApp> samlAppsofUser = orgAPI.getSamlAppsofUser(userAttrs.optString(IDMPODTECHNICIAN.ZUID));
					//
					//					userAttrs.put("SAML_APPS_COUNT", samlAppsofUser != null ? samlAppsofUser.size() : 0);

					JSONObject user = new JSONObject();
					user.put(JsonApiConstants.ID, userAttrs.get(IDMPODTECHNICIAN.USER_ID));
					user.put(JsonApiConstants.TYPE, TYPE);
					user.put(JsonApiConstants.ATTRIBUTES, userAttrs);
					users.put(user);
				}
			}
			catch (Exception e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
			finally
			{
				DBUtils.safeClose(connection, dataSet);
			}

			resp.put(JsonApiConstants.DATA, users);
			resp.put(JsonApiConstants.META, meta);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return resp;
	}

	/**
	 * Currently updates only status
	 *
	 * @param userId
	 * @param attributes
	 * @return
	 */
	public static JSONObject updateAAUser(Long userId, JSONObject attributes) throws DataAccessException
	{
		JSONObject resp = new JSONObject();

		// LOGGER.log(Level.FINER, "changeStatus as {0} for zuid {1}", new Object[]{status, userId});
		Criteria crit = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.USER_ID), userId, QueryConstants.EQUAL);
		DataObject dobj = DBUtils.getOrgPersistence().get(IDMPODTECHNICIAN.TABLE, crit);
		Row r = dobj.getRow(IDMPODTECHNICIAN.TABLE);
		String status = attributes.optString(IDMPODTECHNICIAN.STATUS, null);

		if (status != null)
		{
			if (!(status.equalsIgnoreCase("ACTIVE") || status.equalsIgnoreCase("INACTIVE")))
			{
				status = "INACTIVE";//NO I18N
			}
			else
			{
				status = status.toUpperCase();
			}
			r.set(IDMPODTECHNICIAN.STATUS, status);
		}

		String role = attributes.optString(IDMPODTECHNICIAN.ROLE, null);
		if (role != null && getUserRole() == IdmpodUserRole.SUPER_ADMIN)
		{
			IdmpodUserRole idmpodUserRole = IdmpodUserRole.getRole(role);
			UserAPI userAPI = IAMProxy.getInstance().getUserAPI();
			try
			{
				setUserRole(idmpodUserRole, userAPI.getUser((Long) r.get(IDMPODTECHNICIAN.ZUID)));
			}
			catch (IAMException e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
		}

		dobj.updateRow(r);
		DBUtils.getOrgPersistence().update(dobj);
		return resp;
	}

	public static JSONObject getAAUser(Long userId) throws DataAccessException, IAMException
	{
		final String TYPE = JsonApiHandler.ResourceType.USER.getResType();

		Row userRow = getInternalUserRow(userId);

		JSONObject userAttrs = DBUtils.rowToJson(userRow);

		User orgUser = IAMProxy.getInstance().getUserAPI().getUser(userAttrs.getLong(IDMPODTECHNICIAN.ZUID));
		userAttrs.put("COUNTRY", orgUser.getCountry());
		userAttrs.put("DISPLAY_NAME", orgUser.getDisplayName());
		userAttrs.put("FIRST_NAME", orgUser.getFirstName());
		userAttrs.put("GENDER", orgUser.getGender());
		userAttrs.put("LANGUAGE", orgUser.getLanguage());
		userAttrs.put("LAST_NAME", orgUser.getLastName());
		userAttrs.put("PRIMARY_EMAIL", orgUser.getPrimaryEmail());

		List<AccountsProto.Account.SAMLApp> samlAppsofUser = IAMProxy.getInstance().getOrgAPI().getSamlAppsofUser(userAttrs.optString(IDMPODTECHNICIAN.ZUID));

		userAttrs.put("SAML_APPS_COUNT", samlAppsofUser != null ? samlAppsofUser.size() : 0);

		JSONObject user = new JSONObject();
		user.put(JsonApiConstants.ID, userAttrs.get(IDMPODTECHNICIAN.USER_ID));
		user.put(JsonApiConstants.TYPE, TYPE);
		user.put(JsonApiConstants.ATTRIBUTES, userAttrs);

		return user;
	}

	public static String deleteUser(Long userId) throws DataAccessException, IAMException
	{
		Column coluserid = Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.USER_ID);
		Criteria userCriteria = new Criteria(coluserid, userId, QueryConstants.EQUAL);
		DataObject dataObject = DBUtils.getOrgPersistence().get(IDMPODTECHNICIAN.TABLE, userCriteria);

		Row userRow = dataObject.getRow(IDMPODTECHNICIAN.TABLE);

		userRow.set(IDMPODTECHNICIAN.STATUS, "DELETED");//NO I18N

		dataObject.deleteRow(userRow);

		DBUtils.getOrgPersistence().delete(userRow);

		AppAccountAPI aaAPI = IAMProxy.getInstance().getAppAccountAPI();
		aaAPI.removeAccountMember(IDMPOD_ORG_TYPE.getType(), IdmpodThreadLocal.getAppIdLong(), (Long) userRow.get(IDMPODTECHNICIAN.ZUID), IDMPOD);
		return IAMProxy.getInstance().getUserAPI().getUser((Long) userRow.get(IDMPODTECHNICIAN.ZUID)).getDisplayName();
	}

	public static boolean getShowGettingStarted()
	{
		Boolean show = false;
		String pref = getUserPreference("SHOW_GETTING_STARTED"); //No I18N
		if (pref != null)
		{
			show = Boolean.valueOf(pref);
		}
		else
		{
			show = true;
		}
		if (show)
		{
			try
			{
				setUserPreference(getOrgPersistence(), "SHOW_GETTING_STARTED", "false"); //No I18N
			}
			catch (DataAccessException e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
		}
		return show;
	}

	public static String getUserPreference(ReadOnlyPersistence persistence, String key) throws DataAccessException
	{
		Long zuid = IAMUtil.getCurrentUser().getZUID();
		Criteria criteria = new Criteria(Column.getColumn(USERSPREFERENCES.TABLE, USERSPREFERENCES.KEY), key, QueryConstants.EQUAL, false);
		criteria = criteria.and(new Criteria(Column.getColumn(USERSPREFERENCES.TABLE, USERSPREFERENCES.USER_ID), zuid.toString(), QueryConstants.EQUAL, false));
		DataObject dobj = persistence.get(USERSPREFERENCES.TABLE, criteria);
		if (dobj.containsTable(USERSPREFERENCES.TABLE))
		{
			Row prefRow = dobj.getFirstRow(USERSPREFERENCES.TABLE);
			if (prefRow != null)
			{
				return prefRow.get(USERSPREFERENCES.VALUE).toString();
			}
		}
		return null;
	}

	public static String getUserPreference(String key)
	{
		try
		{
			return getUserPreference(DBUtils.getReadOnlyOrgPersistence(), key);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		return null;
	}

	public static void setUserPreference(Persistence aaPersistence, String key, String value) throws DataAccessException
	{
		Long zuid = IAMUtil.getCurrentUser().getZUID();
		Criteria criteria = new Criteria(Column.getColumn(USERSPREFERENCES.TABLE, USERSPREFERENCES.KEY), key, QueryConstants.EQUAL, false);
		criteria = criteria.and(new Criteria(Column.getColumn(USERSPREFERENCES.TABLE, USERSPREFERENCES.USER_ID), zuid.toString(), QueryConstants.EQUAL, false));
		DataObject dobj = aaPersistence.get(USERSPREFERENCES.TABLE, criteria);
		if (dobj.containsTable(USERSPREFERENCES.TABLE))
		{
			Row prefRow = dobj.getFirstRow(USERSPREFERENCES.TABLE);
			if (prefRow != null)
			{
				prefRow.set(USERSPREFERENCES.VALUE, value);
				dobj.updateRow(prefRow);
				aaPersistence.update(dobj);
			}
		}
		else
		{
			Row prefRow = new Row(USERSPREFERENCES.TABLE);
			prefRow.set(USERSPREFERENCES.USER_ID, zuid.toString());
			prefRow.set(USERSPREFERENCES.KEY, key);
			prefRow.set(USERSPREFERENCES.VALUE, value);
			dobj.addRow(prefRow);
			aaPersistence.add(dobj);
		}
	}
}
