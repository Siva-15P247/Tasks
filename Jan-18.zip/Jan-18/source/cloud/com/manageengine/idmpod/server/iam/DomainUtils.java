package com.manageengine.idmpod.server.iam;

import com.adventnet.iam.*;
import com.manageengine.idmpod.server.error.ErrorCode;
import com.manageengine.idmpod.server.error.IdmpodException;
import com.manageengine.idmpod.server.iam.samlapps.SamlAppsHandler;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DomainUtils
{
	public static final Logger LOG = Logger.getLogger(DomainUtils.class.getName());

	public static String getOrgVerifiedDomain(long zoid)
	{
		String domain = null;
		try
		{
			java.util.List<OrgDomain> domainlist = SamlAppsHandler.getOrgApi().getAllOrgDomain(zoid);
			if (domainlist != null)
			{
				for (OrgDomain orgDom : domainlist)
				{
					if (orgDom.isVerified())
					{
						domain = orgDom.getDomainName();
						break;
					}
				}
			}
		}
		catch (IAMException ex)
		{
			LOG.log(Level.SEVERE, null, ex);
		}
		return domain;
	}

	public static String getContentFromUrl(String url)
	{
		String content = null;
		BufferedReader reader = null;
		try
		{
			URL urlObj = new URL(url);
			HttpURLConnection connection;
			//			if (ProxyAuthenticator.USEPROXY)
			//			{
			//				Authenticator.setDefault(ProxyAuthenticator.getInstance());
			//				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(ProxyAuthenticator.PROXYHOST, ProxyAuthenticator.PROXYPORT));
			//				connection = (HttpURLConnection) (urlObj).openConnection(proxy);
			//			}
			//			else
			{
				connection = (HttpURLConnection) (urlObj).openConnection();
			}
			LOG.log(Level.INFO, "Connection opened: {0}", System.currentTimeMillis());
			connection.setConnectTimeout(60 * 1000);
			connection.setReadTimeout(60 * 1000);
			java.io.InputStream is = connection.getInputStream();
			LOG.log(Level.INFO, "Stream opened: {0}", System.currentTimeMillis());

			StringBuilder fileContent = new StringBuilder();
			reader = new BufferedReader(new InputStreamReader(is));
			String eachLine = null;
			int lines = 0;
			//Just read 10 lines from the file
			while ((eachLine = reader.readLine()) != null)
			{
				fileContent.append(eachLine).append("\n"); //No I18N
				lines++;
				if (lines >= 10)
				{
					break;
				}
			}
			content = fileContent.toString();
			LOG.log(Level.INFO, content);
		}
		catch (java.net.MalformedURLException malformedURLException)
		{
			LOG.log(Level.WARNING, malformedURLException.getMessage());
		}
		catch (Exception exception)
		{
			LOG.log(Level.SEVERE, exception.getMessage(), exception);
		}
		finally
		{
			if (reader != null)
			{
				try
				{
					reader.close();
				}
				catch (Exception ignore)
				{
					LOG.log(Level.FINE, "Exception while reading file data", ignore.getMessage());
				}
			}
		}
		return content;
	}

	public static boolean isValidCertificate(String certString) throws UnsupportedEncodingException
	{
		java.io.InputStream is = new java.io.ByteArrayInputStream(certString.getBytes("UTF-8")); // NO I18N
		boolean isValid = true;
		try
		{
			CertificateFactory cf = CertificateFactory.getInstance("X.509");//NO I18N
			ArrayList mylist = new ArrayList();
			java.security.cert.Certificate c = cf.generateCertificate(is);
			mylist.add(c);

			java.security.cert.CertPath cp = cf.generateCertPath(mylist);

			java.security.cert.TrustAnchor anchor = new java.security.cert.TrustAnchor((java.security.cert.X509Certificate) c, null);
			java.security.cert.PKIXParameters params = new java.security.cert.PKIXParameters(java.util.Collections.singleton(anchor));
			params.setRevocationEnabled(false);
			java.security.cert.CertPathValidator cpv = java.security.cert.CertPathValidator.getInstance("PKIX");//NO I18N
			java.security.cert.PKIXCertPathValidatorResult result = (java.security.cert.PKIXCertPathValidatorResult) cpv.validate(cp, params);
			if (result == null)
			{
				isValid = false;
			}
		}
		catch (Exception ex)
		{
			LOG.log(Level.FINE, "Exception while validating certificate", ex.getMessage());
			isValid = false;
		}
		return isValid;
	}

	/**
	 * method that looks up all IP Addresses that are associated with a URL.
	 *
	 * @param url - to be checked
	 * @return
	 */
	public static ArrayList<String> lookup(String url)
	{
		InetAddress[] addressesForURL;
		ArrayList<String> ipAddresses = new ArrayList<String>();
		try
		{
			addressesForURL = InetAddress.getAllByName(url);
			for (int index = 0; index < addressesForURL.length; index++)
			{
				ipAddresses.add(addressesForURL[index].getHostAddress());
			}//for(int index = 0; index < addressesForURL.length; index++)
		}
		catch (Exception e)
		{
			LOG.log(Level.WARNING, e.getMessage());
			//ensure that no ip addresses are available for this url - since an error occured, no ip will validate.
			ipAddresses.clear();
		}
		LOG.log(Level.INFO, "Lookup Result for {0} is: {1}", new Object[]{url, ipAddresses});
		return ipAddresses;
	}

	/**
	 * @param zoid - org id
	 * @return - Returns the list of domains for the given org
	 * @throws IAMException
	 */
	public static JSONArray getOrgDomains(long zoid) throws IAMException, JSONException
	{
		JSONArray domains = new JSONArray();
		java.util.List<OrgDomain> domainlist = SamlAppsHandler.getOrgApi().getAllOrgDomain(zoid);
		if (domainlist != null && domainlist.size() > 0)
		{
			for (int j = 0; j < domainlist.size(); j++)
			{
				OrgDomain orgdom = domainlist.get(j);
				JSONObject json = new JSONObject();
				json.put("domainname", orgdom.getVerCode()); // NO I18N
				json.put("isverified", orgdom.isVerified()); // NO I18N
				json.put("verificationcode", orgdom.getDomainName()); // NO I18N
				domains.put(json);
			}
		}
		return domains;
	}

	/**
	 * @return - List of org domains for the current org
	 * @throws IAMException
	 */
	public static JSONArray getOrgDomains() throws IAMException, JSONException
	{
		long zoid = IAMUtil.getCurrentUser().getZOID();
		return getOrgDomains(zoid);
	}

	/**
	 * This is validate if at least one org domain is verified
	 *
	 * @param zoid
	 * @return
	 * @throws IAMException
	 */
	public static boolean isDomainVerified(long zoid) throws IAMException
	{
		List<OrgDomain> orgDomains = SamlAppsHandler.getOrgApi().getAllOrgDomain(zoid);
		if (orgDomains == null || orgDomains.isEmpty())
		{
			return false;
		}
		else
		{
			for (OrgDomain orgDomain : orgDomains)
			{
				if (orgDomain.isVerified())
				{
					return true;
				}
			}
			return false;
		}
	}

	/**
	 * To check if domain specified in the email is verified and is part of the
	 * org
	 *
	 * @param zoid
	 * @param emailId
	 * @return
	 * @throws Exception
	 */
	public static boolean isDomainVerified(long zoid, String emailId) throws Exception
	{
		String domainNameFromEmail = emailId.substring(emailId.indexOf('@') + 1);
		OrgDomain domain = SamlAppsHandler.getOrgApi().getOrgDomain(domainNameFromEmail);
		if (domain == null || domain.getZOID() != zoid)
		{
			return false;
		}
		if (!domain.isVerified())
		{
			return false;
		}
		return true;
	}

	public static void updateOrgSAMLConfiguration(HttpServletRequest request, String loginurl, String logouturl, String strFileContents, String algotype, boolean jit) throws IAMException, JSONException
	{
		OrgAPI OrgApi = SamlAppsHandler.getOrgApi();
		long zoid = IAMUtil.getCurrentUser().getZOID();
		Org org = OrgApi.getOrg(zoid);
		boolean result;
		if (org.isUsingSAMLAuthentication())
		{
			result = OrgApi.updateOrgSAMLAuth(zoid, loginurl, logouturl, null, strFileContents, algotype);
		}
		else
		{
			result = OrgApi.addOrgSAMLAuth(zoid, loginurl, logouturl, null, strFileContents, algotype);
		}
		OrgPolicy policy = OrgApi.getOrgPolicy(zoid);
		if (policy == null)
		{
			policy = new OrgPolicy();
		}
		policy.setAutoProvisionSAMLUsers(jit);
		OrgApi.updateOrgPolicy(zoid, policy);
		if (result)
		{
			return;
			//AuditUtil.auditOtherOperations(VaultUtil.getUserId(), null, AuditUtil.OP_SAML_SSO_ENABLED, null, null, VaultUtil.getCurrentTimeMillis(), request.getRemoteAddr());
			//opResult = VaultUtil.getOpStatusSuccessMsg(I18N.getI18nMsg("vault.action.saml_configuration_saved"));
		}
		else
		{
			throw new IdmpodException(ErrorCode.GENERIC_ADD_SAML_CONFIGURATION_FAILED);
		}
	}
}
