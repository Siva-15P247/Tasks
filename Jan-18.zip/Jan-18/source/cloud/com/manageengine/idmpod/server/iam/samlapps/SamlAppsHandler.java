package com.manageengine.idmpod.server.iam.samlapps;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.i18n.I18N;
import com.adventnet.iam.*;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.QueryConstructor;
import com.adventnet.persistence.Row;
import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.error.ErrorCode;
import com.manageengine.idmpod.server.error.IdmpodException;
import com.manageengine.idmpod.server.iam.AppAccountUtils;
import com.manageengine.idmpod.server.iam.IdmpodIAMUtil;
import com.manageengine.idmpod.server.iam.UserUtils;
import com.manageengine.idmpod.server.utils.IdmpodUtils;
import com.manageengine.tables.adsf.ADSIAMAPPLICATIONS;
import com.manageengine.tables.adsf.ADSIAMAPPLICATIONSCATEGORY;
import com.manageengine.tables.adsf.ADSIAMAPPLICATIONSPROPS;
import com.manageengine.tables.idmpod.IDMPODTECHNICIAN;
import com.manageengine.tables.idmpod.IDMPODUSER;
import com.zoho.accounts.Accounts;
import com.zoho.accounts.AccountsProto;
import com.zoho.accounts.AccountsProto.Account.SAMLApp;
import com.zoho.accounts.AccountsProto.Account.SAMLApp.SAMLUser;
import com.zoho.conf.Configuration;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class SamlAppsHandler
{
	public static final Logger LOGGER = Logger.getLogger(SamlAppsHandler.class.getName());
	private static final OrgAPI ORGAPI = IAMProxy.getInstance().getOrgAPI();

	public static JSONObject getSamlAppTemplate(Long templateId)
	{
		final String TYPE = JsonApiHandler.ResourceType.SAML_APP_TEMPLATE.getResType();
		JSONObject appTemplate = new JSONObject();
		try
		{
			ArrayList tablesList = new ArrayList();
			tablesList.add(ADSIAMAPPLICATIONS.TABLE);
			tablesList.add(ADSIAMAPPLICATIONSPROPS.TABLE);

			boolean[] isLeftJoins = new boolean[tablesList.size()];
			Arrays.fill(isLeftJoins, true);

			Criteria crit = new Criteria(Column.getColumn(ADSIAMAPPLICATIONSPROPS.TABLE, ADSIAMAPPLICATIONSPROPS.SUPPORTED_OPERATIONS_BIT), SSO_SUPPORT_FLAG, QueryConstants.EQUAL);
			crit = crit.or(new Criteria(Column.getColumn(ADSIAMAPPLICATIONSPROPS.TABLE, ADSIAMAPPLICATIONSPROPS.SUPPORTED_OPERATIONS_BIT), BOTH_SSO_SYNC, QueryConstants.EQUAL));

			crit = crit.and(new Criteria(Column.getColumn(ADSIAMAPPLICATIONS.TABLE, ADSIAMAPPLICATIONS.APP_ID), templateId, QueryConstants.EQUAL));

			SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, crit);

			DataObject appTemplateDO = DBUtils.getOrgPersistence().get(query);
			if (!appTemplateDO.isEmpty())
			{
				if (appTemplateDO.containsTable(ADSIAMAPPLICATIONS.TABLE))
				{
					Row r = appTemplateDO.getFirstRow(ADSIAMAPPLICATIONS.TABLE);
					JSONObject appTemplateAttrs = DBUtils.rowToJson(r);
					if (appTemplateDO.containsTable(ADSIAMAPPLICATIONSPROPS.TABLE))
					{
						Row propsRow = appTemplateDO.getRow(ADSIAMAPPLICATIONSPROPS.TABLE, new Criteria(Column.getColumn(ADSIAMAPPLICATIONSPROPS.TABLE, ADSIAMAPPLICATIONSPROPS.APP_ID), r.get(ADSIAMAPPLICATIONSPROPS.APP_ID), QueryConstants.EQUAL));
						if (propsRow != null)
						{
							DBUtils.rowToJson(propsRow, appTemplateAttrs);
						}
					}
					appTemplate.put(JsonApiConstants.ID, appTemplateAttrs.get(ADSIAMAPPLICATIONS.APP_ID));
					appTemplate.put(JsonApiConstants.TYPE, TYPE);
					appTemplate.put(JsonApiConstants.ATTRIBUTES, appTemplateAttrs);
				}
			}

		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return appTemplate;
	}

	public static JSONObject getMappedUsers(Long app_id, JSONArray filterArray) throws IAMException
	{
		final String TYPE = JsonApiHandler.ResourceType.USER.getResType();
		JSONObject resp = new JSONObject();
		JSONArray users = new JSONArray();

		List<SAMLUser> samlUsers = getOrgApi().getSamlUsers(IdmpodIAMUtil.getZOID().toString(), app_id.toString());
		List<String> samluserids = null;
		if (samlUsers != null)
		{
			samluserids = samlUsers.stream().filter(su -> su.getIsEnabled()).map(su -> su.getZid()).collect(Collectors.toList());
		}
		else
		{
			samluserids = new ArrayList<>();
		}

		String dispNameFilter = null, emailFilter = null;

		if (filterArray != null)
		{
			for (int i = 0; i < filterArray.length(); i++)
			{
				JSONObject filterObj = filterArray.getJSONObject(i);
				if (filterObj.has("DISPLAY_NAME"))
				{
					dispNameFilter = filterObj.getString("DISPLAY_NAME");
				}
				if (filterObj.has("PRIMARY_EMAIL"))
				{
					emailFilter = filterObj.getString("PRIMARY_EMAIL");
				}
			}
		}

		try
		{
			List<Long> aaids = new ArrayList<>();
			Criteria mappedUserCrit = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.STATUS), "DELETED", QueryConstants.NOT_EQUAL, false);
			mappedUserCrit = mappedUserCrit.and(new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ZUID), samluserids.toArray(new String[samluserids.size()]), QueryConstants.IN));

			DataObject aausersDO = DBUtils.getOrgPersistence().get(IDMPODTECHNICIAN.TABLE, mappedUserCrit);
			Iterator<Row> aausers = aausersDO.getRows(IDMPODTECHNICIAN.TABLE);
			while (aausers.hasNext())
			{
				Row aauser = aausers.next();
				aaids.add((Long) aauser.get(IDMPODTECHNICIAN.ZUID));
			}
			try
			{
				UserAPI userAPI = IAMProxy.getInstance().getUserAPI();

				List<User> userList = userAPI.getUsers(aaids.toArray(new Long[aaids.size()]));

				if (dispNameFilter != null)
				{
					String finalDispNameFilter = dispNameFilter.toLowerCase();
					userList = userList.stream().filter(aauser -> aauser.getDisplayName().toLowerCase().contains(finalDispNameFilter)).collect(Collectors.toList());
				}
				if (emailFilter != null)
				{
					String finalEmailFilter = emailFilter.toLowerCase();
					userList = userList.stream().filter(aauser -> aauser.getPrimaryEmail().toLowerCase().contains(finalEmailFilter)).collect(Collectors.toList());
				}

				if (userList != null)
				{
					for (User user : userList)
					{
						users.put(convertSamlUserToJson(user));
					}
				}

				//LOGGER.info(relationalAPI.getSelectSQL(query));
			}
			catch (Exception e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
			resp.put(JsonApiConstants.DATA, users);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		return resp;
	}

	private static JSONObject convertSamlUserToJson(User orgUser)
	{
		final String TYPE = JsonApiHandler.ResourceType.USER.getResType();

		JSONObject user = new JSONObject();
		JSONObject userAttrs = new JSONObject();

		userAttrs.put("COUNTRY", orgUser.getCountry());
		userAttrs.put("DISPLAY_NAME", orgUser.getDisplayName());
		userAttrs.put("FIRST_NAME", orgUser.getFirstName());
		userAttrs.put("GENDER", orgUser.getGender());
		userAttrs.put("LANGUAGE", orgUser.getLanguage());
		userAttrs.put("LAST_NAME", orgUser.getLastName());
		userAttrs.put("PRIMARY_EMAIL", orgUser.getPrimaryEmail());

		user.put(JsonApiConstants.ID, orgUser.getZUID());
		user.put(JsonApiConstants.TYPE, TYPE);
		user.put(JsonApiConstants.ATTRIBUTES, userAttrs);

		return user;
	}

	public static boolean deleteSAMLApp(Long appId)
	{
		try
		{
			return getOrgApi().deleteSamlApp(IdmpodIAMUtil.getZAID(), appId.toString());
		}
		catch (IAMException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		return false;
	}

	public static JSONObject addCustomApp(JSONObject request, JSONObject resp)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		String app_name = attributes.optString("APP_NAME"); // NO I18N
		String login_url = attributes.optString("LOGIN_URL");// NO I18N
		String acs_url = attributes.optString("ACS_URL");// NO I18N
		String logout_url = attributes.optString("LOGOUT_URL", null);// NO I18N
		String entityid = attributes.optString("ENTITYID");// NO I18N
		String relayState = attributes.optString("RELAY_STATE");// NO I18N
		String description = attributes.optString("DESCRIPTIONS", null);//No I18N
		String publicKey = null;

		JSONArray errors = resp.has(JsonApiConstants.ERRORS) ? resp.getJSONArray(JsonApiConstants.ERRORS) : new JSONArray();

		if (errors != null && errors.length() > 0)
		{
			resp.put(JsonApiConstants.ERRORS, errors);
		}
		else
		{
			String zaid = IdmpodIAMUtil.getZAID();
			Long appId = addSAMLApp(zaid, entityid, acs_url, login_url, app_name, relayState, description, publicKey, NameId.NAMEID_EMAIL_ADDRESS.toString(), (logout_url != null) ? true : false, logout_url, attributes.has("ICON") ? new Base64().decode(attributes.getString("ICON")) : null, null); // NO I18N
			resp.getJSONObject(JsonApiConstants.DATA).put(JsonApiConstants.ID, appId);
		}
		return resp;
	}

	public static String[] assignSamlappsToUsers(String[] appids, String[] zuids) throws Exception
	{
		String[] remarks = new String[2];

		AccountsProto.Account.User[] accountUsers = AppAccountUtils.getAccountUsers(new com.zoho.resource.Criteria(Accounts.RESOURCE.USER.ZUID, com.zoho.resource.Criteria.Comparator.IN, String.join(",", zuids)));
		StringBuilder remSb = new StringBuilder();
		if (accountUsers != null)
		{
			for (int i = 0; i < accountUsers.length; i++)
			{
				AccountsProto.Account.User user = accountUsers[i];
				String name = user.getDisplayName();
				remSb.append(name);
				if (i == accountUsers.length - 2)
				{
					remSb.append(I18N.getMsg("idmpod.common.conj.and"));
				}
				else if (i < accountUsers.length - 1)
				{
					remSb.append(", ");
				}
			}
		}
		remarks[1] = remSb.toString();

		StringBuilder remAppSb = new StringBuilder();
		for (int i = 0; i < appids.length; i++)
		{
			String appid = appids[i];
			SAMLApp samlApp = getOrgApi().getSamlApp(IdmpodIAMUtil.getZAID(), appid);
			remAppSb.append(samlApp.getAppName());
			if (i == appids.length - 2)
			{
				remAppSb.append(I18N.getMsg("idmpod.common.conj.and"));
			}
			else if (i < appids.length - 1)
			{
				remAppSb.append(", ");
			}

			List<SAMLUser> users = null;
			Long zaid = Long.parseLong(IdmpodIAMUtil.getZAID());

			try
			{
				users = getOrgApi().getSamlUsers(IdmpodIAMUtil.getZAID(), appid);
			}
			catch (IAMException ex)
			{
				LOGGER.log(Level.SEVERE, "No users added yet", ex);
			}
			if (users == null)
			{
				getOrgApi().addUserstoSamlApp(zaid, appid, zuids);
				updateUserstoSAMLApp(zaid, appid, zuids, true);
			}
			else
			{
				java.util.Set<String> set = new java.util.HashSet<>();
				for (SAMLUser user : users)
				{
					set.add(user.getZid()); // This will contain all users added to app
				}
				List<String> toAdd = new java.util.ArrayList<>();
				if (zuids != null)
				{
					for (String zid : zuids)
					{
						if (!set.contains(zid))
						{
							toAdd.add(zid);
						}
					}
				}
				if (!toAdd.isEmpty())
				{
					getOrgApi().addUserstoSamlApp(zaid, appid, toAdd.toArray(new String[toAdd.size()]));
				}
				updateUserstoSAMLApp(zaid, appid, zuids, true);
			}
		}

		remarks[0] = remAppSb.toString();

		return remarks;
	}

	public static String[] unassignSamlappsFromUsers(String[] appids, String[] zuids) throws Exception
	{
		String[] remarks = new String[2];

		AccountsProto.Account.User[] accountUsers = AppAccountUtils.getAccountUsers(new com.zoho.resource.Criteria(Accounts.RESOURCE.USER.ZUID, com.zoho.resource.Criteria.Comparator.IN, String.join(",", zuids)));
		StringBuilder remSb = new StringBuilder();
		if (accountUsers != null)
		{
			for (int i = 0; i < accountUsers.length; i++)
			{
				AccountsProto.Account.User user = accountUsers[i];
				String name = user.getDisplayName();
				remSb.append(name);
				if (i == accountUsers.length - 2)
				{
					remSb.append(I18N.getMsg("idmpod.common.conj.and"));
				}
				else if (i < accountUsers.length - 1)
				{
					remSb.append(", ");
				}
			}
		}
		remarks[1] = remSb.toString();

		StringBuilder remAppSb = new StringBuilder();
		for (int i = 0; i < appids.length; i++)
		{
			String appid = appids[i];
			SAMLApp samlApp = getOrgApi().getSamlApp(IdmpodIAMUtil.getZAID(), appid);
			remAppSb.append(samlApp.getAppName());
			if (i == appids.length - 2)
			{
				remAppSb.append(I18N.getMsg("idmpod.common.conj.and"));
			}
			else if (i < appids.length - 1)
			{
				remAppSb.append(", ");
			}

			List<SAMLUser> users = null;
			Long zaid = Long.parseLong(IdmpodIAMUtil.getZAID());
			boolean status = updateUserstoSAMLApp(zaid, appid.toString(), zuids, false);
		}

		remarks[0] = remAppSb.toString();

		return remarks;
	}

	public enum NameId
	{

		NAMEID_UNSPECIFIED(1, "urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified"), // NO I18N
		NAMEID_EMAIL_ADDRESS(2, "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress"), // NO I18N
		NAMEID_PERSISTENCE(3, "urn:oasis:names:tc:SAML:2.0:nameid-format:persistent"), // NO I18N
		NAMEID_TRANSIENT(4, "urn:oasis:names:tc:SAML:2.0:nameid-format:transient"); // NO I18N

		NameId(int i, String s)
		{
			this.intValue = i;
			this.stringConstant = s;
		}

		int intValue;
		String stringConstant;

		public String getStringConstant()
		{
			return stringConstant;
		}

		public int getIntValue()
		{
			return intValue;
		}
	}

	public static OrgAPI getOrgApi()
	{
		return ORGAPI;
	}

	/**
	 * Add a new SAML App for the org
	 *
	 * @param zaid
	 * @param issuer
	 * @param acsUrl
	 * @param singinUrl
	 * @param appName
	 * @param relayState
	 * @param description
	 * @param publicKey
	 * @param nameId
	 * @return
	 * @throws IAMException
	 */
	public static Long addSAMLApp(String zaid, String issuer, String acsUrl, String singinUrl, String appName, String relayState, String description, String publicKey, String nameId, boolean enableLogout, String logoutUrl, byte[] logo, String attributes) throws JSONException
	{
		Long app_id = null;
		try
		{
			String appId = getOrgApi().addSamlApp(zaid, appName, acsUrl, issuer, NameId.NAMEID_EMAIL_ADDRESS.getStringConstant(), singinUrl, true, description, zaid, relayState, enableLogout, logoutUrl);
			if (appId != null)
			{
				app_id = Long.valueOf(appId);
				if (logo != null)
				{
					try
					{
						boolean status = IAMProxy.getInstance().uploadSamlAppLogo(PhotoAPI.SAMLORG, app_id, logo, zaid);
						// LOGGER.log(Level.INFO, "Uploaded the app logo for app " + appName + " with status " + status);
					}
					catch (Exception ex)
					{
						LOGGER.log(Level.SEVERE, "Error while uploading app logo.", ex);
					}
				}
				try
				{
					if (attributes != null && !"".equals(attributes))
					{
						JSONArray jsonAry = new JSONArray(attributes);
						for (int i = 0; i < jsonAry.length(); i++)
						{
							JSONObject attrObj = jsonAry.getJSONObject(i);
							String attrName = attrObj.getString("name"); // NO I18N
							String attrValue = SamlMetaDataUtil.NameIDType.getNameIdType(attrObj.getInt("value")).getNameId(); // NO I18N
							getOrgApi().updateSAMLAppAttribute(zaid, appId, attrName, "", attrValue);
						}
					}
				}
				catch (JSONException jsonEx)
				{
					LOGGER.log(Level.SEVERE, "Error while uploading app attribute.", jsonEx);
				}
				catch (Exception ex)
				{
					LOGGER.log(Level.SEVERE, "Error while uploading app attribute.", ex);
				}
				////AuditUtil.auditOtherOperations(VaultUtil.getUserId(), null, AuditUtil.OP_SAML_APP_ADDED, null, appName, VaultUtil.getCurrentTimeMillis(), request.getRemoteAddr());
			}
		}
		catch (IAMException iamEx)
		{
			LOGGER.log(Level.SEVERE, "Adding SAML App failed with Error code : {0}", iamEx.getErrorCode());
			LOGGER.log(Level.SEVERE, iamEx.getMessage());
			if ("Z102".equals(iamEx.getErrorCode()))
			{
				throw new IdmpodException(ErrorCode.APP_FOR_ISSUER_ALREADY_EXISTS);
			}
			throw new IdmpodException(ErrorCode.GENERIC_ERR_ADDING_SAML_APP);
		}
		return app_id;
	}

	public static JSONObject updateSamlApp(Long appId, JSONObject attributes) throws IAMException
	{
		JSONObject resp = new JSONObject();
		JSONArray errorsArray = new JSONArray();

		boolean isUpdated = false;
		String icon = null;
		byte[] logo = null;
		String appName = null;
		String acs_url = null;
		String entityid = null;
		String login_url = null;
		String logout_url = null;

		if (attributes.has("ICON"))
		{
			String orig = attributes.getString("ICON");  //No I18N
			if (orig.contains(";base64,"))
			{
				//removing "data:image/png;base64," from encoded string
				icon = orig.substring(orig.indexOf(";base64,") + 8);  //No I18N
				logo = new Base64().decode(icon);
			}
			else
			{
				logo = new Base64().decode(attributes.getString("ICON").getBytes()); //No I18N
			}
		}
		if (logo != null)
		{
			try
			{
				boolean status = IAMProxy.getInstance().uploadSamlAppLogo(PhotoAPI.SAMLORG, appId, logo, IdmpodIAMUtil.getZAID());
				// LOGGER.log(Level.INFO, "Updated the app logo for app " + attributes.getString("APP_NAME") + " with status " + status);
			}
			catch (Exception ex)
			{
				LOGGER.log(Level.SEVERE, "Error while updating app logo.", ex);
			}
		}

		JSONObject oldAttributes = getSAMLAppAsJSONObject(getSAMLApp(appId.toString()), IdmpodIAMUtil.getZOID().toString()).getJSONObject(JsonApiConstants.ATTRIBUTES);
		for (String key : attributes.keySet())
		{
			oldAttributes.put(key, attributes.get(key));
		}

		acs_url = oldAttributes.getString("ACS_URL");
		entityid = oldAttributes.getString("ENTITYID");
		logout_url = oldAttributes.optString("LOGOUT_URL", ""); //No I18N
		//		if (attributes.has("METADATA"))
		//		{
		//			LOGGER.log(Level.INFO, "Metadata available for update");
		//			try
		//			{
		//				JSONObject jb = SamlMetaDataUtil.parseSPMetadataFile(attributes.getString("METADATA"));
		//				if (jb.getString("acs_url") != null)
		//				{
		//					LOGGER.log(Level.INFO, "Metadata acs_url is " + jb.getString("acs_url"));
		//					acs_url = jb.getString("acs_url");
		//				}
		//				if (jb.getString("logout_url") != null)
		//				{
		//					LOGGER.log(Level.INFO, "Metadata logout_url is " + jb.getString("logout_url"));
		//					logout_url = jb.getString("logout_url");
		//				}
		//				if (jb.getString("entityid") != null)
		//				{
		//					LOGGER.log(Level.INFO, "Metadata entityid is " + jb.getString("entityid"));
		//					entityid = jb.getString("entityid");
		//				}
		//			}
		//			catch (Exception e)
		//			{
		//				LOGGER.log(Level.SEVERE, "Error while parse Metadata file.", e);
		//			}
		//		}

		try
		{
			isUpdated = getOrgApi().updateSamlApp(IdmpodIAMUtil.getZAID(), appId.toString(), oldAttributes.getString("APP_NAME"), acs_url, entityid, SamlAppsHandler.NameId.NAMEID_EMAIL_ADDRESS.getStringConstant(), oldAttributes.getString("LOGIN_URL"), true, oldAttributes.getString("DESCRIPTION"), IdmpodIAMUtil.getZAID(), oldAttributes.getString("RELAY_STATE"), !org.apache.commons.lang3.StringUtils.isBlank(oldAttributes.optString("LOGOUT_URL", "")), logout_url);//No I18N
			isUpdated = isUpdated && getOrgApi().updateSamlAppStatus(IdmpodIAMUtil.getZAID(), appId.toString(), oldAttributes.optBoolean("IS_ENABLED", true));//No I18N
		}
		catch (IAMException e)
		{
			errorsArray.put(JsonApiHandler.getBaseErrorObject(e.getMessage()));
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		if (isUpdated)
		{
			JSONObject configuredSamlApp = new JSONObject();
			AccountsProto.Account.SAMLApp samlApp = SamlAppsHandler.getSAMLApp(appId.toString());
			String zoid = IdmpodIAMUtil.getZOID().toString();
			configuredSamlApp = SamlAppsHandler.getSAMLAppAsJSONObject(samlApp, zoid);
			resp.put(JsonApiConstants.DATA, configuredSamlApp);
		}
		else
		{
			errorsArray.put(JsonApiHandler.getBaseErrorObject("An error occurred while trying to update the application"));
			resp.put(JsonApiConstants.ERRORS, errorsArray);
		}

		return resp;
	}


	/**
	 * Update an already existing SAML App
	 *
	 * @param zaid
	 * @param appId
	 * @param issuer
	 * @param acsUrl
	 * @param signinUrl
	 * @param appName
	 * @param relayState
	 * @param description
	 * @param publicKey
	 * @param nameID
	 * @param enableLogout
	 * @param logoutUrl
	 * @param logo
	 * @param attributes
	 * @throws IAMException
	 * @throws JSONException
	 */
	public static void updateSAMLApp(String zaid, String appId, String issuer, String acsUrl, String signinUrl, String appName, String relayState, String description, String publicKey, String nameID, boolean enableLogout, String logoutUrl, byte[] logo, String attributes) throws IAMException, JSONException
	{
		boolean isUpdated = false;
		try
		{
			isUpdated = getOrgApi().updateSamlApp(zaid, appId, appName, acsUrl, issuer, nameID, signinUrl, true, description, zaid, relayState, enableLogout, logoutUrl);
		}
		catch (IAMException iamEx)
		{
			LOGGER.log(Level.SEVERE, "Updating SAML App failed with Error code : {0}", iamEx.getErrorCode());
			LOGGER.log(Level.SEVERE, iamEx.getMessage(), iamEx);
			if ("Z102".equals(iamEx.getErrorCode()))
			{
				throw new IdmpodException(ErrorCode.APP_FOR_ISSUER_ALREADY_EXISTS);
			}
			throw new IdmpodException(ErrorCode.GENERIC_ERR_UPDATING_SAML_APP);
		}
		if (isUpdated)
		{
			if (logo != null)
			{
				Long app_id = Long.valueOf(appId);
				try
				{
					boolean status = IAMProxy.getInstance().uploadSamlAppLogo(PhotoAPI.SAMLORG, app_id, logo, zaid);
					// LOGGER.log(Level.INFO, "Uploaded the app logo for app " + appName + " with status " + status);
				}
				catch (Exception ex)
				{
					LOGGER.log(Level.SEVERE, "Error while uploading app logo.", ex);
				}
			}
			try
			{
				JSONArray jsonAry = null;
				if (attributes != null && !"".equals(attributes))
				{
					jsonAry = new JSONArray(attributes);
				}
				else
				{
					jsonAry = new JSONArray();
				}
				addOrUpdateSAMLAppAttributes(zaid, appId, jsonAry);
			}
			catch (JSONException jsonEx)
			{
				LOGGER.log(Level.SEVERE, "Error while uploading app attribute.", jsonEx);
			}
			catch (Exception ex)
			{
				LOGGER.log(Level.SEVERE, "Error while uploading app attribute.", ex);
			}
			////AuditUtil.auditOtherOperations(VaultUtil.getUserId(), null, AuditUtil.OP_SAML_APP_UPDATED, null, appName, VaultUtil.getCurrentTimeMillis(), request.getRemoteAddr());
		}
		else
		{
			throw new IdmpodException(ErrorCode.GENERIC_ERR_UPDATING_SAML_APP);
		}
	}

	public static com.zoho.accounts.AccountsProto.Account.SAMLApp getSAMLApp(String appId) throws IAMException
	{
		return getSAMLApp(IdmpodIAMUtil.getZAID(), appId);
	}

	public static com.zoho.accounts.AccountsProto.Account.SAMLApp getSAMLApp(String zaid, String appId) throws IAMException
	{
		return getOrgApi().getSamlApp(zaid, appId);
	}

	public static List<com.zoho.accounts.AccountsProto.Account.SAMLApp> getAllSAMLApps() throws IAMException
	{
		return getAllSAMLApps(IdmpodIAMUtil.getZAID());
	}

	public static List<com.zoho.accounts.AccountsProto.Account.SAMLApp> getAllSAMLApps(String zaid) throws IAMException
	{
		List<com.zoho.accounts.AccountsProto.Account.SAMLApp> appList = getOrgApi().getAllSamlApp(zaid);
		return (appList == null) ? new java.util.ArrayList() : appList;
	}

	/**
	 * @param zuid
	 * @return
	 * @throws IAMException
	 */
	public static List<SAMLApp> getUserSamlApps(Long zuid) throws IAMException
	{
		return getOrgApi().getSamlAppsofUser(zuid.toString());
	}

	/**
	 * @param zuid
	 * @param appName
	 * @param index
	 * @param limit
	 * @return
	 * @throws IAMException
	 * @throws JSONException
	 */
	public static JSONObject getUserSAMLApps(String zuid, String appName, int index, int limit) throws IAMException, JSONException
	{
		JSONArray apps = new JSONArray();
		List<SAMLApp> appList = getOrgApi().getSamlAppsofUser(zuid);
		if (appList != null)
		{
			String zoid = IdmpodIAMUtil.getZOID().toString();
			for (SAMLApp app : appList)
			{
				if (app.getIsEnabled())
				{
					if (appName == null)
					{
						apps.put(getSAMLAppAsJSONObject(app, zoid));
					}
					else
					{
						String name = app.getAppName().toLowerCase();
						if (name.contains(appName))
						{
							apps.put(getSAMLAppAsJSONObject(app, zoid));
						}
					}
				}
			}
		}
		JSONObject result = new JSONObject();
		result.put("apps", apps); // NO I18N
		result.put("index", index); // NO I18N
		result.put("limit", limit); // NO I18N
		result.put("appName", appName); // NO I18N
		return result;
	}

	public static JSONObject getUsersMappedToSamlApp(String appId) throws DataAccessException, JSONException
	{
		JSONObject results = new JSONObject();
		java.util.List<String> vaultUsers = getMappedUsers(appId);
		if (!vaultUsers.isEmpty())
		{
			Criteria crit = new Criteria(new Column(IDMPODUSER.TABLE, IDMPODUSER.ZUID), vaultUsers.toArray(new String[vaultUsers.size()]), QueryConstants.IN);
			crit = crit.and(new Criteria(new Column(IDMPODUSER.TABLE, IDMPODUSER.STATUS), User.ACTIVE, QueryConstants.EQUAL));
			DataObject dobj = DBUtils.getOrgPersistence().get(IDMPODUSER.TABLE, crit);
			if (dobj.containsTable(IDMPODUSER.TABLE))
			{
				java.util.Iterator<Row> it = dobj.getRows(IDMPODUSER.TABLE);
				while (it.hasNext())
				{
					JSONObject json = new JSONObject();
					Row userRow = it.next();
					json.put(IDMPODUSER.USER_NAME, userRow.get(IDMPODUSER.USER_NAME));
					json.put(IDMPODUSER.EMAIL_ID, userRow.get(IDMPODUSER.EMAIL_ID));
					json.put(IDMPODUSER.ZUID, userRow.get(IDMPODUSER.ZUID));
					json.put(IDMPODUSER.USER_ID, userRow.get(IDMPODUSER.USER_ID).toString());
					results.put(userRow.get(IDMPODUSER.USER_ID).toString(), json);
				}
			}
		}
		return results;
	}

	public static List<String> getMappedUsers(String appId)
	{
		java.util.List<String> vaultUsers = new java.util.ArrayList<>();
		java.util.List<SAMLUser> users = null;
		try
		{
			users = getOrgApi().getSamlUsers(IdmpodIAMUtil.getZOID().toString(), appId);
		}
		catch (IAMException ex)
		{
			LOGGER.log(Level.SEVERE, "Exception while fetching user mapps for the app : " + appId, ex);
			return vaultUsers;
		}

		if (users != null)
		{
			for (SAMLUser user : users)
			{
				if (user.getIsEnabled())
				{
					String zuid = user.getZid();
					vaultUsers.add(zuid);
				}
			}
		}
		return vaultUsers;
	}

	public static JSONObject getSAMLAppAsJSONObject(SAMLApp samlApp, String zoid) throws IAMException
	{
		return getSAMLAppAsJSONObject(samlApp, zoid, JsonApiHandler.ResourceType.SAML_APP.getResType());
	}

	public static JSONObject getSAMLAppAsJSONObject(SAMLApp app, String zoid, final String type) throws JSONException, IAMException
	{
		JSONObject appObj = new JSONObject();

		JSONObject appAttrs = new JSONObject();
		appAttrs.put("IS_ENABLED", app.getIsEnabled());
		appAttrs.put("ENTITYID", app.getIdentifier()); // NO I18N
		appAttrs.put("LOGOUT_URL", app.getLogoutUrl());// NO I18N
		appAttrs.put("ACS_URL", app.getAcsUrl());// NO I18N
		appAttrs.put("LOGIN_URL", app.getSignInUrl()); // NO I18N
		appAttrs.put("APP_NAME", app.getAppName()); // NO I18N
		appAttrs.put("DESCRIPTION", app.getDescription()); // NO I18N
		appAttrs.put("NAMEID", app.getNameIdField()); // NO I18N
		appAttrs.put("CREATED_TIME", app.getCreatedTime()); // NO I18N
		Long modifiedTime = app.getModifiedTime();
		if (modifiedTime == 0)
		{
			modifiedTime = app.getCreatedTime();
		}
		appAttrs.put("MODIFIED_TIME", modifiedTime); // NO I18N

		if (getOrgApi().isSamlAppLogoExist(zoid, Long.valueOf(app.getAppId())))
		{
			try
			{
				appAttrs.put("ICON", new String(new Base64().encode(getAppLogo(app.getAppId(), zoid)), "UTF-8"));
			}
			catch (UnsupportedEncodingException ex)
			{
				LOGGER.log(Level.SEVERE, null, ex);
			}
		}
		else
		{
			// LOGGER.log(Level.INFO, "No app logo for {0}", app.getAppName());
			appAttrs.put("ICON", ""); // NO I18N
		}
		Integer mappedUserCount = 0;
		java.util.List<SAMLUser> users = null;
		try
		{
			users = getOrgApi().getSamlUsers(IdmpodIAMUtil.getZOID().toString(), app.getAppId());
			if (users != null)
			{
				mappedUserCount = users.stream().filter(user -> user.getIsEnabled()).collect(Collectors.toList()).size();
			}
		}
		catch (IAMException ex)
		{
			LOGGER.log(Level.SEVERE, "Exception while fetching user mapps for the app : " + app.getAppId(), ex);
		}
		appAttrs.put("MAPPED_USER_COUNT", mappedUserCount);
		appAttrs.put("RELAY_STATE", app.getDefaultRelayState());
		appAttrs.put("APP_ID", app.getAppId());
		/*Verify if the login url and logout url from the issuer details work; else revert*/
		//		String idpUrl = IAMProxy.getIAMServerURL();//VaultUtil.getAccontsServerURL();
		//		if (!idpUrl.startsWith("https"))
		//		{
		//			idpUrl = "https" + idpUrl.substring(4); // NO I18N
		//		}
		//		if (idpUrl.endsWith("/"))
		//		{
		//			idpUrl = idpUrl + "saml2/idp/initiate?appid=" + app.getAppId(); // NO I18N
		//		}
		//		else
		//		{
		//			idpUrl = idpUrl + "/saml2/idp/initiate?appid=" + app.getAppId(); // NO I18N
		//		}
		//		appAttrs.put("IDP_LOGIN_URL", idpUrl); // NO I18N

		SamlIssuerDetails details = getOrgApi().getSamlIssuerDetails(IdmpodIAMUtil.getZOID(), app.getAppId());

		appAttrs.put("IDP_LOGIN_URL", IdmpodUtils.getServiceUrl() + "/sp-saml-login?appid=" + app.getAppId());
		appAttrs.put("IDP_LOGOUT_URL", IdmpodUtils.getServiceUrl() + "/saml-logout?appid=" + app.getAppId());
		appAttrs.put("ISSUER", details.getIssuer());
		appAttrs.put("CERTIFICATE", details.getPublicKey());
		appAttrs.put("CERTIFICATE_FINGERPRINT", getCertificateFingerprint(details.getPublicKey()));
		String metaString = SamlMetaDataUtil.getIdPMetadata(app.getAppId(), details);
		appAttrs.put("METADATA", metaString);
		String metadata = new String(new Base64().encode(metaString.getBytes()));
		appAttrs.put("ENCODED_METADATA", metadata);

		String idpUrl = IAMProxy.getIAMServerURL();
		if (!idpUrl.startsWith("https"))
		{
			idpUrl = "https" + idpUrl.substring(4); // NO I18N
		}
		if (idpUrl.endsWith("/"))// NO I18N
		{
			idpUrl = idpUrl + "saml2/idp/initiate?appid=" + app.getAppId(); // NO I18N
		}
		else
		{
			idpUrl = idpUrl + "/saml2/idp/initiate?appid=" + app.getAppId(); // NO I18N
		}

		appAttrs.put("ACCESS_URL", idpUrl);

		appObj.put(JsonApiConstants.ID, app.getAppId());
		appObj.put(JsonApiConstants.TYPE, type);
		appObj.put(JsonApiConstants.ATTRIBUTES, appAttrs);

		return appObj;
	}

	/**
	 * Read the file content and return as string
	 *
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public static String getFileContentAsString(File file) throws IOException
	{
		StringBuilder fileData = new StringBuilder(1000);
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
		char[] buf = new char[1024];
		int numRead;
		while ((numRead = reader.read(buf)) != -1)
		{
			String readData = String.valueOf(buf, 0, numRead);
			fileData.append(readData);
			buf = new char[1024];
		}
		reader.close();
		return fileData.toString();
	}

	/**
	 * Extract public key from this cert string and return
	 *
	 * @param certString
	 * @return
	 * @throws CertificateException
	 */
	public static String getPublicKeyFromCert(String certString) throws CertificateException
	{
		if (certString == null)
		{
			return null;
		}
		CertificateFactory f = CertificateFactory.getInstance("X.509");
		X509Certificate certificate = (X509Certificate) f.generateCertificate(new ByteArrayInputStream(certString.getBytes(StandardCharsets.UTF_8)));
		PublicKey pk = certificate.getPublicKey();
		return pk.toString();
	}

	/**
	 * Delete the SAML app for the org
	 *
	 * @param appId
	 * @param zaid
	 * @return
	 */
	public static void deleteSAMLApp(HttpServletRequest request, String appId, String zaid) throws IAMException, JSONException
	{
		if (getOrgApi().deleteSamlApp(zaid, appId))
		{
			return;
			////AuditUtil.auditOtherOperations(VaultUtil.getUserId(), null, AuditUtil.OP_SAML_APP_DELETED, null, appName, VaultUtil.getCurrentTimeMillis(), request.getRemoteAddr());
		}
		else
		{
			throw new IdmpodException(ErrorCode.GENERIC_ERR_DELETING_SAML_APP);
		}

	}

	public static JSONObject getConfigurationDetails(String appId) throws JSONException, IAMException
	{
		if (appId == null)
		{
			return null;
		}
		return getConfigurationDetails(appId, Long.valueOf(IdmpodIAMUtil.getZAID()));
	}

	public static JSONObject getConfigurationDetails(String appId, Long zaid) throws JSONException, IAMException
	{
		JSONObject details = new JSONObject();
		SamlIssuerDetails detail = getOrgApi().getSamlIssuerDetails(zaid, appId);
		details.put("login_url", detail.getSamlIdpLoginURL()); // NO I18N
		String logout_url = IAMProxy.getIAMServerURL() + "/logout";// NO I18N
		details.put("logout_url", logout_url); // NO I18N
		details.put("issuer", detail.getIssuer()); // NO I18N
		details.put("certificate", detail.getPublicKey()); // NO I18N
		details.put("fingerprint", getCertificateFingerprint(detail.getPublicKey())); // NO I18N
		String metaString = SamlMetaDataUtil.getIdPMetadata(appId, detail);
		details.put("meta_data", metaString); // NO I18N
		String data = new String(new Base64().encode(metaString.getBytes()));
		details.put("data", data);// NO I18N
		return details;
	}

	/**
	 * @param zaid
	 * @param appId
	 * @param zuids
	 * @return
	 * @throws IAMException
	 */
	public static boolean updateUserToSAMLApp(HttpServletRequest request, Long userId, Long zaid, String appId, String appName, String[] zuids) throws IAMException, JSONException
	{
		List<SAMLUser> users = null;
		try
		{
			users = getOrgApi().getSamlUsers(zaid.toString(), appId);
		}
		catch (IAMException ex)
		{
			LOGGER.log(Level.SEVERE, "No users added yet", ex);
		}
		if (users == null)
		{
			if (zuids == null || zuids.length == 0)
			{
				return true;
			}
			getOrgApi().addUserstoSamlApp(zaid, appId, zuids);
			updateUserstoSAMLApp(zaid, appId, zuids, true);
			auditUsersAddedOrRemovedOperation(request, userId, appName, new java.util.ArrayList<SAMLUser>(), zuids);
			return true;
		}
		java.util.Set<String> set = new java.util.HashSet<>();
		for (SAMLUser user : users)
		{
			set.add(user.getZid()); // This will contain all users added to app
		}
		List<String> toAdd = new java.util.ArrayList<>();
		if (zuids != null)
		{
			for (String zuid : zuids)
			{
				if (!set.contains(zuid))
				{
					toAdd.add(zuid);
				}
			}
		}
		if (!toAdd.isEmpty())
		{
			getOrgApi().addUserstoSamlApp(zaid, appId, toAdd.toArray(new String[toAdd.size()]));
		}
		if (!set.isEmpty())
		{
			updateUserstoSAMLApp(zaid, appId, set.toArray(new String[set.size()]), false);
		}
		updateUserstoSAMLApp(zaid, appId, zuids, true);
		auditUsersAddedOrRemovedOperation(request, userId, appName, users, zuids);
		return true;
	}

	/**
	 * @param request
	 * @param userId
	 * @param appName
	 * @param users   Contains all users added to this app
	 * @param zuids   Contains users to be added to this app
	 * @throws JSONException
	 */
	private static void auditUsersAddedOrRemovedOperation(HttpServletRequest request, Long userId, String appName, List<SAMLUser> users, String[] zuids) throws JSONException
	{
		java.util.Set<String> added = new java.util.HashSet<>();
		Collections.addAll(added, zuids);
		java.util.Set<String> removed = new java.util.HashSet<>();
		for (SAMLUser user : users)
		{
			if (user.getIsEnabled() && added.contains(user.getZid()))
			{
				added.remove(user.getZid());
			}
			else
			{
				removed.add(user.getZid());
			}
		}
		auditUsersAddedOperation(request, userId, appName, added);
		auditUsersRemovedOperation(request, userId, appName, removed);
	}

	private static void auditUsersAddedOperation(HttpServletRequest request, Long userId, String appName, Set<String> added) throws JSONException
	{
		if (added.isEmpty())
		{
			return;
		}
		//AuditUtil.auditOtherOperations(userId, null, AuditUtil.OP_USER_ADDED_TO_SAML_APP, null, appName, VaultUtil.getCurrentTimeMillis(), request.getRemoteAddr());
	}

	private static void auditUsersRemovedOperation(HttpServletRequest request, Long userId, String appName, Set<String> removed) throws JSONException
	{
		if (removed.isEmpty())
		{
			return;
		}
		//AuditUtil.auditOtherOperations(userId, null, AuditUtil.OP_USER_REMOVED_FROM_SAML_APP, null, appName, VaultUtil.getCurrentTimeMillis(), request.getRemoteAddr());
	}

	/**
	 * @param zaid
	 * @param appId
	 * @param zuids
	 * @return
	 * @throws IAMException
	 */
	public static boolean updateUserstoSAMLApp(Long zaid, String appId, String[] zuids, boolean status)
	{
		boolean respFlag = false;
		for (String zuid : zuids)
		{
			try
			{
				respFlag = getOrgApi().updateUsertoSamlApp(zaid, appId, zuid, status);
			}
			catch (IAMException e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
		}
		return respFlag;
	}

	public static String getIdPMetadata(String appId) throws IAMException
	{
		SamlIssuerDetails detail = getOrgApi().getSamlIssuerDetails(Long.valueOf(IdmpodIAMUtil.getZAID()), appId);
		return SamlMetaDataUtil.getIdPMetadata(appId, detail);
	}

	/**
	 * Extract the certificate fingerprint from the given cert
	 *
	 * @param certStr
	 * @return
	 */
	public static String getCertificateFingerprint(String certStr)
	{
		MessageDigest md = null;
		try
		{
			CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
			X509Certificate cert = (X509Certificate) certificateFactory.generateCertificate(IOUtils.toInputStream(certStr, "UTF-8"));//No I18N

			md = MessageDigest.getInstance("SHA1");
			String fingerprint = DatatypeConverter.printHexBinary(md.digest(cert.getEncoded()));
			fingerprint = fingerprint.replaceAll("(.{2})", "$1 ").trim();
			return fingerprint;
		}
		catch (NoSuchAlgorithmException ex)
		{
			LOGGER.log(Level.SEVERE, null, ex);
		}
		catch (CertificateException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (IOException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		return null;
	}

	public static void addOrUpdateSAMLAppFromMetadata(HttpServletRequest request, String appId, String appName, String description, String relayState, String metadata, byte[] logo) throws IAMException, JSONException
	{
		JSONObject json = SamlMetaDataUtil.parseSPMetadataFile(metadata);
		if (json == null)
		{
			throw new IdmpodException(ErrorCode.GENERIC_METADATA_UPLOAD_FAILED);
		}
		String zaid = IdmpodIAMUtil.getZAID();
		if (appId != null && !"".equals(appId))
		{
			updateSAMLApp(zaid, appId, json.getString("issuer"), json.getString("acs_url"), json.has("login_url") ? json.getString("login_url") : null, appName, relayState, description, (json.has("public_key")) ? json.getString("public_key") : null, json.getString("nameid"), (json.has("logout_url")) ? true : false, (json.has("logout_url")) ? json.getString("logout_url") : null, logo, (json.has("attributes")) ? json.getJSONArray("attributes").toString() : null); // NO I18N
		}
		else
		{
			addSAMLApp(zaid, json.getString("issuer"), json.getString("acs_url"), json.has("login_url") ? json.getString("login_url") : null, appName, relayState, description, (json.has("public_key")) ? json.getString("public_key") : null, json.getString("nameid"), (json.has("logout_url")) ? true : false, (json.has("logout_url")) ? json.getString("logout_url") : null, logo, (json.has("attributes")) ? json.getJSONArray("attributes").toString() : null); // NO I18N
		}
	}

	public static final int SSO_SUPPORT_FLAG = 1, PWD_SYNC_SUPPORT_FLAG = 2;
	public static final int BOTH_SSO_SYNC = SSO_SUPPORT_FLAG + PWD_SYNC_SUPPORT_FLAG;

	public static JSONArray getSamlAppTemplates()
	{
		final String TYPE = JsonApiHandler.ResourceType.SAML_APP_TEMPLATE.getResType();
		JSONArray appTemplates = new JSONArray();
		try
		{
			ArrayList tablesList = new ArrayList();
			tablesList.add(ADSIAMAPPLICATIONS.TABLE);
			tablesList.add(ADSIAMAPPLICATIONSPROPS.TABLE);

			boolean[] isLeftJoins = new boolean[tablesList.size()];
			Arrays.fill(isLeftJoins, true);

			Criteria crit = new Criteria(Column.getColumn(ADSIAMAPPLICATIONSPROPS.TABLE, ADSIAMAPPLICATIONSPROPS.SUPPORTED_OPERATIONS_BIT), SSO_SUPPORT_FLAG, QueryConstants.EQUAL);
			crit = crit.or(new Criteria(Column.getColumn(ADSIAMAPPLICATIONSPROPS.TABLE, ADSIAMAPPLICATIONSPROPS.SUPPORTED_OPERATIONS_BIT), BOTH_SSO_SYNC, QueryConstants.EQUAL));

			SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, crit);

			DataObject appTemplateDO = DBUtils.getOrgPersistence().get(query);
			if (!appTemplateDO.isEmpty())
			{
				if (appTemplateDO.containsTable(ADSIAMAPPLICATIONS.TABLE))
				{
					for (Iterator<Row> it = appTemplateDO.getRows(ADSIAMAPPLICATIONS.TABLE); it.hasNext(); )
					{
						Row r = it.next();
						JSONObject appTemplateAttrs = DBUtils.rowToJson(r);
						if (appTemplateDO.containsTable(ADSIAMAPPLICATIONSPROPS.TABLE))
						{
							Row propsRow = appTemplateDO.getRow(ADSIAMAPPLICATIONSPROPS.TABLE, new Criteria(Column.getColumn(ADSIAMAPPLICATIONSPROPS.TABLE, ADSIAMAPPLICATIONSPROPS.APP_ID), r.get(ADSIAMAPPLICATIONSPROPS.APP_ID), QueryConstants.EQUAL));
							if (propsRow != null)
							{
								DBUtils.rowToJson(propsRow, appTemplateAttrs);
							}
						}
						JSONObject appTemplate = new JSONObject();
						appTemplate.put(JsonApiConstants.ID, appTemplateAttrs.get(ADSIAMAPPLICATIONS.APP_ID));
						appTemplate.put(JsonApiConstants.TYPE, TYPE);
						appTemplate.put(JsonApiConstants.ATTRIBUTES, appTemplateAttrs);
						appTemplates.put(appTemplate);
					}
				}
			}

		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return appTemplates;
	}

	public static JSONObject addTemplateApp(JSONObject request, JSONObject resp)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		JSONObject template = data.getJSONObject(JsonApiConstants.RELATIONSHIPS).getJSONObject("template");//No I18N

		Long templateid = template.getJSONObject(JsonApiConstants.DATA).getLong(JsonApiConstants.ID);

		template = getSamlAppTemplate(templateid);

		JSONObject templateAttrs = template.getJSONObject(JsonApiConstants.ATTRIBUTES);

		String app_name = attributes.optString("APP_NAME"); // NO I18N
		String login_url = templateAttrs.optString(ADSIAMAPPLICATIONSPROPS.DEFAULT_LOGIN_URL);
		String acs_url = templateAttrs.optString(ADSIAMAPPLICATIONSPROPS.DEFAULT_ACS_URL, login_url);
		String logout_url = templateAttrs.optString(ADSIAMAPPLICATIONSPROPS.DEFAULT_LOGOUT_URL, null);
		String entityid = templateAttrs.optString(ADSIAMAPPLICATIONSPROPS.DEFAULT_ENTITY_ID);
		String relayState = null;
		String description = attributes.optString("DESCRIPTION", null);//No I18N
		String publicKey = null;

		byte[] bytes = null;
		try
		{
			bytes = imageToByte(templateAttrs.optString(ADSIAMAPPLICATIONS.APP_NAME));
		}
		catch (IOException ex)
		{
			LOGGER.log(Level.SEVERE, "Error in Image to Byte Conversion", ex);
		}

		String hostId = attributes.optString("HOST_IDENTIFIER", null);//No I18N
		String domainId = attributes.optString("DOMAIN_IDENTIFIER", null);//No I18N
		String customId = attributes.optString("CUSTOM_IDENTIFIER", null);//No I18N

		if (hostId != null)
		{
			login_url = login_url.replace("%HOST_IDENTIFIER%", hostId);//No I18N
			acs_url = acs_url.replace("%HOST_IDENTIFIER%", hostId);//No I18N
			entityid = entityid.replace("%HOST_IDENTIFIER%", hostId);//No I18N
			logout_url = (logout_url != null && !"".equals(logout_url)) ? logout_url.replace("%HOST_IDENTIFIER%", hostId) : null;
		}

		if (domainId != null)
		{
			login_url = login_url.replace("%DOMAIN_IDENTIFIER%", domainId);//No I18N
			acs_url = acs_url.replace("%DOMAIN_IDENTIFIER%", domainId);//No I18N
			entityid = entityid.replace("%DOMAIN_IDENTIFIER%", domainId);//No I18N
			logout_url = (logout_url != null && !"".equals(logout_url)) ? logout_url.replace("%DOMAIN_IDENTIFIER%", domainId) : null;
		}
		if (customId != null)
		{
			login_url = login_url.replace("%CUSTOM_IDENTIFIER%", customId);//No I18N
			acs_url = acs_url.replace("%CUSTOM_IDENTIFIER%", customId);//No I18N
			entityid = entityid.replace("%CUSTOM_IDENTIFIER%", customId);//No I18N
			logout_url = (logout_url != null && !"".equals(logout_url)) ? logout_url.replace("%CUSTOM_IDENTIFIER%", customId) : null;
		}

		JSONArray errors = resp.has(JsonApiConstants.ERRORS) ? resp.getJSONArray(JsonApiConstants.ERRORS) : new JSONArray();

		if (errors != null && errors.length() > 0)
		{
			resp.put(JsonApiConstants.ERRORS, errors);
		}
		else
		{
			String zaid = IdmpodIAMUtil.getZAID();
			Long appId = addSAMLApp(zaid, entityid, acs_url, login_url, app_name, relayState, description, publicKey, NameId.NAMEID_EMAIL_ADDRESS.toString(), (logout_url != null) ? true : false, logout_url, bytes, null);
			resp.getJSONObject(JsonApiConstants.DATA).put(JsonApiConstants.ID, appId);
		}


		return resp;
	}

	public static JSONObject addSamlAppFromMetadata(JSONObject request, JSONObject resp)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		JSONObject template = data.getJSONObject(JsonApiConstants.RELATIONSHIPS).getJSONObject("template");//No I18N

		Long templateid = template.getJSONObject(JsonApiConstants.DATA).getLong(JsonApiConstants.ID);

		template = getSamlAppTemplate(templateid);

		JSONObject templateAttrs = template.getJSONObject(JsonApiConstants.ATTRIBUTES);

		String app_name = attributes.optString("APP_NAME"); // NO I18N
		String login_url = attributes.optString("LOGIN_URL", null); // NO I18N
		String acs_url = attributes.optString("ACS_URL", login_url); // NO I18N
		String logout_url = attributes.optString("LOGOUT_URL", null); // NO I18N
		String entityid = attributes.optString("ENTITYID", null); // NO I18N
		String description = attributes.optString("DESCRIPTION", null);//No I18N
		String publicKey = attributes.optString("CERTIFICATE", null); // NO I18N
		String relayState = null;

		byte[] bytes = null;
		try
		{
			bytes = imageToByte(templateAttrs.optString(ADSIAMAPPLICATIONS.APP_NAME));
		}
		catch (IOException ex)
		{
			LOGGER.log(Level.SEVERE, "Error in Image to Byte Conversion", ex);
		}

		JSONArray errors = resp.has(JsonApiConstants.ERRORS) ? resp.getJSONArray(JsonApiConstants.ERRORS) : new JSONArray();

		if (errors != null && errors.length() > 0)
		{
			resp.put(JsonApiConstants.ERRORS, errors);
		}
		else
		{
			String zaid = IdmpodIAMUtil.getZAID();
			Long appId = addSAMLApp(zaid, entityid, acs_url, login_url, app_name, relayState, description, publicKey, NameId.NAMEID_EMAIL_ADDRESS.toString(), (logout_url != null) ? true : false, logout_url, bytes, null);
			resp.getJSONObject(JsonApiConstants.DATA).put(JsonApiConstants.ID, appId);
		}

		return resp;
	}

	public static byte[] imageToByte(String iconName) throws IOException
	{
		byte[] bytes = null;
		String encodedImage = null;
		FileInputStream fileInputStreamReader = null;
		String APP_DIR = Configuration.getString("app.home");
		File imageFile = new File(APP_DIR + "/../adminPortalAssets/images/appicons/" + iconName + ".png");
		try
		{
			fileInputStreamReader = new FileInputStream(imageFile);
			bytes = new byte[(int) imageFile.length()];
			fileInputStreamReader.read(bytes);
			encodedImage = Base64.encodeBase64(bytes).toString();
		}
		finally
		{
			fileInputStreamReader.close();
		}
		return bytes;
	}

	public static void disableSAMLApp(HttpServletRequest request, String appId, String zaid) throws JSONException
	{
		try
		{
			boolean status = getOrgApi().updateSamlAppStatus(zaid, appId, false);
			if (status)
			{
				return;
				//AuditUtil.auditOtherOperations(VaultUtil.getUserId(), null, AuditUtil.OP_SAML_APP_DISABLED, null, appName, VaultUtil.getCurrentTimeMillis(), request.getRemoteAddr());
			}
			else
			{
				throw new IdmpodException(ErrorCode.GENERIC_ERR_DISABLING_APP);
			}
		}
		catch (IAMException ex)
		{
			LOGGER.log(Level.SEVERE, "Error in disabling app", ex);
			throw new IdmpodException(ErrorCode.GENERIC_ERR_DISABLING_APP);
		}
	}

	public static void enableSAMLApp(HttpServletRequest request, String appId, String zaid) throws JSONException
	{
		try
		{
			boolean status = getOrgApi().updateSamlAppStatus(zaid, appId, true);
			if (status)
			{
				return;
				//AuditUtil.auditOtherOperations(VaultUtil.getUserId(), null, AuditUtil.OP_SAML_APP_ENABLED, null, appName, VaultUtil.getCurrentTimeMillis(), request.getRemoteAddr());
			}
			else
			{
				throw new IdmpodException(ErrorCode.GENERIC_ERR_ENABLING_APP);
			}
		}
		catch (IAMException ex)
		{
			LOGGER.log(Level.SEVERE, "Error in enabling app", ex);
			throw new IdmpodException(ErrorCode.GENERIC_ERR_ENABLING_APP);
		}
	}

	private static byte[] getAppLogo(String app_id, String zoid)
	{
		Object[] args = new Object[]{Long.valueOf(app_id), PhotoAPI.NORMAL, Long.valueOf(zoid)};
		byte[] data = "".getBytes();
		try
		{
			data = IAMProxy.getInstance().downloadPhoto(args, PhotoAPI.SAMLORG);
		}
		catch (IAMException ex)
		{
			LOGGER.log(Level.SEVERE, "Exception while downloading logo for app" + app_id + " " + zoid, ex);
		}
		return data;
	}

	public static JSONArray getSAMLAppAttributes(String zaid, String appId) throws IAMException
	{
		List<SAMLApp.SAMLAttribute> attributes = getOrgApi().getSAMLAttributes(zaid, appId);
		JSONArray ary = new JSONArray();
		if (attributes != null && !attributes.isEmpty())
		{
			for (SAMLApp.SAMLAttribute attr : attributes)
			{
				JSONObject obj = new JSONObject();
				obj.put("name", attr.getAttributeName());
				obj.put("value", attr.getAttributeValue());
				ary.put(obj);
			}
		}
		return ary;
	}

	private static void addOrUpdateSAMLAppAttributes(String zaid, String appId, JSONArray jsonAry) throws IAMException
	{
		List<SAMLApp.SAMLAttribute> attributes = getOrgApi().getSAMLAttributes(zaid, appId);
		if (attributes != null)
		{
			for (int i = 0; i < attributes.size(); i++)
			{
				SAMLApp.SAMLAttribute attr = attributes.get(i);
				boolean status = getOrgApi().deleteSAMLAppAttribute(zaid, appId, attr.getAttributeName());
				//LOGGER.log(Level.INFO, "Deleting attribute"+ attr.getAttributeName() +" for " + appId + " " + status);
			}
		}
		for (int i = 0; i < jsonAry.length(); i++)
		{
			JSONObject attrObj = jsonAry.getJSONObject(i);
			String attrName = attrObj.getString("name"); // NO I18N
			String attrValue = SamlMetaDataUtil.NameIDType.getNameIdType(attrObj.getInt("value")).getNameId();// NO I18N
			getOrgApi().updateSAMLAppAttribute(zaid, appId, attrName, "", attrValue);
		}
	}

	//TODO:Error Array Handling
	//	public static JSONObject disableSAMLApps(HttpServletRequest request, String zaid, String[] appIds)
	//	{
	//		JSONObject opResults = VaultUtil.getOpStatusFailedMsg(I18N.getI18nMsg("vault.action.saml.error_disabling_app"));
	//		try
	//		{
	//			for (String appId : appIds)
	//			{
	//				boolean status = getOrgApi().updateSamlAppStatus(zaid, appId, false);
	//				if (status)
	//				{
	//					String appName = getOrgApi().getSamlApp(zaid, appId).getAppName();
	//					//AuditUtil.auditOtherOperations(VaultUtil.getUserId(), null, AuditUtil.OP_SAML_APP_DISABLED, null, appName, VaultUtil.getCurrentTimeMillis(), request.getRemoteAddr());
	//					opResults = VaultUtil.getOpStatusSuccessMsg(I18N.getI18nMsg("vault.action.success.disabled_saml_apps"));
	//				}
	//			}
	//		}
	//		catch (IAMException ex)
	//		{
	//			LOGGER.log(Level.SEVERE, "Error in disabling app", ex);
	//			opResults = VaultUtil.getOpStatusFailedMsg(I18N.getI18nMsg("vault.action.saml.error_disabling_app"));
	//		}
	//		return opResults;
	//	}

	//TODO:Error Array Handling
	//	public static JSONObject enableSAMLApps(HttpServletRequest request, String zaid, String[] appIds)
	//	{
	//		JSONObject opResults = VaultUtil.getOpStatusFailedMsg(I18N.getI18nMsg("vault.action.saml.error_enabling_app"));
	//		try
	//		{
	//			for (String appId : appIds)
	//			{
	//				boolean status = getOrgApi().updateSamlAppStatus(zaid, appId, true);
	//				if (status)
	//				{
	//					String appName = getOrgApi().getSamlApp(zaid, appId).getAppName();
	//					//AuditUtil.auditOtherOperations(VaultUtil.getUserId(), null, AuditUtil.OP_SAML_APP_ENABLED, null, appName, VaultUtil.getCurrentTimeMillis(), request.getRemoteAddr());
	//					opResults = VaultUtil.getOpStatusSuccessMsg(I18N.getI18nMsg("vault.action.success.enabled_saml_apps"));
	//				}
	//			}
	//		}
	//		catch (IAMException ex)
	//		{
	//			LOGGER.log(Level.SEVERE, "Error in enabling app", ex);
	//			opResults = VaultUtil.getOpStatusFailedMsg(I18N.getI18nMsg("vault.action.saml.error_enabling_app"));
	//		}
	//		return opResults;
	//	}

	//TODO:Error Array Handling
	//	public static JSONObject deleteSAMLApps(HttpServletRequest request, String zaid, String[] appIds)
	//	{
	//		JSONObject opResult = VaultUtil.getOpStatusFailedMsg(I18N.getI18nMsg("vault.action.error.error_deleting_saml_apps"));
	//		try
	//		{
	//			for (String appId : appIds)
	//			{
	//				String appName = getOrgApi().getSamlApp(zaid, appId).getAppName();
	//				if (getOrgApi().deleteSamlApp(zaid, appId))
	//				{
	//					//AuditUtil.auditOtherOperations(VaultUtil.getUserId(), null, AuditUtil.OP_SAML_APP_DELETED, null, appName, VaultUtil.getCurrentTimeMillis(), request.getRemoteAddr());
	//					opResult = VaultUtil.getOpStatusSuccessMsg(I18N.getI18nMsg("vault.action.success.deleted_saml_apps"));
	//				}
	//			}
	//		}
	//		catch (IAMException ex)
	//		{
	//			LOGGER.log(Level.SEVERE, "Error in deleting app", ex);
	//			opResult = VaultUtil.getOpStatusFailedMsg(I18N.getI18nMsg("vault.action.error.error_deleting_saml_apps"));
	//		}
	//		return opResult;
	//	}

	public static String[] assignSamlappsToUser(Long userId, JSONArray saml_applications) throws Exception
	{
		String[] remarks = new String[2];
		String[] appids = saml_applications.toList().toArray(new String[0]);
		Row internalUserRow = UserUtils.getInternalUserRow(userId);
		Long zuid = (Long) internalUserRow.get(IDMPODTECHNICIAN.ZUID);
		remarks[0] = "";
		remarks[1] = IAMProxy.getInstance().getUserAPI().getUser(zuid).getDisplayName();
		List<SAMLApp> userSamlApps = getUserSamlApps(zuid);
		Long zaid = Long.parseLong(IdmpodIAMUtil.getZAID());

		StringBuilder remSb = new StringBuilder();
		for (int i = 0; i < appids.length; i++)
		{
			String appid = appids[i];
			String name = getOrgApi().getSamlApp(IdmpodIAMUtil.getZAID(), appid).getAppName();
			remSb.append(name);
			if (i == appids.length - 2)
			{
				remSb.append(I18N.getMsg("idmpod.common.conj.and"));
			}
			else if (i < appids.length - 1)
			{
				remSb.append(", ");
			}
		}
		remarks[0] = remSb.toString();

		for (String appid : appids)
		{
			if (userSamlApps != null && userSamlApps.stream().anyMatch(userSamlApp -> userSamlApp.getAppId().equalsIgnoreCase(appid)))
			{
				updateUserstoSAMLApp(zaid, appid, new String[]{zuid.toString()}, true);
			}
			else
			{
				List<SAMLUser> users = null;
				try
				{
					users = getOrgApi().getSamlUsers(zaid.toString(), appid.toString());
				}
				catch (IAMException ex)
				{
					LOGGER.log(Level.SEVERE, "No users added yet", ex); // NO I18N
				}
				boolean isOldAppUser = false;
				if (users != null)
				{
					for (SAMLUser user : users)
					{
						if (user.getZid().equals(zuid.toString()))
						{
							isOldAppUser = true;
							break;
						}
					}
				}
				if (isOldAppUser)
				{
					updateUserstoSAMLApp(zaid, appid, new String[]{zuid.toString()}, true);
				}
				else
				{
					getOrgApi().addUserstoSamlApp(zaid, appid, new String[]{zuid.toString()});
					updateUserstoSAMLApp(zaid, appid, new String[]{zuid.toString()}, true);
				}
			}
		}
		return remarks;
	}

	public static String[] assignUsersToSAMLApp(Long appId, JSONArray userIds) throws Exception
	{
		String[] remarks = new String[2];
		List<String> userids = userIds.toList().stream().map(Object::toString).collect(Collectors.toList());
		List<String> zuidsList = new ArrayList<String>();
		String[] zuids = null;
		try
		{
			Criteria cr = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.USER_ID), userids.toArray(new String[userids.size()]), QueryConstants.IN);
			DataObject usersDO = DBUtils.getOrgPersistence().get(IDMPODTECHNICIAN.TABLE, cr);
			Iterator<Row> users = usersDO.getRows(IDMPODTECHNICIAN.TABLE);
			while (users.hasNext())
			{
				Row user = users.next();
				zuidsList.add(user.get(IDMPODTECHNICIAN.ZUID).toString());
			}
			zuids = zuidsList.toArray(new String[0]);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		List<SAMLUser> users = null;
		Long zaid = Long.parseLong(IdmpodIAMUtil.getZAID());
		remarks[0] = "";
		remarks[1] = getOrgApi().getSamlApp(IdmpodIAMUtil.getZAID(), appId.toString()).getAppName();

		AccountsProto.Account.User[] accountUsers = AppAccountUtils.getAccountUsers(new com.zoho.resource.Criteria(Accounts.RESOURCE.USER.ZUID, com.zoho.resource.Criteria.Comparator.IN, String.join(",", zuids)));
		StringBuilder remSb = new StringBuilder();
		if (accountUsers != null)
		{
			for (int i = 0; i < accountUsers.length; i++)
			{
				AccountsProto.Account.User user = accountUsers[i];
				String name = user.getDisplayName();
				remSb.append(name);
				if (i == accountUsers.length - 2)
				{
					remSb.append(I18N.getMsg("idmpod.common.conj.and"));
				}
				else if (i < accountUsers.length - 1)
				{
					remSb.append(", ");
				}
			}
		}
		remarks[0] = remSb.toString();

		try
		{
			users = getOrgApi().getSamlUsers(IdmpodIAMUtil.getZAID(), appId.toString());
		}
		catch (IAMException ex)
		{
			LOGGER.log(Level.SEVERE, "No users added yet", ex);
		}
		if (users == null)
		{
			getOrgApi().addUserstoSamlApp(zaid, appId.toString(), zuids);
			updateUserstoSAMLApp(zaid, appId.toString(), zuids, true);
		}
		else
		{
			java.util.Set<String> set = new java.util.HashSet<>();
			for (SAMLUser user : users)
			{
				set.add(user.getZid()); // This will contain all users added to app
			}
			List<String> toAdd = new java.util.ArrayList<>();
			if (zuids != null)
			{
				for (String zid : zuids)
				{
					if (!set.contains(zid))
					{
						toAdd.add(zid);
					}
				}
			}
			if (!toAdd.isEmpty())
			{
				getOrgApi().addUserstoSamlApp(zaid, appId.toString(), toAdd.toArray(new String[toAdd.size()]));
			}
			updateUserstoSAMLApp(zaid, appId.toString(), zuids, true);
		}

		return remarks;
	}

	public static boolean assignUsersToSAMLApp(HttpServletRequest request, Long userId, Long zaid, String appId, String appName, String[] zuid) throws IAMException
	{
		List<SAMLUser> users = null;
		try
		{
			users = getOrgApi().getSamlUsers(zaid.toString(), appId);
		}
		catch (IAMException ex)
		{
			LOGGER.log(Level.SEVERE, "No users added yet", ex);
		}
		if (users == null)
		{
			getOrgApi().addUserstoSamlApp(zaid, appId, zuid);
			updateUserstoSAMLApp(zaid, appId, zuid, true);
			auditUsersAddedOrRemovedOperation(request, userId, appName, new java.util.ArrayList<SAMLUser>(), zuid);
			return true;
		}
		java.util.Set<String> set = new java.util.HashSet<>();
		for (SAMLUser user : users)
		{
			set.add(user.getZid()); // This will contain all users added to app
		}
		List<String> toAdd = new java.util.ArrayList<>();
		if (zuid != null)
		{
			for (String zid : zuid)
			{
				if (!set.contains(zid))
				{
					toAdd.add(zid);
				}
			}
		}
		if (!toAdd.isEmpty())
		{
			getOrgApi().addUserstoSamlApp(zaid, appId, toAdd.toArray(new String[toAdd.size()]));
		}
		updateUserstoSAMLApp(zaid, appId, zuid, true);
		java.util.Set<String> added = new java.util.HashSet<>();
		Collections.addAll(added, zuid);
		auditUsersAddedOperation(request, userId, appName, added);
		return true;
	}

	public static String[] removeUsersFromSAMLApp(Long appId, JSONArray userIds) throws Exception
	{
		String[] remarks = new String[2];
		remarks[0] = "";
		remarks[1] = getOrgApi().getSamlApp(IdmpodIAMUtil.getZAID(), appId.toString()).getAppName();
		String[] zuids = userIds.toList().stream().map(Object::toString).collect(Collectors.toList()).toArray(new String[0]);

		AccountsProto.Account.User[] accountUsers = AppAccountUtils.getAccountUsers(new com.zoho.resource.Criteria(Accounts.RESOURCE.USER.ZUID, com.zoho.resource.Criteria.Comparator.IN, String.join(",", zuids)));
		StringBuilder remSb = new StringBuilder();
		if (accountUsers != null)
		{
			for (int i = 0; i < accountUsers.length; i++)
			{
				AccountsProto.Account.User user = accountUsers[i];
				String name = user.getDisplayName();
				remSb.append(name);
				if (i == accountUsers.length - 2)
				{
					remSb.append(I18N.getMsg("idmpod.common.conj.and"));
				}
				else if (i < accountUsers.length - 1)
				{
					remSb.append(", ");
				}
			}
		}
		remarks[0] = remSb.toString();

		List<SAMLUser> users = null;
		Long zaid = Long.parseLong(IdmpodIAMUtil.getZAID());
		boolean status = updateUserstoSAMLApp(zaid, appId.toString(), zuids, false);

		// LOGGER.log(Level.FINE, "removing user from appid " + appId.toString() + " zuid " + zuids.toString() + " zaid " + zaid + "Status " + status);
		return remarks;
	}


	public static boolean removeUsersFromSAMLApp(HttpServletRequest request, Long userId, Long zaid, String appId, String appName, String[] zuid) throws IAMException
	{
		List<SAMLUser> users = null;
		try
		{
			users = getOrgApi().getSamlUsers(zaid.toString(), appId);
		}
		catch (IAMException ex)
		{
			LOGGER.log(Level.SEVERE, "No users added yet", ex);
		}
		if (users == null || zuid == null)
		{
			return true;
		}
		java.util.Set<String> allUsers = new java.util.HashSet<>();
		for (SAMLUser user : users)
		{
			allUsers.add(user.getZid());
		}
		java.util.Set<String> removed = new java.util.HashSet<>();
		for (String zid : zuid)
		{
			if (allUsers.contains(zid))
			{
				removed.add(zid); // This will contain all users added to app
			}
		}
		updateUserstoSAMLApp(zaid, appId, removed.toArray(new String[removed.size()]), false);
		auditUsersRemovedOperation(request, userId, appName, removed);
		return true;
	}

	public static boolean isAutoProvisionAllowed(Long zoid) throws IAMException
	{
		boolean isJITprov = false;
		OrgAPI orgApi = IAMProxy.getInstance().getOrgAPI();
		OrgPolicy policy = orgApi.getOrgPolicy(zoid);
		if (policy != null)
		{
			isJITprov = policy.isAutoProvisionAllowed();
		}
		return isJITprov;
	}

	public static JSONArray getSamlAppCategories()
	{
		final String TYPE = JsonApiHandler.ResourceType.SAML_APP_CATEGORY.getResType();
		JSONArray appCategories = new JSONArray();
		try
		{
			ArrayList<String> tablesList = new ArrayList<String>();
			tablesList.add(ADSIAMAPPLICATIONSCATEGORY.TABLE);
			tablesList.add(ADSIAMAPPLICATIONS.TABLE);

			boolean[] isLeftJoins = new boolean[tablesList.size()];
			Arrays.fill(isLeftJoins, false);

			SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, (Criteria) null);

			DataObject appCategoryDO = DBUtils.getOrgPersistence().get(query);
			if (!appCategoryDO.isEmpty())
			{
				if (appCategoryDO.containsTable(ADSIAMAPPLICATIONSCATEGORY.TABLE))
				{
					for (Iterator<Row> it = appCategoryDO.getRows(ADSIAMAPPLICATIONSCATEGORY.TABLE); it.hasNext(); )
					{
						Row r = it.next();
						JSONObject appCategoryAttrs = DBUtils.rowToJson(r);
						JSONObject appCategory = new JSONObject();
						appCategory.put(JsonApiConstants.ID, appCategoryAttrs.get(ADSIAMAPPLICATIONSCATEGORY.CATEGORY_ID));
						appCategory.put(JsonApiConstants.TYPE, TYPE);
						appCategory.put(JsonApiConstants.ATTRIBUTES, appCategoryAttrs);

						JSONArray templateRels = null;

						Iterator<Row> templates = appCategoryDO.getRows(ADSIAMAPPLICATIONS.TABLE, new Criteria(Column.getColumn(ADSIAMAPPLICATIONS.TABLE, ADSIAMAPPLICATIONS.CATEGORY_ID), appCategoryAttrs.get(ADSIAMAPPLICATIONSCATEGORY.CATEGORY_ID), QueryConstants.EQUAL));

						while (templates.hasNext())
						{
							Row template = templates.next();
							if (templateRels == null)
							{
								templateRels = new JSONArray();
							}
							templateRels.put(JsonApiHandler.getResourceIdentifierObject("saml-app-template", template.get(ADSIAMAPPLICATIONS.APP_ID).toString()));
						}

						if (templateRels != null)
						{
							JSONObject rel = new JSONObject();
							rel.put("templates", JsonApiHandler.getResourceObject(templateRels));
							appCategory.put(JsonApiConstants.RELATIONSHIPS, rel);
						}
						appCategories.put(appCategory);
					}
				}
			}

		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return appCategories;
	}

}
