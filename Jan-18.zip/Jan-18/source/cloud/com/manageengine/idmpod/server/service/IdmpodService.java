package com.manageengine.idmpod.server.service;

import com.adventnet.iam.security.SecurityUtil;
import com.adventnet.mfw.service.Service;
import com.adventnet.persistence.DataObject;
import com.adventnet.taskengine.inmemory.TaskExecutor;
import com.manageengine.idmpod.server.utils.IdmpodUtils;
import com.manageengine.idmpod.server.utils.ScheduleUtil;
import com.zoho.ear.dbencryptagent.DBEncryptAgent;
import com.zoho.sas.container.AppResources;

import java.util.concurrent.ThreadPoolExecutor;
import java.util.logging.Level;
import java.util.logging.Logger;

public class IdmpodService implements Service
{
	private static final Logger LOGGER = Logger.getLogger(IdmpodService.class.getName());

	@Override
	public void create(DataObject dataObject) throws Exception
	{

	}

	@Override
	public void start() throws Exception
	{
		LOGGER.log(Level.WARNING, "Starting Idmpod Service");

		initEAR();

		initTaskExecutor();

		LOGGER.log(Level.WARNING, "Idmpod Service successfully started");
	}

	private void initTaskExecutor() throws Exception
	{
		TaskExecutor.newExecutor(ScheduleUtil.getInMemoryTaskExecutorName(), ScheduleUtil.getImteThreadPoolSize(), ScheduleUtil.getImteQueueSize(), new ThreadPoolExecutor.AbortPolicy());
	}

	private void initEAR() throws Exception
	{
		String SECURITY_CONTEXT = AppResources.getProperty("server.dir");

		String[] SECURITY_FILES = new String[]{SECURITY_CONTEXT + "/security-properties.xml", SECURITY_CONTEXT + "/conf/security-privatekey.xml"};//No I18N

		SecurityUtil.initSecurityConfiguration(SECURITY_FILES);

		String refreshToken = IdmpodUtils.getEAROAuthToken();
		DBEncryptAgent.setEARRefreshToken(refreshToken);
		DBEncryptAgent.setEAROrgIdInterface("com.manageengine.idmpod.server.ear.IdmpodEAROrgIdImpl");    //NO I18N
	}

	@Override
	public void stop() throws Exception
	{
		LOGGER.log(Level.WARNING, "Stopping Idmpod Service");
	}

	@Override
	public void destroy() throws Exception
	{

	}
}
