package com.manageengine.idmpod.server.utils;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.*;
import com.adventnet.persistence.*;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.error.ErrorCode;
import com.manageengine.idmpod.server.error.IdmpodException;
import com.manageengine.idmpod.server.iam.AppAccountUtils;
import com.manageengine.idmpod.server.iam.IdmpodIAMUtil;
import com.manageengine.idmpod.server.iam.InviteUtils;
import com.manageengine.idmpod.server.iam.UserUtils;
import com.manageengine.idmpod.server.zstore.LicenseUtil;
import com.manageengine.tables.idmpod.ORGPREFERENCES;
import com.zoho.accounts.AccountsProto;
import com.zoho.conf.Configuration;
import org.json.JSONObject;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class IdmpodUtils
{

	private static final Logger LOGGER = Logger.getLogger(IdmpodUtils.class.getName());

	private static final Logger JSP_LOGGER = Logger.getLogger("JSP_LOGGER");

	public static final String APP_DIR = Configuration.getString("app.home");

	private static final String CONFIG_KEY_LOGSDEPSERVER_HOST = "com.zoho.idmpod.logsdepserver.host";//No I18N
	public static final String CONFIG_KEY_LOGSAPISERVER_HOST = "com.zoho.idmpod.logsapiserver.host";//No I18N
	public static final String CONFIG_KEY_OAUTH_CLIENTID = "com.zoho.idmpod.oauth.clientId";//No I18N
	public static final String CONFIG_KEY_OAUTH_SECRET = "com.zoho.idmpod.oauth.secret";//No I18N
	public static final String CONFIG_KEY_ZOHOLOGS_PARAM_TYPE = "com.zoho.logs.params.type";//No I18N
	public static final String CONFIG_KEY_EAR_REFRESH_TOKEN = "com.zoho.idmpod.earRefreshToken";//No I18N

	public static final String CONFIG_KEY_RETENTION_DAYS_MIN = "com.zoho.idmpod.retention.days.min";//No I18N
	public static final String CONFIG_KEY_RETENTION_DAYS_MAX = "com.zoho.idmpod.retention.days.max";//No I18N
	public static final String CONFIG_KEY_RETENTION_DAYS_DEFAULT = "com.zoho.idmpod.retention.days.default";//No I18N

	public static final String CONFIG_KEY_AGENT_BUILD_NUMBERS = "com.zoho.idmpod.agent.build.numbers";//No I18N

	public static final String CONFIG_KEY_PATH_ELA_HELP_ROOT = "com.zoho.idmpod.path.elaHelpRoot";//No I18N
	public static final String CONFIG_KEY_PATH_ME_CLOUD = "com.zoho.idmpod.path.meCloud";//No I18N

	public static final boolean IS_DEVELOPMENT = !Configuration.getBoolean("production");//No I18N

	private static Properties idmpodProps = null;

	static
	{
		String configLocation = APP_DIR + File.separator + "conf" + File.separator + "idmpod.properties";//No I18N
		LOGGER.log(Level.INFO, "loading idmpod configuration from {0}", configLocation);
		Properties prop = new Properties();
		try (FileReader fileReader = new FileReader(configLocation))
		{
			prop.load(fileReader);
			idmpodProps = prop;
		}
		catch (IOException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
	}

	public static String getProperty(String key, String defaultValue)
	{
		return idmpodProps.getProperty(key, defaultValue);
	}

	public static String getProperty(String key)
	{
		return idmpodProps.getProperty(key);
	}

	public static String getServiceUrl()
	{
		return getProperty("serviceurl");
	}

	public static String getProductVersion()
	{
		return getProperty("product.version");
	}

	public static String getProductBuild()
	{
		return getProperty("product.build");
	}

	public static Logger getJspLogger()
	{
		return JSP_LOGGER;
	}

	public static void handleFirstTimeLogin() throws Exception
	{
		//check space is reserved.
		if (!CommonDBUtil.checkSpace())
		{
			//space not reserved yet!
			//check validity to create AppAccount then space.
			if (IdmpodIAMUtil.canUserCreateSpace())
			{
				User user = IAMUtil.getCurrentUser();
				Org org = IdmpodIAMUtil.getOrCreateOrg();
				long zoid = org.getZOID();
				String orgName = org.getOrgName();
				String zaid = user.getZaid();
				String zaaid = IdmpodIAMUtil.getOrCreateZaaid(org);
				CollaborationUtils.reserveSpace(zaaid);//reserve space for appAccount
				CollaborationUtils.associateName(zaaid, zaid);//associate the reserved space for zaid also
				CommonDBUtil.addOrgInCommonDb(zoid, orgName, zaid, zaaid);//Now add the org details in commondb
				IdmpodUtils.setOrgPreference(DBUtils.getAAPersistence(zaaid), "COUNTRY_CODE", user.getCountry());//NO I18N
				IdmpodUtils.setOrgPreference(DBUtils.getAAPersistence(zaaid), "STATUS", "OPEN");//NO I18N

				LicenseUtil.startTrial(zaaid);
			}
			else
			{
				throw new IdmpodException(ErrorCode.DBSPACE_CREATE_LOW_ACCESS);
			}
		}
		//space available. handle user's account.
		IdmpodIAMUtil.handleFirstTimeUserAccount();
	}

	public static Throwable getRootCause(Throwable e)
	{
		if (e.getCause() == null)
		{
			return e;
		}
		else
		{
			return getRootCause(e.getCause());
		}
	}

	public static JSONObject getDebugInfo(User user)
	{
		JSONObject resp = new JSONObject();

		resp.put("USER_DISPLAY_NAME", user.getDisplayName());
		resp.put("VERIFIED_CONTACT_EMAIL", user.getContactEmail());
		resp.put("LOCALE", user.getLocaleInfo());
		resp.put("COUNTRY", user.getCountry());
		resp.put("ORG_ROLE", user.getUserRole());
		resp.put("ZUID", user.getZUID());
		resp.put("ZOID", user.getZOID());
		resp.put("ZAID", user.getZaid());
		resp.put("STATUS", user.getUserStatus());
		String zaaid = CommonDBUtil.getZaaid(user);
		resp.put("HAS_IDMPOD_ACCOUNT", zaaid != null);
		if (zaaid != null)
		{
			resp.put("ZAAID", zaaid);
			try
			{
				Persistence persistence = DBUtils.getAAPersistence(zaaid);
				resp.put("IS_USER_ACTIVE", UserUtils.isUserActive(persistence, user));
				resp.put("IS_INVITED_USER", InviteUtils.isUserInvited(persistence, user));
				resp.put("ACCOUNT_ROLE", UserUtils.getUserRole(persistence, user.getZUID()));
			}
			catch (Exception e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}

			AccountsProto.Account.AppAccount idmpodAppAccount = AppAccountUtils.getIdmpodAppAccount(Long.parseLong(zaaid));
			if (idmpodAppAccount != null)
			{
				resp.put("ACCOUNT_STATUS", idmpodAppAccount.getAccountStatus());
				resp.put("ACCOUNT_CREATION_TIME", idmpodAppAccount.getCreatedTime());
				String aa_zuid = idmpodAppAccount.getZuid();
				try
				{
					User aa_user = IAMProxy.getInstance().getUserAPI().getUser(Long.parseLong(aa_zuid));
					resp.put("ACCOUNT_CONTACT_USER", aa_user.getDisplayName());
					resp.put("ACCOUNT_CONTACT_MAIL", aa_user.getContactEmail());
				}
				catch (IAMException e)
				{
					LOGGER.log(Level.SEVERE, e.getMessage(), e);
				}
				resp.put("SCREEN_NAME", idmpodAppAccount.getScreenName());
			}
		}

		return resp;
	}

	public static String getOrgPreference(ReadOnlyPersistence persistence, String key) throws DataAccessException
	{
		DataObject dobj = persistence.get(ORGPREFERENCES.TABLE, new Criteria(Column.getColumn(ORGPREFERENCES.TABLE, ORGPREFERENCES.KEY), key, QueryConstants.EQUAL, false));
		if (dobj.containsTable(ORGPREFERENCES.TABLE))
		{
			Row prefRow = dobj.getFirstRow(ORGPREFERENCES.TABLE);
			if (prefRow != null)
			{
				return prefRow.get(ORGPREFERENCES.VALUE).toString();
			}
		}
		return null;
	}

	public static String getOrgPreference(String key)
	{
		try
		{
			return getOrgPreference(DBUtils.getReadOnlyOrgPersistence(),key);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		return null;
	}

	public static void setOrgPreference(Persistence aaPersistence, String key, String value) throws DataAccessException
	{
		DataObject dobj = aaPersistence.get(ORGPREFERENCES.TABLE, new Criteria(Column.getColumn(ORGPREFERENCES.TABLE, ORGPREFERENCES.KEY), key, QueryConstants.EQUAL, false));
		if (dobj.containsTable(ORGPREFERENCES.TABLE))
		{
			Row prefRow = dobj.getFirstRow(ORGPREFERENCES.TABLE);
			if (prefRow != null)
			{
				prefRow.set(ORGPREFERENCES.VALUE, value);
				dobj.updateRow(prefRow);
				aaPersistence.update(dobj);
			}
		}
		else
		{
			Row prefRow = new Row(ORGPREFERENCES.TABLE);
			prefRow.set(ORGPREFERENCES.KEY, key);
			prefRow.set(ORGPREFERENCES.VALUE, value);
			dobj.addRow(prefRow);
			aaPersistence.add(dobj);
		}
	}

	public static String getEAROAuthToken()
	{
		return getProperty("ear.oauthtoken");
	}
}
