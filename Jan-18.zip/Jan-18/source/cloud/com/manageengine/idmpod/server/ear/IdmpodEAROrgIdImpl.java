package com.manageengine.idmpod.server.ear;

import com.manageengine.idmpod.server.utils.IdmpodThreadLocal;
import com.zoho.ear.dbencryptagent.EAROrgIdInterface;

public class IdmpodEAROrgIdImpl implements EAROrgIdInterface
{
	@Override
	public long getOrgId()
	{
		Long orgId = IdmpodThreadLocal.getAppIdLong();
		return orgId;
	}
}
