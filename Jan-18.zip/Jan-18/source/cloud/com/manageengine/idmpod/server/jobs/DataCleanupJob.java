package com.manageengine.idmpod.server.jobs;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.*;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.utils.CollaborationUtils;
import com.manageengine.idmpod.server.utils.CommonDBUtil;
import com.manageengine.idmpod.server.utils.IdmpodUtils;
import com.manageengine.idmpod.server.zstore.LicenseUtil;
import com.manageengine.tables.idmpod.*;
import com.zoho.scheduler.RunnableJob;

import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DataCleanupJob implements RunnableJob
{
	private static final Logger LOGGER = Logger.getLogger(DataCleanupJob.class.getName());

	String[] tables = {IDMPODTECHNICIAN.TABLE, IDMPODDIRECTORIES.TABLE, IDMPODAZUREDATASTORE.TABLE, IDMPODGOOGLEDATASTORE.TABLE, IDMPODSUBSCRIPTIONS.TABLE, IDMPODAPPLICATIONACCESSAUDIT.TABLE, IDMPODGENERALADMINAUDITLOGS.TABLE, IDMPODCLIENTACCESSAUDIT.TABLE};

	private static void dropUVHforTable(String tableName, Persistence persistence) throws DataAccessException
	{
		Criteria uvhDeleteCriteria = new Criteria(Column.getColumn(UVHVALUES.TABLE, UVHVALUES.PATTERN), tableName + ":", QueryConstants.STARTS_WITH);
		DataObject dataObject = persistence.get(UVHVALUES.TABLE, (Criteria) uvhDeleteCriteria);
		dataObject.deleteRows(UVHVALUES.TABLE, (Criteria) null);
		persistence.update(dataObject);
	}

	@Override
	public void run(long l) throws Exception
	{
		LOGGER.log(Level.INFO, "Entering {0}.{1}", new Object[]{"DataCleanupJob", "run"});

		Persistence commonPers = CommonDBUtil.getPersistance();

		DataObject dataObject = commonPers.get(IDMPODORG.TABLE, (Criteria) null);
		if (dataObject.containsTable(IDMPODORG.TABLE))
		{
			Iterator<Row> rows = dataObject.getRows(IDMPODORG.TABLE);
			while (rows.hasNext())
			{
				Row row = rows.next();
				String zaaid = row.get(IDMPODORG.ZAAID).toString();
				if (IdmpodUtils.getOrgPreference(DBUtils.getReadOnlyAAPersistence(zaaid), "STATUS").equalsIgnoreCase("CLOSED"))
				{
					Long accountCloseTime = Long.parseLong(IdmpodUtils.getOrgPreference(DBUtils.getReadOnlyAAPersistence(zaaid), "ACCOUNT_CLOSE_TIME"));//No I18N
					accountCloseTime += LicenseUtil.DAYS_30;
					if (accountCloseTime < System.currentTimeMillis())
					{
						Persistence persistence = DBUtils.getAAPersistence(zaaid);

						//drop table data and UVH values
						for (String table : tables)
						{
							//drop table data
							DataObject dropDO = persistence.get(table, (Criteria) null);
							dropDO.deleteRows(table, (Criteria) null);
							persistence.update(dropDO);
							//drop UVH values
							dropUVHforTable(table, persistence);
						}

						//TODO: Remove all jobs

						CollaborationUtils.unreserveSpace(zaaid);
						dataObject.deleteRow(row);
						commonPers.update(dataObject);
					}
				}
			}

			LOGGER.log(Level.INFO, "Exiting {0}.{1}", new Object[]{"DataCleanupJob", "run"});
		}
	}
}
