package com.manageengine.idmpod.server.iam.directory.jobs;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.iam.IAMProxy;
import com.adventnet.iam.UserAPI;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Persistence;
import com.adventnet.persistence.QueryConstructor;
import com.adventnet.persistence.Row;
import com.google.api.services.admin.directory.Directory;
import com.google.api.services.admin.directory.model.User;
import com.google.api.services.admin.directory.model.Users;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.iam.directory.DirectoryHandler;
import com.manageengine.idmpod.server.iam.directory.gsuite.GSuiteHandler;
import com.manageengine.idmpod.server.utils.CommonDBUtil;
import com.manageengine.idmpod.server.utils.IdmpodThreadLocal;
import com.manageengine.tables.idmpod.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.manageengine.idmpod.server.iam.directory.DirectoryHandler.handleSyncDirectoryUser;

public class GSuiteDirectorySyncJob extends DirectorySyncJob
{
	private static final Logger LOGGER = Logger.getLogger(GSuiteDirectorySyncJob.class.getName());

	public GSuiteDirectorySyncJob()
	{
		super();
	}

	public GSuiteDirectorySyncJob(Long jobId)
	{
		super(jobId);
	}

	@Override
	public void run(long jobId) throws Exception
	{
		LOGGER.log(Level.INFO, "Starting AzureActiveDirectorySyncJob job {0}", jobId); // No I18N
		Row orgRow = CommonDBUtil.getOrgRowForJob(jobId);
		IdmpodThreadLocal.setAppId(orgRow.get(IDMPODORG.ZAAID).toString());

		ArrayList<String> tablesList = new ArrayList<String>();
		tablesList.add(IDMPODDIRECTORYJOBS.TABLE);
		tablesList.add(IDMPODDIRECTORIES.TABLE);
		tablesList.add(IDMPODDIRECTORYNODES.TABLE);
		tablesList.add(IDMPODDIRECTORYPARAMS.TABLE);


		boolean[] isLeftJoins = new boolean[tablesList.size()];
		Arrays.fill(isLeftJoins, true);

		SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, new Criteria(Column.getColumn(IDMPODDIRECTORYJOBS.TABLE, IDMPODDIRECTORYJOBS.JOB_ID), jobId, QueryConstants.EQUAL));

		Persistence orgPersistence = DBUtils.getOrgPersistence();

		DataObject syncDO = orgPersistence.get(query);

		Row jobRow = syncDO.getFirstRow(IDMPODDIRECTORYJOBS.TABLE);

		Boolean isFullFetch = ((Long) jobRow.get(IDMPODDIRECTORYJOBS.SYNC_TYPE)).equals(DirectoryHandler.SYNC_TYPE.FETCH_ONLY);

		LOGGER.info("Is full fetch:" + isFullFetch);

		if (syncDO.containsTable(IDMPODDIRECTORIES.TABLE))
		{
			Row directoryRow = syncDO.getFirstRow(IDMPODDIRECTORIES.TABLE);
			Long directoryId = (Long) directoryRow.get(IDMPODDIRECTORIES.DIRECTORY_ID);

			Row syncDetailsRow = new Row(IDMPODDIRECTORYSYNCDETAILS.TABLE);

			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.JOB_ID, jobId);
			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.DIRECTORY_ID, directoryId);
			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.SYNC_TYPE, jobRow.get(IDMPODDIRECTORYJOBS.SYNC_TYPE));
			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.SYNC_STATUS, DirectoryHandler.SYNC_STATUS.RUNNING);
			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.SYNC_START_TIME, System.currentTimeMillis());

			syncDO.addRow(syncDetailsRow);

			Criteria syncEnabledNodesCrit = isFullFetch ? null : new Criteria(Column.getColumn(IDMPODDIRECTORYNODES.TABLE, IDMPODDIRECTORYNODES.SYNC_ENABLED), Boolean.TRUE, QueryConstants.EQUAL);

			Iterator<Row> syncEnabledNodes = syncDO.getRows(IDMPODDIRECTORYNODES.TABLE, syncEnabledNodesCrit);

			JSONArray domains = new JSONArray();

			while (syncEnabledNodes.hasNext())
			{
				LOGGER.info("syncEnabledNode found");
				Row syncEnabledNode = syncEnabledNodes.next();

				domains.put(DBUtils.rowToJson(syncEnabledNode));

				Row synchedNode = new Row(IDMPODSYNCHEDNODES.TABLE);
				synchedNode.set(IDMPODSYNCHEDNODES.DIRECTORY_ID, directoryId);
				synchedNode.set(IDMPODSYNCHEDNODES.SYNC_ID, syncDetailsRow.get(IDMPODDIRECTORYSYNCDETAILS.SYNC_ID));
				synchedNode.set(IDMPODSYNCHEDNODES.NODE_ID, syncEnabledNode.get(IDMPODDIRECTORYNODES.NODE_ID));

				syncDO.addRow(synchedNode);
			}
			orgPersistence.update(syncDO);

			// LOGGER.info("Domains:" + domains.toString(4));

			if (syncDO.containsTable(IDMPODDIRECTORYPARAMS.TABLE))
			{
				JSONObject directoryAttrs = new JSONObject();
				for (Iterator<Row> pit = syncDO.getRows(IDMPODDIRECTORYPARAMS.TABLE); pit.hasNext(); )
				{
					Row pr = pit.next();
					directoryAttrs.put((String) pr.get(IDMPODDIRECTORYPARAMS.PARAM_NAME), pr.get(IDMPODDIRECTORYPARAMS.ENCRYPTED_PARAM_VALUE));
				}
				Long authTokenId = directoryAttrs.optLong("GSUITE_AUTH_TOKEN_ID"); // No I18N
				Directory directory = GSuiteHandler.getDirectoryForAuthToken(authTokenId);
				try
				{
					LOGGER.info("Domains to sync:" + domains.length());
					//TODO: Construct Domain criteria
					//					JSONObject domainObj = domains.getJSONObject(domainId);
					//					String currentDomainName = domainObj.getString(IDMPODDIRECTORYNODES.NODE_IDENTIFIER);
					//					Long nodeId = domainObj.getLong(IDMPODDIRECTORYNODES.NODE_ID);

					String skipToken = null;
					do
					{
						DataObject dataObject = DBUtils.getOrgPersistence().constructDataObject();
						Users users = null;
						if (skipToken == null)
						{
							users = directory.users().list().setCustomer("my_customer").setMaxResults(500).execute(); // No I18N
						}
						else
						{
							users = directory.users().list().setCustomer("my_customer").setMaxResults(500).setPageToken(skipToken).execute(); // No I18N
						}
						if (users.getNextPageToken() != null)
						{
							skipToken = users.getNextPageToken();
						}
						else
						{
							skipToken = null;
						}
						List<User> userList = users.getUsers();
						for (int i = 0; i < userList.size(); i++)
						{
							User user = userList.get(i);
							try
							{
								Row userRow = new Row(IDMPODSYNCHEDUSERS.TABLE);
								userRow.set(IDMPODSYNCHEDUSERS.SYNC_ID, syncDetailsRow.get(IDMPODDIRECTORYSYNCDETAILS.SYNC_ID));
								userRow.set(IDMPODSYNCHEDUSERS.DIRECTORY_ID, directoryId);
								userRow.set(IDMPODSYNCHEDUSERS.FIRST_NAME, user.getName().getGivenName());
								userRow.set(IDMPODSYNCHEDUSERS.USER_IDENTIFIER, user.getId());
								userRow.set(IDMPODSYNCHEDUSERS.LAST_NAME, user.getName().getFamilyName());
								userRow.set(IDMPODSYNCHEDUSERS.USER_DISPLAY_NAME, user.getName().getFullName());
								userRow.set(IDMPODSYNCHEDUSERS.USER_PRINCIPAL_NAME, user.getPrimaryEmail());
								userRow.set(IDMPODSYNCHEDUSERS.USER_EMAIL, user.getPrimaryEmail());
								dataObject.addRow(userRow);
							}
							catch (Exception e)
							{
								LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
								// LOGGER.info(user.toPrettyString());
							}
						}
						AzureActiveDirectorySyncJob.handleFetchAndIAM(orgRow, jobRow, dataObject);

					} while (skipToken != null);
				}
				catch (Exception e)
				{
					LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
				}

				syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.SYNC_END_TIME, System.currentTimeMillis());
				syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.SYNC_STATUS, DirectoryHandler.SYNC_STATUS.SUCCESS);
				syncDO.updateRow(syncDetailsRow);
				orgPersistence.update(syncDO);
			}

			LOGGER.log(Level.INFO, "Finishing AzureActiveDirectorySyncJob job {0}", jobId); // No I18N
		}
	}
}
