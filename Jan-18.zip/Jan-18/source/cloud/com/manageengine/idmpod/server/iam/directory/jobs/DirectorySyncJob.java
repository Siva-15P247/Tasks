package com.manageengine.idmpod.server.iam.directory.jobs;

import com.adventnet.iam.IAMProxy;
import com.adventnet.iam.UserAPI;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.iam.directory.DirectoryHandler;
import com.manageengine.tables.idmpod.IDMPODDIRECTORYJOBS;
import com.manageengine.tables.idmpod.IDMPODORG;
import com.manageengine.tables.idmpod.IDMPODSYNCHEDUSERS;
import com.zoho.scheduler.RunnableJob;

import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.manageengine.idmpod.server.iam.directory.DirectoryHandler.handleSyncDirectoryUser;

public abstract class DirectorySyncJob implements Runnable, RunnableJob
{
	private static final Logger LOGGER = Logger.getLogger(DirectorySyncJob.class.getName());

	Long jobId = null;

	public DirectorySyncJob(Long jobId)
	{
		this.jobId = jobId;
	}

	public DirectorySyncJob()
	{
		this.jobId = null;
	}

	@Override
	public void run()
	{
		LOGGER.info("In memory run for jobid:" + jobId);
		try
		{
			run(jobId);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
	}

	public static void handleFetchAndIAM(Row orgRow, Row jobRow, DataObject dataObject) throws Exception
	{
		DBUtils.getOrgPersistence().add(dataObject);
		if ((Long) jobRow.get(IDMPODDIRECTORYJOBS.SYNC_TYPE) == DirectoryHandler.SYNC_TYPE.FETCH_AND_IAM)
		{
			//TODO: Fetch unique zuids and check status?
			UserAPI uapi = IAMProxy.getInstance().getUserAPI();
			Iterator<Row> userRows = dataObject.getRows(IDMPODSYNCHEDUSERS.TABLE);
			Long zoid = (Long) orgRow.get(IDMPODORG.ZOID);
			while (userRows.hasNext())
			{
				Row userRow = userRows.next();
				String email = null;
				String userName = (String) userRow.get(IDMPODSYNCHEDUSERS.USER_DISPLAY_NAME);
				if (userRow.get(IDMPODSYNCHEDUSERS.USER_EMAIL) != null)
				{
					email = (String) userRow.get(IDMPODSYNCHEDUSERS.USER_EMAIL);
				}
				else if (userRow.get(IDMPODSYNCHEDUSERS.USER_PRINCIPAL_NAME) != null)
				{
					email = (String) userRow.get(IDMPODSYNCHEDUSERS.USER_PRINCIPAL_NAME);
				}
				else
				{
					//TODO: Handle no-email error
					continue;
				}
				handleSyncDirectoryUser(zoid, email, userName, userRow);
				dataObject.updateRow(userRow);
			}
			DBUtils.getOrgPersistence().update(dataObject);
		}
	}
}
