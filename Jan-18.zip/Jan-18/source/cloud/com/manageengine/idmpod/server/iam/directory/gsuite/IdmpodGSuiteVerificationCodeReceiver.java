package com.manageengine.idmpod.server.iam.directory.gsuite;

import com.google.api.client.extensions.java6.auth.oauth2.VerificationCodeReceiver;
import com.manageengine.idmpod.server.utils.IdmpodUtils;

import java.io.IOException;

public class IdmpodGSuiteVerificationCodeReceiver implements VerificationCodeReceiver
{
	@Override
	public String getRedirectUri() throws IOException
	{
		String serviceUrl = IdmpodUtils.getServiceUrl();
		if (!serviceUrl.endsWith("/"))
		{
			serviceUrl = serviceUrl + "/";
		}
		return serviceUrl + "gsuitecb"; // NO I18N
	}

	@Override
	public String waitForCode() throws IOException
	{
		return null;
	}

	@Override
	public void stop() throws IOException
	{

	}
}
