package com.manageengine.idmpod.server.utils;

import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.IPUtil;
import com.adventnet.iam.security.LRUCacheMap;
import com.adventnet.iam.security.SecurityUtil;
import com.zoho.accounts.AccountsConfiguration;
import com.zoho.accounts.AccountsConstants;
import org.json.JSONObject;

import javax.servlet.http.HttpServletRequest;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

public class IPInfo
{
	private static final Logger LOGGER = Logger.getLogger(IPInfo.class.getName());

	private String zipCode = null;
	private String ispName = null;
	private String domainName = null;
	private String netSpeed = null;
	private String countryCode = null;
	private String timeZone = null;
	private String city = null;
	private String longitude = null;
	private String region = null;
	private String countryName = null;
	private String latitude = null;
	private String timeZone_ID = null;
	private String ip_address = null;
	private JSONObject jobj = null;
	private static LRUCacheMap<String, IPInfo> cacheMap = new LRUCacheMap<String, IPInfo>(2000, 500, 30 * 60 * 1000, TimeUnit.MILLISECONDS);

	IPInfo(JSONObject json)
	{
		jobj = json;
		zipCode = json.optString("ZIPCODE");    //No I18N
		ispName = json.optString("ISP_NAME");    //No I18N
		domainName = json.optString("DOMAIN_NAME");    //No I18N
		netSpeed = json.optString("NETSPEED");    //No I18N
		countryCode = json.optString("COUNTRY_CODE");    //No I18N
		timeZone = json.optString("TIMEZONE");    //No I18N
		city = json.optString("CITY");    //No I18N
		longitude = json.optString("LONGITUDE");    //No I18N
		region = json.optString("REGION");    //No I18N
		countryName = json.optString("COUNTRY_NAME");    //No I18N
		latitude = json.optString("LATITUDE");    //No I18N
		timeZone_ID = json.optString("OLSON_TIME_ZONE"); //No I18N
		ip_address = json.optString("IP_ADDRESS");//No I18N
	}

	public JSONObject getAsJson()
	{
		return jobj;
	}

	public String getZipCode()
	{
		return this.zipCode;
	}

	public String getISPName()
	{
		return this.ispName;
	}

	public String getDomainName()
	{
		return this.domainName;
	}

	public String getNetSpeed()
	{
		return this.netSpeed;
	}

	public String getCountryCode()
	{
		return this.countryCode;
	}

	public String getTimeZone()
	{
		return this.timeZone;
	}

	public String getCity()
	{
		return this.city;
	}

	public String getLongitude()
	{
		return this.longitude;
	}

	public String getCountryName()
	{
		return this.countryName;
	}

	public String getRegion()
	{
		return this.region;
	}

	public String getLatitude()
	{
		return this.latitude;
	}

	public String getTimeZoneID()
	{
		return this.timeZone_ID;
	}

	public String getIPAddress()
	{
		return this.ip_address;
	}

	public static IPInfo getIPInfo(HttpServletRequest request) throws Exception
	{
		return getIPInfo(request.getRemoteAddr());
	}

	public static IPInfo getIPInfo(String remoteIp) throws Exception
	{
		return getIPInfo(remoteIp, 3000);
	}

	public static IPInfo getIPInfo(String remoteIp, int timeout) throws Exception
	{
		boolean isPrivateIP = IAMUtil.isPrivateIP(remoteIp);
		if (!isValid(remoteIp) || isPrivateIP)
		{
			return null;
		}
		if (cacheMap.containsKey(remoteIp))
		{
			return cacheMap.get(remoteIp);
		}
		String ipLocationServer = IdmpodUtils.getProperty("iplocation.server.url", "http://internaliplocation.zoho.com/getipinfo");    //No I18N
		StringBuilder sb = null;
		if (ipLocationServer != null)
		{
			sb = new StringBuilder(ipLocationServer);
			sb.append(ipLocationServer.contains("?") ? '&' : '?').append("type=").append(AccountsConstants.IPINFO_REQUESTTYPE).append("&reqparam=").append(AccountsConstants.IPINFO_REQUESTPARAM).append("&ip=").append(remoteIp); //No I18N
		}
		String response = connectAndGet(sb.toString(), timeout, false);
		if (response != null)
		{
			JSONObject j = new JSONObject(response);
			if (!"-".equals(j.optString("COUNTRY_CODE", "-")))
			{
				j.put("IP_ADDRESS", remoteIp);
				IPInfo ipInfo = new IPInfo(j);
				cacheMap.put(remoteIp, ipInfo);
				return ipInfo;
			}
			cacheMap.put(remoteIp, null);
		}
		return null;
	}

	public static boolean isValid(Object value)
	{
		return value != null && !value.equals("null") && !value.equals("");
	}

	public static String connectAndGet(String url, int timeout, boolean useProxy)
	{
		return connectAndGet(url, timeout, null, useProxy);
	}

	public static String connectAndGet(String url, int timeout, Map<String, String> headers, boolean useProxy)
	{
		try
		{
			byte[] bytes = connectAndGetAsBytes(url, timeout, headers, useProxy);
			if (bytes != null)
			{
				try
				{
					return new String(bytes, "UTF-8"); //No I18N
				}
				catch (UnsupportedEncodingException e)
				{
					LOGGER.log(Level.WARNING, "Exception while geting from bytes", e);
				}
			}
		}
		catch (IOException e)
		{
			LOGGER.log(Level.WARNING, "Exception while geting from bytes", e);
		}
		return null;
	}

	public static byte[] connectAndGetAsBytes(String url, int timeout, Map<String, String> headers, boolean useProxy) throws IOException
	{
		return connectAndGetAsBytes(url, timeout, headers, null);
	}

	public static byte[] connectAndGetAsBytes(String url, int timeout, Map<String, String> headers, Proxy proxy) throws IOException
	{
		return connectAndGetAsBytes(url, timeout, headers, proxy, false);
	}

	public static byte[] connectAndGetAsBytes(String url, int timeout, Map<String, String> headers, Proxy proxy, boolean checkForSSRF) throws IOException
	{
		return connectAndGetAsBytes(url, timeout, timeout, headers, proxy, checkForSSRF);
	}

	public static byte[] connectAndGetAsBytes(String url, int readTimeout, int connectTimeout, Map<String, String> headers, Proxy proxy, boolean checkForSSRF) throws IOException
	{
		ByteArrayOutputStream baos = null;
		InputStream is = null;
		BufferedReader br = null;
		URL conURL = new URL(url);
		HttpURLConnection urlConnection = null;
		if (checkForSSRF && !validateURL(conURL))
		{
			LOGGER.log(Level.SEVERE, "SSRF attack..." + url);
			return null;
		}
		try
		{
			if (proxy == null)
			{
				urlConnection = (HttpURLConnection) (conURL.openConnection());
			}
			else
			{
				urlConnection = (HttpURLConnection) (conURL.openConnection(proxy));
			}
			urlConnection.setConnectTimeout(connectTimeout);
			urlConnection.setReadTimeout(readTimeout);
			if (headers != null && !headers.isEmpty())
			{
				Set<Map.Entry<String, String>> entrySet = headers.entrySet();
				for (Map.Entry<String, String> entry : entrySet)
				{
					urlConnection.addRequestProperty(entry.getKey(), entry.getValue());
				}
			}

			if (checkForSSRF)
			{
				urlConnection.setInstanceFollowRedirects(false);
			}

			urlConnection.connect();
			if (urlConnection.getResponseCode() < 200 || urlConnection.getResponseCode() >= 300)
			{
				is = urlConnection.getErrorStream();
			}
			else
			{
				is = urlConnection.getInputStream();
			}
			baos = new ByteArrayOutputStream();
			int r;
			if (is != null)
			{
				while ((r = is.read()) != -1)
				{
					baos.write(r);
				}
				return baos.toByteArray();
			}
			return null;
		}
		finally
		{
			try
			{
				if (br != null)
				{
					br.close();
				}
			}
			catch (IOException ioe)
			{
				LOGGER.log(Level.FINE, null, ioe);
			}
			try
			{
				if (is != null)
				{
					is.close();
				}
			}
			catch (IOException ioe)
			{
				LOGGER.log(Level.FINE, null, ioe);
			}
			try
			{
				if (baos != null)
				{
					baos.close();
				}
				if (is != null)
				{
					is.close();
				}
			}
			catch (IOException ioe)
			{
				LOGGER.log(Level.WARNING, "Error at connection finally block ", ioe);
			}
		}
	}

	private static final String[] URL_PROTOCOLS = new String[]{"http", "https"};//No I18N
	private static final Pattern DOMAIN_NAME_PATTERN = Pattern.compile("^(?:\\p{Alnum}([\\p{Alnum}-]{0,61}\\p{Alnum})?\\.)+(\\p{Alpha}([\\p{Alnum}-]{0,22}\\p{Alpha}))$");//No I18N

	public static boolean validateURL(URL url)
	{
		//For localzoho development purpose to connect local servers for testing.
		if (AccountsConfiguration.IS_LOCAL_SERVER.toBooleanValue())
		{
			return true;
		}

		String urlProtocol = url.getProtocol();
		boolean allowedProtocol = false;
		for (String protocol : URL_PROTOCOLS)
		{
			if (protocol.equals(urlProtocol))
			{
				allowedProtocol = true;
				break;
			}
		}

		String urlString = url.toString();
		if (!allowedProtocol)
		{
			LOGGER.log(Level.SEVERE, "URL protocol : \"{0}\" is not supported. URL : \"{1}\"", new Object[]{urlProtocol, urlString});
			return false;
		}

		String domainName = url.getHost();
		if (!isFQDN(domainName))
		{
			LOGGER.log(Level.SEVERE, "Domain name \"{0}\" is not FQDN. URL : \"{1}\"", new Object[]{domainName, urlString});
			return false;
		}

		if (IPUtil.isPrivateIP(domainName))
		{
			LOGGER.log(Level.SEVERE, "Attempting to access LAN IP via URL. ACCESS DENIED for URL {0}", urlString);
			return false;
		}
		return true;
	}

	private static boolean isFQDN(String domainName)
	{
		if (!SecurityUtil.isValid(domainName) || domainName.length() > 255)
		{
			return false;
		}

		if (domainName.indexOf('.') > 0 && DOMAIN_NAME_PATTERN.matcher(domainName).matches())
		{
			return true;
		}
		return false;
	}

	@Override
	public String toString()
	{
		return getAsJson() != null ? getAsJson().toString(4) : "";
	}
}
