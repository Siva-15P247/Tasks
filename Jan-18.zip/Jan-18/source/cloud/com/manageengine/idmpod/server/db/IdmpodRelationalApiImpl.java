package com.manageengine.idmpod.server.db;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.DataSet;
import com.adventnet.ds.query.QueryConstructionException;
import com.adventnet.ds.query.SelectQuery;

import java.sql.Connection;
import java.sql.SQLException;

public class IdmpodRelationalApiImpl implements IdmpodRelationalApi
{
	@Override
	public RelationalAPI getContextualApi()
	{
		return RelationalAPI.getInstance();
	}

	@Override
	public DataSet executeQuery(SelectQuery query, Connection connection) throws QueryConstructionException, SQLException
	{
		return RelationalAPI.getInstance().executeQuery(query, connection);
	}
}
