package com.manageengine.idmpod.server.utils;

import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.User;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.logging.Level;
import java.util.logging.Logger;

public class IdmpodThreadLocal
{

	private static final ThreadLocal<RequestInfo> REQUEST_INFO_LOCAL = new ThreadLocal<IdmpodThreadLocal.RequestInfo>();
	private static final Logger LOGGER = Logger.getLogger(IdmpodThreadLocal.class.getName());

	public static void setRequestDetails(HttpServletRequest request, HttpServletResponse response)
	{
		getRequestInfo().setRequest(request);
		getRequestInfo().setResponse(response);
	}

	public static HttpServletRequest getRequest()
	{
		return getRequestInfo().getRequest();
	}

	public static HttpServletResponse getResponse()
	{
		return getRequestInfo().getResponse();
	}

	public static void setAppId(String appId)
	{
		getRequestInfo().setAppId(appId);
	}

	public static String getAppId(boolean nullSafe)
	{
		return getRequestInfo().getAppId(nullSafe);
	}

	public static String getAppId()
	{
		return getRequestInfo().getAppId(false);
	}

	public static long getAppIdLong()
	{
		return Long.parseLong(getAppId());
	}

	private static RequestInfo getRequestInfo()
	{
		RequestInfo requestInfo = REQUEST_INFO_LOCAL.get();
		if (requestInfo == null)
		{
			requestInfo = new RequestInfo();
			REQUEST_INFO_LOCAL.set(requestInfo);
		}
		return requestInfo;
	}

	public static void clean()
	{
		REQUEST_INFO_LOCAL.set(null);
	}

	public static String getOrgCountryCode()
	{
		return getRequestInfo().getOrgCountryCode();
	}

	private static class RequestInfo
	{

		private HttpServletRequest request;
		private HttpServletResponse response;

		private String appId;
		private String orgCountryCode;

		private HttpServletRequest getRequest()
		{
			return request;
		}

		private void setRequest(HttpServletRequest request)
		{
			this.request = request;
		}

		private HttpServletResponse getResponse()
		{
			return response;
		}

		private void setResponse(HttpServletResponse response)
		{
			this.response = response;
		}

		private String getAppId()
		{
			if (appId == null)
			{
				appId = CommonDBUtil.getZaaid();
			}
			return appId;
		}

		private String getAppId(boolean nullSafe)
		{
			if (appId == null)
			{
				appId = CommonDBUtil.getZaaid(nullSafe);
			}
			return appId;
		}

		/**
		 * Should not be done in user thread! only to handle timer tasks and store handlers
		 */
		private void setAppId(String appId)
		{
			LOGGER.log(Level.WARNING, "setting appId directly:{0}", appId);
			User user = IAMUtil.getCurrentUser();
			if (user != null)
			{
				throw new IllegalStateException("setting appId in user thread which is not allowed!");//No I18N
			}
			this.appId = appId;
		}

		public String getOrgCountryCode()
		{
			if (orgCountryCode == null)
			{
				try
				{
					orgCountryCode = CommonDBUtil.getOrgCountryCode();
				}
				catch (Exception e)
				{
					LOGGER.log(Level.SEVERE, e.getMessage(), e);
				}
			}
			return orgCountryCode;
		}
	}

}