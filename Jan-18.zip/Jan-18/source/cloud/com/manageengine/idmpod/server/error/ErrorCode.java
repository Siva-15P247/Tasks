package com.manageengine.idmpod.server.error;

import com.adventnet.i18n.I18N;

import java.util.logging.Level;
import java.util.logging.Logger;

public enum ErrorCode
{
	//Internal
	DBSPACE_NOT_RESERVED("Space not reserved yet"),//No I18N
	DBSPACE_CREATE_LOW_ACCESS("Cannot reserve space due to low access level"),//No I18N
	//Internal Ends

	USER_NOT_INVITED("User not invited to the current project"),//No I18N
	USER_ACCESS_DENIED("User dont have enough permission to perform current operation", "idmpod.exception.common.access_denied"),//No I18N
	USER_IN_DIFFERENT_ORG("User already under different org"),//No I18N
	USER_IN_SAME_ORG("User already present in same org"), //No I18N

	COLLABORATION_EXCEPTION("Exception while using collaboration bean"),//No I18N

	HANDLER_EXCEPTION("failure while handling the given request"),//No I18N

	METADATA_UPLOAD_FAILED_INVALID_CERT("metadata_upload_failed_invalid_cert"),//No I18N

	GENERIC_ERR_DISABLING_APP("error_disabling_app"), GENERIC_ERR_ENABLING_APP("error_enabling_app"),//No I18N

	GENERIC_ERR_ADDING_SAML_APP("error_while_adding_saml_app"), GENERIC_METADATA_UPLOAD_FAILED("metadata_upload_failed"),//No I18N

	GENERIC_ERR_DELETING_SAML_APP("error_while_deleting_saml_app"),//No I18N
	GENERIC_ADD_SAML_CONFIGURATION_FAILED("add_saml_configuration_failed"),//No I18N

	APP_FOR_ISSUER_ALREADY_EXISTS("an_app_for_issuer_already_exists"), GENERIC_ERR_UPDATING_SAML_APP("error_while_updating_saml_app"),//No I18N

	GENERIC_METADATA_PARSE_FAILED("error.message.metadata_upload_failed"), METADATA_PARSE_FAILED_INVALID_CERT("error.message.metadata_upload_failed_invalid_cert"), API_RESOURCE_NOT_EXIST("Resource does not exist"), USER_LIMIT_REACHED("Users limit reached", "idmpod.exception.subscription.limit_reached"),//No I18N
	DOMAIN_VERIFICATION_CNAME_FAIL("idmpod.exception.domain_verification.cname", "idmpod.exception.domain_verification.cname"),DOMAIN_VERIFICATION_HTML_FAIL("idmpod.exception.domain_verification.html", "idmpod.exception.domain_verification.html");//No I18N

	private static final Logger LOGGER = Logger.getLogger(ErrorCode.class.getName());

	private final String message;
	private final String i18nMsg;

	ErrorCode(String message)
	{
		this.message = message;
		this.i18nMsg = null;
	}

	ErrorCode(String message, String i18nMsg)
	{
		this.message = message;
		this.i18nMsg = i18nMsg;
	}

	public String getMessage()
	{
		return this.message;
	}

	public String getI18nMsg()
	{
		try
		{
			return I18N.getMsg(i18nMsg);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		return null;
	}
}
