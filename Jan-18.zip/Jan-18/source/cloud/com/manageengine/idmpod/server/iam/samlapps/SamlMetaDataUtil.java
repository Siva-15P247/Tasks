package com.manageengine.idmpod.server.iam.samlapps;


import com.adventnet.iam.IAMUtil;
import com.adventnet.iam.SamlIssuerDetails;
import com.adventnet.iam.security.SecurityRequestWrapper;
import com.adventnet.iam.security.SecurityUtil;
import com.adventnet.iam.security.UploadedFileItem;
import com.manageengine.idmpod.server.error.ErrorCode;
import com.manageengine.idmpod.server.error.IdmpodException;
import com.manageengine.idmpod.server.iam.DomainUtils;
import com.manageengine.idmpod.server.iam.IAMCommunicator;
import com.manageengine.idmpod.server.utils.IdmpodUtils;
import org.apache.commons.codec.binary.Base64;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.opensaml.DefaultBootstrap;
import org.opensaml.common.xml.SAMLConstants;
import org.opensaml.saml2.metadata.*;
import org.opensaml.saml2.metadata.provider.DOMMetadataProvider;
import org.opensaml.saml2.metadata.provider.FilesystemMetadataProvider;
import org.opensaml.saml2.metadata.provider.MetadataProviderException;
import org.opensaml.xml.Configuration;
import org.opensaml.xml.ConfigurationException;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.XMLObjectBuilder;
import org.opensaml.xml.io.Marshaller;
import org.opensaml.xml.io.MarshallingException;
import org.opensaml.xml.parse.BasicParserPool;
import org.opensaml.xml.security.credential.UsageType;
import org.opensaml.xml.security.keyinfo.KeyInfoGenerator;
import org.opensaml.xml.security.keyinfo.KeyInfoHelper;
import org.opensaml.xml.security.x509.BasicX509Credential;
import org.opensaml.xml.security.x509.X509KeyInfoGeneratorFactory;
import org.opensaml.xml.signature.X509Certificate;
import org.opensaml.xml.signature.X509Data;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.servlet.http.HttpServletRequest;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SamlMetaDataUtil
{

	private static final String SP_ENTITY_ID = "zoho.com"; // NO I18N
	private static final String[] URLS = new String[]{"https://accounts.zoho.com/samlresponse/", // NO I18N
			"https://eu-accounts.zoho.com/samlresponse/", // NO I18N
			"https://accounts-ro.zoho.com/samlresponse/"}; // NO I18N
	private static final Logger LOGGER = Logger.getLogger(SamlMetaDataUtil.class.getName());

	public enum NameIDType
	{
		NameIDTypeFirstName("FIRST_NAME", "first_name", 2), // NO I18N
		NameIDTypeFullName("FULL_NAME", "full_name", 4), // NO I18N
		NameIDTypeEmail("EMAIL_ID", "email", 1), // NO I18N
		NameIDTypeLastName("LAST_NAME", "last_name", 3); // NO I18N
		private String nameId;
		private String stringValue;
		private int intValue;

		private NameIDType(String nameId, String stringValue, int intValue)
		{
			this.nameId = nameId;
			this.stringValue = stringValue;
			this.intValue = intValue;
		}

		String getStringValue()
		{
			return this.stringValue;
		}

		int getIntValue()
		{
			return this.intValue;
		}

		String getNameId()
		{
			return this.nameId;
		}

		public static NameIDType getNameIdType(String stringValue)
		{
			for (NameIDType value : NameIDType.values())
			{
				if (value.stringValue.equals(stringValue))
				{
					return value;
				}
			}
			return null;
		}

		static NameIDType getNameIdType(int intValue)
		{
			for (NameIDType value : NameIDType.values())
			{
				if (value.intValue == intValue)
				{
					return value;
				}
			}
			return null;
		}
	}

	static
	{
		try
		{
			DefaultBootstrap.bootstrap();
		}
		catch (ConfigurationException ex)
		{
			LOGGER.log(Level.SEVERE, "Error while initializing SAML library", ex);
		}
	}


	public static JSONObject readAndParseMetaData(HttpServletRequest request) throws FileNotFoundException, IOException, CertificateException, JSONException
	{
		File file = null;
		if (request.getAttribute(SecurityUtil.MULTIPART_FORM_REQUEST) != null)
		{
			SecurityRequestWrapper wrapper = SecurityRequestWrapper.getInstance(request);
			List<UploadedFileItem> files = wrapper.getMultipartFiles();

			if (files.size() > 0)
			{
				UploadedFileItem fileItem = files.get(0);
				file = fileItem.getUploadedFile();
			}
		}
		return parseMetaData(file);
	}


	/**
	 * Parse the metadata file and return attributes nacessary to enable saml
	 *
	 * @param file
	 * @return
	 * @throws CertificateException
	 * @throws JSONException
	 */
	public static JSONObject parseMetaData(File file) throws CertificateException, JSONException
	{
		if (file == null)
		{
			throw new IdmpodException(ErrorCode.GENERIC_METADATA_UPLOAD_FAILED);
		}
		JSONObject json = new JSONObject();
		FilesystemMetadataProvider idpMetaDataProvider = null;
		String login_url = null;
		String logout_url = null;
		String algo = null;
		String certString = null;

		try
		{
			DocumentBuilder builder = SecurityUtil.getDocumentBuilder(false, false);
			Document doc = builder.parse(file);
			String entityId = doc.getDocumentElement().getAttribute("entityID"); // NO I18N

			idpMetaDataProvider = new FilesystemMetadataProvider(file);
			idpMetaDataProvider.setRequireValidMetadata(true); //Enable validation
			idpMetaDataProvider.setParserPool(new BasicParserPool());
			idpMetaDataProvider.initialize();

			EntityDescriptor entityDescriptor = idpMetaDataProvider.getEntityDescriptor(entityId);
			for (SingleSignOnService sss : entityDescriptor.getIDPSSODescriptor(SAMLConstants.SAML20P_NS).getSingleSignOnServices())
			{
				login_url = sss.getLocation();
				break;
			}
			for (SingleLogoutService sss : entityDescriptor.getIDPSSODescriptor(SAMLConstants.SAML20P_NS).getSingleLogoutServices())
			{
				logout_url = sss.getLocation();
				break;
			}
			if (logout_url == null)
			{
				logout_url = login_url;
			}
			java.util.List<KeyDescriptor> keyDescriptors = entityDescriptor.getIDPSSODescriptor(SAMLConstants.SAML20P_NS).getKeyDescriptors();
			KeyDescriptor keyDesc = null;

			for (KeyDescriptor kd : keyDescriptors)
			{
				if (kd.getUse() == UsageType.SIGNING)
				{
					keyDesc = kd;
					break;
				}
			}

			if (keyDesc != null)
			{
				X509Data x509Data = (X509Data) keyDesc.getKeyInfo().getX509Datas().get(0);
				X509Certificate certificate = (X509Certificate) x509Data.getX509Certificates().get(0);
				java.security.cert.X509Certificate cert = KeyInfoHelper.getCertificate(certificate);
				algo = cert.getSigAlgName();
				algo = (algo.indexOf("RSA") != -1) ? "RSA" : "DSA"; //No I18N
				certString = convertToPem(cert);
			}
			if (certString == null)
			{
				throw new IdmpodException(ErrorCode.METADATA_UPLOAD_FAILED_INVALID_CERT);
			}

			json.put("login_url", login_url); //No I18N
			json.put("logout_url", logout_url); //No I18N
			json.put("certificate", certString); //No I18N
			json.put("algorithm", algo); //No I18N
			//json.put(APIConstants.OPSTATUS, APIConstants.SUCCESS);
		}
		catch (SAXException ex)
		{
			LOGGER.log(Level.SEVERE, null, ex);
		}
		catch (IOException ex)
		{
			LOGGER.log(Level.SEVERE, null, ex);
		}
		catch (MetadataProviderException mepe)
		{
			LOGGER.log(Level.SEVERE, "Exception while saving metadata to db", mepe);
		}
		finally
		{
			if (idpMetaDataProvider != null)
			{
				((org.opensaml.saml2.metadata.provider.AbstractReloadingMetadataProvider) idpMetaDataProvider).destroy();
			}
		}
		return json;
	}

	/**
	 * Convert an X509 certification to pem encoded string
	 *
	 * @param x509cert
	 * @return
	 * @throws CertificateEncodingException
	 */
	protected static String convertToPem(java.security.cert.X509Certificate x509cert) throws CertificateEncodingException
	{
		Base64 encoder = new Base64(64);
		String cert_begin = "-----BEGIN CERTIFICATE-----\n";// NO I18N
		String end_cert = "-----END CERTIFICATE-----"; // NO I18N
		byte[] derCert = x509cert.getEncoded();
		String pemCertPre = new String(encoder.encode(derCert));
		String pemCert = cert_begin + pemCertPre + end_cert;
		return pemCert;
	}

	/**
	 * @return
	 */
	public static String createSPMetaData() throws TransformerConfigurationException, TransformerException
	{
		String metadataXML = null;
		try
		{
			EntityDescriptor spEntityDescriptor = (EntityDescriptor) buildXMLObject(EntityDescriptor.DEFAULT_ELEMENT_NAME);
			spEntityDescriptor.setEntityID(SP_ENTITY_ID);
			SPSSODescriptor spSSODescriptor = (SPSSODescriptor) buildXMLObject(SPSSODescriptor.DEFAULT_ELEMENT_NAME);
			spSSODescriptor.setWantAssertionsSigned(true);
			spSSODescriptor.setAuthnRequestsSigned(true);
			NameIDFormat nameIDFormat = (NameIDFormat) buildXMLObject(NameIDFormat.DEFAULT_ELEMENT_NAME);
			//nameIDFormat.setFormat("urn:oasis:names:tc:SAML:2.0:nameid-format:transient");  // NO I18N
			nameIDFormat.setFormat("urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress");  // NO I18N
			spSSODescriptor.getNameIDFormats().add(nameIDFormat);

			SingleLogoutService logoutService = (SingleLogoutService) buildXMLObject(SingleLogoutService.DEFAULT_ELEMENT_NAME);
			String serviceName = IAMCommunicator.getServiceName();
			String iamUrl = com.adventnet.iam.IAMUtil.getLogoutURL() + "?servicename=" + serviceName; // NO I18N
			logoutService.setLocation(iamUrl);
			logoutService.setBinding(SAMLConstants.SAML2_REDIRECT_BINDING_URI);
			spSSODescriptor.getSingleLogoutServices().add(logoutService);

			String[] urls = getConsumerUrls();
			for (int i = 0; i < urls.length; i++)
			{
				AssertionConsumerService assertionConsumerService = (AssertionConsumerService) buildXMLObject(AssertionConsumerService.DEFAULT_ELEMENT_NAME);
				assertionConsumerService.setIndex(i);
				assertionConsumerService.setBinding(SAMLConstants.SAML2_POST_BINDING_URI);

				// Setting address for our AssertionConsumerService
				assertionConsumerService.setLocation(urls[i]);
				spSSODescriptor.getAssertionConsumerServices().add(assertionConsumerService);

				spSSODescriptor.addSupportedProtocol(SAMLConstants.SAML20P_NS);

			}
			/*
			 //SPSSODescriptor spSSODescriptor = spEntityDescriptor.getSPSSODescriptor(SAMLConstants.SAML20P_NS);
             X509KeyInfoGeneratorFactory keyInfoGeneratorFactory = new X509KeyInfoGeneratorFactory();
             keyInfoGeneratorFactory.setEmitEntityCertificate(true);
             KeyInfoGenerator keyInfoGenerator = keyInfoGeneratorFactory.newInstance();

             KeyDescriptor signKeyDescriptor = (KeyDescriptor) buildXMLObject(KeyDescriptor.DEFAULT_ELEMENT_NAME);
             signKeyDescriptor.setUse(UsageType.SIGNING);  //Set usage
             // Generating key info. The element will contain the public key. The key is used to by the IDP to verify signatures
             try {
             signKeyDescriptor.setKeyInfo(keyInfoGenerator.generate(signingCredential));
             } catch (SecurityException e) {
             LOGGER.log(Level.SEVERE, e.getMessage(), e);
             }

             spSSODescriptor.getKeyDescriptors().add(signKeyDescriptor);
             */
			//update data in entity descriptor
			spEntityDescriptor.getRoleDescriptors().add(spSSODescriptor);

			DocumentBuilder builder;
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

			builder = factory.newDocumentBuilder();
			Document document = builder.newDocument();
			Marshaller out = Configuration.getMarshallerFactory().getMarshaller(spEntityDescriptor);
			out.marshall(spEntityDescriptor, document);

			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			StringWriter stringWriter = new StringWriter();
			StreamResult streamResult = new StreamResult(stringWriter);
			DOMSource source = new DOMSource(document);
			transformer.transform(source, streamResult);
			stringWriter.close();
			metadataXML = stringWriter.toString();
		}
		catch (ParserConfigurationException pce)
		{
			LOGGER.log(Level.SEVERE, pce.getMessage(), pce);
		}
		catch (MarshallingException me)
		{
			LOGGER.log(Level.SEVERE, me.getMessage(), me);
		}
		catch (TransformerConfigurationException tce)
		{
			LOGGER.log(Level.SEVERE, tce.getMessage(), tce);
		}
		catch (TransformerException te)
		{
			LOGGER.log(Level.SEVERE, te.getMessage(), te);
		}
		catch (IOException ioe)
		{
			LOGGER.log(Level.SEVERE, ioe.getMessage(), ioe);
		}
		return metadataXML;
	}

	public static XMLObject buildXMLObject(QName objectQName)
	{
		XMLObjectBuilder builder = Configuration.getBuilderFactory().getBuilder(objectQName);
		if (builder == null)
		{
			return null;
		}
		return builder.buildObject(objectQName.getNamespaceURI(), objectQName.getLocalPart(), objectQName.getPrefix());
	}

	public static String[] getConsumerUrls()
	{
		String orgDomain = DomainUtils.getOrgVerifiedDomain(IAMUtil.getCurrentUser().getZOID());
		String[] endPoints = new String[URLS.length];
		for (int i = 0; i < URLS.length; i++)
		{
			endPoints[i] = URLS[i] + orgDomain;
		}
		return endPoints;
	}

	static String getIdPMetadata(String appId, SamlIssuerDetails detail)
	{
		String metadata = null;
		try
		{
			EntityDescriptor idpEntityDescriptor = (EntityDescriptor) buildXMLObject(EntityDescriptor.DEFAULT_ELEMENT_NAME);
			idpEntityDescriptor.setEntityID(detail.getIssuer());
			IDPSSODescriptor idpSSODescriptor = (IDPSSODescriptor) buildXMLObject(IDPSSODescriptor.DEFAULT_ELEMENT_NAME);
			idpSSODescriptor.setWantAuthnRequestsSigned(Boolean.FALSE);
			NameIDFormat nameIDFormat = (NameIDFormat) buildXMLObject(NameIDFormat.DEFAULT_ELEMENT_NAME);
			//nameIDFormat.setFormat("urn:oasis:names:tc:SAML:2.0:nameid-format:transient");  // NO I18N
			nameIDFormat.setFormat("urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress");  // NO I18N
			idpSSODescriptor.getNameIDFormats().add(nameIDFormat);

			// Add logout service
			SingleLogoutService logoutService = (SingleLogoutService) buildXMLObject(SingleLogoutService.DEFAULT_ELEMENT_NAME);
			String serviceName = IAMCommunicator.getServiceName();
			//String logoutURL = com.adventnet.iam.IAMUtil.getLogoutURL() + "?servicename=" + serviceName; // NO I18N
			String logoutURL = IdmpodUtils.getServiceUrl() + "/saml-logout?appid=" + appId; //No I18n
			logoutService.setLocation(logoutURL);
			logoutService.setBinding(SAMLConstants.SAML2_REDIRECT_BINDING_URI);
			idpSSODescriptor.getSingleLogoutServices().add(logoutService);

			// Add sign in services
			String singinURL = IdmpodUtils.getServiceUrl() + "/sp-saml-login?appid=" + appId; //No I18n
			SingleSignOnService ssoService = (SingleSignOnService) buildXMLObject(SingleSignOnService.DEFAULT_ELEMENT_NAME);
			ssoService.setLocation(singinURL);
			ssoService.setBinding(SAMLConstants.SAML2_POST_BINDING_URI);
			idpSSODescriptor.getSingleSignOnServices().add(ssoService);

			ssoService = (SingleSignOnService) buildXMLObject(SingleSignOnService.DEFAULT_ELEMENT_NAME);
			ssoService.setLocation(singinURL);
			ssoService.setBinding(SAMLConstants.SAML2_REDIRECT_BINDING_URI);
			idpSSODescriptor.getSingleSignOnServices().add(ssoService);

			//Add signing key
			ByteArrayInputStream inputStream = new ByteArrayInputStream(detail.getPublicKey().getBytes());
			CertificateFactory cf = CertificateFactory.getInstance("X.509");
			java.security.cert.X509Certificate publicKey = (java.security.cert.X509Certificate) cf.generateCertificate(inputStream);

			X509KeyInfoGeneratorFactory keyInfoGeneratorFactory = new X509KeyInfoGeneratorFactory();
			keyInfoGeneratorFactory.setEmitEntityCertificate(true);
			KeyInfoGenerator keyInfoGenerator = keyInfoGeneratorFactory.newInstance();

			KeyDescriptor signKeyDescriptor = (KeyDescriptor) buildXMLObject(KeyDescriptor.DEFAULT_ELEMENT_NAME);
			signKeyDescriptor.setUse(UsageType.SIGNING);  //Set usage
			// Generating key info. The element will contain the public key. The key is used to by the IDP to verify signatures
			BasicX509Credential credential = new BasicX509Credential();
			credential.setEntityCertificate(publicKey);
			try
			{
				signKeyDescriptor.setKeyInfo(keyInfoGenerator.generate(credential));
			}
			catch (org.opensaml.xml.security.SecurityException e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
			idpSSODescriptor.getKeyDescriptors().add(signKeyDescriptor);
			idpSSODescriptor.addSupportedProtocol(SAMLConstants.SAML20P_NS);
			idpEntityDescriptor.getRoleDescriptors().add(idpSSODescriptor);

			DocumentBuilder builder;
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

			builder = factory.newDocumentBuilder();
			Document document = builder.newDocument();
			Marshaller out = Configuration.getMarshallerFactory().getMarshaller(idpEntityDescriptor);
			out.marshall(idpEntityDescriptor, document);

			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			StringWriter stringWriter = new StringWriter();
			StreamResult streamResult = new StreamResult(stringWriter);
			DOMSource source = new DOMSource(document);
			transformer.transform(source, streamResult);
			stringWriter.close();
			metadata = stringWriter.toString();
		}
		catch (ParserConfigurationException pce)
		{
			LOGGER.log(Level.SEVERE, pce.getMessage(), pce);
		}
		catch (MarshallingException me)
		{
			LOGGER.log(Level.SEVERE, me.getMessage(), me);
		}
		catch (TransformerConfigurationException tce)
		{
			LOGGER.log(Level.SEVERE, tce.getMessage(), tce);
		}
		catch (TransformerException te)
		{
			LOGGER.log(Level.SEVERE, te.getMessage(), te);
		}
		catch (IOException ioe)
		{
			LOGGER.log(Level.SEVERE, ioe.getMessage(), ioe);
		}
		catch (CertificateException certEx)
		{
			LOGGER.log(Level.SEVERE, certEx.getMessage(), certEx);
		}
		return metadata;
	}

	public static JSONObject parseSPMetadataFile(String file) throws JSONException
	{
		if (file == null)
		{
			return null;
		}
		JSONObject json = new JSONObject();
		DOMMetadataProvider spMetaDataProvider = null;
		String acs_url = null;
		String logout_url = null;
		String certString = null;

		try
		{
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			documentBuilderFactory.setNamespaceAware(true);
			documentBuilderFactory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); //No I18n
			Document doc = documentBuilderFactory.newDocumentBuilder().parse(new InputSource(new StringReader(file)));


			//			DocumentBuilder builder = SecurityUtil.getDocumentBuilder(false, false);
			//			Document doc = builder.parse(new InputSource(new StringReader(file)));
			String entityId = doc.getDocumentElement().getAttribute("entityID"); // NO I18N

			spMetaDataProvider = new DOMMetadataProvider(doc.getDocumentElement());
			spMetaDataProvider.setRequireValidMetadata(true); //Enable validation
			spMetaDataProvider.setParserPool(new BasicParserPool());
			spMetaDataProvider.initialize();

			EntityDescriptor entityDescriptor = spMetaDataProvider.getEntityDescriptor(entityId);
			SPSSODescriptor descriptor = entityDescriptor.getSPSSODescriptor(SAMLConstants.SAML20P_NS);
			if (descriptor == null)
			{
				return null;
			}
			if (!descriptor.getNameIDFormats().isEmpty())
			{
				descriptor.getNameIDFormats().get(0).getFormat();
			}

			if (descriptor.getSingleLogoutServices().size() > 0)
			{
				logout_url = descriptor.getSingleLogoutServices().get(0).getLocation();
			}

			if (!descriptor.getAssertionConsumerServices().isEmpty())
			{
				for (AssertionConsumerService acs : descriptor.getAssertionConsumerServices())
				{
					if (acs.getBinding().equals(SAMLConstants.SAML2_POST_BINDING_URI))
					{
						acs_url = acs.getLocation();
					}
				}
			}

			java.util.List<KeyDescriptor> keyDescriptors = descriptor.getKeyDescriptors();
			KeyDescriptor keyDesc = null;

			for (KeyDescriptor kd : keyDescriptors)
			{
				if (kd.getUse() == UsageType.SIGNING)
				{
					keyDesc = kd;
					break;
				}
			}

			if (keyDesc != null)
			{
				X509Data x509Data = (X509Data) keyDesc.getKeyInfo().getX509Datas().get(0);
				X509Certificate certificate = (X509Certificate) x509Data.getX509Certificates().get(0);
				java.security.cert.X509Certificate cert = KeyInfoHelper.getCertificate(certificate);
				certString = convertToPem(cert);
			}

			List<AttributeConsumingService> atrCS = descriptor.getAttributeConsumingServices();
			if (!atrCS.isEmpty())
			{
				JSONArray jsonAttr = new JSONArray();
				AttributeConsumingService atcs = atrCS.get(0);
				List<RequestedAttribute> attrs = atcs.getRequestAttributes();
				for (RequestedAttribute attribute : attrs)
				{
					String name = attribute.getName();
					if (NameIDType.getNameIdType(name) != null)
					{
						JSONObject obj = new JSONObject();
						obj.put("name", attribute.getFriendlyName()); //No I18N
						obj.put("value", name); //No I18N
						jsonAttr.put(obj);
					}
				}
				json.put("ATTRIBUTES", jsonAttr); //No I18N
			}
			json.put("ACS_URL", acs_url); //No I18N
			json.put("LOGOUT_URL", logout_url); //No I18N
			json.put("PUBLIC_KEY", certString); //No I18N
			json.put("ISSUER", entityId); //No I18N
			//json.put(APIConstants.OPSTATUS, APIConstants.SUCCESS);
			json.put("NAMEID", SamlAppsHandler.NameId.NAMEID_EMAIL_ADDRESS.getStringConstant());
		}
		catch (CertificateException ex)
		{
			LOGGER.log(Level.SEVERE, null, ex);
		}
		catch (SAXException ex)
		{
			LOGGER.log(Level.SEVERE, null, ex);
		}
		catch (IOException ex)
		{
			LOGGER.log(Level.SEVERE, null, ex);
		}
		catch (MetadataProviderException mepe)
		{
			LOGGER.log(Level.SEVERE, "Exception while saving metadata to db", mepe);
		}
		catch (ParserConfigurationException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		finally
		{
			if (spMetaDataProvider != null)
			{
				spMetaDataProvider.destroy();
			}
		}
		return json;
	}

	public static JSONArray getAttributes()
	{
		NameIDType[] values = NameIDType.values();
		JSONArray ary = new JSONArray();
		for (NameIDType value : values)
		{
			JSONObject object = new JSONObject();
			object.put("name", value.getStringValue()); //No I18N
			object.put("value", value.getIntValue()); //No I18N
			ary.put(object);
		}
		return ary;
	}
}

