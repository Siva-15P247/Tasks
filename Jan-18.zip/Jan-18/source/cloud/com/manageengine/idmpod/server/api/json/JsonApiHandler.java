package com.manageengine.idmpod.server.api.json;

import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.idmpod.server.error.ErrorCode;
import com.manageengine.idmpod.server.error.IdmpodException;
import com.manageengine.idmpod.server.utils.CommonDBUtil;
import com.manageengine.tables.idmpod.IDMPODJSONAPIMAPPING;
import com.zoho.accounts.AccountsConstants;
import com.zoho.accounts.AccountsUtil;
import org.json.JSONArray;
import org.json.JSONObject;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.manageengine.idmpod.server.api.json.JsonApiConstants.*;

public class JsonApiHandler
{
	public static final int UNPROCESSABLE_ENTITY = 422;
	volatile private static JsonApiHandler instance = null;
	private static final Logger LOGGER = Logger.getLogger(JsonApiHandler.class.getName());
	private Hashtable<String, Hashtable<String, Hashtable<String, Object>>> apiMapping = new Hashtable<String, Hashtable<String, Hashtable<String, Object>>>();

	public static enum ResourceType
	{
		USER("user"), // NO I18N
		INVITED_USER("invited-user"), // NO I18N
		SAML_APP("saml-app"), // NO I18N
		DIRECTORY("directory"), // NO I18N
		ORGANIZATIONAL_UNIT("organizational-unit"), // NO I18N
		DOMAIN("domain"), // NO I18N
		AZURE_AUTH_TOKEN("azure-auth-token"), // NO I18N
		GSUITE_AUTH_TOKEN("gsuite-auth-token"), // NO I18N
		DIRECTORY_TYPE("directory-type"), // NO I18N
		SYNCHED_OBJECT("synched-object"), // NO I18N
		SAML_APP_TEMPLATE("saml-app-template"), // NO I18N
		SAML_APP_CATEGORY("saml-app-category"), // NO I18N
		DASHBOARD("dashboard"), // NO I18N
		DASHBOARD_CHART("dashboard-chart"), // NO I18N
		CHART("chart"), // NO I18N
		REPORT("report"), // NO I18N
		REPORT_INPUT("report-input"), // NO I18N
		REPORT_FIELD("report-field"), // NO I18N
		APPLICATION_ACCESS_EVENT("application-access-event"), // NO I18N
		ADMIN_AUDIT_EVENT("admin-audit-event"), // NO I18N
		PDOMAIN("pdomain"),//No I18N
		SUBSCRIPTION("subscription"); // NO I18N

		private final String resType;

		private ResourceType(String resourceType)
		{
			resType = resourceType;
		}

		public String getResType()
		{
			return resType;
		}
	}

	public static JsonApiHandler getInstance()
	{
		if (instance == null)
		{
			synchronized (JsonApiHandler.class)
			{
				if (instance == null)
				{
					instance = new JsonApiHandler();
				}
			}
		}
		return instance;
	}

	private JsonApiHandler()
	{
		try
		{
			initializeAPIMap();
		}
		catch (Exception ex)
		{
			LOGGER.log(Level.SEVERE, "RestAPIHandler::Exception while initializing RestAPI map", ex);
		}
	}

	private void initializeAPIMap()
	{
		try
		{
			DataObject dataObject = CommonDBUtil.getPersistance().get(IDMPODJSONAPIMAPPING.TABLE, (Row) null);
			for (Iterator<Row> iterator = dataObject.getRows(IDMPODJSONAPIMAPPING.TABLE); iterator.hasNext(); )
			{
				Row row = iterator.next();
				String urlPath = (String) row.get(IDMPODJSONAPIMAPPING.URL_PATH);
				String httpMethod = (String) row.get(IDMPODJSONAPIMAPPING.HTTP_METHOD);
				String className = (String) row.get(IDMPODJSONAPIMAPPING.CLASS_NAME);
				String methodName = (String) row.get(IDMPODJSONAPIMAPPING.METHOD_NAME);
				String aa_member_role = (String) row.get(IDMPODJSONAPIMAPPING.AA_MEMBER_ROLE);

				// Reference to RestAPI class is obtained variable obj.
				Class<?> caller = Class.forName(className);
				Class<?>[] argTypes = new Class<?>[]{};
				Method getInstanceMethod = caller.getMethod(GET_INSTANCE_METHOD, argTypes);
				Object obj = getInstanceMethod.invoke(caller);

				// Reference to RestAPI method is stored in executionMethod.
				argTypes = new Class<?>[]{JSONObject.class};
				Method executionMethod = caller.getMethod(methodName, argTypes);

				Hashtable<String, Object> mappingInfo = new Hashtable<String, Object>();
				mappingInfo.put(CLASS_INSTANCE, obj);
				mappingInfo.put(METHOD_INSTANCE, executionMethod);
				if (aa_member_role != null)
				{
					mappingInfo.put(IDMPODJSONAPIMAPPING.AA_MEMBER_ROLE, aa_member_role);
				}

				Hashtable<String, Hashtable<String, Object>> httpMethodMap = apiMapping.getOrDefault(urlPath, new Hashtable<String, Hashtable<String, Object>>());
				httpMethodMap.put(httpMethod, mappingInfo);
				apiMapping.put(urlPath, httpMethodMap);
			}
			LOGGER.log(Level.INFO, " Rest API map initialized in RestAPIHandler:\n" + apiMapping.toString());
		}
		catch (Exception ex)
		{
			LOGGER.log(Level.SEVERE, "RestAPIHandler::initializeAPIMap() Exception while initializing RestAPI map - ", ex);
		}
	}

	Pattern actionUrlPattern = Pattern.compile("[^\\d]+(\\d+)[^\\d]+");
	Pattern singleResourceUrlPattern = Pattern.compile("[^\\d]+(\\d+)$");
	Pattern textIdPattern = Pattern.compile("(.+\\/)([\\w.]+)");

	public int execute(HttpServletRequest request, HttpServletResponse response)
	{
		int respCode = HttpServletResponse.SC_OK;
		JSONObject resp = null;
		String urlPath = (request.getRequestURI()).replaceFirst(JsonApiConstants.BASE_PATH, "");//NO I18N

		String actionTargetId = null;
		String singleResourceId = null;

		if (urlPath.matches(".+\\d+$"))
		{
			if (request.getMethod().equalsIgnoreCase("DELETE"))
			{
				respCode = HttpServletResponse.SC_NO_CONTENT;
			}
			Matcher singleResourceUrlMatcher = singleResourceUrlPattern.matcher(urlPath);
			if (singleResourceUrlMatcher.matches())
			{
				singleResourceId = singleResourceUrlMatcher.group(1);
			}
			urlPath = urlPath.replaceFirst("\\d+$", "{id}");//NO I18N
			//			LOGGER.info("single Resource url");
		}
		else if (urlPath.matches(".+\\d+.+"))
		{
			Matcher actionUrlMatcher = actionUrlPattern.matcher(urlPath);
			if (actionUrlMatcher.matches())
			{
				actionTargetId = actionUrlMatcher.group(1);
			}
			urlPath = urlPath.replaceFirst("\\d+", "{id}");//NO I18N
			//			LOGGER.info("resource action url");
		}
		Hashtable<String, Hashtable<String, Object>> httpMethodMap = apiMapping.get(urlPath);
		if (httpMethodMap == null)
		{
			if (urlPath.matches(".+\\/[\\w.]+"))
			{
				//Text ids- email/domain
				Matcher textIdMatcher = textIdPattern.matcher(urlPath);
				if (textIdMatcher.matches())
				{
					singleResourceId = textIdMatcher.group(2);
				}
				urlPath = urlPath.replaceFirst("(.+\\/)([\\w.]+)", "$1{id}");//NO I18N
				httpMethodMap = apiMapping.get(urlPath);
			}
		}
		//		LOGGER.log(Level.INFO, "urlPath:{0}", new String[]{urlPath});
		try
		{
			if (httpMethodMap != null)
			{
				String httpMethod = request.getMethod().toUpperCase();
				Hashtable<String, Object> mappingInfo = httpMethodMap.get(httpMethod);
				if (mappingInfo != null)
				{
					String req_aa_member_role = (String) mappingInfo.get(IDMPODJSONAPIMAPPING.AA_MEMBER_ROLE);
					String aa_member_role = AccountsUtil.getCurrentUserRole();
					boolean authorized = true;

					if (req_aa_member_role != null && !req_aa_member_role.equalsIgnoreCase(aa_member_role))
					{
						authorized = false;
						if (req_aa_member_role.equalsIgnoreCase(AccountsConstants.Role.ADMIN))
						{
							if (aa_member_role.equalsIgnoreCase(AccountsConstants.Role.SUPER_ADMIN))
							{
								authorized = true;
							}
						}
						if (req_aa_member_role.equalsIgnoreCase(AccountsConstants.Role.USER))
						{
							authorized = true;
						}
					}

					if (!authorized)
					{
						LOGGER.log(Level.WARNING, "Unauthorized api access for method - " + httpMethod + "- for URL-" + urlPath + "; Req role:" + req_aa_member_role + "; Current user role:" + aa_member_role);
						respCode = HttpServletResponse.SC_FORBIDDEN;
						return respCode;
					}
					//					else
					//					{
					//						LOGGER.log(Level.INFO, "Authorized api access for method - " + httpMethod + "- for URL-" + urlPath + "; Req role:" + req_aa_member_role + "; Current user role:" + aa_member_role);
					//					}

					Object obj = mappingInfo.get(CLASS_INSTANCE);
					Method executionMethod = (Method) mappingInfo.get(METHOD_INSTANCE);
					//					LOGGER.log(Level.INFO, "Accessing {3} URL: {0}, Class: {1}, Method : {2}", new String[]{urlPath, obj.getClass().getName(), executionMethod.getName(), httpMethod});
					//executionMethod.invoke(obj, request, response);
					JSONObject requestObj = processRequest(request);
					if (actionTargetId != null)
					{
						requestObj.put(JsonApiConstants.DATA, JsonApiHandler.getResourceIdentifierObject(null, actionTargetId));
					}
					if (singleResourceId != null && !requestObj.has(JsonApiConstants.DATA))
					{
						requestObj.put(JsonApiConstants.DATA, JsonApiHandler.getResourceIdentifierObject(null, singleResourceId));
					}
					resp = (JSONObject) executionMethod.invoke(obj, requestObj);
					if (resp == null)
					{
						respCode = HttpServletResponse.SC_NO_CONTENT;
						resp = new JSONObject();
					}
					if (resp.has(JsonApiConstants.ERRORS) && resp.getJSONArray(JsonApiConstants.ERRORS).length() > 0)
					{
						respCode = UNPROCESSABLE_ENTITY;
					}
					response.setStatus(respCode);
					setResponseJSON(response, resp);
				}
				else
				{
					LOGGER.log(Level.WARNING, "RestAPI unavailable for method - " + httpMethod + "- for URL-" + urlPath);
					respCode = HttpServletResponse.SC_NOT_FOUND;
				}
			}
			else
			{
				LOGGER.log(Level.WARNING, "RestAPI unavailable for url- " + urlPath);
				respCode = HttpServletResponse.SC_NOT_FOUND;
			}

		}
		//		catch (IllegalArgumentException iae)
		//		{
		//			//Validation error handling
		//			setResponseJSON(response, resp);
		//			respCode = UNPROCESSABLE_ENTITY;
		//		}
		catch (InvocationTargetException ite)
		{
			Throwable e = ite.getCause();
			if (e instanceof IdmpodException)
			{
				if (((IdmpodException) e).getErrorCode() == ErrorCode.API_RESOURCE_NOT_EXIST)
				{
					respCode = HttpServletResponse.SC_NOT_FOUND;
				}
			}
			LOGGER.log(Level.SEVERE, "Invocation Target Exception cause-", e);
		}
		catch (IdmpodException ie)
		{
			//TODO: Unified Error Handling
			LOGGER.log(Level.SEVERE, "IdmpodException while executing RestAPI - ", ie);
		}
		catch (Exception ex)
		{
			respCode = HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
			LOGGER.log(Level.SEVERE, "Exception while executing RestAPI - ", ex);
		}
		return respCode;
	}

	public static JSONObject processRequest(HttpServletRequest request)
	{
		if (request.getMethod().toUpperCase().equals("GET"))
		{
			JSONObject req = new JSONObject();
			try
			{
				Enumeration<String> parameterNames = request.getParameterNames();
				while (parameterNames.hasMoreElements())
				{
					String parameterName = parameterNames.nextElement();
					req.put(parameterName, request.getParameter(parameterName));
				}
			}
			catch (Exception e)
			{
				LOGGER.log(Level.SEVERE, " ", e);
			}
			return req;
		}
		else
		{
			StringBuffer jb = new StringBuffer();
			String line;
			try
			{
				BufferedReader reader = request.getReader();
				while ((line = reader.readLine()) != null)
				{
					jb.append(line);
				}
			}
			catch (Exception e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
			if (jb.length() > 0)
			{
				return new JSONObject(jb.toString());
			}
			else
			{
				return new JSONObject();
			}
		}
	}

	public static void setResponseJSON(HttpServletResponse response, JSONObject resp)
	{
		try
		{
			PrintWriter out = response.getWriter();
			response.setContentType(JsonApiConstants.JSON_CONTENT_TYPE);
			out.println(resp.toString());
			out.close();
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, " ", e);
		}
	}

	public static JSONObject getErrorObject(String attr, String errMsg)
	{
		JSONObject errObj = new JSONObject();

		errObj.put(JsonApiConstants.DETAIL, errMsg);
		errObj.put(JsonApiConstants.SOURCE, new JSONObject().put(JsonApiConstants.POINTER, DATA_ATTRIBUTES_PATH + attr));

		return errObj;
	}

	public static JSONObject getBaseErrorObject(String errMsg)
	{
		JSONObject errObj = new JSONObject();

		errObj.put(JsonApiConstants.DETAIL, errMsg);
		errObj.put(JsonApiConstants.SOURCE, new JSONObject().put(JsonApiConstants.POINTER, DATA_PATH));

		return errObj;
	}

	public static JSONObject getResourceObject(String type, String id, JSONObject attributes)
	{
		return getResourceObject(type, id, attributes, null);
	}

	public static JSONObject getResourceObject(String type, String id, JSONObject attributes, JSONObject relationships)
	{
		JSONObject data = new JSONObject();
		data.put(JsonApiConstants.TYPE, type);
		data.put(JsonApiConstants.ID, id);
		data.put(JsonApiConstants.ATTRIBUTES, attributes);
		data.put(JsonApiConstants.RELATIONSHIPS, relationships);
		return data;
	}

	public static JSONObject getResourceObject(JSONObject data)
	{
		JSONObject resObj = new JSONObject();
		resObj.put(JsonApiConstants.DATA, data);
		return resObj;
	}

	public static JSONObject getResourceObject(JSONArray data)
	{
		JSONObject resObj = new JSONObject();
		resObj.put(JsonApiConstants.DATA, data);
		return resObj;
	}

	public static JSONObject getResourceIdentifierObject(String type, String id)
	{
		return getResourceObject(type, id, null, null);
	}

	public static Long getResourceId(JSONObject requestJson, JSONObject respJson)
	{
		Long id = null;

		if (requestJson.has(JsonApiConstants.DATA))
		{
			JSONObject data = requestJson.getJSONObject(JsonApiConstants.DATA);
			if (data.has(JsonApiConstants.ID))
			{
				id = data.getLong(JsonApiConstants.ID);
			}
		}

		if (id == null && respJson != null)
		{
			//Create resource case
			if (respJson.has(JsonApiConstants.DATA))
			{
				//No errors case
				JSONObject respData = respJson.getJSONObject(JsonApiConstants.DATA);
				if (respData.has(JsonApiConstants.ID))
				{
					id = respData.getLong(JsonApiConstants.ID);
				}
			}
		}
		return id;
	}

}
