package com.manageengine.idmpod.server.zstore;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.User;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Persistence;
import com.adventnet.persistence.Row;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.error.ErrorCode;
import com.manageengine.idmpod.server.error.IdmpodException;
import com.manageengine.idmpod.server.iam.IdmpodUserRole;
import com.manageengine.idmpod.server.utils.IdmpodThreadLocal;
import com.manageengine.idmpod.server.utils.IdmpodUtils;
import com.manageengine.tables.idmpod.IDMPODSUBSCRIPTIONS;
import com.manageengine.tables.idmpod.IDMPODTECHNICIAN;
import org.apache.commons.lang3.time.DateUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LicenseUtil
{
	private static final Logger LOGGER = Logger.getLogger(LicenseUtil.class.getName());

	public static final Long PLANID_FREE = 700100L;
	public static final Long PLANID_TRIAL = 1L;
	public static final String PLANTYPE_FREE = "FREE";//No I18N
	public static final String PLANTYPE_TRIAL = "TRIAL";//No I18N
	public static final String PLANTYPE_REGISTERED = "REGISTERED";//No I18N
	public static final Long DAYS_30 = (30l * 24 * 60 * 60 * 1000);

	public static void enforceLicenseRestrictions(String zaaid, Row licenseRow)
	{
		Long usersCount = Long.parseLong(licenseRow.get(IDMPODSUBSCRIPTIONS.NO_OF_USERS).toString());
		if (usersCount == -1L)
		{
			return;
		}
		else
		{
			int activeUserCount = DBUtils.getCount(IDMPODTECHNICIAN.TABLE, new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.STATUS), "ACTIVE", QueryConstants.EQUAL, false), zaaid);
			if (activeUserCount > usersCount)
			{
				Criteria deActCrit = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.STATUS), "ACTIVE", QueryConstants.EQUAL, false);
				deActCrit = deActCrit.and(new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ROLE), IdmpodUserRole.USER.toString(), QueryConstants.EQUAL, true));
				try
				{
					DataObject dataObject = DBUtils.getAAPersistence(zaaid).get(IDMPODTECHNICIAN.TABLE, deActCrit);
					if (dataObject.containsTable(IDMPODTECHNICIAN.TABLE))
					{
						Iterator<Row> rows = dataObject.getRows(IDMPODTECHNICIAN.TABLE);
						while (rows.hasNext())
						{
							Row row = rows.next();
							row.set(IDMPODTECHNICIAN.STATUS, "INACTIVE");//No I18N
							dataObject.updateRow(row);
							DBUtils.getAAPersistence(zaaid).update(dataObject);
						}
					}
				}
				catch (Exception e)
				{
					LOGGER.log(Level.SEVERE, e.getMessage(), e);
				}
			}
		}
	}

	public static void startTrial(String zaaid) throws Exception
	{
		DataObject licenseDo = getLicenseDetailsDO(zaaid, true);
		Plan trialPlan = getPlan(PLANID_TRIAL);
		Long expiryTime = DateUtils.ceiling(new Date(), Calendar.DATE).getTime() + DAYS_30;
		if (licenseDo.containsTable(IDMPODSUBSCRIPTIONS.TABLE))
		{
			Row licenseRow = licenseDo.getFirstRow(IDMPODSUBSCRIPTIONS.TABLE);
			licenseRow.set(IDMPODSUBSCRIPTIONS.ZID, zaaid);
			licenseRow.set(IDMPODSUBSCRIPTIONS.PROFILEID, zaaid);
			licenseRow.set(IDMPODSUBSCRIPTIONS.PLANID, trialPlan.getPlanId());
			licenseRow.set(IDMPODSUBSCRIPTIONS.PLANNAME, trialPlan.getPlanName());
			licenseRow.set(IDMPODSUBSCRIPTIONS.PLANTYPE, trialPlan.getPlanType());
			licenseRow.set(IDMPODSUBSCRIPTIONS.NO_OF_USERS, trialPlan.getMaxUsers());
			licenseRow.set(IDMPODSUBSCRIPTIONS.EXPIRYTIME, expiryTime);
			licenseDo.updateRow(licenseRow);
			DBUtils.getAAPersistence(zaaid).update(licenseDo);
			enforceLicenseRestrictions(zaaid, licenseRow);
			LOGGER.log(Level.INFO, "Trial started for {0}", zaaid);
		}
		else
		{
			Row licenseRow = new Row(IDMPODSUBSCRIPTIONS.TABLE);
			licenseRow.set(IDMPODSUBSCRIPTIONS.ZID, zaaid);
			licenseRow.set(IDMPODSUBSCRIPTIONS.PROFILEID, zaaid);
			licenseRow.set(IDMPODSUBSCRIPTIONS.PLANID, trialPlan.getPlanId());
			licenseRow.set(IDMPODSUBSCRIPTIONS.PLANNAME, trialPlan.getPlanName());
			licenseRow.set(IDMPODSUBSCRIPTIONS.PLANTYPE, trialPlan.getPlanType());
			licenseRow.set(IDMPODSUBSCRIPTIONS.NO_OF_USERS, trialPlan.getMaxUsers());
			licenseRow.set(IDMPODSUBSCRIPTIONS.EXPIRYTIME, expiryTime);
			licenseDo.addRow(licenseRow);
			DBUtils.getAAPersistence(zaaid).add(licenseDo);
			enforceLicenseRestrictions(zaaid, licenseRow);
			LOGGER.log(Level.INFO, "Trial started for {0}", zaaid);
		}
	}

	public static Row downgrade2Free(String zaaid) throws Exception
	{
		return downgrade2Free(zaaid, true);
	}

	public static Row downgrade2Free(String zaaid, boolean isMig) throws Exception
	{
		DataObject licenseDo = getLicenseDetailsDO(zaaid, isMig);
		Plan freePlan = getPlan(PLANID_FREE);
		if (licenseDo.containsTable(IDMPODSUBSCRIPTIONS.TABLE))
		{
			Row licenseRow = licenseDo.getFirstRow(IDMPODSUBSCRIPTIONS.TABLE);
			licenseRow.set(IDMPODSUBSCRIPTIONS.ZID, zaaid);
			licenseRow.set(IDMPODSUBSCRIPTIONS.PROFILEID, zaaid);
			licenseRow.set(IDMPODSUBSCRIPTIONS.PLANID, freePlan.getPlanId());
			licenseRow.set(IDMPODSUBSCRIPTIONS.PLANNAME, freePlan.getPlanName());
			licenseRow.set(IDMPODSUBSCRIPTIONS.PLANTYPE, freePlan.getPlanType());
			licenseRow.set(IDMPODSUBSCRIPTIONS.NO_OF_USERS, freePlan.getMaxUsers());
			licenseRow.set(IDMPODSUBSCRIPTIONS.EXPIRYTIME, -1);
			licenseDo.updateRow(licenseRow);
			DBUtils.getAAPersistence(zaaid).update(licenseDo);
			enforceLicenseRestrictions(zaaid, licenseRow);
			LOGGER.log(Level.INFO, "Account {0} downgraded to free", zaaid);
			return licenseRow;
		}
		else if (isMig)
		{
			Row licenseRow = new Row(IDMPODSUBSCRIPTIONS.TABLE);
			licenseRow.set(IDMPODSUBSCRIPTIONS.ZID, zaaid);
			licenseRow.set(IDMPODSUBSCRIPTIONS.PROFILEID, zaaid);
			licenseRow.set(IDMPODSUBSCRIPTIONS.PLANID, freePlan.getPlanId());
			licenseRow.set(IDMPODSUBSCRIPTIONS.PLANNAME, freePlan.getPlanName());
			licenseRow.set(IDMPODSUBSCRIPTIONS.PLANTYPE, freePlan.getPlanType());
			licenseRow.set(IDMPODSUBSCRIPTIONS.NO_OF_USERS, freePlan.getMaxUsers());
			licenseRow.set(IDMPODSUBSCRIPTIONS.EXPIRYTIME, -1);
			licenseDo.addRow(licenseRow);
			DBUtils.getAAPersistence(zaaid).add(licenseDo);
			enforceLicenseRestrictions(zaaid, licenseRow);
			LOGGER.log(Level.INFO, "Account {0} downgraded to free", zaaid);
			return licenseRow;
		}
		else
		{
			LOGGER.log(Level.SEVERE, "Unusual: account {0} does not have any license row, please check.", zaaid);
		}
		return null;
	}

	public static JSONObject getSubscriptionDetails(String zaaid)
	{

		JSONObject subs = new JSONObject();
		try
		{
			Row licRow = LicenseUtil.getLicenseDetailsRow(zaaid, true);
			if (licRow != null)
			{
				DBUtils.rowToJson(licRow, subs);
			}
			else
			{
				licRow = downgrade2Free(zaaid, true);
				IdmpodUtils.setOrgPreference(DBUtils.getAAPersistence(zaaid), "STATUS", "OPEN");//NO I18N
				DBUtils.rowToJson(licRow, subs);
			}
			int activeUserCount = DBUtils.getCount(IDMPODTECHNICIAN.TABLE, new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.STATUS), "ACTIVE", QueryConstants.EQUAL, false), zaaid);
			subs.put("ACTIVE_USER_COUNT", activeUserCount);
			try
			{
				subs.put("STATUS", IdmpodUtils.getOrgPreference(DBUtils.getReadOnlyAAPersistence(zaaid), "STATUS"));
			}
			catch (Exception e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		return subs;
	}

	public static JSONObject getCurrentSubscriptionDetails()
	{
		return getSubscriptionDetails(IdmpodThreadLocal.getAppId());
	}

	public static boolean allowAddUsers(int i)
	{
		return allowAddUsers(i, false);
	}

	public static boolean allowAddUsers(int i, boolean throwEx)
	{
		long maxUsers = getCurrentSubscriptionDetails().optLong(IDMPODSUBSCRIPTIONS.NO_OF_USERS, -1L);
		int activeUserCount = DBUtils.getCount(IDMPODTECHNICIAN.TABLE, new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.STATUS), "ACTIVE", QueryConstants.EQUAL, false), IdmpodThreadLocal.getAppId());
		if (maxUsers == -1 || (maxUsers - activeUserCount) >= i)
		{
			return true;
		}
		if (throwEx)
		{
			throw new IdmpodException(ErrorCode.USER_LIMIT_REACHED);
		}
		else
		{
			return false;
		}
	}

	public static class Addon
	{

		private long addonId;
		private String addonType;
		private String addonName;
		private int max;
		private int costPerMonth;// In dollar

		public Addon(JSONObject addonJson) throws JSONException
		{
			this.addonId = addonJson.getLong("ADDONID");//No I18N
			this.addonType = addonJson.getString("ADDONTYPE");
			this.addonName = addonJson.getString("ADDONNAME");
			this.max = addonJson.getInt("MAX");//No I18N
			this.costPerMonth = addonJson.getInt("COSTPERMONTH");//No I18N
		}

		/**
		 * To get the addon ID.
		 *
		 * @return
		 */
		public long getAddonId()
		{
			return this.addonId;
		}

		/**
		 * To get the addon type - USER.
		 *
		 * @return
		 */
		public String getAddonType()
		{
			return this.addonType;
		}

		/**
		 * To get the addon name - User.
		 *
		 * @return
		 */
		public String getAddonName()
		{
			return this.addonName;
		}

		/**
		 * To get the maximum limit for the addon.
		 *
		 * @return maximum limit
		 */
		public int getMax()
		{
			return this.max;
		}

		/**
		 * To get the cost per month for the addon. Useful when the addon object is defined under a licensing plan.
		 *
		 * @return cost per month
		 */
		public int getCostPerMonth()
		{
			return this.costPerMonth;
		}
	}

	public static class Plan
	{
		private long planId;
		private String planType;
		private String planName;
		private Addon userAddon;

		public Plan(JSONObject planJson) throws JSONException
		{
			this.planId = planJson.getLong("PLANID");//No I18N
			this.planType = planJson.getString("PLANTYPE");
			this.planName = planJson.getString("PLANNAME");
			this.userAddon = new Addon(planJson.getJSONObject("ADDON"));//No I18N
		}

		/**
		 * To get the plan ID of the current instance.
		 *
		 * @return Plan ID as <code>long</code>
		 */
		public long getPlanId()
		{
			return this.planId;
		}

		/**
		 * To get the plan type of the current instance.
		 *
		 * @return Plan type
		 */
		public String getPlanType()
		{
			return this.planType;
		}

		/**
		 * To get the plan name of the current instance.
		 *
		 * @return Plan name
		 */
		public String getPlanName()
		{
			return this.planName;
		}

		/**
		 * To get the user addon.
		 *
		 * @return
		 */
		public Addon getUserAddon()
		{
			return this.userAddon;
		}

		/**
		 * To get the maximum number of allowed users under the current plan.
		 *
		 * @return Maximum number of allowed users
		 */
		public int getMaxUsers()
		{
			return this.userAddon.getMax();
		}
	}

	public static Row getLicenseDetailsRow(String zId, boolean isInternal) throws Exception
	{
		Criteria paymentsSubCrit = null;
		if (!isInternal)
		{
			paymentsSubCrit = new Criteria(Column.getColumn(IDMPODSUBSCRIPTIONS.TABLE, IDMPODSUBSCRIPTIONS.PLANTYPE), PLANTYPE_TRIAL, QueryConstants.NOT_EQUAL, false);
		}
		DataObject licenseDo = DBUtils.getReadOnlyAAPersistence(zId).get(IDMPODSUBSCRIPTIONS.TABLE, paymentsSubCrit);
		if (licenseDo.size(IDMPODSUBSCRIPTIONS.TABLE) > -1)
		{
			return licenseDo.getFirstRow(IDMPODSUBSCRIPTIONS.TABLE);
		}
		else
		{
			LOGGER.log(Level.SEVERE, "User license row returning null");
			return null;
		}
	}

	public static boolean isTrial(String zaaid)
	{
		boolean trial = false;

		Criteria paymentsSubCrit = new Criteria(Column.getColumn(IDMPODSUBSCRIPTIONS.TABLE, IDMPODSUBSCRIPTIONS.PLANTYPE), PLANTYPE_TRIAL, QueryConstants.EQUAL, false);
		try
		{
			DataObject licenseDo = DBUtils.getAAPersistence(zaaid).get(IDMPODSUBSCRIPTIONS.TABLE, paymentsSubCrit);
			if (licenseDo.containsTable(IDMPODSUBSCRIPTIONS.TABLE))
			{
				trial = true;
			}
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		return trial;
	}

	public static Row getLicenseDetailsRow(String zId) throws Exception
	{
		return getLicenseDetailsRow(zId, false);
	}

	public static DataObject getLicenseDetailsDO(String zId) throws Exception
	{
		return getLicenseDetailsDO(zId, true);
	}

	public static DataObject getLicenseDetailsDO(String zId, boolean isInternal) throws Exception
	{
		Criteria paymentsSubCrit = null;
		if (!isInternal)
		{
			paymentsSubCrit = new Criteria(Column.getColumn(IDMPODSUBSCRIPTIONS.TABLE, IDMPODSUBSCRIPTIONS.PLANTYPE), PLANTYPE_TRIAL, QueryConstants.NOT_EQUAL, false);
		}
		DataObject licenseDo = DBUtils.getAAPersistence(zId).get(IDMPODSUBSCRIPTIONS.TABLE, paymentsSubCrit);
		return licenseDo;
	}

	public static Plan getPlan(Long planId) throws IOException, JSONException
	{
		JSONArray allPlans = getLicensingPlans();
		int plansCount = allPlans.length();

		Plan plan = null;
		for (int i = 0; i < plansCount; i++)
		{
			JSONObject planJson = (JSONObject) allPlans.get(i);
			if (planId.equals(planJson.getLong(IDMPODSUBSCRIPTIONS.PLANID)))
			{
				plan = new Plan(planJson);
				break;
			}
		}

		return plan;
	}

	private static JSONArray licensingPlans = null;

	public static JSONArray getLicensingPlans() throws IOException, JSONException
	{
		if (licensingPlans == null)
		{
			// Read the <SERVER_HOME>/conf/setup/LicensePlan.txt file and instantiate licensePlanJson
			String lpFilePath = com.zoho.conf.Configuration.getString("app.home") + File.separator + "conf" + File.separator + "idmpod" + File.separator + "LicensePlan.txt";//No I18N
			LOGGER.log(Level.FINE, "Licensing plan file: {0}", lpFilePath);
			File licensePlanFile = new File(lpFilePath);
			BufferedReader br = null;
			try
			{
				br = new BufferedReader(new FileReader(licensePlanFile));
				String line;
				licensingPlans = new JSONArray();
				while ((line = br.readLine()) != null)
				{
					// Check and ignore blank lines or comment lines starting with "##"
					if (line != null && line.trim().length() > 0 && !line.startsWith("##"))
					{
						licensingPlans.put(new JSONObject(line));
					}
				}
			}
			finally
			{
				if (br != null)
				{
					br.close();
				}
			}
		}

		return licensingPlans;
	}

	public static JSONArray getPaymentAdmins(String zaaid) throws Exception
	{
		Persistence persistence = DBUtils.getAAPersistence(zaaid);
		Criteria selectCriteria = new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ROLE), IdmpodUserRole.getString(IdmpodUserRole.SUPER_ADMIN), QueryConstants.EQUAL).or(new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.ORG_ROLE), User.SUPER_ADMIN, QueryConstants.EQUAL));
		selectCriteria = selectCriteria.and(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.STATUS), "ACTIVE", QueryConstants.EQUAL, false);//NO I18N
		DataObject dataObject = persistence.get(IDMPODTECHNICIAN.TABLE, selectCriteria);
		Iterator<?> rows = dataObject.getRows(IDMPODTECHNICIAN.TABLE);
		JSONArray orgAdmins = new JSONArray();
		while (rows.hasNext())
		{
			Row row = (Row) rows.next();
			Long zuid = (Long) row.get(IDMPODTECHNICIAN.ZUID);
			orgAdmins.put(zuid);
		}
		return orgAdmins;
	}
}
