package com.manageengine.idmpod.server.iam.directory;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.*;
import com.adventnet.i18n.I18N;
import com.adventnet.iam.*;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.QueryConstructor;
import com.adventnet.persistence.Row;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.api.json.MSRestApiInterface;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.error.ErrorCode;
import com.manageengine.idmpod.server.error.IdmpodException;
import com.manageengine.idmpod.server.iam.*;
import com.manageengine.idmpod.server.utils.ScheduleUtil;
import com.manageengine.idmpod.server.zstore.LicenseUtil;
import com.manageengine.tables.idmpod.*;
import com.microsoft.azure.AzureEnvironment;
import com.zoho.sas.container.AppResources;
import com.zoho.scheduler.*;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import org.json.JSONArray;
import org.json.JSONObject;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

import javax.naming.*;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import java.io.IOException;
import java.sql.Connection;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

import static com.manageengine.idmpod.server.db.DBUtils.datasetToJson;

public class DirectoryHandler
{
	private static final Logger LOGGER = Logger.getLogger(DirectoryHandler.class.getName());

	public static JSONArray getDirectoryTypes()
	{
		final String TYPE = JsonApiHandler.ResourceType.DIRECTORY_TYPE.getResType();
		JSONArray directoryTypes = new JSONArray();
		try
		{
			ArrayList<String> tablesList = new ArrayList<String>();
			tablesList.add(IDMPODDIRECTORYTYPES.TABLE);

			boolean[] isLeftJoins = new boolean[tablesList.size()];
			Arrays.fill(isLeftJoins, true);

			Criteria criteria = new Criteria(Column.getColumn(IDMPODDIRECTORYTYPES.TABLE, IDMPODDIRECTORYTYPES.TYPE_HANDLER), "ActiveDirectory", QueryConstants.NOT_EQUAL, false);

			SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, criteria);

			DataObject directoryTypesDO = DBUtils.getOrgPersistence().get(query);
			if (!directoryTypesDO.isEmpty())
			{
				if (directoryTypesDO.containsTable(IDMPODDIRECTORYTYPES.TABLE))
				{
					for (Iterator<Row> it = directoryTypesDO.getRows(IDMPODDIRECTORYTYPES.TABLE); it.hasNext(); )
					{
						Row r = it.next();
						JSONObject directoryTypeAttrs = DBUtils.rowToJson(r);
						JSONObject directoryType = new JSONObject();
						directoryType.put(JsonApiConstants.ID, directoryTypeAttrs.get(IDMPODDIRECTORYTYPES.DIRECTORY_TYPE_ID));
						directoryType.put(JsonApiConstants.TYPE, TYPE);
						directoryType.put(JsonApiConstants.ATTRIBUTES, directoryTypeAttrs);
						directoryTypes.put(directoryType);
					}
				}
			}

		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return directoryTypes;
	}

	public static JSONObject getDirectoryType(Long typeid)
	{
		final String TYPE = JsonApiHandler.ResourceType.DIRECTORY_TYPE.getResType();
		JSONObject directoryType = null;
		try
		{
			ArrayList<String> tablesList = new ArrayList<String>();
			tablesList.add(IDMPODDIRECTORYTYPES.TABLE);

			boolean[] isLeftJoins = new boolean[tablesList.size()];
			Arrays.fill(isLeftJoins, true);

			SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, new Criteria(Column.getColumn(IDMPODDIRECTORYTYPES.TABLE, IDMPODDIRECTORYTYPES.DIRECTORY_TYPE_ID), typeid, QueryConstants.EQUAL));

			DataObject directoryTypesDO = DBUtils.getOrgPersistence().get(query);
			if (!directoryTypesDO.isEmpty())
			{
				if (directoryTypesDO.containsTable(IDMPODDIRECTORYTYPES.TABLE))
				{
					Row r = directoryTypesDO.getFirstRow(IDMPODDIRECTORYTYPES.TABLE);
					JSONObject directoryTypeAttrs = DBUtils.rowToJson(r);
					directoryType = new JSONObject();
					directoryType.put(JsonApiConstants.ID, typeid);
					directoryType.put(JsonApiConstants.TYPE, TYPE);
					directoryType.put(JsonApiConstants.ATTRIBUTES, directoryTypeAttrs);
				}
			}

		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return directoryType;
	}

	public static Boolean verifyLdapCredentials(JSONObject request, JSONObject resp)
	{
		Boolean verified = false;

		// LOGGER.info(request.toString(4));

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		String username = attributes.getString("SERVICE_ACCOUNT_USERNAME");//"CN=Administrator,CN=Users,DC=omp,DC=local";//No I18N
		String password = attributes.getString("SERVICE_ACCOUNT_PASSWORD");//"Laptop@135";//No I18N

		Hashtable<String, String> env = new Hashtable<>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, attributes.getString("LDAP_CONNECTION_URL"));
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, username); // use DN
		env.put(Context.SECURITY_CREDENTIALS, password);
		env.put(Context.REFERRAL, "follow");

		DirContext ctx = null;

		JSONArray errors = resp.has(JsonApiConstants.ERRORS) ? resp.getJSONArray(JsonApiConstants.ERRORS) : new JSONArray();
		try
		{
			ctx = new InitialDirContext(env);
			SearchControls controls = new SearchControls();
			controls.setSearchScope(SearchControls.OBJECT_SCOPE);
			NamingEnumeration<SearchResult> results = ctx.search(attributes.getString("SERVICE_ACCOUNT_CONTEXT_NAME"), "(objectclass=person)", controls);//No I18N
			while (results.hasMore())
			{
				SearchResult sr = results.next();
				// LOGGER.info(sr.toString());
			}
			verified = true;
		}
		catch (AuthenticationException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			errors.put(JsonApiHandler.getBaseErrorObject(e.getMessage()));
		}
		catch (NameNotFoundException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			errors.put(JsonApiHandler.getBaseErrorObject(e.getMessage()));
		}
		catch (NamingException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			errors.put(JsonApiHandler.getBaseErrorObject(e.getMessage()));
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			errors.put(JsonApiHandler.getBaseErrorObject(e.getMessage()));
		}
		finally
		{
			if (ctx != null)
			{
				try
				{
					ctx.close();
				}
				catch (NamingException e)
				{
					LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
				}
			}
			if (errors != null && errors.length() > 0)
			{
				resp.put(JsonApiConstants.ERRORS, errors);
			}
		}


		return verified;
	}

	public static JSONArray getDirectories()
	{
		final String TYPE = JsonApiHandler.ResourceType.DIRECTORY.getResType();
		JSONArray directories = new JSONArray();
		try
		{
			directories.put(getInternalDirectory());

			ArrayList<String> tablesList = new ArrayList<String>();
			tablesList.add(IDMPODDIRECTORIES.TABLE);
			tablesList.add(IDMPODDIRECTORYPARAMS.TABLE);

			boolean[] isLeftJoins = new boolean[tablesList.size()];
			Arrays.fill(isLeftJoins, true);

			SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, (Criteria) null);

			DataObject directoriesDO = DBUtils.getOrgPersistence().get(query);
			if (!directoriesDO.isEmpty())
			{
				if (directoriesDO.containsTable(IDMPODDIRECTORIES.TABLE))
				{
					for (Iterator<Row> it = directoriesDO.getRows(IDMPODDIRECTORIES.TABLE); it.hasNext(); )
					{
						Row r = it.next();
						JSONObject directoryAttrs = DBUtils.rowToJson(r);
						if (directoriesDO.containsTable(IDMPODDIRECTORYPARAMS.TABLE))
						{
							for (Iterator<Row> pit = directoriesDO.getRows(IDMPODDIRECTORYPARAMS.TABLE, new Criteria(Column.getColumn(IDMPODDIRECTORYPARAMS.TABLE, IDMPODDIRECTORYPARAMS.DIRECTORY_ID), directoryAttrs.get(IDMPODDIRECTORIES.DIRECTORY_ID), QueryConstants.EQUAL)); pit.hasNext(); )
							{
								Row pr = pit.next();
								directoryAttrs.put((String) pr.get(IDMPODDIRECTORYPARAMS.PARAM_NAME), pr.get(IDMPODDIRECTORYPARAMS.ENCRYPTED_PARAM_VALUE));
							}
						}
						//Set last sync details
						DataObject jobDOForDirectory = getJobDOForDirectory(directoryAttrs.getLong(IDMPODDIRECTORIES.DIRECTORY_ID));
						if (jobDOForDirectory.containsTable(IDMPODDIRECTORYJOBS.TABLE))
						{
							Row jobRowForDirectory = jobDOForDirectory.getFirstRow(IDMPODDIRECTORYJOBS.TABLE);
							Long jobId = (Long) jobRowForDirectory.get(IDMPODDIRECTORYJOBS.JOB_ID);
							getLastSyncStatusForJob(jobId, directoryAttrs);
							getLastSyncStatusForDirectory(directoryAttrs.getLong(IDMPODDIRECTORIES.DIRECTORY_ID), directoryAttrs);
							Repetition repetition = ScheduleUtil.getRepetition(jobId.toString());
							Job job = ScheduleUtil.fetchJobDetails(jobId);
							if (repetition instanceof PeriodicRepetition)
							{
								try
								{
									ScheduleUtil.convertPeriodicToCalendar(jobId);
									repetition = ScheduleUtil.getRepetition(jobId.toString());
								}
								catch (Exception e)
								{
									LOGGER.log(Level.INFO, e.getMessage(), e);
								}
							}

							IdmpodCalendarRepetition idmpodCalendarRepetition = new IdmpodCalendarRepetition((CalendarRepetition) repetition);
							JSONObject executionTimeInfo = idmpodCalendarRepetition.getExecutionTimeInfo();

							directoryAttrs.put("DAILY_SYNC_TIME_HOUR", executionTimeInfo.getInt("HOURS"));
							directoryAttrs.put("DAILY_SYNC_TIME_MIN", executionTimeInfo.getInt("MINUTES"));
							directoryAttrs.put("SYNC_SETUP", true);
						}
						else
						{
							directoryAttrs.put("LAST_SYNCHED_STATUS", I18N.getMsg("idmpod.directory_settings.directory.list.sync_status.config_incomplete"));
							directoryAttrs.put("SYNC_SETUP", false);
						}
						//Finish set last sync details
						JSONObject directory = new JSONObject();
						JSONObject relationship = new JSONObject();
						relationship.put("directory-type", JsonApiHandler.getResourceObject(JsonApiHandler.getResourceIdentifierObject("directory-types", directoryAttrs.get(IDMPODDIRECTORIES.DIRECTORY_TYPE_ID).toString())));
						directory.put(JsonApiConstants.ID, directoryAttrs.get(IDMPODDIRECTORIES.DIRECTORY_ID));
						directory.put(JsonApiConstants.TYPE, TYPE);
						directory.put(JsonApiConstants.ATTRIBUTES, directoryAttrs);
						directory.put(JsonApiConstants.RELATIONSHIPS, relationship);
						directories.put(directory);
					}
				}
			}

		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return directories;
	}

	private static JSONObject getLastSyncStatusForDirectory(Long directoryId, JSONObject directoryAttrs)
	{
		JSONObject lastSyncDetails = null;
		ArrayList<String> tablesList = new ArrayList<String>();

		tablesList.add(IDMPODDIRECTORYJOBS.TABLE);
		tablesList.add(IDMPODDIRECTORYSYNCDETAILS.TABLE);

		boolean[] isLeftJoins = new boolean[tablesList.size()];
		Arrays.fill(isLeftJoins, true);

		Criteria crit = new Criteria(new Column(IDMPODDIRECTORYJOBS.TABLE, IDMPODDIRECTORYJOBS.DIRECTORY_ID), directoryId, QueryConstants.EQUAL);

		try
		{
			SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, crit);
			query.setRange(new Range(1, 1));

			query.addSortColumn(new SortColumn(Column.getColumn(IDMPODDIRECTORYSYNCDETAILS.TABLE, IDMPODDIRECTORYSYNCDETAILS.SYNC_START_TIME), false));

			Connection connection = null;
			DataSet dataSet = null;
			try
			{
				RelationalAPI relationalAPI = DBUtils.getOrgRelationalApi();
				connection = relationalAPI.getConnection();
				dataSet = relationalAPI.executeQuery(query, connection);
				while (dataSet.next())
				{
					lastSyncDetails = DBUtils.datasetToJson(dataSet);
					directoryAttrs.put("LAST_SYNC_TIME", lastSyncDetails.get(IDMPODDIRECTORYSYNCDETAILS.SYNC_START_TIME));
					directoryAttrs.put("SYNCHED_OBJECTS", DBUtils.getCount(IDMPODSYNCHEDUSERS.TABLE, new Criteria(Column.getColumn(IDMPODSYNCHEDUSERS.TABLE, IDMPODSYNCHEDUSERS.SYNC_ID), lastSyncDetails.getLong(IDMPODDIRECTORYSYNCDETAILS.SYNC_ID), QueryConstants.EQUAL)));
					directoryAttrs.put("SYNC_STATUS", lastSyncDetails.get(IDMPODDIRECTORYSYNCDETAILS.SYNC_STATUS));
					try
					{
						directoryAttrs.put("LAST_SYNCHED_STATUS", I18N.getMsg("idmpod.directory_settings.directory.list.sync_status.sucess"));
					}
					catch (Exception e)
					{
						LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
					}
					break;
				}
			}
			catch (Exception e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
			finally
			{
				DBUtils.safeClose(connection, dataSet);
			}
		}
		catch (DataAccessException e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}

		return directoryAttrs;
	}

	private static JSONObject getLastSyncStatusForJob(Long jobId, JSONObject directoryAttrs)
	{
		JSONObject lastSyncDetails = getLastSyncInfoForJob(jobId);

		if (lastSyncDetails == null)
		{
			try
			{
				directoryAttrs.put("LAST_SYNCHED_STATUS", I18N.getMsg("idmpod.directory_settings.directory.list.sync_status.config_complete_schedule_notrun"));
			}
			catch (Exception e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
		}
		else
		{
			directoryAttrs.put("LAST_SYNC_TIME", lastSyncDetails.get(IDMPODDIRECTORYSYNCDETAILS.SYNC_START_TIME));
			directoryAttrs.put("SYNCHED_OBJECTS", DBUtils.getCount(IDMPODSYNCHEDUSERS.TABLE, new Criteria(Column.getColumn(IDMPODSYNCHEDUSERS.TABLE, IDMPODSYNCHEDUSERS.SYNC_ID), lastSyncDetails.getLong(IDMPODDIRECTORYSYNCDETAILS.SYNC_ID), QueryConstants.EQUAL)));
			try
			{
				directoryAttrs.put("LAST_SYNCHED_STATUS", I18N.getMsg("idmpod.directory_settings.directory.list.sync_status.sucess"));
			}
			catch (Exception e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
		}

		return directoryAttrs;
	}

	private static JSONObject getLastSyncInfoForJob(Long jobId)
	{
		JSONObject lastSyncDetails = null;
		SelectQuery query = new SelectQueryImpl(Table.getTable(IDMPODDIRECTORYSYNCDETAILS.TABLE));
		query.addSelectColumn(Column.getColumn(IDMPODDIRECTORYSYNCDETAILS.TABLE, "*"));

		query.setCriteria(new Criteria(Column.getColumn(IDMPODDIRECTORYSYNCDETAILS.TABLE, IDMPODDIRECTORYSYNCDETAILS.JOB_ID), jobId, QueryConstants.EQUAL));

		query.setRange(new Range(1, 1));

		query.addSortColumn(new SortColumn(Column.getColumn(IDMPODDIRECTORYSYNCDETAILS.TABLE, IDMPODDIRECTORYSYNCDETAILS.SYNC_START_TIME), false));

		Connection connection = null;
		DataSet dataSet = null;
		try
		{
			RelationalAPI relationalAPI = DBUtils.getOrgRelationalApi();
			connection = relationalAPI.getConnection();
			dataSet = relationalAPI.executeQuery(query, connection);
			while (dataSet.next())
			{
				lastSyncDetails = DBUtils.datasetToJson(dataSet);
			}
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		finally
		{
			DBUtils.safeClose(connection, dataSet);
		}

		return lastSyncDetails;
	}


	public static JSONObject getDirectory(Long directoryId)
	{
		JSONObject directory = null;
		final String TYPE = JsonApiHandler.ResourceType.DIRECTORY.getResType();
		try
		{
			if (directoryId == 0L)
			{
				return getInternalDirectory();
			}
			ArrayList<String> tablesList = new ArrayList<String>();
			tablesList.add(IDMPODDIRECTORIES.TABLE);
			tablesList.add(IDMPODDIRECTORYPARAMS.TABLE);

			boolean[] isLeftJoins = new boolean[tablesList.size()];
			Arrays.fill(isLeftJoins, true);

			Criteria dirCrit = new Criteria(Column.getColumn(IDMPODDIRECTORIES.TABLE, IDMPODDIRECTORIES.DIRECTORY_ID), directoryId, QueryConstants.EQUAL);

			SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, dirCrit);

			DataObject directoriesDO = DBUtils.getOrgPersistence().get(query);

			if (!directoriesDO.isEmpty())
			{
				if (directoriesDO.containsTable(IDMPODDIRECTORIES.TABLE))
				{
					Row r = directoriesDO.getFirstRow(IDMPODDIRECTORIES.TABLE);
					JSONObject directoryAttrs = DBUtils.rowToJson(r);
					if (directoriesDO.containsTable(IDMPODDIRECTORYPARAMS.TABLE))
					{
						for (Iterator<Row> pit = directoriesDO.getRows(IDMPODDIRECTORYPARAMS.TABLE, new Criteria(Column.getColumn(IDMPODDIRECTORYPARAMS.TABLE, IDMPODDIRECTORYPARAMS.DIRECTORY_ID), directoryAttrs.get(IDMPODDIRECTORIES.DIRECTORY_ID), QueryConstants.EQUAL)); pit.hasNext(); )
						{
							Row pr = pit.next();
							directoryAttrs.put((String) pr.get(IDMPODDIRECTORYPARAMS.PARAM_NAME), pr.get(IDMPODDIRECTORYPARAMS.ENCRYPTED_PARAM_VALUE));
						}
					}
					//Set last sync details
					DataObject jobDOForDirectory = getJobDOForDirectory(directoryAttrs.getLong(IDMPODDIRECTORIES.DIRECTORY_ID));
					if (jobDOForDirectory.containsTable(IDMPODDIRECTORYJOBS.TABLE))
					{
						Row jobRowForDirectory = jobDOForDirectory.getFirstRow(IDMPODDIRECTORYJOBS.TABLE);
						Long jobId = (Long) jobRowForDirectory.get(IDMPODDIRECTORYJOBS.JOB_ID);
						getLastSyncStatusForJob(jobId, directoryAttrs);
						getLastSyncStatusForDirectory(directoryAttrs.getLong(IDMPODDIRECTORIES.DIRECTORY_ID), directoryAttrs);
						Repetition repetition = ScheduleUtil.getRepetition(jobId.toString());
						Job job = ScheduleUtil.fetchJobDetails(jobId);
						if (repetition instanceof PeriodicRepetition)
						{
							Integer periodicity = ((PeriodicRepetition) repetition).getPeriodicity();
							try
							{
								ScheduleUtil.convertPeriodicToCalendar(jobId);
								repetition = ScheduleUtil.getRepetition(jobId.toString());
							}
							catch (Exception e)
							{
								LOGGER.log(Level.INFO, e.getMessage(), e);
							}
						}

						IdmpodCalendarRepetition idmpodCalendarRepetition = new IdmpodCalendarRepetition((CalendarRepetition) repetition);
						JSONObject executionTimeInfo = idmpodCalendarRepetition.getExecutionTimeInfo();

						directoryAttrs.put("DAILY_SYNC_TIME_HOUR", executionTimeInfo.getInt("HOURS"));
						directoryAttrs.put("DAILY_SYNC_TIME_MIN", executionTimeInfo.getInt("MINUTES"));
						directoryAttrs.put("SYNC_SETUP", true);
					}
					else
					{
						directoryAttrs.put("LAST_SYNCHED_STATUS", I18N.getMsg("idmpod.directory_settings.directory.list.sync_status.config_incomplete"));
						directoryAttrs.put("SYNC_SETUP", false);
					}
					//Finish set last sync details
					directory = new JSONObject();
					JSONObject relationship = new JSONObject();
					relationship.put("directory-type", JsonApiHandler.getResourceObject(JsonApiHandler.getResourceIdentifierObject("directory-types", directoryAttrs.get(IDMPODDIRECTORIES.DIRECTORY_TYPE_ID).toString())));
					directory.put(JsonApiConstants.ID, directoryAttrs.get(IDMPODDIRECTORIES.DIRECTORY_ID));
					directory.put(JsonApiConstants.TYPE, TYPE);
					directory.put(JsonApiConstants.ATTRIBUTES, directoryAttrs);
					directory.put(JsonApiConstants.RELATIONSHIPS, relationship);
				}
			}

		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		finally
		{
			if (directory == null)
			{
				throw new IdmpodException(ErrorCode.API_RESOURCE_NOT_EXIST);
			}
		}
		return directory;
	}

	private static JSONObject getInternalDirectory()
	{
		JSONObject directory = new JSONObject();
		directory.put(JsonApiConstants.ID, 0L);
		directory.put(JsonApiConstants.TYPE, JsonApiHandler.ResourceType.DIRECTORY.getResType());
		JSONObject directoryAttrs = new JSONObject();

		directoryAttrs.put("DIRECTORY_DISPLAY_NAME", "Zoho");

		directory.put(JsonApiConstants.ATTRIBUTES, directoryAttrs);

		return directory;
	}

	public static JSONObject addDirectory(JSONObject data)
	{
		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);
		JSONObject relationships = data.getJSONObject(JsonApiConstants.RELATIONSHIPS);

		try
		{
			DataObject DO = DBUtils.getOrgPersistence().constructDataObject();

			Row r = new Row(IDMPODDIRECTORIES.TABLE);
			String directoryName = attributes.has("DIRECTORY_DISPLAY_NAME") && attributes.getString("DIRECTORY_DISPLAY_NAME").trim().length() != 0 ? attributes.getString("DIRECTORY_DISPLAY_NAME") : attributes.optString("BASE_DOMAIN_NAME");//No I18N
			r.set(IDMPODDIRECTORIES.DIRECTORY_NAME, directoryName);
			r.set(IDMPODDIRECTORIES.DIRECTORY_TYPE_ID, relationships.getJSONObject("directory-type").getJSONObject(JsonApiConstants.DATA).getLong(JsonApiConstants.ID));

			DO.addRow(r);

			for (String key : attributes.keySet())
			{
				Row pr = new Row(IDMPODDIRECTORYPARAMS.TABLE);
				pr.set(IDMPODDIRECTORYPARAMS.DIRECTORY_ID, r.get(IDMPODDIRECTORIES.DIRECTORY_ID));
				pr.set(IDMPODDIRECTORYPARAMS.PARAM_NAME, key);
				pr.set(IDMPODDIRECTORYPARAMS.ENCRYPTED_PARAM_VALUE, attributes.get(key));

				DO.addRow(pr);
			}

			DBUtils.getOrgPersistence().add(DO);

			Long directoryId = (Long) r.get(IDMPODDIRECTORIES.DIRECTORY_ID);

			data.put(JsonApiConstants.ID, directoryId);
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		return data;
	}

	public static JSONObject verifyAndAddActiveDirectory(JSONObject request, JSONObject resp)
	{

		Boolean verified = false;

		// LOGGER.info(request.toString(4));

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		String username = attributes.getString("SERVICE_ACCOUNT_USERNAME");//"CN=Administrator,CN=Users,DC=omp,DC=local";//No I18N
		String password = attributes.getString("SERVICE_ACCOUNT_PASSWORD");//"Laptop@135";//No I18N

		Hashtable<String, String> env = new Hashtable<>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, attributes.getString("LDAP_CONNECTION_URL"));
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, username); // use DN
		env.put(Context.SECURITY_CREDENTIALS, password);
		env.put(Context.REFERRAL, "follow");

		DirContext ctx = null;

		JSONArray errors = resp.has(JsonApiConstants.ERRORS) ? resp.getJSONArray(JsonApiConstants.ERRORS) : new JSONArray();
		JSONArray included = new JSONArray();
		try
		{
			ctx = new InitialDirContext(env);
			SearchControls controls = new SearchControls();
			controls.setSearchScope(SearchControls.OBJECT_SCOPE);
			NamingEnumeration<SearchResult> results = ctx.search(attributes.getString("SERVICE_ACCOUNT_CONTEXT_NAME"), "(objectclass=person)", controls);//No I18N
			while (results.hasMore())
			{
				SearchResult sr = results.next();
				// LOGGER.info(sr.toString());
			}
			verified = true;

			if (verified)
			{
				DirectoryHandler.addDirectory(data);
				JSONObject relationships = data.getJSONObject(JsonApiConstants.RELATIONSHIPS);
				String directoryId = data.optString(JsonApiConstants.ID);
				relationships.put("organizational-units", JsonApiHandler.getResourceObject(fetchAndUpdateOUs(env, ctx, attributes.getString("BASE_DOMAIN_NAME"), included, directoryId)));
			}

		}
		catch (AuthenticationException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			errors.put(JsonApiHandler.getBaseErrorObject(e.getMessage()));
		}
		catch (NameNotFoundException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			errors.put(JsonApiHandler.getBaseErrorObject(e.getMessage()));
		}
		catch (NamingException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			errors.put(JsonApiHandler.getBaseErrorObject(e.getMessage()));
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			errors.put(JsonApiHandler.getBaseErrorObject(e.getMessage()));
		}
		finally
		{
			if (ctx != null)
			{
				try
				{
					ctx.close();
				}
				catch (NamingException e)
				{
					LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
				}
			}
		}
		if (errors != null && errors.length() > 0)
		{
			resp.put(JsonApiConstants.ERRORS, errors);
		}
		else
		{
			resp.put(JsonApiConstants.DATA, data);
			if (included.length() > 0)
			{
				resp.put(JsonApiConstants.INCLUDED, included);
			}
		}
		return resp;
	}

	private static JSONArray fetchAndUpdateDomains(String authToken, String base_domain_name, JSONArray included, String directoryId, AzureEnvironment environment) throws DataAccessException, IOException
	{
		DataObject dObj = DBUtils.getOrgPersistence().get(IDMPODDIRECTORYNODES.TABLE, new Criteria(Column.getColumn(IDMPODDIRECTORYNODES.TABLE, IDMPODDIRECTORYNODES.DIRECTORY_ID), Long.valueOf(directoryId), QueryConstants.EQUAL));
		JSONArray resp = null;

		String graphEndpoint = environment.graphEndpoint();

		String urlString = graphEndpoint + base_domain_name + "/domains/";//No I18N

		Map<String, String> headers = new HashMap<>();
		headers.put("authorization", "Bearer " + authToken);
		headers.put("Accept", "application/json");
		headers.put("Content-Type", "application/json");

		OkHttpClient httpClient = new OkHttpClient().newBuilder().build();
		Retrofit retrofit = new Retrofit.Builder().baseUrl(urlString).client(httpClient).addCallAdapterFactory(RxJavaCallAdapterFactory.create()).addConverterFactory(GsonConverterFactory.create()).build();
		MSRestApiInterface service = retrofit.create(MSRestApiInterface.class);
		Map<String, String> query = new HashMap<>();
		query.put("api-version", "1.6");
		Call<ResponseBody> call3 = service.getRawjson(urlString, query, headers);
		Response<ResponseBody> response = call3.execute();

		if (response.code() == 200)
		{
			JsonParser parser = new JsonParser();
			JsonObject appResponse = parser.parse(response.body().string()).getAsJsonObject();
			JSONObject oresponse = new JSONObject(appResponse.toString());
			JSONArray domains = oresponse.getJSONArray("value");//No I18N
			for (int i = 0; i < domains.length(); i++)
			{
				JSONObject domain = domains.getJSONObject(i);
				String domainName = domain.getString("name");

				Row domainRow = dObj.getRow(IDMPODDIRECTORYNODES.TABLE, new Criteria(Column.getColumn(IDMPODDIRECTORYNODES.TABLE, IDMPODDIRECTORYNODES.NODE_IDENTIFIER), domainName, QueryConstants.EQUAL, false));
				if (domainRow == null && domain.getBoolean("isVerified"))
				{
					domainRow = new Row(IDMPODDIRECTORYNODES.TABLE);

					domainRow.set(IDMPODDIRECTORYNODES.NODE_IDENTIFIER, domainName);
					domainRow.set(IDMPODDIRECTORYNODES.NODE_DISPLAY_NAME, domainName);
					domainRow.set(IDMPODDIRECTORYNODES.DIRECTORY_ID, directoryId);

					dObj.addRow(domainRow);

					DBUtils.getOrgPersistence().fillGeneratedValues(dObj);
				}
				if (domain.getBoolean("isVerified"))
				{
					if (resp == null)
					{
						resp = new JSONArray();
					}
					JSONObject domainObj = new JSONObject();
					domainObj.put(IDMPODDIRECTORYNODES.NODE_IDENTIFIER, domainName);
					domainObj.put(IDMPODDIRECTORYNODES.NODE_DISPLAY_NAME, domainName);
					domainObj.put(IDMPODDIRECTORYNODES.DIRECTORY_ID, directoryId);
					domainObj.put(IDMPODDIRECTORYNODES.NODE_ID, domainRow.get(IDMPODDIRECTORYNODES.NODE_ID));
					JSONObject rel = new JSONObject();
					rel.put("directory", JsonApiHandler.getResourceObject(JsonApiHandler.getResourceIdentifierObject("directory", directoryId)));
					JSONObject resObj = JsonApiHandler.getResourceObject("domains", domainRow.get(IDMPODDIRECTORYNODES.NODE_ID).toString(), domainObj, rel);//NO I18N
					included.put(resObj);
					resp.put(resObj);
				}
			}
		}

		DBUtils.getOrgPersistence().update(dObj);
		return resp;
	}

	private static JSONArray fetchAndUpdateOUs(Hashtable<String, String> env, DirContext ctx, String base_domain_name, JSONArray included, String directoryId) throws NamingException, DataAccessException
	{
		DataObject dObj = DBUtils.getOrgPersistence().get(IDMPODDIRECTORYNODES.TABLE, new Criteria(Column.getColumn(IDMPODDIRECTORYNODES.TABLE, IDMPODDIRECTORYNODES.DIRECTORY_ID), Long.valueOf(directoryId), QueryConstants.EQUAL));
		JSONArray resp = getChildOUs(ctx, null, base_domain_name, included, directoryId, dObj);
		DBUtils.getOrgPersistence().update(dObj);
		return resp;
	}

	private static JSONArray getChildOUs(DirContext ctx, Row parentDN, String ctxBase, JSONArray included, String directoryId, DataObject dObj) throws NamingException, DataAccessException
	{
		JSONArray res = null;
		SearchControls controls = new SearchControls();
		controls.setSearchScope(SearchControls.ONELEVEL_SCOPE);
		String ctxName = parentDN != null ? (calcCtxName((String) parentDN.get(IDMPODDIRECTORYNODES.NODE_IDENTIFIER), ctxBase)) : "";
		NamingEnumeration<SearchResult> results = ctx.search(ctxName, "(objectclass=organizationalUnit)", controls);//NO I18N
		while (results != null && results.hasMore())
		{
			SearchResult sr = results.next();
			String ouDN = (String) sr.getAttributes().get("distinguishedname").get();//NO I18N

			JSONObject ou = new JSONObject();
			JSONObject rel = new JSONObject();
			ou.put("DISTINGUISHED_NAME", ouDN);
			ou.put("ORGANIZATIONAL_UNIT_NAME", sr.getAttributes().get("ou").get());
			rel.put("directory", JsonApiHandler.getResourceObject(JsonApiHandler.getResourceIdentifierObject("directory", directoryId)));
			if (parentDN != null)
			{
				rel.put("parent", JsonApiHandler.getResourceObject(JsonApiHandler.getResourceIdentifierObject("organizational-unit", parentDN.get(IDMPODDIRECTORYNODES.NODE_ID).toString())));
			}
			//ou.put("CONTEXT_NAME", ctxName);
			//TODO:Check for existing nodes
			Row r = new Row(IDMPODDIRECTORYNODES.TABLE);
			r.set(IDMPODDIRECTORYNODES.NODE_DISPLAY_NAME, ou.get("ORGANIZATIONAL_UNIT_NAME"));
			r.set(IDMPODDIRECTORYNODES.DIRECTORY_ID, Long.valueOf(directoryId));
			r.set(IDMPODDIRECTORYNODES.NODE_IDENTIFIER, ouDN);
			r.set(IDMPODDIRECTORYNODES.PARENT_NODE, parentDN != null ? (parentDN.get(IDMPODDIRECTORYNODES.NODE_ID)) : null);

			dObj.addRow(r);

			DBUtils.getOrgPersistence().fillGeneratedValues(dObj);

			JSONArray childOUs = getChildOUs(ctx, r, ctxBase, included, directoryId, dObj);
			if (childOUs != null)
			{
				rel.put("child-ous", JsonApiHandler.getResourceObject(childOUs));
				ou.put("HAS_CHILDREN", true);
			}
			else
			{
				ou.put("HAS_CHILDREN", false);
			}
			ou.put("NODE_ID", r.get(IDMPODDIRECTORYNODES.NODE_ID));
			ou.put("SYNC_ENABLED", false);
			if (res == null)
			{
				res = new JSONArray();
			}
			JSONObject resObj = JsonApiHandler.getResourceObject("organizational-unit", r.get(IDMPODDIRECTORYNODES.NODE_ID).toString(), ou, rel);//NO I18N
			included.put(resObj);
			res.put(resObj);
		}
		return res;
	}

	public static String calcCtxName(String dn, String ctxBase)
	{
		if (dn.trim().length() > 0)
		{
			String[] domComps = ctxBase.split(Pattern.quote("."));

			for (String domComp : domComps)
			{
				dn = dn.replaceAll("(^|,)DC=" + domComp, "");//NO I18N
			}
		}
		return dn;
	}

	public static void updateOrganizationUnit(Long aLong, JSONObject jsonObject)
	{
		try
		{
			DataObject dObj = DBUtils.getOrgPersistence().get(IDMPODDIRECTORYNODES.TABLE, new Criteria(Column.getColumn(IDMPODDIRECTORYNODES.TABLE, IDMPODDIRECTORYNODES.NODE_ID), aLong, QueryConstants.EQUAL));

			Row r = dObj.getFirstRow(IDMPODDIRECTORYNODES.TABLE);

			if (jsonObject.has(IDMPODDIRECTORYNODES.SYNC_ENABLED))
			{
				r.set(IDMPODDIRECTORYNODES.SYNC_ENABLED, jsonObject.get(IDMPODDIRECTORYNODES.SYNC_ENABLED));
			}

			dObj.updateRow(r);

			DBUtils.getOrgPersistence().update(dObj);
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
	}

	public static JSONArray getDomains(Long directory)
	{
		final String TYPE = JsonApiHandler.ResourceType.DOMAIN.getResType();
		JSONArray domains = new JSONArray();
		try
		{
			ArrayList<String> tablesList = new ArrayList<String>();
			tablesList.add(IDMPODDIRECTORYNODES.TABLE);

			boolean[] isLeftJoins = new boolean[tablesList.size()];
			Arrays.fill(isLeftJoins, true);

			Criteria dirCrit = new Criteria(Column.getColumn(IDMPODDIRECTORYNODES.TABLE, IDMPODDIRECTORYNODES.DIRECTORY_ID), directory, QueryConstants.EQUAL);

			SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, dirCrit);

			DataObject domainsDo = DBUtils.getOrgPersistence().get(query);

			if (!domainsDo.isEmpty())
			{
				if (domainsDo.containsTable(IDMPODDIRECTORYNODES.TABLE))
				{
					for (Iterator<Row> it = domainsDo.getRows(IDMPODDIRECTORYNODES.TABLE); it.hasNext(); )
					{
						Row r = it.next();
						JSONObject domainAttrs = DBUtils.rowToJson(r);
						JSONObject domainRel = new JSONObject();
						domainRel.put("directory", JsonApiHandler.getResourceObject(JsonApiHandler.getResourceIdentifierObject("directory", directory.toString())));
						JSONObject domain = new JSONObject();
						domain.put(JsonApiConstants.ID, domainAttrs.get(IDMPODDIRECTORYNODES.NODE_ID));
						domain.put(JsonApiConstants.TYPE, TYPE);
						domain.put(JsonApiConstants.ATTRIBUTES, domainAttrs);
						domain.put(JsonApiConstants.RELATIONSHIPS, domainRel);
						domains.put(domain);
					}
				}
			}

		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return domains;
	}

	public static JSONArray getOrganizationalUnits(Long directory)
	{
		final String TYPE = JsonApiHandler.ResourceType.ORGANIZATIONAL_UNIT.getResType();
		JSONArray organizationalUnits = new JSONArray();
		try
		{
			ArrayList<String> tablesList = new ArrayList<String>();
			tablesList.add(IDMPODDIRECTORYNODES.TABLE);

			boolean[] isLeftJoins = new boolean[tablesList.size()];
			Arrays.fill(isLeftJoins, true);

			Criteria dirCrit = new Criteria(Column.getColumn(IDMPODDIRECTORYNODES.TABLE, IDMPODDIRECTORYNODES.DIRECTORY_ID), directory, QueryConstants.EQUAL);

			SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, dirCrit);

			DataObject ousDO = DBUtils.getOrgPersistence().get(query);

			if (!ousDO.isEmpty())
			{
				if (ousDO.containsTable(IDMPODDIRECTORYNODES.TABLE))
				{
					for (Iterator<Row> it = ousDO.getRows(IDMPODDIRECTORYNODES.TABLE); it.hasNext(); )
					{
						Row r = it.next();
						JSONObject ouAttrs = DBUtils.rowToJson(r);
						JSONObject ouRelationships = new JSONObject();
						ouRelationships.put("directory", JsonApiHandler.getResourceObject(JsonApiHandler.getResourceIdentifierObject("directory", directory.toString())));
						if (r.get(IDMPODDIRECTORYNODES.PARENT_NODE) != null)
						{
							ouRelationships.put("parent", JsonApiHandler.getResourceObject(JsonApiHandler.getResourceIdentifierObject("organizational-unit", r.get(IDMPODDIRECTORYNODES.PARENT_NODE).toString())));
						}
						JSONObject organizationalUnit = new JSONObject();
						organizationalUnit.put(JsonApiConstants.ID, ouAttrs.get(IDMPODDIRECTORYNODES.NODE_ID));
						organizationalUnit.put(JsonApiConstants.TYPE, TYPE);
						organizationalUnit.put(JsonApiConstants.ATTRIBUTES, ouAttrs);
						organizationalUnit.put(JsonApiConstants.RELATIONSHIPS, ouRelationships);
						organizationalUnits.put(organizationalUnit);
					}
				}
			}

		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return organizationalUnits;
	}

	public static JSONObject getSynchedObjects(Long directory_id, Long job_id, Long nodes[], Integer page_size, Integer page_number) throws DataAccessException
	{
		Row dtRow = getDirectoryTypeRowForDirectory(directory_id);
		if (job_id == 0 || job_id == null)
		{
			job_id = getLatestJobIdForDirectory(directory_id);
		}
		if (dtRow.get(IDMPODDIRECTORYTYPES.TYPE_HANDLER).toString().equalsIgnoreCase("ActiveDirectory"))
		{
			return getSynchedADObjects(directory_id, job_id, nodes, page_size, page_number);
		}
		else
		{
			return getSynchedAADObjects(directory_id, job_id, nodes, page_size, page_number);
		}
	}

	private static Long getLatestJobIdForDirectory(Long directory_id) throws DataAccessException
	{
		Criteria jobCrit = new Criteria(Column.getColumn(IDMPODDIRECTORYJOBS.TABLE, IDMPODDIRECTORYJOBS.DIRECTORY_ID), directory_id, QueryConstants.EQUAL);
		jobCrit = jobCrit.and(new Criteria(Column.getColumn(IDMPODDIRECTORYJOBS.TABLE, IDMPODDIRECTORYJOBS.JOB_TYPE), ScheduleUtil.JobType.ONE_TIME, QueryConstants.EQUAL));

		ArrayList<String> tablesList = new ArrayList<String>();
		tablesList.add(IDMPODDIRECTORYJOBS.TABLE);
		tablesList.add(IDMPODDIRECTORYSYNCDETAILS.TABLE);

		boolean[] isLeftJoins = new boolean[tablesList.size()];
		Arrays.fill(isLeftJoins, true);

		SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, jobCrit);

		DataObject dobj = DBUtils.getOrgPersistence().get(query);

		Row jobRow = null;

		if (dobj.containsTable(IDMPODDIRECTORYJOBS.TABLE))
		{
			jobRow = dobj.getFirstRow(IDMPODDIRECTORYJOBS.TABLE);
			return (Long) jobRow.get(IDMPODDIRECTORYJOBS.JOB_ID);
		}
		else
		{
			return null;
		}
	}

	private static JSONObject getSynchedAADObjects(Long directory_id, Long job_id, Long[] nodes, Integer page_size, Integer page_number)
	{
		final String TYPE = JsonApiHandler.ResourceType.SYNCHED_OBJECT.getResType();
		JSONObject resp = new JSONObject();
		JSONObject meta = new JSONObject();
		JSONArray synchedObjects = new JSONArray();
		try
		{
			Criteria jobCrit = new Criteria(Column.getColumn(IDMPODDIRECTORYJOBS.TABLE, IDMPODDIRECTORYJOBS.JOB_ID), job_id, QueryConstants.EQUAL);
			Criteria nodeCrit = getDomainCriteria(nodes);

			SelectQuery query = new SelectQueryImpl(Table.getTable(IDMPODDIRECTORYJOBS.TABLE));
			query.addJoin(new Join(Table.getTable(IDMPODDIRECTORYJOBS.TABLE), Table.getTable(IDMPODDIRECTORYSYNCDETAILS.TABLE), new String[]{IDMPODDIRECTORYJOBS.JOB_ID}, new String[]{IDMPODDIRECTORYSYNCDETAILS.JOB_ID}, Join.INNER_JOIN));
			query.addJoin(new Join(Table.getTable(IDMPODDIRECTORYSYNCDETAILS.TABLE), Table.getTable(IDMPODSYNCHEDUSERS.TABLE), new String[]{IDMPODDIRECTORYSYNCDETAILS.SYNC_ID}, new String[]{IDMPODSYNCHEDUSERS.SYNC_ID}, Join.INNER_JOIN));

			query.addSelectColumn(Column.getColumn(IDMPODSYNCHEDUSERS.TABLE, "*"));

			Criteria queryCrit = null;

			if (nodeCrit == null)
			{
				queryCrit = jobCrit;
			}
			else
			{
				queryCrit = jobCrit.and(nodeCrit);
			}

			query.setCriteria(queryCrit);

			Range range = DBUtils.constructRange(page_number, page_size);

			Integer totalCount = DBUtils.getUnmodifiedQueryCount(query);
			Boolean atLastPage = (page_number * page_size) >= totalCount;

			meta.put("FIRST", 1);
			meta.put("NEXT", atLastPage ? null : page_number + 1);
			meta.put("PREV", page_number > 1 ? page_number - 1 : 1);
			meta.put("LAST", Math.ceil(totalCount.doubleValue() / page_size.doubleValue()));
			meta.put("TOTAL", totalCount);
			meta.put("START_INDEX", (page_number - 1) * page_size + 1);
			meta.put("END_INDEX", (page_number * page_size) > totalCount ? totalCount : (page_number * page_size));
			meta.put("JOB_STATUS", getJobStatus(job_id));

			query.setRange(range);

			Connection connection = null;
			DataSet dataSet = null;
			try
			{
				RelationalAPI relationalAPI = DBUtils.getOrgRelationalApi();
				connection = relationalAPI.getConnection();
				dataSet = relationalAPI.executeQuery(query, connection);

				while (dataSet.next())
				{
					JSONObject synchedObjectAttrs = datasetToJson(dataSet);
					JSONObject synchedObject = new JSONObject();
					synchedObject.put(JsonApiConstants.ID, synchedObjectAttrs.get(IDMPODSYNCHEDUSERS.SYNCED_USER_ID));
					synchedObject.put(JsonApiConstants.TYPE, TYPE);
					synchedObject.put(JsonApiConstants.ATTRIBUTES, synchedObjectAttrs);
					synchedObjects.put(synchedObject);
				}

				// LOGGER.info(relationalAPI.getSelectSQL(query));
			}
			catch (Exception e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
			finally
			{
				DBUtils.safeClose(connection, dataSet);
			}

			resp.put(JsonApiConstants.DATA, synchedObjects);
			resp.put(JsonApiConstants.META, meta);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return resp;
	}

	private static Criteria getDomainCriteria(Long[] nodes) throws DataAccessException
	{
		if (nodes == null)
		{
			return null;
		}
		Criteria domainCrit = null;
		Criteria nodeCrit = new Criteria(Column.getColumn(IDMPODDIRECTORYNODES.TABLE, IDMPODDIRECTORYNODES.NODE_ID), nodes, QueryConstants.IN);
		DataObject nodeDO = DBUtils.getOrgPersistence().get(IDMPODDIRECTORYNODES.TABLE, nodeCrit);

		if (!nodeDO.isEmpty())
		{
			Iterator<Row> domains = nodeDO.getRows(IDMPODDIRECTORYNODES.TABLE);
			while (domains.hasNext())
			{
				Row domainRow = domains.next();
				Criteria cDomainCrit = new Criteria(Column.getColumn(IDMPODSYNCHEDUSERS.TABLE, IDMPODSYNCHEDUSERS.USER_PRINCIPAL_NAME), "@" + domainRow.get(IDMPODDIRECTORYNODES.NODE_IDENTIFIER), QueryConstants.ENDS_WITH, false);
				if (domainCrit == null)
				{
					domainCrit = cDomainCrit;
				}
				else
				{
					domainCrit = domainCrit.or(cDomainCrit);
				}
			}
		}

		return domainCrit;
	}

	public static JSONObject getSynchedADObjects(Long directory_id, Long job_id, Long nodes[], Integer page_size, Integer page_number)
	{
		final String TYPE = JsonApiHandler.ResourceType.SYNCHED_OBJECT.getResType();
		JSONObject resp = new JSONObject();
		JSONObject meta = new JSONObject();
		JSONArray synchedObjects = new JSONArray();
		try
		{
			Criteria jobCrit = new Criteria(Column.getColumn(IDMPODDIRECTORYJOBS.TABLE, IDMPODDIRECTORYJOBS.JOB_ID), job_id, QueryConstants.EQUAL);
			if (nodes != null)
			{
				Criteria nodeCrit = new Criteria(Column.getColumn(IDMPODSYNCHEDUSERS.TABLE, IDMPODSYNCHEDUSERS.NODE_ID), nodes, QueryConstants.IN);
				jobCrit = jobCrit.and(nodeCrit);
			}

			SelectQuery query = new SelectQueryImpl(Table.getTable(IDMPODDIRECTORYJOBS.TABLE));
			query.addJoin(new Join(Table.getTable(IDMPODDIRECTORYJOBS.TABLE), Table.getTable(IDMPODDIRECTORYSYNCDETAILS.TABLE), new String[]{IDMPODDIRECTORYJOBS.JOB_ID}, new String[]{IDMPODDIRECTORYSYNCDETAILS.JOB_ID}, Join.INNER_JOIN));
			query.addJoin(new Join(Table.getTable(IDMPODDIRECTORYSYNCDETAILS.TABLE), Table.getTable(IDMPODSYNCHEDNODES.TABLE), new String[]{IDMPODDIRECTORYSYNCDETAILS.SYNC_ID}, new String[]{IDMPODSYNCHEDNODES.SYNC_ID}, Join.INNER_JOIN));
			query.addJoin(new Join(Table.getTable(IDMPODSYNCHEDNODES.TABLE), Table.getTable(IDMPODSYNCHEDUSERS.TABLE), new String[]{IDMPODSYNCHEDNODES.NODE_ID, IDMPODSYNCHEDNODES.SYNC_ID}, new String[]{IDMPODSYNCHEDUSERS.NODE_ID, IDMPODSYNCHEDUSERS.SYNC_ID}, Join.INNER_JOIN));

			query.addSelectColumn(Column.getColumn(IDMPODSYNCHEDUSERS.TABLE, "*"));

			query.setCriteria(jobCrit.and(jobCrit));

			Range range = DBUtils.constructRange(page_number, page_size);

			Integer totalCount = DBUtils.getUnmodifiedQueryCount(query);
			Boolean atLastPage = (page_number * page_size) >= totalCount;

			meta.put("FIRST", 1);
			meta.put("NEXT", atLastPage ? null : page_number + 1);
			meta.put("PREV", page_number > 1 ? page_number - 1 : null);
			meta.put("LAST", Math.ceil(totalCount.doubleValue() / page_size.doubleValue()));
			meta.put("TOTAL", totalCount);
			meta.put("START_INDEX", (page_number - 1) * page_size + 1);
			meta.put("END_INDEX", (page_number * page_size) > totalCount ? totalCount : (page_number * page_size));
			meta.put("JOB_STATUS", getJobStatus(job_id));

			query.setRange(range);

			Connection connection = null;
			DataSet dataSet = null;
			try
			{
				RelationalAPI relationalAPI = DBUtils.getOrgRelationalApi();
				connection = relationalAPI.getConnection();
				dataSet = relationalAPI.executeQuery(query, connection);

				while (dataSet.next())
				{
					JSONObject synchedObjectAttrs = datasetToJson(dataSet);
					JSONObject synchedObject = new JSONObject();
					synchedObject.put(JsonApiConstants.ID, synchedObjectAttrs.get(IDMPODSYNCHEDUSERS.SYNCED_USER_ID));
					synchedObject.put(JsonApiConstants.TYPE, TYPE);
					synchedObject.put(JsonApiConstants.ATTRIBUTES, synchedObjectAttrs);
					synchedObjects.put(synchedObject);
				}

				// LOGGER.info(relationalAPI.getSelectSQL(query));
			}
			catch (Exception e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
			finally
			{
				DBUtils.safeClose(connection, dataSet);
			}

			resp.put(JsonApiConstants.DATA, synchedObjects);
			resp.put(JsonApiConstants.META, meta);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return resp;
	}

	private static Long getJobStatus(Long job_id) throws DataAccessException
	{
		ArrayList<String> tables = new ArrayList<>();
		tables.add(IDMPODDIRECTORYJOBS.TABLE);
		tables.add(IDMPODDIRECTORYSYNCDETAILS.TABLE);

		boolean[] isLeftJoins = new boolean[tables.size()];
		Arrays.fill(isLeftJoins, true);

		Criteria jobCrit = new Criteria(Column.getColumn(IDMPODDIRECTORYJOBS.TABLE, IDMPODDIRECTORYJOBS.JOB_ID), job_id, QueryConstants.EQUAL);

		SelectQuery query = QueryConstructor.get(tables, isLeftJoins, jobCrit);

		DataObject jobstatusDO = DBUtils.getOrgPersistence().get(query);

		if (!jobstatusDO.containsTable(IDMPODDIRECTORYSYNCDETAILS.TABLE))
		{
			return SYNC_STATUS.QUEUED;
		}
		else if (jobstatusDO.getRow(IDMPODDIRECTORYSYNCDETAILS.TABLE, new Criteria(Column.getColumn(IDMPODDIRECTORYSYNCDETAILS.TABLE, IDMPODDIRECTORYSYNCDETAILS.SYNC_STATUS), SYNC_STATUS.RUNNING, QueryConstants.EQUAL)) != null)
		{
			return SYNC_STATUS.RUNNING;
		}
		else
		{
			return SYNC_STATUS.STOPPED;
		}

	}

	public static DataObject getJobDOForDirectory(Long directoryId) throws DataAccessException
	{
		Criteria jobCrit = new Criteria(Column.getColumn(IDMPODDIRECTORYJOBS.TABLE, IDMPODDIRECTORYJOBS.DIRECTORY_ID), directoryId, QueryConstants.EQUAL);
		jobCrit = jobCrit.and(new Criteria(Column.getColumn(IDMPODDIRECTORYJOBS.TABLE, IDMPODDIRECTORYJOBS.JOB_TYPE), ScheduleUtil.JobType.REPETITION, QueryConstants.EQUAL));

		ArrayList<String> tablesList = new ArrayList<String>();
		tablesList.add(IDMPODDIRECTORYJOBS.TABLE);

		boolean[] isLeftJoins = new boolean[tablesList.size()];
		Arrays.fill(isLeftJoins, true);

		SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, jobCrit);

		DataObject dobj = DBUtils.getOrgPersistence().get(query);

		return dobj;
	}

	public static JSONObject setupDirectorySync(JSONObject request)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);
		Long directoryId = data.getLong(JsonApiConstants.ID);
		try
		{
			DataObject dobj = getJobDOForDirectory(directoryId);

			Row r = null;

			if (dobj.containsTable(IDMPODDIRECTORYJOBS.TABLE))
			{
				r = dobj.getFirstRow(IDMPODDIRECTORYJOBS.TABLE);
			}
			else
			{
				r = new Row(IDMPODDIRECTORYJOBS.TABLE);
				r.set(IDMPODDIRECTORYJOBS.DIRECTORY_ID, directoryId);
				r.set(IDMPODDIRECTORYJOBS.JOB_TYPE, ScheduleUtil.JobType.REPETITION);
				r.set(IDMPODDIRECTORYJOBS.SYNC_TYPE, SYNC_TYPE.FETCH_AND_IAM);

				dobj.addRow(r);

				DBUtils.getOrgPersistence().add(dobj);

				Row typeRow = getDirectoryTypeRowForDirectory(directoryId);

				String syncClass = null;
				if (typeRow.get(IDMPODDIRECTORYTYPES.TYPE_HANDLER).toString().equalsIgnoreCase("ActiveDirectory"))
				{
					syncClass = "com.manageengine.idmpod.server.iam.directory.jobs.ActiveDirectorySyncJob";//No I18N
				}
				else if (typeRow.get(IDMPODDIRECTORYTYPES.TYPE_HANDLER).toString().equalsIgnoreCase("AzureActiveDirectory"))
				{
					syncClass = "com.manageengine.idmpod.server.iam.directory.jobs.AzureActiveDirectorySyncJob";//No I18N
				}
				else if (typeRow.get(IDMPODDIRECTORYTYPES.TYPE_HANDLER).toString().equalsIgnoreCase("GSuite"))
				{
					syncClass = "com.manageengine.idmpod.server.iam.directory.jobs.GSuiteDirectorySyncJob";//No I18N
				}

				ScheduleUtil.addDailyCalendarRepetition(r.get(IDMPODDIRECTORYJOBS.JOB_ID).toString(), 0, 0, null, null);
				ScheduleUtil.addRepetitiveJob(r.get(IDMPODDIRECTORYJOBS.JOB_ID).toString(), (Long) r.get(IDMPODDIRECTORYJOBS.JOB_ID), syncClass, true, System.currentTimeMillis());
			}

			request.put("JOB_ID", (Long) r.get(IDMPODDIRECTORYJOBS.JOB_ID));
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return request;
	}

	public static JSONObject verifyAndUpdateActiveDirectory(Long directoryId, JSONObject request, JSONObject resp)
	{

		Boolean verified = false;

		// LOGGER.info(request.toString(4));

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		String username = attributes.getString("SERVICE_ACCOUNT_USERNAME");//"CN=Administrator,CN=Users,DC=omp,DC=local";//No I18N
		String password = attributes.getString("SERVICE_ACCOUNT_PASSWORD");//"Laptop@135";//No I18N

		Hashtable<String, String> env = new Hashtable<>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, attributes.getString("LDAP_CONNECTION_URL"));
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, username); // use DN
		env.put(Context.SECURITY_CREDENTIALS, password);
		env.put(Context.REFERRAL, "follow");

		DirContext ctx = null;

		JSONArray errors = resp.has(JsonApiConstants.ERRORS) ? resp.getJSONArray(JsonApiConstants.ERRORS) : new JSONArray();
		JSONArray included = new JSONArray();
		try
		{
			ctx = new InitialDirContext(env);
			SearchControls controls = new SearchControls();
			controls.setSearchScope(SearchControls.OBJECT_SCOPE);
			NamingEnumeration<SearchResult> results = ctx.search(attributes.getString("SERVICE_ACCOUNT_CONTEXT_NAME"), "(objectclass=person)", controls);//No I18N
			while (results.hasMore())
			{
				SearchResult sr = results.next();
				// LOGGER.info(sr.toString());
			}
			verified = true;

			if (verified)
			{
				DirectoryHandler.updateDirectory(directoryId, data);
				JSONObject relationships = data.getJSONObject(JsonApiConstants.RELATIONSHIPS);
				relationships.put("organizational-units", JsonApiHandler.getResourceObject(fetchAndUpdateOUs(env, ctx, attributes.getString("BASE_DOMAIN_NAME"), included, directoryId.toString())));
			}

		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			errors.put(JsonApiHandler.getBaseErrorObject(e.getMessage()));
		}
		finally
		{
			if (ctx != null)
			{
				try
				{
					ctx.close();
				}
				catch (NamingException e)
				{
					LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
				}
			}
		}
		if (errors != null && errors.length() > 0)
		{
			resp.put(JsonApiConstants.ERRORS, errors);
		}
		else
		{
			resp.put(JsonApiConstants.DATA, data);
			if (included.length() > 0)
			{
				resp.put(JsonApiConstants.INCLUDED, included);
			}
		}
		return resp;
	}

	public static JSONObject updateDirectory(Long directoryId, JSONObject data)
	{
		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);
		JSONObject relationships = data.getJSONObject(JsonApiConstants.RELATIONSHIPS);

		try
		{
			ArrayList<String> tablesList = new ArrayList<String>();
			tablesList.add(IDMPODDIRECTORIES.TABLE);
			tablesList.add(IDMPODDIRECTORYPARAMS.TABLE);

			boolean[] isLeftJoins = new boolean[tablesList.size()];
			Arrays.fill(isLeftJoins, true);

			Criteria dirCrit = new Criteria(Column.getColumn(IDMPODDIRECTORIES.TABLE, IDMPODDIRECTORIES.DIRECTORY_ID), directoryId, QueryConstants.EQUAL);

			SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, dirCrit);

			DataObject directoriesDO = DBUtils.getOrgPersistence().get(query);


			Row directoryRow = directoriesDO.getFirstRow(IDMPODDIRECTORIES.TABLE);
			String directoryName = attributes.has("DIRECTORY_DISPLAY_NAME") && attributes.getString("DIRECTORY_DISPLAY_NAME").trim().length() != 0 ? attributes.getString("DIRECTORY_DISPLAY_NAME") : attributes.optString("BASE_DOMAIN_NAME");//No I18N
			directoryRow.set(IDMPODDIRECTORIES.DIRECTORY_NAME, directoryName);
			directoryRow.set(IDMPODDIRECTORIES.DIRECTORY_TYPE_ID, relationships.getJSONObject("directory-type").getJSONObject(JsonApiConstants.DATA).getLong(JsonApiConstants.ID));

			directoriesDO.updateRow(directoryRow);

			for (String key : attributes.keySet())
			{
				Row pr = directoriesDO.getRow(IDMPODDIRECTORYPARAMS.TABLE, new Criteria(Column.getColumn(IDMPODDIRECTORYPARAMS.TABLE, IDMPODDIRECTORYPARAMS.PARAM_NAME), key, QueryConstants.EQUAL));
				if (pr == null)
				{
					pr = new Row(IDMPODDIRECTORYPARAMS.TABLE);
					pr.set(IDMPODDIRECTORYPARAMS.DIRECTORY_ID, directoryRow.get(IDMPODDIRECTORIES.DIRECTORY_ID));
					pr.set(IDMPODDIRECTORYPARAMS.PARAM_NAME, key);
					pr.set(IDMPODDIRECTORYPARAMS.ENCRYPTED_PARAM_VALUE, attributes.get(key));
					directoriesDO.addRow(pr);
				}
				else
				{
					pr.set(IDMPODDIRECTORYPARAMS.DIRECTORY_ID, directoryRow.get(IDMPODDIRECTORIES.DIRECTORY_ID));
					pr.set(IDMPODDIRECTORYPARAMS.PARAM_NAME, key);
					pr.set(IDMPODDIRECTORYPARAMS.ENCRYPTED_PARAM_VALUE, attributes.get(key));
					directoriesDO.updateRow(pr);
				}
			}

			DBUtils.getOrgPersistence().update(directoriesDO);
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		return data;
	}

	public static JSONObject importDirectoryUsers(Long directoryId, JSONArray userids)
	{
		JSONObject status = new JSONObject();
		String[] remarks = new String[2];
		JSONArray errors = new JSONArray();
		StringBuilder remSb = new StringBuilder();
		if (directoryId == 0L)
		{
			remarks[1] = "Zoho";//No I18N
			UserAPI userAPI = IAMProxy.getInstance().getUserAPI();
			//Definitely Existing zoho users
			for (int i = 0; i < userids.length(); i++)
			{
				Long userId = userids.getLong(i);
				String userDisplayName = null;
				try
				{
					User user = userAPI.getUser(userId);
					userDisplayName = user.getDisplayName();
					remSb.append(user.getDisplayName());
					if (i == userids.length() - 2)
					{
						remSb.append(I18N.getMsg("idmpod.common.conj.and"));
					}
					else if (i < userids.length() - 1)
					{
						remSb.append(", ");
					}
					addUserFromIAM(IdmpodIAMUtil.getZOID(), user, true);
				}
				catch (IAMException ie)
				{
					String error = IdmpodException.getErrorMessageForIAMException(ie);

					errors.put(JsonApiHandler.getErrorObject(userDisplayName, error));
				}
				catch (IdmpodException e)
				{
					String error = e.getErrorCode().getI18nMsg();

					errors.put(JsonApiHandler.getErrorObject(userDisplayName, error));
				}
				catch (Exception e)
				{
					LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
				}
			}
		}
		else
		{
			try
			{
				Long[] syncUserIds = new Long[userids.length()];
				for (int i = 0; i < userids.length(); i++)
				{
					syncUserIds[i] = userids.getLong(i);
				}
				Criteria usersCrit = new Criteria(Column.getColumn(IDMPODDIRECTORIES.TABLE, IDMPODDIRECTORIES.DIRECTORY_ID), directoryId, QueryConstants.EQUAL);
				usersCrit = usersCrit.and(new Criteria(Column.getColumn(IDMPODSYNCHEDUSERS.TABLE, IDMPODSYNCHEDUSERS.SYNCED_USER_ID), syncUserIds, QueryConstants.IN));
				ArrayList<String> tablesList = new ArrayList<String>();
				tablesList.add(IDMPODDIRECTORIES.TABLE);
				tablesList.add(IDMPODSYNCHEDUSERS.TABLE);

				boolean[] isLeftJoins = new boolean[tablesList.size()];
				Arrays.fill(isLeftJoins, true);

				SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, usersCrit);

				DataObject importUsersDO = DBUtils.getOrgPersistence().get(query);

				if (importUsersDO.containsTable(IDMPODDIRECTORIES.TABLE))
				{
					Row directoryRow = importUsersDO.getFirstRow(IDMPODDIRECTORIES.TABLE);
					remarks[1] = directoryRow.get(IDMPODDIRECTORIES.DIRECTORY_NAME).toString();

					if (importUsersDO.containsTable(IDMPODSYNCHEDUSERS.TABLE))
					{
						Iterator<Row> synchedUsersRows = importUsersDO.getRows(IDMPODSYNCHEDUSERS.TABLE);
						ArrayList<String> userDispNames = new ArrayList<>();
						UserAPI uapi = IAMProxy.getInstance().getUserAPI();
						while (synchedUsersRows.hasNext())
						{
							String userDisplayName = null;
							try
							{
								String userEmail = null;
								Row synchedUserRow = synchedUsersRows.next();
								String userName = (String) synchedUserRow.get(IDMPODSYNCHEDUSERS.USER_DISPLAY_NAME);
								userDisplayName = userName;
								userDispNames.add(userName);
								userEmail = (String) synchedUserRow.get(IDMPODSYNCHEDUSERS.USER_EMAIL);
								if (userEmail == null)
								{
									userEmail = (String) synchedUserRow.get(IDMPODSYNCHEDUSERS.USER_PRINCIPAL_NAME);
								}
								if (userEmail == null)
								{
									continue;
								}
								User user = uapi.getUser(userEmail);
								Long zoid = IdmpodIAMUtil.getZOID();
								if (user == null && DomainUtils.isDomainVerified(zoid, userEmail))
								{
									//If Domain verified add Directly
									Long zuid = AppAccountUtils.addUserToIAM(zoid, userName, null, userEmail);
									if (LicenseUtil.allowAddUsers(1))
									{
										addUserFromIAM(zoid, user);
									}
								}
								else if (user == null)
								{
									//If not verified domain but new user;
									//								Long zuid = AppAccountUtils.addUserToIAM(zoid, userName, null, userEmail, false);
									//								user = uapi.getUser(zuid);
									//								addUserFromIAM(zoid, user);
									AppAccountUtils.sendInvitation(userEmail);
									DBUtils.addInvitedUserEntry("", "", userEmail, IdmpodUserRole.USER, null);
								}
								else
								{
									//Existing org user;
									if (LicenseUtil.allowAddUsers(1))
									{
										addUserFromIAM(zoid, user);
									}
								}
							}
							catch (IAMException ie)
							{
								String error = IdmpodException.getErrorMessageForIAMException(ie);

								errors.put(JsonApiHandler.getErrorObject(userDisplayName, error));
							}
							catch (IdmpodException e)
							{
								String error = e.getErrorCode().getI18nMsg();

								errors.put(JsonApiHandler.getErrorObject(userDisplayName, error));
							}
						}
						for (int i = 0; i < userDispNames.size(); i++)
						{
							String userDispName = userDispNames.get(i);
							remSb.append(userDispName);
							if (i == userDispNames.size() - 2)
							{
								remSb.append(I18N.getMsg("idmpod.common.conj.and"));
							}
							else if (i < userDispNames.size() - 1)
							{
								remSb.append(", ");
							}
						}
					}
				}
			}
			catch (DataAccessException e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
			catch (Exception e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
		}
		remarks[0] = remSb.toString();

		if (errors.length() > 0)
		{
			try
			{
				errors.put(JsonApiHandler.getBaseErrorObject(I18N.getMsg("idmpod.exception.common.error_occurred.adding_users")));
			}
			catch (Exception e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
			status.put("ERRORS", errors);
		}

		status.put("REMARKS", remarks);
		return status;
	}

	public static Long addUserFromIAM(long zoid, User user, Boolean... flags) throws Exception
	{
		UserAPI uapi = IAMProxy.getInstance().getUserAPI();
		String email = user.getPrimaryEmail();
		if (user.getZOID() == zoid)
		{
			// if user is member of same org
			UserUtils.setUserRole(IdmpodUserRole.USER, user, flags);
			return 0L;
		}
		else
		{
			return 3L;
		}
	}

	public static JSONObject addUsersToIAM(JSONArray emailIds)
	{
		JSONObject status = new JSONObject();
		StringBuilder remSb = new StringBuilder();
		JSONArray errors = new JSONArray();
		for (int i = 0; i < emailIds.length(); i++)
		{
			//TODO: Check if user already exists and do regular handling
			String emailId = emailIds.getString(i);
			try
			{
				remSb.append(emailId);
				if (i == emailIds.length() - 2)
				{
					remSb.append(I18N.getMsg("idmpod.common.conj.and"));
				}
				else if (i < emailIds.length() - 1)
				{
					remSb.append(", ");
				}
				try
				{
					AppAccountUtils.sendInvitation(emailId);
					DBUtils.addInvitedUserEntry("", "", emailId, IdmpodUserRole.USER, null);
				}
				catch (IAMException ie)
				{
					String error = IdmpodException.getErrorMessageForIAMException(ie);

					errors.put(JsonApiHandler.getErrorObject(emailId, error));
				}
			}
			catch (Exception e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
		}
		status.put("REMARKS", remSb.toString());
		if (errors.length() > 0)
		{
			try
			{
				errors.put(JsonApiHandler.getBaseErrorObject(I18N.getMsg("idmpod.exception.common.error_occurred.adding_users")));
			}
			catch (Exception e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
			status.put("ERRORS", errors);
		}
		return status;
	}

	public static void deleteDirectory(Long directoryId)
	{
		try
		{
			DataObject jobDO = getJobDOForDirectory(directoryId);

			Row jobRow = null;

			if (jobDO.containsTable(IDMPODDIRECTORYJOBS.TABLE))
			{
				jobRow = jobDO.getFirstRow(IDMPODDIRECTORYJOBS.TABLE);
				Long jobId = (Long) jobRow.get(IDMPODDIRECTORYJOBS.JOB_ID);
				ScheduleUtil.deleteJobByID(jobId);
			}

			DataObject dirDO = DBUtils.getOrgPersistence().get(IDMPODDIRECTORIES.TABLE, new Criteria(Column.getColumn(IDMPODDIRECTORIES.TABLE, IDMPODDIRECTORIES.DIRECTORY_ID), directoryId, QueryConstants.EQUAL));
			Row dirRow = dirDO.getFirstRow(IDMPODDIRECTORIES.TABLE);

			DBUtils.getOrgPersistence().delete(dirRow);
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
	}

	public static void updateSchedule(Long directoryId, String daily_sync_time_hour, String daily_sync_time_min)
	{
		try
		{
			DataObject jobDOForDirectory = getJobDOForDirectory(directoryId);
			if (jobDOForDirectory.containsTable(IDMPODDIRECTORYJOBS.TABLE))
			{
				Row jobRowForDirectory = jobDOForDirectory.getFirstRow(IDMPODDIRECTORYJOBS.TABLE);
				Long jobId = (Long) jobRowForDirectory.get(IDMPODDIRECTORYJOBS.JOB_ID);
				ScheduleUtil.updateCalendarRepetition(jobId, daily_sync_time_hour == null ? null : Integer.parseInt(daily_sync_time_hour), daily_sync_time_min == null ? null : Integer.parseInt(daily_sync_time_min));
			}
		}
		catch (DataAccessException e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
	}

	public static JSONObject getPublicDomainAsJSON(OrgDomain domain)
	{
		final String TYPE = JsonApiHandler.ResourceType.PDOMAIN.getResType();
		JSONObject domainObject = new JSONObject();
		JSONObject domainAttrs = new JSONObject();

		domainAttrs.put("DOMAIN_NAME", domain.getDomainName());
		domainAttrs.put("CREATED_TIMESTAMP", domain.getCreatedTime());
		domainAttrs.put("IS_PRIMARY", domain.isPrimary());
		domainAttrs.put("IS_VERIFIED", domain.isVerified());
		domainAttrs.put("VERIFICATION_CODE", domain.getVerCode());
		domainAttrs.put("VERIFICATION_URL", domain.getVerificationUrl());
		domainAttrs.put("VERIFICATION_BY", domain.getVerBy());
		domainAttrs.put("VERIFICATION_DATE", domain.getVerDate());
		domainAttrs.put("VERIFICATION_MODE", domain.getVerMode());
		domainAttrs.put("CNAME", "zb" + domain.getVerCode().substring(0, 8));

		domainObject.put(JsonApiConstants.ID, domain.getDomainName());
		domainObject.put(JsonApiConstants.TYPE, TYPE);
		domainObject.put(JsonApiConstants.ATTRIBUTES, domainAttrs);
		return domainObject;
	}

	public static JSONObject addPublicDomain(JSONObject request, JSONObject resp)
	{
		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);

		String domainname = attributes.get("DOMAIN_NAME").toString();

		JSONArray errors = resp.has(JsonApiConstants.ERRORS) ? resp.getJSONArray(JsonApiConstants.ERRORS) : new JSONArray();

		OrgAPI orgAPI = IAMProxy.getInstance().getOrgAPI();
		long zoid = IAMUtil.getCurrentUser().getZOID();

		try
		{
			if (orgAPI.isOrgDomainExist(domainname))
			{
				errors.put(JsonApiHandler.getErrorObject("DOMAIN_NAME", "Domain name already configured with Zoho"));
			}
			else
			{
				boolean addresult = orgAPI.addOrgDomain(zoid, domainname, false, false);
				if (!addresult)
				{
					LOGGER.info("Domain addition failed");
				}
				else
				{
					return getPublicDomain(domainname);
				}
			}
		}
		catch (IAMException ie)
		{
			String error = IdmpodException.getErrorMessageForIAMException(ie);

			errors.put(JsonApiHandler.getErrorObject("DOMAIN_NAME", error));
		}
		catch (Exception ex)
		{
			LOGGER.log(Level.SEVERE, ex.getMessage(), ex);
		}

		if (errors != null && errors.length() > 0)
		{
			resp.put(JsonApiConstants.ERRORS, errors);
		}
		else
		{
			resp.put(JsonApiConstants.DATA, data);
		}
		return resp;
	}

	public static JSONObject getPublicDomain(String domainname)
	{
		JSONObject resp = new JSONObject();
		JSONObject domain = new JSONObject();

		OrgAPI orgAPI = IAMProxy.getInstance().getOrgAPI();
		long zoid = IAMUtil.getCurrentUser().getZOID();
		try
		{
			domain = getPublicDomainAsJSON(orgAPI.getOrgDomain(domainname));
		}
		catch (IAMException e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		resp.put(JsonApiConstants.DATA, domain);
		return resp;
	}

	public static void deletePublicDomain(String domainName)
	{
		long zoid = IAMUtil.getCurrentUser().getZOID();
		OrgAPI orgAPI = IAMProxy.getInstance().getOrgAPI();
		OrgDomain orgDom = null;
		try
		{
			orgDom = orgAPI.getOrgDomain(domainName);
			if (orgDom != null && orgDom.getZOID() == zoid)
			{ // if org domain and belongs to the current org
				boolean delresult = orgAPI.deleteOrgDomain(domainName);
				if (!delresult)
				{
					LOGGER.info("Domain deletion failed");
				}
			}
			else
			{
				LOGGER.info("Attempt to delete non-org domain");
			}
		}
		catch (IAMException e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
	}

	public static void verifyDomain(String domainName, int verificationMode) throws IAMException
	{
		OrgAPI orgAPI = IAMProxy.getInstance().getOrgAPI();
		OrgDomain orgDomain = orgAPI.getOrgDomain(domainName);
		long ZUID = IAMUtil.getCurrentUser().getZUID();
		long ZOID = IAMUtil.getCurrentUser().getZOID();

		if (verificationMode == OrgDomain.CNAME_VERIFICATION_MODE)
		{
			ArrayList<String> validIPAddresses = DomainUtils.lookup(AppResources.getProperty("domain.validation.url", "domain.zoho.com")); //No I18N
			String cname = new StringBuffer("zb").append(orgDomain.getVerCode(), 0, 8).append('.').append(domainName).toString(); //No I18N
			ArrayList<String> ipAddresses = DomainUtils.lookup(cname);
			//if the CNAME is not yet configured, then no ips will be returned. This is an invalid condition
			if (ipAddresses == null || ipAddresses.size() < 1)
			{
				throw new IdmpodException(ErrorCode.DOMAIN_VERIFICATION_CNAME_FAIL);
			}

			if (validIPAddresses.containsAll(ipAddresses))
			{
				orgAPI.updateDomainVerification(domainName, true, ZUID);
			}
			else
			{
				throw new IdmpodException(ErrorCode.DOMAIN_VERIFICATION_CNAME_FAIL);
			}
		}
		else if (verificationMode == OrgDomain.HTML_VERIFICATION_MODE)
		{
			Org org = orgAPI.getOrg(ZOID);
			String url = new StringBuffer("http://www.").append(domainName).append("/zohoverify/verifyforzoho.html").toString(); //No I18N

			String codeToBeChecked = DomainUtils.getContentFromUrl(url);
			String verificationCode = orgDomain.getVerCode();
			if (codeToBeChecked == null || !codeToBeChecked.contains(verificationCode))
			{
				// Try without www
				url = new StringBuffer("http://").append(domainName).append("/zohoverify/verifyforzoho.html").toString(); //No I18N
				codeToBeChecked = DomainUtils.getContentFromUrl(url);
			}

			if (codeToBeChecked != null && codeToBeChecked.contains(verificationCode))
			{
				//domain successfully validated, update the orgDomain object
				orgAPI.updateDomainVerification(domainName, true, ZUID);
			}
			else
			{
				throw new IdmpodException(ErrorCode.DOMAIN_VERIFICATION_HTML_FAIL);
			}
		}
	}

	public static class SYNC_TYPE
	{
		public static final Long FETCH_ONLY = 0L;
		public static final Long FETCH_AND_IAM = 1L;
	}

	public static class SYNC_STATUS
	{
		public static final Long QUEUED = 0L;
		public static final Long RUNNING = 1L;
		public static final Long FAILURE = 2L;
		public static final Long SUCCESS = 3L;
		public static final Long STOPPING = 5L;
		public static final Long STOPPED = 6L;
	}

	public static Long fetchSampleData(Long directoryId) throws DataAccessException, QueryConstructionException
	{
		Criteria jobCrit = new Criteria(Column.getColumn(IDMPODDIRECTORYJOBS.TABLE, IDMPODDIRECTORYJOBS.DIRECTORY_ID), directoryId, QueryConstants.EQUAL);
		jobCrit = jobCrit.and(new Criteria(Column.getColumn(IDMPODDIRECTORYJOBS.TABLE, IDMPODDIRECTORYJOBS.JOB_TYPE), ScheduleUtil.JobType.ONE_TIME, QueryConstants.EQUAL));
		jobCrit = jobCrit.and(new Criteria(Column.getColumn(IDMPODDIRECTORYSYNCDETAILS.TABLE, IDMPODDIRECTORYSYNCDETAILS.SYNC_STATUS), SYNC_STATUS.RUNNING, QueryConstants.EQUAL));

		ArrayList<String> tablesList = new ArrayList<String>();
		tablesList.add(IDMPODDIRECTORYJOBS.TABLE);
		tablesList.add(IDMPODDIRECTORYSYNCDETAILS.TABLE);

		boolean[] isLeftJoins = new boolean[tablesList.size()];
		Arrays.fill(isLeftJoins, true);

		SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, jobCrit);

		DataObject dobj = DBUtils.getOrgPersistence().get(query);

		// LOGGER.info("Select Query:" + DBUtils.getOrgRelationalApi().getSelectSQL(query));

		Row jobRow = null;

		if (dobj.containsTable(IDMPODDIRECTORYJOBS.TABLE))
		{
			jobRow = dobj.getFirstRow(IDMPODDIRECTORYJOBS.TABLE);
		}
		else
		{
			Row typeRow = getDirectoryTypeRowForDirectory(directoryId);

			jobRow = new Row(IDMPODDIRECTORYJOBS.TABLE);
			jobRow.set(IDMPODDIRECTORYJOBS.DIRECTORY_ID, directoryId);
			jobRow.set(IDMPODDIRECTORYJOBS.JOB_TYPE, ScheduleUtil.JobType.ONE_TIME);
			jobRow.set(IDMPODDIRECTORYJOBS.SYNC_TYPE, SYNC_TYPE.FETCH_ONLY);

			dobj.addRow(jobRow);

			DBUtils.getOrgPersistence().add(dobj);

			String typeHandler = typeRow.get(IDMPODDIRECTORYTYPES.TYPE_HANDLER).toString();

			String syncClass = null;
			if (typeHandler.equalsIgnoreCase("ActiveDirectory"))
			{
				syncClass = "com.manageengine.idmpod.server.iam.directory.jobs.ActiveDirectorySyncJob"; // No I18N
			}
			else if (typeHandler.equalsIgnoreCase("AzureActiveDirectory"))
			{
				syncClass = "com.manageengine.idmpod.server.iam.directory.jobs.AzureActiveDirectorySyncJob"; // No I18N
			}
			else if (typeHandler.equalsIgnoreCase("GSuite"))
			{
				syncClass = "com.manageengine.idmpod.server.iam.directory.jobs.GSuiteDirectorySyncJob"; // No I18N
			}

			// LOGGER.info("syncClass:" + syncClass);
			ScheduleUtil.addInMemoryTask((Long) jobRow.get(IDMPODDIRECTORYJOBS.JOB_ID), syncClass);
		}

		return (Long) jobRow.get(IDMPODDIRECTORYJOBS.JOB_ID);
	}

	public static Long syncNow(Long directoryId) throws DataAccessException, QueryConstructionException
	{
		Criteria jobCrit = new Criteria(Column.getColumn(IDMPODDIRECTORYJOBS.TABLE, IDMPODDIRECTORYJOBS.DIRECTORY_ID), directoryId, QueryConstants.EQUAL);
		jobCrit = jobCrit.and(new Criteria(Column.getColumn(IDMPODDIRECTORYJOBS.TABLE, IDMPODDIRECTORYJOBS.JOB_TYPE), ScheduleUtil.JobType.ONE_TIME, QueryConstants.EQUAL));
		jobCrit = jobCrit.and(new Criteria(Column.getColumn(IDMPODDIRECTORYSYNCDETAILS.TABLE, IDMPODDIRECTORYSYNCDETAILS.SYNC_STATUS), SYNC_STATUS.RUNNING, QueryConstants.EQUAL));

		ArrayList<String> tablesList = new ArrayList<String>();
		tablesList.add(IDMPODDIRECTORYJOBS.TABLE);
		tablesList.add(IDMPODDIRECTORYSYNCDETAILS.TABLE);

		boolean[] isLeftJoins = new boolean[tablesList.size()];
		Arrays.fill(isLeftJoins, true);

		SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, jobCrit);

		DataObject dobj = DBUtils.getOrgPersistence().get(query);

		Row jobRow = null;

		if (dobj.containsTable(IDMPODDIRECTORYJOBS.TABLE))
		{
			jobRow = dobj.getFirstRow(IDMPODDIRECTORYJOBS.TABLE);
		}
		else
		{
			Row typeRow = getDirectoryTypeRowForDirectory(directoryId);

			jobRow = new Row(IDMPODDIRECTORYJOBS.TABLE);
			jobRow.set(IDMPODDIRECTORYJOBS.DIRECTORY_ID, directoryId);
			jobRow.set(IDMPODDIRECTORYJOBS.JOB_TYPE, ScheduleUtil.JobType.ONE_TIME);
			jobRow.set(IDMPODDIRECTORYJOBS.SYNC_TYPE, SYNC_TYPE.FETCH_AND_IAM);

			dobj.addRow(jobRow);

			DBUtils.getOrgPersistence().add(dobj);

			String typeHandler = typeRow.get(IDMPODDIRECTORYTYPES.TYPE_HANDLER).toString();

			String syncClass = null;
			if (typeHandler.equalsIgnoreCase("ActiveDirectory"))
			{
				syncClass = "com.manageengine.idmpod.server.iam.directory.jobs.ActiveDirectorySyncJob"; // No I18N
			}
			else if (typeHandler.equalsIgnoreCase("AzureActiveDirectory"))
			{
				syncClass = "com.manageengine.idmpod.server.iam.directory.jobs.AzureActiveDirectorySyncJob"; // No I18N
			}
			else if (typeHandler.equalsIgnoreCase("GSuite"))
			{
				syncClass = "com.manageengine.idmpod.server.iam.directory.jobs.GSuiteDirectorySyncJob"; // No I18N
			}

			// LOGGER.info("syncClass:" + syncClass);
			ScheduleUtil.addInMemoryTask((Long) jobRow.get(IDMPODDIRECTORYJOBS.JOB_ID), syncClass);
		}

		return (Long) jobRow.get(IDMPODDIRECTORYJOBS.JOB_ID);
	}

	private static Row getDirectoryTypeRowForDirectory(Long directoryId) throws DataAccessException
	{
		Criteria dirCrit = new Criteria(Column.getColumn(IDMPODDIRECTORIES.TABLE, IDMPODDIRECTORIES.DIRECTORY_ID), directoryId, QueryConstants.EQUAL);

		ArrayList<String> tablesList = new ArrayList<String>();
		tablesList.add(IDMPODDIRECTORYTYPES.TABLE);
		tablesList.add(IDMPODDIRECTORIES.TABLE);

		boolean[] isLeftJoins = new boolean[tablesList.size()];
		Arrays.fill(isLeftJoins, true);

		SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, dirCrit);

		DataObject dobj = DBUtils.getOrgPersistence().get(query);

		return dobj.getRow(IDMPODDIRECTORYTYPES.TABLE);
	}

	public static void handleSyncDirectoryUser(Long zoid, String email, String userName, Row userRow) throws Exception
	{
		UserAPI uapi = IAMProxy.getInstance().getUserAPI();
		User user = uapi.getUser(email);
		if (user == null && DomainUtils.isDomainVerified(zoid, email))
		{
			//If Domain verified add Directly
			if (LicenseUtil.allowAddUsers(1))
			{
				Long zuid = AppAccountUtils.addUserToIAM(zoid, userName, null, email);
				DirectoryHandler.addUserFromIAM(zoid, uapi.getUser(zuid));
				userRow.set(IDMPODSYNCHEDUSERS.ZUID, zuid);
			}
		}
		else if (user == null)
		{
			//If not verified domain but new user;
			//Invitation not allowed; So options? -Currently none; implement add Domain
			//			AppAccountUtils.sendInvitation(email);
			//			DBUtils.addInvitedUserEntry("", "", email, IdmpodUserRole.USER, null);
			userRow.set(IDMPODSYNCHEDUSERS.ZUID, null);
		}
		else
		{
			//Existing user;
			if (LicenseUtil.allowAddUsers(1))
			{
				DirectoryHandler.addUserFromIAM(zoid, user);
			}
			userRow.set(IDMPODSYNCHEDUSERS.ZUID, user.getZUID());
		}
	}
}
