package com.manageengine.idmpod.server.iam.directory.azure;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.iam.directory.DirectoryHandler;
import com.manageengine.idmpod.server.utils.HttpUtils;
import com.manageengine.idmpod.server.utils.IdmpodUtils;
import com.manageengine.tables.idmpod.IDMPODAZUREDATASTORE;
import com.manageengine.tables.idmpod.IDMPODDIRECTORYNODES;
import com.microsoft.aad.adal4j.AuthenticationContext;
import com.microsoft.aad.adal4j.AuthenticationResult;
import com.microsoft.aad.adal4j.ClientCredential;
import com.microsoft.azure.AzureEnvironment;
import org.apache.http.client.methods.HttpGet;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URI;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.logging.Logger;

public class AzureHandler
{
	private static final Logger LOGGER = Logger.getLogger(AzureHandler.class.getName());

	private static final String APPLICATION_NAME = "Identity Manager Plus"; // NO I18N

	public static final String ACTIVE_DIRECTORY_ENDPOINT_URL = "https://login.microsoftonline.com/"; // No I18N
	public static final String CLIENT_ID = IdmpodUtils.getProperty("azure.client_id");
	public static final String CLIENT_SECRET = IdmpodUtils.getProperty("azure.client_secret");

	public static ClientCredential credential = new ClientCredential(CLIENT_ID, CLIENT_SECRET);

	public static String getRedirectUrl() throws IOException
	{
		String serviceUrl = IdmpodUtils.getServiceUrl();
		if (!serviceUrl.endsWith("/"))
		{
			serviceUrl = serviceUrl + "/";
		}
		return serviceUrl + "azurecb"; // NO I18N
	}

	public static String createAuthToken()
	{
		String id = null;
		try
		{
			DataObject dataObject = DBUtils.getOrgPersistence().constructDataObject();
			Row r = new Row(IDMPODAZUREDATASTORE.TABLE);
			dataObject.addRow(r);
			DBUtils.getOrgPersistence().add(dataObject);

			id = r.get(IDMPODAZUREDATASTORE.UNIQUE_ID).toString();
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return id;
	}

	public static void updateAuthToken(JSONObject req)
	{
		String id = req.getString("state");
		String code = req.optString("code", null); // NO I18N
		String error = req.optString("error", null); // NO I18N

		try
		{
			DataObject dataObject = DBUtils.getOrgPersistence().get(IDMPODAZUREDATASTORE.TABLE, new Criteria(Column.getColumn(IDMPODAZUREDATASTORE.TABLE, IDMPODAZUREDATASTORE.UNIQUE_ID), id, QueryConstants.EQUAL));
			if (dataObject.containsTable(IDMPODAZUREDATASTORE.TABLE))
			{
				Row r = dataObject.getFirstRow(IDMPODAZUREDATASTORE.TABLE);
				if (code != null)
				{
					AuthenticationContext context = null;
					AuthenticationResult result = null;
					ExecutorService exeService = null;

					AzureEnvironment environment = AzureEnvironment.AZURE;
					String endUrl = environment.activeDirectoryEndpoint();
					String graphEndpoint = environment.graphEndpoint();

					try
					{
						exeService = Executors.newFixedThreadPool(1);
						context = new AuthenticationContext(endUrl + "common", false, exeService); // NO I18N
						Future<AuthenticationResult> future = context.acquireTokenByAuthorizationCode(code, new URI(getRedirectUrl()), credential, graphEndpoint, null);
						result = future.get();
						exeService.shutdown();
					}
					catch (Exception e)
					{
						LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
					}

					r.set(IDMPODAZUREDATASTORE.ENCRYPTED_CODE, result.getRefreshToken());
				}
				else
				{
					r.set(IDMPODAZUREDATASTORE.STATUS, error);
				}

				dataObject.updateRow(r);

				DBUtils.getOrgPersistence().update(dataObject);
			}
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

	}

	public static JSONObject getAuthToken(String id)
	{
		final String TYPE = JsonApiHandler.ResourceType.AZURE_AUTH_TOKEN.getResType();
		try
		{
			DataObject dataObject = DBUtils.getOrgPersistence().get(IDMPODAZUREDATASTORE.TABLE, new Criteria(Column.getColumn(IDMPODAZUREDATASTORE.TABLE, IDMPODAZUREDATASTORE.UNIQUE_ID), id, QueryConstants.EQUAL));
			if (dataObject.containsTable(IDMPODAZUREDATASTORE.TABLE))
			{
				Row r = dataObject.getFirstRow(IDMPODAZUREDATASTORE.TABLE);

				JSONObject authTokenAttrs = new JSONObject();
				authTokenAttrs.put(IDMPODAZUREDATASTORE.ENCRYPTED_CODE, r.get(IDMPODAZUREDATASTORE.ENCRYPTED_CODE));

				JSONObject authToken = new JSONObject();
				authToken.put(JsonApiConstants.ID, id);
				authToken.put(JsonApiConstants.TYPE, TYPE);
				authToken.put(JsonApiConstants.ATTRIBUTES, authTokenAttrs);

				// LOGGER.info(authToken.toString());

				return authToken;
			}
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		return null;
	}

	public static void addDirectory(JSONObject request, JSONObject resp)
	{
		// LOGGER.info(request.toString());

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);
		JSONObject relationships = data.getJSONObject(JsonApiConstants.RELATIONSHIPS);
		JSONObject authTokenInfo = relationships.getJSONObject("azure-auth-token").getJSONObject(JsonApiConstants.DATA);
		Long refreshTokenId = authTokenInfo.optLong(JsonApiConstants.ID);
		String baseDomainName = attributes.get("BASE_DOMAIN_NAME").toString();
		attributes.put("AZURE_AUTH_TOKEN_ID", refreshTokenId);

		JSONArray errors = resp.has(JsonApiConstants.ERRORS) ? resp.getJSONArray(JsonApiConstants.ERRORS) : new JSONArray();
		JSONArray included = new JSONArray();


		DirectoryHandler.addDirectory(data);
		String directoryId = data.optString(JsonApiConstants.ID);

		try
		{
			relationships.put("domains", JsonApiHandler.getResourceObject(fetchAndUpdateDomains(refreshTokenId.toString(), baseDomainName, included, directoryId)));
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (IOException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		if (errors != null && errors.length() > 0)
		{
			resp.put(JsonApiConstants.ERRORS, errors);
		}
		else
		{
			resp.put(JsonApiConstants.DATA, data);
			if (included.length() > 0)
			{
				resp.put(JsonApiConstants.INCLUDED, included);
			}
		}
	}

	private static JSONArray fetchAndUpdateDomains(String refreshTokenId, String baseDomainName, JSONArray included, String directoryId) throws DataAccessException, IOException
	{
		DataObject dObj = DBUtils.getOrgPersistence().get(IDMPODDIRECTORYNODES.TABLE, new Criteria(Column.getColumn(IDMPODDIRECTORYNODES.TABLE, IDMPODDIRECTORYNODES.DIRECTORY_ID), Long.valueOf(directoryId), QueryConstants.EQUAL));
		JSONArray resp = null;

		AzureEnvironment environment = AzureEnvironment.AZURE;
		String graphUrl = environment.graphEndpoint();

		try
		{
			String urlString = graphUrl + baseDomainName + "/domains/";//No I18N

			AuthenticationResult authentication = getAuthentication(refreshTokenId, environment.activeDirectoryEndpoint());

			HttpGet hg = new HttpGet(HttpUtils.constructUrl(urlString, new String[]{"api-version", "1.6"}));//No I18N
			hg.setHeader("Authorization", authentication.getAccessTokenType() + " " + authentication.getAccessToken());//No I18N
			hg.setHeader("Accept", "application/json");//No I18N
			hg.setHeader("Content-Type", "application/json");//No I18N

			HttpUtils.HttpResult httpResponse = HttpUtils.getHttpResponse(hg);

			if (httpResponse.getStatus() == 200)
			{
				JsonParser parser = new JsonParser();
				JsonObject appResponse = parser.parse(httpResponse.getContent()).getAsJsonObject();
				JSONObject oresponse = new JSONObject(appResponse.toString());
				JSONArray domains = oresponse.getJSONArray("value");//No I18N

				for (int i = 0; i < domains.length(); i++)
				{
					JSONObject domain = domains.getJSONObject(i);
					String domainName = domain.getString("name");

					Row domainRow = dObj.getRow(IDMPODDIRECTORYNODES.TABLE, new Criteria(Column.getColumn(IDMPODDIRECTORYNODES.TABLE, IDMPODDIRECTORYNODES.NODE_IDENTIFIER), domainName, QueryConstants.EQUAL, false));
					if (domainRow == null && domain.getBoolean("isVerified"))
					{
						domainRow = new Row(IDMPODDIRECTORYNODES.TABLE);

						domainRow.set(IDMPODDIRECTORYNODES.NODE_IDENTIFIER, domainName);
						domainRow.set(IDMPODDIRECTORYNODES.NODE_DISPLAY_NAME, domainName);
						domainRow.set(IDMPODDIRECTORYNODES.DIRECTORY_ID, directoryId);

						dObj.addRow(domainRow);

						DBUtils.getOrgPersistence().fillGeneratedValues(dObj);
					}
					if (domain.getBoolean("isVerified"))
					{
						if (resp == null)
						{
							resp = new JSONArray();
						}
						JSONObject domainObj = new JSONObject();
						domainObj.put(IDMPODDIRECTORYNODES.NODE_IDENTIFIER, domainName);
						domainObj.put(IDMPODDIRECTORYNODES.NODE_DISPLAY_NAME, domainName);
						domainObj.put(IDMPODDIRECTORYNODES.DIRECTORY_ID, directoryId);
						domainObj.put(IDMPODDIRECTORYNODES.NODE_ID, domainRow.get(IDMPODDIRECTORYNODES.NODE_ID));
						JSONObject rel = new JSONObject();
						rel.put("directory", JsonApiHandler.getResourceObject(JsonApiHandler.getResourceIdentifierObject("directory", directoryId)));
						JSONObject resObj = JsonApiHandler.getResourceObject("domains", domainRow.get(IDMPODDIRECTORYNODES.NODE_ID).toString(), domainObj, rel);//NO I18N
						included.put(resObj);
						resp.put(resObj);
					}
				}
			}
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		DBUtils.getOrgPersistence().update(dObj);
		return resp;
	}

	public static AuthenticationResult getAuthentication(String refreshTokenId, String endUrl) throws DataAccessException
	{
		DataObject dataObject = DBUtils.getOrgPersistence().get(IDMPODAZUREDATASTORE.TABLE, new Criteria(Column.getColumn(IDMPODAZUREDATASTORE.TABLE, IDMPODAZUREDATASTORE.UNIQUE_ID), refreshTokenId, QueryConstants.EQUAL));

		AuthenticationContext context = null;
		AuthenticationResult result = null;
		ExecutorService exeService = null;

		String refreshToken = null;
		try
		{
			Row row = dataObject.getFirstRow(IDMPODAZUREDATASTORE.TABLE);
			refreshToken = row.get(IDMPODAZUREDATASTORE.ENCRYPTED_CODE).toString();

			// LOGGER.info("refreshToken : "+refreshToken);

			exeService = Executors.newFixedThreadPool(1);
			context = new AuthenticationContext(endUrl + "common", false, exeService); // NO I18N
			Future<AuthenticationResult> future = context.acquireTokenByRefreshToken(refreshToken, credential, null);
			result = future.get();
			exeService.shutdown();

			row.set(IDMPODAZUREDATASTORE.ENCRYPTED_CODE, result.getRefreshToken());
			dataObject.updateRow(row);
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		DBUtils.getOrgPersistence().update(dataObject);
		return result;
	}

	public static void updateDirectory(JSONObject request, JSONObject resp)
	{
		// LOGGER.info(request.toString());

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);
		JSONObject relationships = data.getJSONObject(JsonApiConstants.RELATIONSHIPS);
		JSONObject authTokenInfo = relationships.getJSONObject("azure-auth-token").getJSONObject(JsonApiConstants.DATA);
		Long refreshTokenId = authTokenInfo.optLong(JsonApiConstants.ID);
		String baseDomainName = attributes.get("BASE_DOMAIN_NAME").toString();
		attributes.put("AZURE_AUTH_TOKEN_ID", refreshTokenId);

		JSONArray errors = resp.has(JsonApiConstants.ERRORS) ? resp.getJSONArray(JsonApiConstants.ERRORS) : new JSONArray();
		JSONArray included = new JSONArray();

		String directoryId = data.optString(JsonApiConstants.ID);
		DirectoryHandler.updateDirectory(Long.parseLong(directoryId), data);

		try
		{
			relationships.put("domains", JsonApiHandler.getResourceObject(fetchAndUpdateDomains(refreshTokenId.toString(), baseDomainName, included, directoryId)));
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (IOException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		if (errors != null && errors.length() > 0)
		{
			resp.put(JsonApiConstants.ERRORS, errors);
		}
		else
		{
			resp.put(JsonApiConstants.DATA, data);
			if (included.length() > 0)
			{
				resp.put(JsonApiConstants.INCLUDED, included);
			}
		}
	}
}
