package com.manageengine.idmpod.server.error;

import com.adventnet.i18n.I18N;
import com.adventnet.iam.IAMErrorCode;
import com.adventnet.iam.IAMException;
import com.manageengine.idmpod.server.utils.IdmpodUtils;
import com.zoho.resource.ResourceException;

import java.util.logging.Level;
import java.util.logging.Logger;

public class IdmpodException extends RuntimeException
{
	private static final Logger LOGGER = Logger.getLogger(IdmpodException.class.getName());

	private final ErrorCode errorCode;

	public IdmpodException(ErrorCode errorCode)
	{
		this.errorCode = errorCode;
	}

	public IdmpodException(ErrorCode errorCode, Throwable e)
	{
		super(e);
		this.errorCode = errorCode;
	}

	public ErrorCode getErrorCode()
	{
		return this.errorCode;
	}

	public static String getErrorMessageForIAMException(IAMException ie)
	{
		String error = null;
		Throwable rootCause = IdmpodUtils.getRootCause(ie);
		if (rootCause instanceof ResourceException)
		{
			error = ((ResourceException) rootCause).getErrorCode().getDescription();
		}
		else
		{
			String errorCode = ie.getErrorCode();
			if (errorCode.equalsIgnoreCase("U128"))
			{
				try
				{
					error = I18N.getMsg("idmpod.exception.iam_exception.u128");
				}
				catch (Exception e)
				{
					LOGGER.log(Level.SEVERE, e.getMessage(), e);
				}
			}
			else
			{
				error = IAMErrorCode.getErrorDescription(errorCode);
			}
		}
		return error;
	}
}
