package com.manageengine.idmpod.server.iam;

import com.adventnet.iam.*;
import com.adventnet.iam.xss.IAMEncoder;
import com.adventnet.persistence.DataAccessException;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.error.ErrorCode;
import com.manageengine.idmpod.server.error.IdmpodException;
import com.manageengine.idmpod.server.utils.HttpUtils;
import com.manageengine.idmpod.server.utils.IdmpodThreadLocal;
import com.zoho.accounts.AccountsConstants;
import com.zoho.accounts.AccountsProto.Account.AppAccount;
import com.zoho.accounts.AccountsUtil;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class IdmpodIAMUtil
{


	private static final Logger LOGGER = Logger.getLogger(IdmpodIAMUtil.class.getName());

	private static final String DEFAULT_ORG_SUFFIX = " - idmpod";//No I18N

	public static final AccountsConstants.OrgType IDMPOD_ORG_TYPE = AccountsConstants.OrgType.IDMPOD;

	private static Service idmpodService = null;

	private static String serviceName;

	private static String loginRedirectUrl;
	private static String logoutRedirectUrl;

	public static String getServiceName()
	{
		if (serviceName == null)
		{
			serviceName = System.getProperty("service.name");
		}
		return serviceName;
	}

	private static String iamServerUrl;

	public static String getIAMServerURL()
	{
		if (iamServerUrl == null)
		{
			iamServerUrl = IAMProxy.getIAMServerURL();
		}
		return iamServerUrl;
	}

	public static Service getIAMService()
	{
		if (idmpodService == null)
		{
			idmpodService = IAMProxy.getInstance().getServiceAPI().getService(getServiceName());
		}
		return idmpodService;
	}

	public static String getLoginRedirectUrl()
	{
		if (loginRedirectUrl == null)
		{
			String httpServerUrl = AppAccountUtils.SERVICE_URL;
			loginRedirectUrl = new StringBuilder(IAMProxy.getIAMServerURL()).append("/login?servicename=")//No I18N
					.append(IdmpodIAMUtil.getServiceName()).append("&serviceurl=")//No I18N
					.append(httpServerUrl).append("&signupurl=")//No I18N
					.append(httpServerUrl).append("/signup")//No I18N
					.toString();
		}
		return loginRedirectUrl;
	}

	public static String getLogoutRedirectUrl()
	{
		if (logoutRedirectUrl == null)
		{
			String httpServerUrl = AppAccountUtils.SERVICE_URL;
			logoutRedirectUrl = new StringBuilder(IAMUtil.getLogoutURL()).append("?servicename=")//No I18N
					.append(IdmpodIAMUtil.getServiceName()).append("&serviceurl=")//No I18N
					.append(httpServerUrl).toString();
		}
		return logoutRedirectUrl;
	}

	public static String getLoggedInDataspaceName()
	{
		AppAccount appAccount = AccountsUtil.getCurrentAppAccount();
		String dataSpaceName = (appAccount != null) ? appAccount.getZaaid() : null;
		// LOGGER.log(Level.INFO, "IAMUtil:getLoggedInDataspaceName() - Logged In Data Space Name - {0}", dataSpaceName);
		return dataSpaceName;
	}

	//	public static String createOAuthRefreshToken(String... scopes) throws IAMException
	//	{
	//		OAuthAPI oAuthApi = IAMProxy.getInstance().getOAuthAPI();
	//		String clientId = IdmpodUtils.getProperty(IdmpodUtils.CONFIG_KEY_OAUTH_CLIENTID, null);
	//		long userId = IAMUtil.getCurrentUser().getZUID();
	//		String userTicket = IAMUtil.getCurrentTicket();
	//		return oAuthApi.generateUserOAuthRefreshTokenbyTicket(clientId, userId, userTicket, scopes, null, null, null);
	//	}

	private static final String REVOKE_OAUTH_PATH = "/oauth/v2/token/revoke";//No I18N

	public static void deleteOAuthRefreshToken(String refreshToken) throws Exception
	{
		String iamServerUrl = getIAMServerURL();
		String response = HttpUtils.getHttpResponse(iamServerUrl + REVOKE_OAUTH_PATH, "token", refreshToken)//No I18N
				.getContent();
		// LOGGER.log(Level.INFO, "revoke refreshToken response:{0}", response);
	}

	public static boolean inviteUser(String firstName, String lastName, String emailid, IdmpodUserRole role)
	{
		try
		{
			String iamRoleString = IdmpodUserRole.getIAMRole(role);
			//add user with default/simple/0 role in org level and given role in account level
			IAMProxy.getInstance().getAppAccountAPI().inviteUserToAppAccount(IDMPOD_ORG_TYPE.getType(), IdmpodThreadLocal.getAppIdLong(), emailid, firstName, lastName, getServiceName(), iamRoleString, IdmpodThreadLocal.getRequest().getRemoteAddr(), getIAMService().getWebUrl(), null, -1, IdmpodUserRole.getOrgRole(role));
		}
		catch (Exception ex)
		{
			LOGGER.log(Level.SEVERE, "exception while inviting user", ex);
			return false;
		}
		return true;
	}

	private static String getAppAccountRole(IdmpodUserRole role)
	{
		if (role == IdmpodUserRole.ADMINISTRATOR)
		{
			return AccountsConstants.Role.ADMIN;
		}
		else
		{
			return AccountsConstants.Role.USER;
		}
	}

	public static boolean reInviteUser(String emailId, String firstName, String lastName, IdmpodUserRole userRole)
	{
		try
		{
			String appAccountRole = getAppAccountRole(userRole);
			long zaaid = Long.parseLong(IdmpodThreadLocal.getAppId());
			deleteInvitation(emailId);
			IAMProxy.getInstance().getAppAccountAPI().reInviteUserToAppAccount(IDMPOD_ORG_TYPE.getType(), zaaid, emailId, firstName, lastName, getServiceName(), appAccountRole, IdmpodThreadLocal.getRequest().getRemoteAddr(), getIAMService().getWebUrl(), null, -1);
		}
		catch (IAMException ex)
		{
			LOGGER.log(Level.SEVERE, "exception while reinviting user", ex);
			return false;
		}
		return true;
	}

	public static void deleteInvitation(String email) throws IAMException
	{
		long zaaid = IdmpodThreadLocal.getAppIdLong();
		IAMProxy.getInstance().getAppAccountAPI().deleteInvitation(IDMPOD_ORG_TYPE.getType(), zaaid, email, getServiceName());
	}

	public static void deleteUser(long zuid) throws IAMException
	{
		String email = IAMProxy.getInstance().getUserAPI().getUser(zuid).getPrimaryEmail();
		deleteInvitation(email);
		IAMProxy.getInstance().getAppAccountAPI().removeAccountMember(IDMPOD_ORG_TYPE.getType(), IdmpodThreadLocal.getAppIdLong(), zuid, IdmpodIAMUtil.getServiceName());
	}

	public static void changeStatus(long zuid, boolean active) throws IAMException
	{
		// LOGGER.log(Level.FINER, "IdmpodIAMUtil:changeStatus going to update the user {0} with status - {1}", new Object[]{zuid, active});
		int statusId;
		if (active)
		{
			statusId = AccountsConstants.AppAccountMemberStatus.ACTIVE;
		}
		else
		{
			statusId = AccountsConstants.AppAccountMemberStatus.INACTIVE;
		}
		IAMProxy.getInstance().getAppAccountAPI().changeAccountMemberStatus(IDMPOD_ORG_TYPE.getType(), IdmpodThreadLocal.getAppIdLong(), zuid, getServiceName(), statusId);
	}

	public static void changeUserRole(IdmpodUserRole role, long zuid)
	{
		// LOGGER.log(Level.FINER, "IdmpodIAMUtil:changeUserRole going to change the user role as {0} for user - {1}", new Object[]{role, zuid});
		String appAcRole = getAppAccountRole(role);
		try
		{
			long zaaid = IdmpodThreadLocal.getAppIdLong();
			IAMProxy.getInstance().getAppAccountAPI().changeAccountMemberRole(IDMPOD_ORG_TYPE.getType(), zaaid, zuid, getServiceName(), UserUtils.getZARID(appAcRole));
			IAMProxy.getInstance().getAppAccountAPI().changeOrgUserRole(IDMPOD_ORG_TYPE.getType(), zaaid, zuid, getServiceName());
		}
		catch (IAMException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
	}

	//only OrgAdmin or non-org user can create space
	public static boolean canUserCreateSpace()
	{
		User currentUser = IAMUtil.getCurrentUser();
		boolean result = false;
		if (currentUser.getZOID() == -1)
		{//non Org user can always create DBSpace
			result = true;
		}
		else if (currentUser.isOrgAdmin())
		{
			result = true;
		}
		return result;
	}

	/**
	 * If user signup made on our page, we will validate org name and Org for that user will be created.
	 * But, if user signup did from accounts site, we will create unique org name and Org for that user
	 * will be created after login only and it will be done in this method while handling first time login.
	 *
	 * @throws IAMException
	 */
	public static Org getOrCreateOrg() throws IAMException
	{
		Org org = IAMUtil.getCurrentUserOrg();
		if (org == null)
		{
			User user = IAMUtil.getCurrentUser();
			AppAccountAPI aaapi = IAMProxy.getInstance().getAppAccountAPI();
			String email = user.getPrimaryEmail();
			String orgName = email.substring(0, email.indexOf("@"));//No I18N
			orgName = orgName.replaceAll("[^A-Za-z0-9-]", "");//No I18N
			orgName += DEFAULT_ORG_SUFFIX;
			//LOGGER.log(Level.INFO, "userOrg null. creating Org :{0} via createAppAccount API", orgName);

			//invoke app account creation with new org and current user as org admin
			aaapi.createAppAccount(IDMPOD_ORG_TYPE.getType(), user.getZaid(), user.getZUID(), IdmpodIAMUtil.getServiceName(), orgName, orgName, true, UserUtils.getZARID(AccountsConstants.Role.SUPER_ADMIN));

			//get org object from user's zaid
			long zaid = Long.parseLong(user.getZaid());
			org = IAMProxy.getInstance().getOrgAPI().getOrg(zaid);
			user.setUserRole(2);
			user.setZOID(org.getZOID());
			IAMUtil.setCurrentUser(user);
		}
		// LOGGER.log(Level.INFO, "returning org with id:{0}", org.getZOID());
		return org;
	}

	/**
	 * AppAccount for the given user will be fetched using IAM APIs. if empty, new appaccount will
	 * be created with SUPER_ADMIN role for the current user
	 *
	 * @return
	 * @throws IAMException
	 */
	public static String getOrCreateZaaid(Org org) throws IAMException
	{
		AppAccount currAppAccount = AccountsUtil.getCurrentAppAccount();
		AppAccountAPI aaapi = IAMProxy.getInstance().getAppAccountAPI();
		User user = IAMUtil.getCurrentUser();
		String zaid = user.getZaid();
		long zuid = user.getZUID();
		String orgName = org.getOrgName();
		String serviceName = IdmpodIAMUtil.getServiceName();
		if (currAppAccount == null)
		{
			// LOGGER.log(Level.INFO, "currentAppAccount is null");
			List<AppAccount> appAcList = aaapi.getAllAppAccountForAccount(IDMPOD_ORG_TYPE.getType(), zaid, serviceName);
			if (appAcList != null && !appAcList.isEmpty())
			{
				// LOGGER.log(Level.INFO, "getting first appAccount for the zaid:{0}", zaid);
				currAppAccount = appAcList.get(0);
			}
		}
		String zaaid;
		if (currAppAccount != null)
		{
			zaaid = currAppAccount.getZaaid();
		}
		else
		{
			String zarid = UserUtils.getZARID(AccountsConstants.Role.SUPER_ADMIN);
			// LOGGER.info("ZARID:" + zarid);
			Long zaaidL = aaapi.createAppAccount(IDMPOD_ORG_TYPE.getType(), zaid, zuid, serviceName, orgName, orgName, true, zarid);
			zaaid = zaaidL.toString();
		}
		return zaaid;
	}


	public static String checkAndCreateZaaid(User user, Org org) throws IAMException
	{
		AppAccountAPI aaapi = IAMProxy.getInstance().getAppAccountAPI();
		AppAccount currAppAccount = null;
		String zaid = user.getZaid();
		long zuid = user.getZUID();
		String orgName = org.getOrgName();
		String serviceName = IdmpodIAMUtil.getServiceName();
		if (currAppAccount == null)
		{
			List<AppAccount> appAcList = aaapi.getAllAppAccountForAccount(IDMPOD_ORG_TYPE.getType(), zaid, serviceName);
			if (appAcList != null && !appAcList.isEmpty())
			{
				currAppAccount = appAcList.get(0);
			}
		}
		String zaaid;
		if (currAppAccount != null)
		{
			zaaid = currAppAccount.getZaaid();
		}
		else
		{
			String zarid = UserUtils.getZARID(AccountsConstants.Role.SUPER_ADMIN);
			Long zaaidL = aaapi.createAppAccount(IDMPOD_ORG_TYPE.getType(), zaid, zuid, serviceName, orgName, orgName, true, zarid);
			zaaid = zaaidL.toString();
		}
		return zaaid;
	}

	/**
	 * After assuring space reservation, this method will be called.
	 *
	 * @throws IAMException
	 * @throws DataAccessException
	 * @throws IdmpodException
	 */
	public static void handleFirstTimeUserAccount() throws DataAccessException, IAMException, IdmpodException
	{
		User user = IAMUtil.getCurrentUser();
		String email = user.getPrimaryEmail();
		if (user.getUserRole() == AccountsConstants.UserRole.SUPER_ADMIN)
		{
			UserUtils.setUserRole(IdmpodUserRole.SUPER_ADMIN);//force Admin role for OrgAdmin
			UserUtils.setViewResource(UserUtils.RESOURCE_VIEW_ALL);//change resource view to all
		}
		else
		{
			IdmpodUserRole userRole = UserUtils.getUserRole();
			if (userRole == null)
			{//new user
				userRole = InviteUtils.getInvitedUserRole();
				if (userRole == null)
				{//user not invited. throw exception
					throw new IdmpodException(ErrorCode.USER_NOT_INVITED);
				}
				UserUtils.setUserRole(userRole);
				String viewResource = InviteUtils.getViewResource();
				UserUtils.setViewResource(viewResource);

				//remove from invited entries in db
				DBUtils.removeInvitedUser(email);
			}
		}
	}

	public static String getZAID()
	{
		return IAMUtil.getCurrentUser().getZaid();
	}

	public static Long getZOID()
	{
		return IAMUtil.getCurrentUser().getZOID();
	}

	public static void createOrg(String organization_name) throws IAMException
	{
		Org org = IAMUtil.getCurrentUserOrg();
		if (org == null)
		{
			User user = IAMUtil.getCurrentUser();
			AppAccountAPI aaapi = IAMProxy.getInstance().getAppAccountAPI();
			String orgName = organization_name.replaceAll("[^A-Za-z0-9-]", "");//No I18N
			LOGGER.log(Level.INFO, "creating Org :{0} via createAppAccount API", orgName);

			//invoke app account creation with new org and current user as org admin
			aaapi.createAppAccount(IDMPOD_ORG_TYPE.getType(), user.getZaid(), user.getZUID(), IdmpodIAMUtil.getServiceName(), organization_name, orgName, true, UserUtils.getZARID(AccountsConstants.Role.SUPER_ADMIN));

			//get org object from user's zaid
			long zaid = Long.parseLong(user.getZaid());
			org = IAMProxy.getInstance().getOrgAPI().getOrg(zaid);
			user.setUserRole(2);
			user.setZOID(org.getZOID());
			IAMUtil.setCurrentUser(user);
		}
	}

	public static Long checkAndCreateOrg(User user, String organization_name) throws IAMException
	{
		Org org = null;
		if (user.getZOID() != -1)
		{
			org = IAMProxy.getInstance().getOrgAPI().getOrg(user.getZOID());
		}
		if (org == null)
		{
			AppAccountAPI aaapi = IAMProxy.getInstance().getAppAccountAPI();
			String orgName = organization_name.replaceAll("[^A-Za-z0-9-]", "");//No I18N
			LOGGER.log(Level.INFO, "creating Org :{0} via createAppAccount API", orgName);

			//invoke app account creation with new org and current user as org admin
			aaapi.createAppAccount(IDMPOD_ORG_TYPE.getType(), user.getZaid(), user.getZUID(), IdmpodIAMUtil.getServiceName(), organization_name, orgName, true, UserUtils.getZARID(AccountsConstants.Role.SUPER_ADMIN));

			//get org object from user's zaid
			long zaid = Long.parseLong(user.getZaid());
			org = IAMProxy.getInstance().getOrgAPI().getOrg(zaid);
			user.setUserRole(2);
			user.setZOID(org.getZOID());
		}
		return org.getZOID();
	}

	public static String getLoginRedirectUrl(String serviceurl)
	{
		if (serviceurl == null)
		{
			return getLoginRedirectUrl();
		}
		else
		{
			String loginRedirectURL = null;
			try {
				loginRedirectURL = IAMProxy.getIAMServerURL() + "/login?servicename=" +//No I18N
					IdmpodIAMUtil.getServiceName() + "&serviceurl=" +//No I18N
					IAMEncoder.encodeURL(serviceurl) + "&signupurl=" +//No I18N
					AppAccountUtils.SERVICE_URL + "/signup"//No I18N
					;
			}
			catch(Exception e){
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
			return loginRedirectURL;
		}
	}
}
