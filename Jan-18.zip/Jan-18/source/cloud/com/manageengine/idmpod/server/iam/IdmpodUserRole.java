package com.manageengine.idmpod.server.iam;

import com.adventnet.iam.User;
import com.zoho.accounts.AccountsConstants;

public enum IdmpodUserRole
{
	SUPER_ADMIN, ADMINISTRATOR, USER;

	public static IdmpodUserRole getRole(String roleString)
	{
		roleString = roleString.toUpperCase();
		if (roleString.equalsIgnoreCase("SUPER ADMIN"))
		{
			return SUPER_ADMIN;
		}
		else
		{
			return IdmpodUserRole.valueOf(roleString);
		}
	}

	public static String getString(IdmpodUserRole userRole)
	{
		switch (userRole)
		{
			case SUPER_ADMIN:
				return "Super Admin";//No I18N
			case ADMINISTRATOR:
				return "Administrator";//No I18N
			case USER:
				return "User";//No I18N
		}
		return null;
	}

	public static String getIAMRole(IdmpodUserRole userRole)
	{
		String toReturn;
		if (userRole == SUPER_ADMIN)
		{
			toReturn = AccountsConstants.Role.SUPER_ADMIN;
		}
		else if (userRole == ADMINISTRATOR)
		{
			toReturn = AccountsConstants.Role.ADMIN;
		}
		else
		{
			toReturn = AccountsConstants.Role.USER;
		}
		return toReturn;
	}

	public static Integer getOrgRole(IdmpodUserRole userRole)
	{
		switch (userRole)
		{
			case ADMINISTRATOR:
				return User.ORG_ADMIN;
			case USER:
				return User.NONE;
		}
		return null;
	}

	@Override
	public String toString()
	{
		return getString(this);
	}
}
