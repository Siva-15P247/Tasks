package com.manageengine.idmpod.server.utils;


import com.adventnet.ds.query.Criteria;
import com.adventnet.iam.IAMUtil;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.adventnet.sas.ds.SASThreadLocal;
import com.adventnet.taskengine.inmemory.TaskExecutor;
import com.manageengine.tables.idmpod.IDMPODCOMMONJOBS;
import com.zoho.scheduler.*;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ScheduleUtil
{

	private static final String DEFAULT_POOL_NAME = "com.manageengine.idmpod.DefaultThreadPool"; // No I18N
	private static final String IN_MEMORY_TASK_EXECUTOR_NAME = "IdmpodTaskExecutor"; // No I18N
	private static final Integer IMTE_THREAD_POOL_SIZE = 20;
	private static final Integer IMTE_QUEUE_SIZE = 40;

	private static final Logger LOGGER = Logger.getLogger(ScheduleUtil.class.getName());

	public static String getInMemoryTaskExecutorName()
	{
		return IN_MEMORY_TASK_EXECUTOR_NAME;
	}

	public static Integer getImteQueueSize()
	{
		return IMTE_QUEUE_SIZE;
	}

	public static Integer getImteThreadPoolSize()
	{
		return IMTE_THREAD_POOL_SIZE;
	}

	public static void updateCalendarRepetition(Long jobId, Integer hours, Integer mins)
	{
		try
		{
			CalendarRepetition calendarRepetition = RepetitionManager.getInstance(DEFAULT_POOL_NAME).getCalendar(jobId.toString());
			IdmpodCalendarRepetition idmpodCalendarRepetition = new IdmpodCalendarRepetition(calendarRepetition);
			JSONObject executionTimeInfo = idmpodCalendarRepetition.getExecutionTimeInfo();
			hours = hours != null ? hours : executionTimeInfo.getInt("HOURS");//No I18N
			mins = mins != null ? mins : executionTimeInfo.getInt("MINUTES");//No I18N
			int seconds = 0;
			if (hours == 0 && mins == 0)
			{
				seconds = 5;
			}
			calendarRepetition.setExecutionTime(hours, mins, seconds);
			RepetitionManager.getInstance(DEFAULT_POOL_NAME).updateCalendar(calendarRepetition);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
	}

	public static void addInMemoryTask(Long jobId, String syncClass)
	{
		try
		{
			CommonDBUtil.addJobInCommonDB(jobId);
			Class<? extends Runnable> aClass = (Class<? extends Runnable>) Class.forName(syncClass);
			TaskExecutor.getExecutor(IN_MEMORY_TASK_EXECUTOR_NAME).submit(aClass.getDeclaredConstructor(Long.class).newInstance(jobId));
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
	}

	public static class JobType
	{
		public static final Long ONE_TIME = 0L;
		public static final Long REPETITION = 1L;
	}

	public static void addDailyCalendarRepetition(String name, Integer hours, Integer minutes, String date, String timeZone) throws Exception
	{
		CalendarRepetition c = new CalendarRepetition(name);
		c.setRepetitionType(CalendarRepetition.RepetitionType.DAILY);
		int seconds = 0;
		if (hours == 0 && minutes == 0)
		{
			seconds = 5;
		}
		c.setExecutionTime(hours, minutes, seconds);
		if (date != null)
		{
			c.setStartDate(getDayOfDate(date), getMonthOfDate(date) - 1, getYearOfDate(date));
		}
		if (timeZone == null)
		{
			timeZone = IAMUtil.getCurrentUser().getTimezone();
		}
		c.setTimeZone(timeZone);
		RepetitionManager.getInstance(DEFAULT_POOL_NAME).addCalendar(c);
	}

	public static void addDailyCalendarRepetition(String name, Integer hours, Integer minutes) throws Exception
	{
		CalendarRepetition c = new CalendarRepetition(name);
		c.setRepetitionType(CalendarRepetition.RepetitionType.DAILY);
		int seconds = 0;
		if (hours == 0 && minutes == 0)
		{
			seconds = 5;
		}
		c.setExecutionTime(hours, minutes, seconds);
		c.setIsCommon(true);
		RepetitionManager.getInstance(DEFAULT_POOL_NAME).addCalendar(c);
	}

	public static void addWeeklyCalendarRepetition(String name, Integer hours, Integer minutes, int[] daysOfWeek, String timeZone) throws Exception
	{
		CalendarRepetition c = new CalendarRepetition(name);
		c.setRepetitionType(CalendarRepetition.RepetitionType.WEEKLY);
		c.setExecutionTime(hours, minutes, 00);
		c.setDaysOfWeek(daysOfWeek);
		timeZone = (timeZone == null) ? IAMUtil.getCurrentUser().getTimezone() : timeZone;
		c.setTimeZone(timeZone);
		RepetitionManager.getInstance(DEFAULT_POOL_NAME).addCalendar(c);
	}

	/**
	 * @param name
	 * @param period           in seconds
	 * @param reschedulePolicy
	 * @param startDate
	 * @param endDate
	 * @throws Exception
	 */
	public static void addPeriodicRepetition(String name, int period, PeriodicRepetition.ReschedulePolicy reschedulePolicy, Long startDate, Long endDate) throws Exception
	{

		PeriodicRepetition prep = new PeriodicRepetition(name);
		prep.setPeriodicity(period);
		if (reschedulePolicy != null)
		{
			prep.setReschedulePolicy(reschedulePolicy);
		}
		if (startDate != null)
		{
			prep.setStartDate(startDate);
		}
		if (endDate != null)
		{
			prep.setEndDate(endDate);
		}
		RepetitionManager.getInstance(DEFAULT_POOL_NAME).addPeriodic(prep);
	}

	public static void updatePeriodicInterval(String repName, int secs) throws Exception
	{
		PeriodicRepetition pr = RepetitionManager.getInstance(DEFAULT_POOL_NAME).getPeriodic(repName);
		pr.setPeriodicity(secs);
		RepetitionManager.getInstance(DEFAULT_POOL_NAME).updatePeriodic(pr);
	}

	public static boolean addRepetitiveJob(String repetitionName, long jobID, String className, Boolean status) throws Exception
	{
		return addRepetitiveJob(DEFAULT_POOL_NAME, repetitionName, jobID, className, status, null);
	}

	public static boolean addRepetitiveJob(String repetitionName, long jobID, String className, Boolean status, Long time) throws Exception
	{
		return addRepetitiveJob(DEFAULT_POOL_NAME, repetitionName, jobID, className, status, time);
	}

	public static boolean addRepetitiveJob(Long jobID, String repetitionName, String className) throws Exception
	{
		RepetitiveJob rj = new RepetitiveJob(jobID, className);
		rj.setRepetition(repetitionName);
		rj.setTransactionTimeout(-1);

		Boolean status = null;
		status = (status != null) ? status : true;
		rj.setAdminStatus(status);

		JobScheduler.getInstance(DEFAULT_POOL_NAME).submitRepetitiveJob(rj);
		LOGGER.log(Level.INFO, "Repetitive Job is added for repetition {0},  jobid {1}, class {2}", new Object[]{repetitionName, jobID, className}); // No I18N
		return true;
	}

	public static boolean addRepetitiveJob(String pool, String repetitionName, long jobID, String className, Boolean status, Long time) throws Exception
	{
		try
		{
			CommonDBUtil.addJobInCommonDB(jobID);
			// JobID should be given by service . The user who add job should only use his id range for job id . Otherwise exception will be thrown .
			RepetitiveJob rj = new RepetitiveJob(jobID, className);
			rj.setRepetition(repetitionName);
			rj.setTransactionTimeout(-1);

			status = (status != null) ? status : true;
			rj.setAdminStatus(status);

			if (time != null)
			{
				rj.setTimeOfExecution(time);
			}
			JobScheduler.getInstance(pool).submitRepetitiveJob(rj);
			LOGGER.log(Level.INFO, "Repetitive Job is added for repetition {0},  jobid {1}, class {2}, time {3}", new Object[]{repetitionName, jobID, className, time}); // No I18N
			return true;
		}
		catch (TaskEngineException te)
		{
			if (te.getMessage().contains("Duplicate entry"))
			{
				LOGGER.log(Level.SEVERE, "Exception during add repetition jobID {0}::{1} Exception::{2}", new Object[]{repetitionName, jobID, te}); // No I18N
				return true;
			}
			else
			{
				LOGGER.log(Level.SEVERE, "Exception 1", te); // No I18N
				return false;
			}
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Exception ", e); // No I18N
			return false;
		}
	}

	public static Boolean getAdminStatus(long jobID) throws Exception
	{
		Job jobDetails = fetchJobDetails(jobID);
		if (jobDetails == null)
		{
			return null;
		}
		return jobDetails.getAdminStatus();
	}

	public static Job fetchJobDetails(long jobID) throws Exception
	{
		try
		{
			Job jobDetails = JobScheduler.getInstance(DEFAULT_POOL_NAME).fetchJob(jobID);
			return jobDetails;

		}
		catch (Exception e)
		{
			return null;//for one time sync,job entry is removed in JOB table ,so exception will happend
		}
	}

	public static Boolean getAdminStatus(long jobID, String poolName) throws Exception
	{
		Job jobDetails = fetchJobDetails(jobID, poolName);
		if (jobDetails == null)
		{
			return null;
		}
		return jobDetails.getAdminStatus();
	}

	public static Job fetchJobDetails(long jobID, String poolName) throws Exception
	{
		try
		{
			Job jobDetails = JobScheduler.getInstance(poolName).fetchJob(jobID);
			return jobDetails;

		}
		catch (Exception e)
		{
			return null;//for one time sync,job entry is removed in JOB table ,so exception will happend
		}
	}

	public static void disableJob(long jobID) throws Exception
	{
		try
		{
			Job rj = JobScheduler.getInstance(DEFAULT_POOL_NAME).fetchJob(jobID);
			rj.setAdminStatus(false);
			if (rj instanceof RepetitiveJob)
			{
				JobScheduler.getInstance(DEFAULT_POOL_NAME).updateRepetitiveJob((RepetitiveJob) rj);
			}
			LOGGER.log(Level.INFO, "updating ScheduledTime of job with jobID : '{'0'}'{0}", jobID); // No I18N
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Exception ", e); // No I18N
		}
	}

	public static boolean enableJob(long jobID) throws Exception
	{
		try
		{
			Job rj = JobScheduler.getInstance(DEFAULT_POOL_NAME).fetchJob(jobID);
			rj.setAdminStatus(true);
			//updating RepetitiveJob
			if (rj instanceof RepetitiveJob)
			{
				JobScheduler.getInstance(DEFAULT_POOL_NAME).updateRepetitiveJob((RepetitiveJob) rj);
			}
			LOGGER.log(Level.INFO, "Enabled JobByID with jobID :{0}", jobID); // No I18N
			return true;
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Exception ", e); // No I18N
		}
		return false;
	}

	public static void deleteJobByID(long jobID)
	{
		try
		{
			JobScheduler.getInstance(DEFAULT_POOL_NAME).delete(jobID);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Exception during delete jobID {0} Exception::{1}", new Object[]{jobID, e}); // No I18N
		}
	}

	public static void deleteJobByID(long jobID, String poolName)
	{
		try
		{
			JobScheduler.getInstance(poolName).delete(jobID);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Exception during delete jobID {0} Exception::{1}", new Object[]{jobID, e}); // No I18N
		}
	}

	public static void deleteJobByName(String repetitionName)
	{
		try
		{
			RepetitionManager.getInstance(DEFAULT_POOL_NAME).deleteRepetition(repetitionName);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Exception during delete repetition  {0} Exception::{1}", new Object[]{repetitionName, e}); // No I18N
		}
	}

	public static Repetition getRepetition(String repName)
	{
		try
		{
			return RepetitionManager.getInstance(DEFAULT_POOL_NAME).getRepetition(repName);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		return null;
	}

	public static int getDayOfDate(String date)
	{
		//Dont't change the substring index and all scheduler date format should be dd-MM-yyyy
		return Integer.parseInt(date.substring(0, 2));
	}

	public static int getMonthOfDate(String date)
	{
		//Dont't change the substring index and all scheduler date format should be dd-MM-yyyy
		return Integer.parseInt(date.substring(3, 5));
	}

	public static int getYearOfDate(String date)
	{
		//Dont't change the substring index and all scheduler date format should be dd-MM-yyyy
		return Integer.parseInt(date.substring(6, 10));
	}

	private static int getDayInt(String day)
	{
		int weekDay = Calendar.MONDAY;
		if ("Sunday".equals(day))
		{
			weekDay = Calendar.SUNDAY;
		}
		else if ("Monday".equals(day))
		{
			weekDay = Calendar.MONDAY;
		}
		else if ("Tuesday".equals(day))
		{
			weekDay = Calendar.TUESDAY;
		}
		else if ("Wednesday".equals(day))
		{
			weekDay = Calendar.WEDNESDAY;
		}
		else if ("Thursday".equals(day))
		{
			weekDay = Calendar.THURSDAY;
		}
		else if ("Friday".equals(day))
		{
			weekDay = Calendar.FRIDAY;
		}
		else if ("Saturday".equals(day))
		{
			weekDay = Calendar.SATURDAY;
		}
		return weekDay;
	}

	public static Job fetchJob(String pool, long jobid) throws Exception
	{
		return JobScheduler.getInstance(pool).fetchRepetitiveJob(jobid);
	}

	public static Job fetchJob(String pool, String jobName) throws Exception
	{
		return JobScheduler.getInstance(pool).fetchJob(jobName);
	}

	/**
	 * @param jobID
	 * @param className
	 * @param triggerTime
	 * @throws Exception
	 */
	public static void addOneTimeJob(long jobID, String className, Long triggerTime)
	{
		try
		{
			CommonDBUtil.addJobInCommonDB(jobID);
			OneTimeJob otj = new OneTimeJob(jobID, className);
			if (triggerTime != null)
			{
				otj.setTimeOfExecution(triggerTime);
			}
			otj.setTransactionTimeout(-1);
			JobScheduler.getInstance(DEFAULT_POOL_NAME).submitOneTimeJob(otj);
			LOGGER.log(Level.INFO, "One Time Job is added for jobid {0}, class {1}", new Object[]{jobID, className});
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Exception ", e);
		}
	}

	public static JSONObject getCommonSchedulersStatus()
	{
		JSONObject status = new JSONObject();

		status.put("SUBS_REP_EXIST", !(ScheduleUtil.getRepetition("IdmpodSubscriptionScheduler") == null));
		status.put("CLEANUP_REP_EXIST", !(ScheduleUtil.getRepetition("IdmpodCleanupScheduler") == null));
		DataObject dataObject = null;
		try
		{
			dataObject = CommonDBUtil.getPersistance().get(IDMPODCOMMONJOBS.TABLE, (Criteria) null);
			if (dataObject.containsTable(IDMPODCOMMONJOBS.TABLE))
			{
				Iterator<Row> rows = dataObject.getRows(IDMPODCOMMONJOBS.TABLE);
				while (rows.hasNext())
				{
					Row row = rows.next();
					Long jobId = Long.parseLong(row.get(IDMPODCOMMONJOBS.JOB_ID).toString());
					if (ScheduleUtil.fetchJobDetails(jobId) == null)
					{
						status.put(row.get(IDMPODCOMMONJOBS.REPETITION_NAME).toString(), false);
					}
					else
					{
						status.put(row.get(IDMPODCOMMONJOBS.REPETITION_NAME).toString(), true);
					}
				}
			}
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}

		return status;
	}

	public static void setupCommonSchedulers()
	{
		try
		{
			SASThreadLocal.setThreadLocalForDomain(CommonDBUtil.IDMPODADMIN);
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
		if (ScheduleUtil.getRepetition("IdmpodSubscriptionScheduler") == null)
		{
			LOGGER.log(Level.WARNING, "IdmpodSubscriptionScheduler is missing; Attempting to add now:");
			try
			{
				ScheduleUtil.addDailyCalendarRepetition("IdmpodSubscriptionScheduler", 1, 0);//NO I18N
			}
			catch (Exception e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
		}

		if (ScheduleUtil.getRepetition("IdmpodCleanupScheduler") == null)
		{
			LOGGER.log(Level.WARNING, "IdmpodCleanupScheduler is missing; Attempting to add now:");
			try
			{
				ScheduleUtil.addDailyCalendarRepetition("IdmpodCleanupScheduler", 2, 0);//NO I18N
			}
			catch (Exception e)
			{
				LOGGER.log(Level.SEVERE, e.getMessage(), e);
			}
		}

		try
		{
			DataObject dataObject = CommonDBUtil.getPersistance().get(IDMPODCOMMONJOBS.TABLE, (Criteria) null);
			if (dataObject.containsTable(IDMPODCOMMONJOBS.TABLE))
			{
				Iterator<Row> rows = dataObject.getRows(IDMPODCOMMONJOBS.TABLE);
				while (rows.hasNext())
				{
					Row row = rows.next();
					Long jobId = Long.parseLong(row.get(IDMPODCOMMONJOBS.JOB_ID).toString());
					if (ScheduleUtil.fetchJobDetails(jobId) == null)
					{
						ScheduleUtil.addRepetitiveJob(jobId, row.get(IDMPODCOMMONJOBS.REPETITION_NAME).toString(), row.get(IDMPODCOMMONJOBS.CLASS_NAME).toString());
					}
				}
			}
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}

	}

	public static void convertPeriodicToCalendar(Long jobId) throws Exception
	{
		Repetition repetition = getRepetition(jobId.toString());
		if (repetition instanceof PeriodicRepetition)
		{
			Job job = fetchJobDetails(jobId);
			String className = job.getClassName();
			JobScheduler.getInstance(DEFAULT_POOL_NAME).delete(job.getJobID());
			String repetitionName = repetition.getRepetitionName();
			RepetitionManager.getInstance(DEFAULT_POOL_NAME).deleteRepetition(repetitionName);

			addDailyCalendarRepetition(repetitionName, 0, 0, null, null);
			addRepetitiveJob(repetitionName, jobId, className, true, null);
		}
	}
}
