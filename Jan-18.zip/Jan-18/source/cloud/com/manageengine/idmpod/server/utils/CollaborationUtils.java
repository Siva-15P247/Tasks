package com.manageengine.idmpod.server.utils;

import com.adventnet.collaboration.Collaboration;
import com.adventnet.mfw.bean.BeanUtil;
import com.manageengine.idmpod.server.error.ErrorCode;
import com.manageengine.idmpod.server.error.IdmpodException;

import java.util.logging.Level;
import java.util.logging.Logger;

public class CollaborationUtils
{

	private static final Logger LOGGER = Logger.getLogger(CollaborationUtils.class.getName());

	private static final String COLLOBORATION_BEAN = "CollaborationBean";//No I18N

	public static void reserveSpace(String spaceName) throws IdmpodException
	{
		try
		{
			Collaboration c = (Collaboration) BeanUtil.lookup(COLLOBORATION_BEAN);
			if (!c.dataSpaceExists(spaceName))
			{
				LOGGER.log(Level.INFO, "reserving space for name:{0}", spaceName);
				c.reserveDataSpace(spaceName);
			}
		}
		catch (Exception e)
		{
			throw new IdmpodException(ErrorCode.COLLABORATION_EXCEPTION, e);
		}
	}

	public static Boolean checkAndReserverSpace(String spaceName)
	{
		try
		{
			Collaboration c = (Collaboration) BeanUtil.lookup(COLLOBORATION_BEAN);
			if (!c.dataSpaceExists(spaceName))
			{
				LOGGER.log(Level.INFO, "reserving space for name:{0}", spaceName);
				c.reserveDataSpace(spaceName);
			}
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
			return false;
		}
		return true;
	}

	public static void unreserveSpace(String spaceName) throws IdmpodException
	{
		try
		{
			Collaboration c = (Collaboration) BeanUtil.lookup(COLLOBORATION_BEAN);
			if (c.dataSpaceExists(spaceName))
			{
				LOGGER.log(Level.INFO, "unreserving space for name:{0}", spaceName);
				c.unreserveDataSpace(spaceName);
			}
		}
		catch (Exception e)
		{
			throw new IdmpodException(ErrorCode.COLLABORATION_EXCEPTION, e);
		}
	}

	//associates space reserved by spaceNameX also to spaceNameY
	public static void associateName(String spaceNameX, String spaceNameY) throws IdmpodException
	{
		try
		{
			Collaboration c = (Collaboration) BeanUtil.lookup(COLLOBORATION_BEAN);
			if (!c.dataSpaceExists(spaceNameY))
			{
				c.associateDataSpaceName(spaceNameX, spaceNameY);
			}
		}
		catch (Exception e)
		{
			throw new IdmpodException(ErrorCode.COLLABORATION_EXCEPTION, e);
		}
	}

}
