package com.manageengine.idmpod.server.zstore;

public final class ZStoreConstants
{
	public static final String UNIQUE_ID = "zId"; //No I18N
	public static final String USER_ID = "zuid"; //No I18N
	public static final String EMAIL_ID = "emailid"; //No I18N
	public static final String COMPANY_NAME = "companyname"; //No I18N
	public static final String NAME = "name"; //No I18N
	public static final String PLAN_NAME = "planname"; //No I18N
	public static final String PLAN_ID = "planid"; //No I18N
	public static final String ID = "id"; //No I18N
	public static final String TOTAL_COUNT = "total"; //No I18N
	public static final String USED_COUNT = "alloted"; //No I18N
	public static final String PROFILEID = "profileid"; //No I18N
	public static final String PAY_PERIOD = "frequency"; //No I18N
	public static final String EXPIRY_DATE = "expirydate"; //No I18N
	public static final String NEXT_DUE_DATE = "nextduedateInLong";//No I18N
	public static final String ADDON_LIST = "addons"; //No I18N
	public static final String ADMIN_ZUIDS = "admin_zuid"; //No I18N
	public static final String PRIMARY_ZUID = "primary_zuid";//No I18N
	public static final String ADMIN_PRIVILEGE = "admin_privilege";//No I18N
	public static final String PROPAGATE = "propagate";//No I18N
	public static final String TRIAL_TYPE = "trialtype";//No I18N
	public static final String RESULT = "result";//No I18N
	public static final String MESSAGE = "msg";//No I18N
	public static final String SUCCESS = "success";//No I18N
	public static final String FAILURE = "failure";//No I18N
	public static final String REMOTE_USER_IP = "remoteuserip";//No I18N
	public static final String DEPENDENT_SERVICE_ADDONID = "addonid";//No I18N
	public static final String SERVICE_JSON = "servicejson"; //No I18N
	public static final String SERVICE_ID = "serviceid"; //No I18N
	public static final String ADDON_ID = "addonid"; //No I18N
	public static final String REASON = "reason"; //No I18N
	public static final String FAILEDPROFILES = "failedProfiles"; //No I18N
	public static final String FREE_PROFILE_ID = "freeProfile";//No I18N
	public static final String DOWNGRADE_REASON = "downgradereason";//No I18N
	public static final String ORGCREATEDTIME = "orgcreatedtime";//No I18N
	public static final String PROVISIONING = "provisioning";//No I18N
	public static final String RECURRINGSUCCESS = "RecurringSuccess";//No I18N
	public static final String RETRYSUCCESS = "RetrySuccess";//No I18N
	public static final String CANCELLICENSE = "CancelLicense";//No I18N
	public static final String RETRYFAIL = "RetryFail";//No I18N
	public static final String RECURRINGFAIL = "RecurringFail";//No I18N

	public static final String PROPAGATE_SERVICE_UNIQUE_ID = "dependent_uniqueid";//No I18N
	public static final String PROPAGATE_UNIQUE_ID = "SDP_UNIQUE_ID";//No I18N
	public static final String PROPAGATE_ADDON_TYPE = "SDP_ADDON_TYPE";//No I18N

	public static enum TRIAL_TYPES
	{
		TRIAL_TYPE_PLAN(1), TRIAL_TYPE_ADDON(2);

		private final int id;

		private TRIAL_TYPES(int id)
		{
			this.id = id;
		}

		public int getID()
		{
			return id;
		}

		public static TRIAL_TYPES getTrialType(int id)
		{
			for (TRIAL_TYPES trialType : values())
			{
				if (trialType.getID() == id)
				{
					return trialType;
				}
			}
			throw new IllegalArgumentException("Invalid id for trial type : " + id);//No I18N
		}
	}

	public static enum LicenseOperation
	{
		TRIAL_PLAN,
		TRIAL_ADDON,
		NEW_LICENSE,
		MODIFY_LICENSE,
		CANCEL_PLAN,
		CANCEL_ADDON,
		RENEW_LICENSE,
		CHANGE_EDITION,
		CHANGE_PAY_PERIOD,
		EXTEND_TRIAL,
		CHANGE_PROFILEID,
		LICENSE_UDATED
	}
}
