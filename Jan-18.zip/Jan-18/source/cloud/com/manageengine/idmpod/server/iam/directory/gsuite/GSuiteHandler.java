package com.manageengine.idmpod.server.iam.directory.gsuite;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.google.api.client.auth.oauth2.AuthorizationCodeRequestUrl;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.VerificationCodeReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.auth.oauth2.GoogleTokenResponse;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.admin.directory.Directory;
import com.google.api.services.admin.directory.DirectoryScopes;
import com.google.api.services.admin.directory.model.Domains;
import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.iam.directory.DirectoryHandler;
import com.manageengine.idmpod.server.utils.IdmpodUtils;
import com.manageengine.tables.idmpod.IDMPODDIRECTORYNODES;
import com.manageengine.tables.idmpod.IDMPODGOOGLEDATASTORE;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class GSuiteHandler
{
	private static final Logger LOGGER = Logger.getLogger(GSuiteHandler.class.getName());

	private static final String APPLICATION_NAME = "Identity Manager Plus"; // NO I18N
	private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
	private static final NetHttpTransport HTTP_TRANSPORT;

	static
	{
		try
		{
			HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	private static final List<String> SCOPES = new ArrayList<>();

	static
	{
		SCOPES.add(DirectoryScopes.ADMIN_DIRECTORY_USER_READONLY);
		SCOPES.add(DirectoryScopes.ADMIN_DIRECTORY_DOMAIN_READONLY);
	}

	private static final GoogleClientSecrets CLIENT_SECRETS;
	private static final GoogleAuthorizationCodeFlow FLOW;

	static
	{
		try
		{
			GoogleClientSecrets.Details details = new GoogleClientSecrets.Details();
			details.setAuthUri("https://accounts.google.com/o/oauth2/auth").setClientId(IdmpodUtils.getProperty("gsuite.client_id")).setClientSecret(IdmpodUtils.getProperty("gsuite.client_secret")).setTokenUri("https://accounts.google.com/o/oauth2/token");//No I18N
			details.setFactory(JSON_FACTORY);
			CLIENT_SECRETS = new GoogleClientSecrets();
			CLIENT_SECRETS.setInstalled(details);
			FLOW = new GoogleAuthorizationCodeFlow.Builder(HTTP_TRANSPORT, JSON_FACTORY, CLIENT_SECRETS, SCOPES).setDataStoreFactory(new IdmpodGSuiteDataStoreFactory()).
					setAccessType("offline").build(); // NO I18N
		}
		catch (IOException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	private static final VerificationCodeReceiver VERIFICATION_CODE_RECEIVER = new IdmpodGSuiteVerificationCodeReceiver();

	private static final AuthorizationCodeRequestUrl AUTHORIZATION_URL;

	static
	{
		try
		{
			AUTHORIZATION_URL = FLOW.newAuthorizationUrl().setRedirectUri(VERIFICATION_CODE_RECEIVER.getRedirectUri());
		}
		catch (IOException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			throw new RuntimeException(e);
		}
	}

	public static AuthorizationCodeRequestUrl getAuthorizationUrl()
	{
		return AUTHORIZATION_URL;
	}

	public static String createAuthToken()
	{
		String id = null;
		try
		{
			DataObject dataObject = DBUtils.getOrgPersistence().constructDataObject();
			Row r = new Row(IDMPODGOOGLEDATASTORE.TABLE);
			dataObject.addRow(r);
			DBUtils.getOrgPersistence().add(dataObject);

			id = r.get(IDMPODGOOGLEDATASTORE.UNIQUE_ID).toString();
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return id;
	}

	public static void updateAuthToken(JSONObject req)
	{
		String id = req.getString("state");
		String code = req.optString("code", null); // NO I18N
		String error = req.optString("error", null); // NO I18N

		try
		{
			DataObject dataObject = DBUtils.getOrgPersistence().get(IDMPODGOOGLEDATASTORE.TABLE, new Criteria(Column.getColumn(IDMPODGOOGLEDATASTORE.TABLE, IDMPODGOOGLEDATASTORE.UNIQUE_ID), id, QueryConstants.EQUAL));
			if (dataObject.containsTable(IDMPODGOOGLEDATASTORE.TABLE))
			{
				Row r = dataObject.getFirstRow(IDMPODGOOGLEDATASTORE.TABLE);
				if (code != null)
				{
					r.set(IDMPODGOOGLEDATASTORE.ENCRYPTED_CODE, code);

					GoogleTokenResponse tokenResponse = FLOW.newTokenRequest(code).setRedirectUri(VERIFICATION_CODE_RECEIVER.getRedirectUri()).execute();
					FLOW.createAndStoreCredential(tokenResponse, id);
				}
				else
				{
					r.set(IDMPODGOOGLEDATASTORE.STATUS, error);
				}

				dataObject.updateRow(r);

				DBUtils.getOrgPersistence().update(dataObject);
			}
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (IOException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		// LOGGER.info(req.toString(4));
	}

	public static JSONObject getAuthToken(String id)
	{
		final String TYPE = JsonApiHandler.ResourceType.GSUITE_AUTH_TOKEN.getResType();
		try
		{
			DataObject dataObject = DBUtils.getOrgPersistence().get(IDMPODGOOGLEDATASTORE.TABLE, new Criteria(Column.getColumn(IDMPODGOOGLEDATASTORE.TABLE, IDMPODGOOGLEDATASTORE.UNIQUE_ID), id, QueryConstants.EQUAL));
			if (dataObject.containsTable(IDMPODGOOGLEDATASTORE.TABLE))
			{
				Row r = dataObject.getFirstRow(IDMPODGOOGLEDATASTORE.TABLE);

				JSONObject authTokenAttrs = new JSONObject();
				authTokenAttrs.put(IDMPODGOOGLEDATASTORE.ENCRYPTED_CODE, r.get(IDMPODGOOGLEDATASTORE.ENCRYPTED_CODE));
				authTokenAttrs.put(IDMPODGOOGLEDATASTORE.STATUS, r.get(IDMPODGOOGLEDATASTORE.STATUS));

				JSONObject authToken = new JSONObject();
				authToken.put(JsonApiConstants.ID, id);
				authToken.put(JsonApiConstants.TYPE, TYPE);
				authToken.put(JsonApiConstants.ATTRIBUTES, authTokenAttrs);
				return authToken;
			}
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		return null;
	}

	public static void addDirectory(JSONObject request, JSONObject resp)
	{
		// LOGGER.info(request.toString(4));

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);
		JSONObject relationships = data.getJSONObject(JsonApiConstants.RELATIONSHIPS);
		JSONObject authTokenInfo = relationships.getJSONObject("gsuite-auth-token").getJSONObject(JsonApiConstants.DATA);
		Long authTokenId = authTokenInfo.optLong(JsonApiConstants.ID);
		attributes.put("GSUITE_AUTH_TOKEN_ID", authTokenId);

		JSONArray errors = resp.has(JsonApiConstants.ERRORS) ? resp.getJSONArray(JsonApiConstants.ERRORS) : new JSONArray();
		JSONArray included = new JSONArray();


		DirectoryHandler.addDirectory(data);
		String directoryId = data.optString(JsonApiConstants.ID);
		try
		{
			relationships.put("domains", JsonApiHandler.getResourceObject(fetchAndUpdateDomains(authTokenId, included, directoryId)));
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (IOException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		if (errors != null && errors.length() > 0)
		{
			resp.put(JsonApiConstants.ERRORS, errors);
		}
		else
		{
			resp.put(JsonApiConstants.DATA, data);
			if (included.length() > 0)
			{
				resp.put(JsonApiConstants.INCLUDED, included);
			}
		}
	}

	private static JSONArray fetchAndUpdateDomains(Long authTokenId, JSONArray included, String directoryId) throws DataAccessException, IOException
	{
		DataObject dObj = DBUtils.getOrgPersistence().get(IDMPODDIRECTORYNODES.TABLE, new Criteria(Column.getColumn(IDMPODDIRECTORYNODES.TABLE, IDMPODDIRECTORYNODES.DIRECTORY_ID), Long.valueOf(directoryId), QueryConstants.EQUAL));
		JSONArray resp = null;

		Credential credential = FLOW.loadCredential(authTokenId.toString());
		if (credential != null && (credential.getRefreshToken() != null || credential.getExpiresInSeconds() == null || credential.getExpiresInSeconds() > 60))
		{
			Directory directory = new Directory.Builder(HTTP_TRANSPORT, JSON_FACTORY, credential).setApplicationName(APPLICATION_NAME).build();
			List<Domains> domains = directory.domains().list("my_customer").execute().getDomains(); // NO I18N
			for (Domains domain : domains)
			{
				String domainName = domain.getDomainName();

				Row domainRow = dObj.getRow(IDMPODDIRECTORYNODES.TABLE, new Criteria(Column.getColumn(IDMPODDIRECTORYNODES.TABLE, IDMPODDIRECTORYNODES.NODE_IDENTIFIER), domainName, QueryConstants.EQUAL, false));
				if (domainRow == null)
				{
					domainRow = new Row(IDMPODDIRECTORYNODES.TABLE);

					domainRow.set(IDMPODDIRECTORYNODES.NODE_IDENTIFIER, domainName);
					domainRow.set(IDMPODDIRECTORYNODES.NODE_DISPLAY_NAME, domainName);
					domainRow.set(IDMPODDIRECTORYNODES.DIRECTORY_ID, directoryId);

					dObj.addRow(domainRow);

					DBUtils.getOrgPersistence().fillGeneratedValues(dObj);
				}

				if (resp == null)
				{
					resp = new JSONArray();
				}
				JSONObject domainObj = new JSONObject();
				domainObj.put(IDMPODDIRECTORYNODES.NODE_IDENTIFIER, domainName);
				domainObj.put(IDMPODDIRECTORYNODES.NODE_DISPLAY_NAME, domainName);
				domainObj.put(IDMPODDIRECTORYNODES.DIRECTORY_ID, directoryId);
				domainObj.put(IDMPODDIRECTORYNODES.NODE_ID, domainRow.get(IDMPODDIRECTORYNODES.NODE_ID));
				JSONObject rel = new JSONObject();
				rel.put("directory", JsonApiHandler.getResourceObject(JsonApiHandler.getResourceIdentifierObject("directory", directoryId)));
				JSONObject resObj = JsonApiHandler.getResourceObject("domains", domainRow.get(IDMPODDIRECTORYNODES.NODE_ID).toString(), domainObj, rel);//NO I18N
				included.put(resObj);
				resp.put(resObj);

			}
		}
		DBUtils.getOrgPersistence().update(dObj);
		return resp;
	}

	public static Directory getDirectoryForAuthToken(Long authTokenId) throws IOException
	{
		return new Directory.Builder(HTTP_TRANSPORT, JSON_FACTORY, FLOW.loadCredential(authTokenId.toString())).setApplicationName(APPLICATION_NAME).build();
	}

	public static void updateDirectory(JSONObject request, JSONObject resp)
	{
		// LOGGER.info(request.toString(4));

		JSONObject data = request.getJSONObject(JsonApiConstants.DATA);

		JSONObject attributes = data.getJSONObject(JsonApiConstants.ATTRIBUTES);
		JSONObject relationships = data.getJSONObject(JsonApiConstants.RELATIONSHIPS);
		JSONObject authTokenInfo = relationships.getJSONObject("gsuite-auth-token").getJSONObject(JsonApiConstants.DATA);
		Long authTokenId = authTokenInfo.optLong(JsonApiConstants.ID);
		attributes.put("GSUITE_AUTH_TOKEN_ID", authTokenId);

		JSONArray errors = resp.has(JsonApiConstants.ERRORS) ? resp.getJSONArray(JsonApiConstants.ERRORS) : new JSONArray();
		JSONArray included = new JSONArray();

		String directoryId = data.optString(JsonApiConstants.ID);
		DirectoryHandler.updateDirectory(Long.parseLong(directoryId), data);
		try
		{
			relationships.put("domains", JsonApiHandler.getResourceObject(fetchAndUpdateDomains(authTokenId, included, directoryId)));
		}
		catch (DataAccessException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}
		catch (IOException e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		if (errors != null && errors.length() > 0)
		{
			resp.put(JsonApiConstants.ERRORS, errors);
		}
		else
		{
			resp.put(JsonApiConstants.DATA, data);
			if (included.length() > 0)
			{
				resp.put(JsonApiConstants.INCLUDED, included);
			}
		}
	}
}
