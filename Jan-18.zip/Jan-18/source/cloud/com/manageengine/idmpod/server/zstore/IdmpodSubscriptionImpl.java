package com.manageengine.idmpod.server.zstore;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.iam.IAMProxy;
import com.adventnet.iam.Org;
import com.adventnet.iam.OrgAPI;
import com.adventnet.iam.User;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Row;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.iam.*;
import com.manageengine.idmpod.server.utils.CollaborationUtils;
import com.manageengine.idmpod.server.utils.CommonDBUtil;
import com.manageengine.idmpod.server.utils.IdmpodUtils;
import com.manageengine.tables.idmpod.IDMPODORG;
import com.manageengine.tables.idmpod.IDMPODSUBSCRIPTIONS;
import com.manageengine.tables.idmpod.IDMPODTECHNICIAN;
import com.zoho.accounts.AccountsProto;
import com.zoho.store.bean.SubscriptionBean;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

public class IdmpodSubscriptionImpl implements SubscriptionBean
{
	private static final Logger LOGGER = Logger.getLogger(IdmpodSubscriptionImpl.class.getName());

	public enum PAY_PERIOD
	{
		MONTHLY(1), QUARTERLY(2), SEMESTERLY(3), YEARLY(4);

		private final Integer payPeriodValue;

		PAY_PERIOD(Integer val)
		{
			payPeriodValue = val;
		}

		public int getValue()
		{
			return payPeriodValue;
		}

		public String getStringValue()
		{
			return payPeriodValue.toString();
		}
	}

	@Override
	public JSONObject getServiceSubscriptionInfo(String zId, long serviceId) throws Exception
	{
		try
		{
			LOGGER.log(Level.INFO, "Getting service subscription info for zID : " + zId);

			String zaaid = zId;
			/* if((Boolean) licRow.get(IDMPODSUBSCRIPTIONS.IS_ENCRYPTED)){
        	zaaid = LicenseUtil.getZAAID(id);
        }*/
			JSONObject licDetails = new JSONObject();
			JSONArray addOnsArray = new JSONArray();
			JSONObject addOnJson = new JSONObject();

			Row licRow = LicenseUtil.getLicenseDetailsRow(zaaid);
			if (licRow != null)
			{
				Long planID = (Long) licRow.get(IDMPODSUBSCRIPTIONS.PLANID);
				LicenseUtil.Plan plan = LicenseUtil.getPlan(planID);
				LicenseUtil.Addon addOn = plan.getUserAddon();
				licDetails.put(ZStoreConstants.PLAN_NAME, plan.getPlanName());
				licDetails.put(ZStoreConstants.PLAN_ID, planID.toString());
				licDetails.put(ZStoreConstants.EXPIRY_DATE, licRow.get(IDMPODSUBSCRIPTIONS.EXPIRYTIME));
				licDetails.put(ZStoreConstants.PROFILEID, licRow.get(IDMPODSUBSCRIPTIONS.PROFILEID));

				addOnJson.put(ZStoreConstants.ID, addOn.getAddonId());
				addOnJson.put(ZStoreConstants.TOTAL_COUNT, licRow.get(IDMPODSUBSCRIPTIONS.NO_OF_USERS));
				// Active user count
				int activeUserCount = DBUtils.getCount(IDMPODTECHNICIAN.TABLE, new Criteria(Column.getColumn(IDMPODTECHNICIAN.TABLE, IDMPODTECHNICIAN.STATUS), "ACTIVE", QueryConstants.EQUAL, false), zaaid);
				addOnJson.put(ZStoreConstants.USED_COUNT, "" + activeUserCount);
				addOnsArray.put(addOnJson);
			}


			Row orgRow = CommonDBUtil.getAAOrgRow(zaaid);


			licDetails.put(ZStoreConstants.UNIQUE_ID, zId);
			licDetails.put(ZStoreConstants.COMPANY_NAME, orgRow != null ? orgRow.get(IDMPODORG.NAME) : "");

			licDetails.put(ZStoreConstants.ORGCREATEDTIME, orgRow != null ? orgRow.get(IDMPODORG.CREATEDTIME) : "");


			licDetails.put(ZStoreConstants.ADDON_LIST, addOnsArray);

			AccountsProto.Account.AppAccount idmpodAppAccount = AppAccountUtils.getIdmpodAppAccount(Long.parseLong(zaaid));
			if (idmpodAppAccount != null)
			{
				licDetails.put(ZStoreConstants.PRIMARY_ZUID, idmpodAppAccount.getZuid());//Verify
			}

			licDetails.put(ZStoreConstants.ADMIN_ZUIDS, LicenseUtil.getPaymentAdmins(zaaid));
			licDetails.put(ZStoreConstants.PAY_PERIOD, PAY_PERIOD.YEARLY.getStringValue());
			LOGGER.log(Level.INFO, "License details " + licDetails);
			return licDetails;
		}
		catch (Exception e)
		{
			return getStatusJSON(false, zId, "Unable to get Subscription Information", e);//No I18N
		}
	}

	@Override
	public JSONObject renewSubscription(JSONArray licJSONArray) throws Exception
	{
		LOGGER.log(Level.INFO, "Renewing subscription with json : " + licJSONArray);
		JSONObject respJSONObj = new JSONObject();
		JSONArray respJSONArray = new JSONArray();
		Iterator<String> reccurStatusIt = licJSONArray.getJSONObject(0).keys();
		while (reccurStatusIt.hasNext())
		{
			String reccurStatus = reccurStatusIt.next();
			if (reccurStatus.equals(ZStoreConstants.RECURRINGSUCCESS) || reccurStatus.equals(ZStoreConstants.RETRYSUCCESS) || reccurStatus.equals(ZStoreConstants.CANCELLICENSE) || reccurStatus.equals(ZStoreConstants.RECURRINGFAIL) || reccurStatus.equals(ZStoreConstants.RETRYFAIL))
			{
				JSONArray array = licJSONArray.getJSONObject(0).getJSONArray(reccurStatus);
				for (int i = 0; i < array.length(); i++)
				{
					JSONObject json = array.getJSONObject(i);
					String zId = json.getString(ZStoreConstants.UNIQUE_ID);
					String zaaid = zId;
					JSONObject resObj = new JSONObject();
					try
					{
						if (reccurStatus.equals(ZStoreConstants.RECURRINGSUCCESS) || reccurStatus.equals(ZStoreConstants.RETRYSUCCESS))
						{
							DataObject licenseDO = LicenseUtil.getLicenseDetailsDO(zaaid);
							Row licenseRow = licenseDO.getFirstRow(IDMPODSUBSCRIPTIONS.TABLE);
							LOGGER.log(Level.FINE, "licenseRow: {0}, status: {1}", new Object[]{licenseRow, json});
							licenseRow.set(IDMPODSUBSCRIPTIONS.PROFILEID, json.getString(ZStoreConstants.PROFILEID));
							// NOTE: July 10th onwards new key nextduedateInLong
							licenseRow.set(IDMPODSUBSCRIPTIONS.EXPIRYTIME, (json.has(ZStoreConstants.NEXT_DUE_DATE)) ? json.getLong(ZStoreConstants.NEXT_DUE_DATE) : json.getLong(ZStoreConstants.EXPIRY_DATE));
							licenseDO.updateRow(licenseRow);
							DBUtils.getAAPersistence(zaaid).update(licenseDO);
							LicenseUtil.enforceLicenseRestrictions(zaaid, licenseRow);
							resObj.put(zId, ZStoreConstants.SUCCESS);
						}
						else if (reccurStatus.equals(ZStoreConstants.CANCELLICENSE))
						{
							DataObject licenseDO = LicenseUtil.getLicenseDetailsDO(zaaid);
							Row licenseRow = licenseDO.getFirstRow(IDMPODSUBSCRIPTIONS.TABLE);
							LicenseUtil.downgrade2Free(zaaid);
							//Note: Subscription cancel disable Enterprise notification
							resObj.put(zId, ZStoreConstants.SUCCESS);
						}
						else
						{
							resObj.put(zId, ZStoreConstants.SUCCESS);
						}
					}
					catch (Exception e)
					{
						LOGGER.log(Level.SEVERE, "Error in processing renewal for : " + zId, e);
					}
					respJSONArray.put(resObj);
				}
			}
		}
		respJSONObj.put(ZStoreConstants.RESULT, respJSONArray);
		LOGGER.log(Level.INFO, "renewSubscription : " + respJSONObj);
		return respJSONObj;
	}

	@Override
	public JSONObject addSubscription(String zID, JSONObject json) throws Exception
	{
		LOGGER.log(Level.INFO, "addSubscription zId:" + zID + "  ::: " + json);
		try
		{
			String zaaid = zID;
			LicenseUtil.Plan plan = LicenseUtil.getPlan(Long.parseLong(json.getString(ZStoreConstants.PLAN_ID)));
			DataObject licenseDO = LicenseUtil.getLicenseDetailsDO(zaaid);
			Row licenseRow = null;
			if (licenseDO.size(IDMPODSUBSCRIPTIONS.TABLE) > -1)
			{
				licenseRow = licenseDO.getFirstRow(IDMPODSUBSCRIPTIONS.TABLE);
				licenseRow.set(IDMPODSUBSCRIPTIONS.ZID, zID);
				licenseRow.set(IDMPODSUBSCRIPTIONS.PLANNAME, json.get(ZStoreConstants.PLAN_NAME));
				licenseRow.set(IDMPODSUBSCRIPTIONS.PLANID, json.get(ZStoreConstants.PLAN_ID));
				licenseRow.set(IDMPODSUBSCRIPTIONS.PAYMENTOWNER, json.get(ZStoreConstants.USER_ID));
				licenseRow.set(IDMPODSUBSCRIPTIONS.PLANTYPE, plan.getPlanType());
				licenseRow.set(IDMPODSUBSCRIPTIONS.EXPIRYTIME, json.get(ZStoreConstants.EXPIRY_DATE));
				licenseRow.set(IDMPODSUBSCRIPTIONS.PROFILEID, json.get(ZStoreConstants.PROFILEID));
				JSONArray addOn = (JSONArray) json.get(ZStoreConstants.ADDON_LIST);
				for (int i = 0; i < addOn.length(); i++)
				{
					JSONObject addOnJSON = (JSONObject) addOn.get(i);
					int ps_addonCount = Integer.parseInt(addOnJSON.getString(ZStoreConstants.TOTAL_COUNT));
					licenseRow.set(IDMPODSUBSCRIPTIONS.NO_OF_USERS, ps_addonCount);
				}
				licenseDO.updateRow(licenseRow);
				DBUtils.getAAPersistence(zaaid).update(licenseDO);
			}
			else
			{
				//Note: calling addSubscription method without creating free license.
				licenseRow = new Row(IDMPODSUBSCRIPTIONS.TABLE);
				licenseRow.set(IDMPODSUBSCRIPTIONS.ZID, zID);
				licenseRow.set(IDMPODSUBSCRIPTIONS.PLANNAME, json.get(ZStoreConstants.PLAN_NAME));
				licenseRow.set(IDMPODSUBSCRIPTIONS.PLANID, json.get(ZStoreConstants.PLAN_ID));
				licenseRow.set(IDMPODSUBSCRIPTIONS.PAYMENTOWNER, json.get(ZStoreConstants.USER_ID));
				licenseRow.set(IDMPODSUBSCRIPTIONS.PLANTYPE, plan.getPlanType());
				licenseRow.set(IDMPODSUBSCRIPTIONS.EXPIRYTIME, json.get(ZStoreConstants.EXPIRY_DATE));
				licenseRow.set(IDMPODSUBSCRIPTIONS.PROFILEID, json.get(ZStoreConstants.PROFILEID));
				JSONArray addOn = (JSONArray) json.get(ZStoreConstants.ADDON_LIST);
				for (int i = 0; i < addOn.length(); i++)
				{
					JSONObject addOnJSON = (JSONObject) addOn.get(i);
					int ps_addonCount = Integer.parseInt(addOnJSON.getString(ZStoreConstants.TOTAL_COUNT));
					licenseRow.set(IDMPODSUBSCRIPTIONS.NO_OF_USERS, ps_addonCount);
				}
				licenseDO.addRow(licenseRow);
				DBUtils.getAAPersistence(zaaid).add(licenseDO);
			}
			LicenseUtil.enforceLicenseRestrictions(zaaid, licenseRow);
			return getJSONResponse(zID, true, ZStoreConstants.LicenseOperation.NEW_LICENSE, null);
		}
		catch (Exception e)
		{
			return getStatusJSON(false, zID, "Unable to add Subscription Information", e);//No I18N
		}
	}

	@Override
	public JSONObject modifySubscription(String zID, JSONObject json) throws Exception
	{
		LOGGER.log(Level.INFO, "modifySubscription zId:" + zID + " :::" + json);
		JSONObject resObj = new JSONObject();
		try
		{
			String zaaid = zID;
			DataObject licenseDO = LicenseUtil.getLicenseDetailsDO(zaaid);
			Row licenseRow = licenseDO.getFirstRow(IDMPODSUBSCRIPTIONS.TABLE);
			licenseRow.set(IDMPODSUBSCRIPTIONS.PLANID, json.get(ZStoreConstants.PLAN_ID));
			licenseRow.set(IDMPODSUBSCRIPTIONS.EXPIRYTIME, json.get(ZStoreConstants.EXPIRY_DATE));
			JSONArray addOn = (JSONArray) json.get(ZStoreConstants.ADDON_LIST);
			for (int i = 0; i < addOn.length(); i++)
			{
				JSONObject addOnJSON = (JSONObject) addOn.get(i);
				int ps_addonCount = Integer.parseInt(addOnJSON.getString(ZStoreConstants.TOTAL_COUNT));
				licenseRow.set(IDMPODSUBSCRIPTIONS.NO_OF_USERS, ps_addonCount);
			}
			licenseDO.updateRow(licenseRow);
			DBUtils.getAAPersistence(zaaid).update(licenseDO);
			LicenseUtil.enforceLicenseRestrictions(zaaid, licenseRow);
			resObj.put(ZStoreConstants.RESULT, ZStoreConstants.SUCCESS);
			return resObj;
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Unable to add modify Subscription", e);
			resObj.put(ZStoreConstants.RESULT, ZStoreConstants.FAILURE);
		}
		return resObj;
	}

	@Override
	public JSONObject cancelSubscription(String zID, JSONObject json) throws Exception
	{
		LOGGER.log(Level.INFO, "cancelSubscription zId:" + zID + " :::" + json);
		JSONObject resObj = new JSONObject();
		try
		{
			String zaaid = zID;
			LicenseUtil.downgrade2Free(zaaid);
			resObj.put(ZStoreConstants.RESULT, ZStoreConstants.SUCCESS);
			return resObj;
		}
		catch (Exception e)
		{
			LOGGER.log(Level.SEVERE, "Unable to cancel Subscription", e);
			resObj.put(ZStoreConstants.RESULT, ZStoreConstants.FAILURE);
		}
		return resObj;
	}

	@Override
	public JSONObject userPrivilege(long zuid, long serviceid) throws Exception
	{
		LOGGER.log(Level.INFO, "Getting user privelage for zuid : " + zuid);
		JSONObject jsonObj = new JSONObject();
		jsonObj.put(ZStoreConstants.USER_ID, zuid);
		JSONArray userAppAccountDetails = new JSONArray();
		try
		{
			User user = IAMProxy.getInstance().getUserAPI().getUser(zuid);
			String zaaid = CommonDBUtil.getZaaid(user);
			if (zaaid != null)
			{
				IdmpodUserRole userRole = UserUtils.getUserRole(DBUtils.getAAPersistence(zaaid), zuid);
				LOGGER.log(Level.INFO, "User role for {1} is {0} ", new Object[]{userRole.toString(), zuid});
				if (userRole == IdmpodUserRole.SUPER_ADMIN)
				{
					//Row licenserow = LicenseUtil.getLicenseDetailsRow();
					JSONObject appAccobj = new JSONObject();
					/*if((Boolean) licenserow.get(IDMPODSUBSCRIPTIONS.IS_ENCRYPTED)){
						zaaid = LicenseUtil.getCustomId((Long)licenserow.get(IDMPODSUBSCRIPTIONS.ACCOUNT_AUTO_ID));
					}*/
					appAccobj.put(ZStoreConstants.ID, zaaid);
					appAccobj.put(ZStoreConstants.NAME, "idmpod");
					userAppAccountDetails.put(appAccobj);
				}
			}
			else
			{
				LOGGER.log(Level.WARNING, "User with ZUID [" + zuid + "] has not subscribed to idmpod");//No I18N
			}
		}
		catch (Exception e)
		{
			LOGGER.log(Level.WARNING, "Unable to get user privilege for ZUID " + zuid, e);//No I18N
		}
		jsonObj.put(ZStoreConstants.ADMIN_PRIVILEGE, userAppAccountDetails);
		LOGGER.log(Level.INFO, "User privileage for zuid " + zuid + " is : " + jsonObj);
		return jsonObj;
	}

	@Override
	public JSONObject extendTrialDuration(String zID, JSONObject json) throws Exception
	{
		//		LOGGER.log(Level.INFO, "Extending trial duration with zID {0}, and json : {1}", new Object[]{zID, json});
		//		if (ZStoreConstants.FAILURE.equals(json.getString(ZStoreConstants.RESULT)))
		//		{
		//			return getStatusJSON(false, zID, json.optString(ZStoreConstants.MESSAGE), null);
		//		}
		//		try
		//		{
		//			String zaaid = zID;
		//			LOGGER.log(Level.INFO, "Extending trial for : " + json);
		//			DataObject licDO = LicenseUtil.getLicenseDetailsDO(zaaid);
		//			licDO.set(IDMPODSUBSCRIPTIONS.TABLE, IDMPODSUBSCRIPTIONS.EXPIRYTIME, json.getLong(ZStoreConstants.EXPIRY_DATE));
		//			DBUtils.getAAPersistence(zaaid).update(licDO);
		//			return getJSONResponse(zID, true, ZStoreConstants.LicenseOperation.EXTEND_TRIAL, null);
		//		}
		//		catch (Exception e)
		//		{
		//			return getStatusJSON(false, zID, "Unable to extend trial", e);//No I18N
		//		}
		LOGGER.log(Level.INFO, "Entering {0}.{1}", new Object[]{"IdmpodSubscriptionImpl", "extendTrialDuration"});
		return null;
	}

	@Override
	public JSONObject setTrial(String zID, JSONObject json) throws Exception
	{
		//		LOGGER.log(Level.INFO, "Set Trial plan {0}", new Object[]{json});
		//		JSONObject resObj = new JSONObject();
		//		if (ZStoreConstants.FAILURE.equals(json.getString(ZStoreConstants.RESULT)))
		//		{
		//			resObj.put(ZStoreConstants.RESULT, ZStoreConstants.FAILURE);
		//			return resObj;
		//		}
		//		try
		//		{
		//			String zaaid = zID;
		//			ZStoreConstants.TRIAL_TYPES trialType = ZStoreConstants.TRIAL_TYPES.getTrialType(json.getInt(ZStoreConstants.TRIAL_TYPE));
		//			if (trialType == ZStoreConstants.TRIAL_TYPES.TRIAL_TYPE_PLAN)
		//			{
		//				DataObject licDO = LicenseUtil.getLicenseDetailsDO(zaaid);
		//				Long planId = json.getLong(ZStoreConstants.PLAN_ID);
		//				LicenseUtil.Plan trialPlan = LicenseUtil.getPlan(planId);
		//				if (licDO.size(IDMPODSUBSCRIPTIONS.TABLE) == -1)
		//				{
		//					Row licenseRow = new Row(IDMPODSUBSCRIPTIONS.TABLE);
		//					licenseRow.set(IDMPODSUBSCRIPTIONS.EXPIRYTIME, json.get(ZStoreConstants.EXPIRY_DATE));
		//					licenseRow.set(IDMPODSUBSCRIPTIONS.NO_OF_USERS, trialPlan.getMaxUsers());
		//					licenseRow.set(IDMPODSUBSCRIPTIONS.PROFILEID, json.get(ZStoreConstants.PROFILEID));
		//					licenseRow.set(IDMPODSUBSCRIPTIONS.PLANTYPE, trialPlan.getPlanType());
		//					licenseRow.set(IDMPODSUBSCRIPTIONS.PLANID, json.get(ZStoreConstants.PLAN_ID));
		//					licenseRow.set(IDMPODSUBSCRIPTIONS.PAYMENTOWNER, json.get(ZStoreConstants.USER_ID));
		//					DataObject newLicenseDO = DBUtils.getAAPersistence(zaaid).constructDataObject();
		//					newLicenseDO.addRow(licenseRow);
		//					DBUtils.getAAPersistence(zaaid).add(newLicenseDO);
		//					LOGGER.log(Level.INFO, "Trial plan enabled for ZAAID: {0}", new Object[]{zaaid});
		//					resObj.put(ZStoreConstants.RESULT, ZStoreConstants.SUCCESS);
		//				}
		//				else
		//				{
		//					LOGGER.log(Level.INFO, "Trial plan enabled {0} ", new Object[]{json});
		//					Row licenseRow = licDO.getFirstRow(IDMPODSUBSCRIPTIONS.TABLE);
		//					if (!(licenseRow.get(IDMPODSUBSCRIPTIONS.PLANTYPE).equals(LicenseUtil.PLANTYPE_REGISTERED)))
		//					{
		//						licenseRow.set(IDMPODSUBSCRIPTIONS.EXPIRYTIME, json.get(ZStoreConstants.EXPIRY_DATE));
		//						licenseRow.set(IDMPODSUBSCRIPTIONS.NO_OF_USERS, trialPlan.getMaxUsers());
		//						licenseRow.set(IDMPODSUBSCRIPTIONS.PROFILEID, json.get(ZStoreConstants.PROFILEID));
		//						licenseRow.set(IDMPODSUBSCRIPTIONS.PLANTYPE, trialPlan.getPlanType());
		//						licenseRow.set(IDMPODSUBSCRIPTIONS.PLANID, trialPlan.getPlanId());
		//						licDO.updateRow(licenseRow);
		//						DBUtils.getAAPersistence(zaaid).update(licDO);
		//						LicenseUtil.enforceLicenseRestrictions(licenseRow);
		//					}
		//					else
		//					{
		//						LOGGER.log(Level.INFO, "Already paid plan, so not updating TRIAL again {0} ", new Object[]{json});
		//					}
		//					resObj.put(ZStoreConstants.RESULT, ZStoreConstants.SUCCESS);
		//				}
		//				return resObj;
		//			}
		//		}
		//		catch (Exception e)
		//
		//		{
		//			resObj.put(ZStoreConstants.RESULT, ZStoreConstants.FAILURE);
		//			LOGGER.log(Level.SEVERE, "Unable to set trial plan", e);
		//		}
		//		return resObj;
		LOGGER.log(Level.INFO, "Entering {0}.{1}", new Object[]{"IdmpodSubscriptionImpl", "setTrial"});
		return null;
	}

	@Override
	public JSONObject subscriptionFromIntegService(JSONArray jsonArray) throws Exception
	{
		LOGGER.log(Level.INFO, "Entering {0}.{1}", new Object[]{"IdmpodSubscriptionImpl", "subscriptionFromIntegService"});
		return null;
	}

	@Override
	public JSONObject propagationSuccess(JSONObject jsonObject) throws Exception
	{
		LOGGER.log(Level.INFO, "Entering {0}.{1}", new Object[]{"IdmpodSubscriptionImpl", "propagationSuccess"});
		return null;
	}

	@Override
	public JSONObject cancelTrial(String zID, JSONObject json) throws Exception
	{
		//		try
		//		{
		//			LOGGER.log(Level.INFO, "Cancelling trial with zID {0}, and json : {1}", new Object[]{zID, json});
		//			String zaaid = zID;
		//			DataObject licDO = LicenseUtil.getLicenseDetailsDO(zaaid);
		//			Row licRow = licDO.getFirstRow(IDMPODSUBSCRIPTIONS.TABLE);
		//			if (licRow.get(IDMPODSUBSCRIPTIONS.PLANTYPE).equals(LicenseUtil.PLANTYPE_REGISTERED))
		//			{
		//				LOGGER.log(Level.WARNING, "Cancel trial sent for registered license. Ignoring processing.");
		//				return getJSONResponse(zID, true, ZStoreConstants.LicenseOperation.CANCEL_PLAN, null);
		//			}
		//
		//			LicenseUtil.Plan plan = LicenseUtil.getPlan(LicenseUtil.PLANID_FREE);
		//			licRow.set(IDMPODSUBSCRIPTIONS.PLANID, plan.getPlanId());
		//			licRow.set(IDMPODSUBSCRIPTIONS.PLANTYPE, plan.getPlanType());
		//			licRow.set(IDMPODSUBSCRIPTIONS.NO_OF_USERS, plan.getMaxUsers());
		//			licRow.set(IDMPODSUBSCRIPTIONS.EXPIRYTIME, -1L);
		//			licDO.updateRow(licRow);
		//			DBUtils.getAAPersistence(zaaid).update(licDO);
		//
		//			// When a user purchases when he is in trial mode, payments will call cancelTrial followed by addSubscription. If we cancel the license in this case,
		//			if (json.has("reason") && "subscription".equals(json.get("reason")))
		//			{
		//				LOGGER.log(Level.INFO, "Enforce license restriction ignoring because of purchasing");
		//			}
		//			else
		//			{
		//				LicenseUtil.enforceLicenseRestrictions(licDO.getFirstRow(IDMPODSUBSCRIPTIONS.TABLE));
		//			}
		//			return getJSONResponse(zID, true, ZStoreConstants.LicenseOperation.CANCEL_PLAN, null);
		//		}
		//		catch (Exception e)
		//		{
		//			return getStatusJSON(false, zID, "Unable to cancel the trial license", e);//No I18N
		//		}
		LOGGER.log(Level.INFO, "Entering {0}.{1}", new Object[]{"IdmpodSubscriptionImpl", "cancelTrial"});
		return null;
	}

	@Override
	public JSONObject cancelTrialInquiry(JSONArray licJSONArray) throws Exception
	{
		//		LOGGER.log(Level.INFO, "Cancelling trial inquiry with json : " + licJSONArray);
		//		JSONObject respJSON = new JSONObject();
		//
		//		for (int i = 0; i < licJSONArray.length(); i++)
		//		{
		//			JSONObject json = licJSONArray.getJSONObject(i);
		//			String zId = json.getString(ZStoreConstants.UNIQUE_ID);
		//			String zaaid = zId;
		//			LOGGER.log(Level.INFO, "Cancelling license with JSON : " + json);
		//			JSONObject resp = new JSONObject();
		//			try
		//			{
		//				if (!json.has(ZStoreConstants.ADDON_ID))
		//				{
		//					json.put(ZStoreConstants.TRIAL_TYPE, ZStoreConstants.TRIAL_TYPES.TRIAL_TYPE_PLAN.getID());
		//					LOGGER.log(Level.INFO, "Cancelling the plan trial with information : " + json);
		//					DataObject licDO = LicenseUtil.getLicenseDetailsDO(zaaid);
		//					Row licRow = licDO.getFirstRow(IDMPODSUBSCRIPTIONS.TABLE);
		//					if (licRow.get(IDMPODSUBSCRIPTIONS.PLANTYPE).equals(LicenseUtil.PLANTYPE_REGISTERED))
		//					{
		//						LOGGER.log(Level.WARNING, "Cancel trial sent for registered license. Ignoring processing.");
		//						return getJSONResponse(zId, true, ZStoreConstants.LicenseOperation.CANCEL_PLAN, null);
		//					}
		//
		//					LicenseUtil.Plan plan = LicenseUtil.getPlan(LicenseUtil.PLANID_FREE);
		//					licRow.set(IDMPODSUBSCRIPTIONS.PLANID, plan.getPlanId());
		//					licRow.set(IDMPODSUBSCRIPTIONS.PLANTYPE, plan.getPlanType());
		//					licRow.set(IDMPODSUBSCRIPTIONS.NO_OF_USERS, plan.getMaxUsers());
		//					licRow.set(IDMPODSUBSCRIPTIONS.EXPIRYTIME, -1L);
		//					licDO.updateRow(licRow);
		//					DBUtils.getAAPersistence(zaaid).update(licDO);
		//
		//					if (json.has("reason") && "subscription".equals(json.get("reason")))
		//					{
		//						LOGGER.log(Level.INFO, "Enforce license restriction ignoring because of purchasing");
		//					}
		//					else
		//					{
		//						LicenseUtil.enforceLicenseRestrictions(licDO.getFirstRow(IDMPODSUBSCRIPTIONS.TABLE));
		//					}
		//					resp = getJSONResponse(zId, true, ZStoreConstants.LicenseOperation.CANCEL_PLAN, null);
		//				}
		//                /*else
		//                 {
		//                 json.put(ZStoreConstants.TRIAL_TYPE, TRIAL_TYPE.TRIAL_TYPE_ADDON.getID());
		//                 resp = getLicenseBean(zId).cancelAddonTrial(zId, json);
		//                 }*/
		//			}
		//			catch (Exception e)
		//			{
		//				LOGGER.log(Level.WARNING, "Exception while cancelling trial for zid : " + zId, e);
		//				resp = getStatusJSON(false, zId, "Error when cancelling for " + zId, e);//No I18N
		//			}
		//			respJSON.put(zId, resp);
		//		}
		//		return respJSON;
		LOGGER.log(Level.INFO, "Entering {0}.{1}", new Object[]{"IdmpodSubscriptionImpl", "cancelTrialInquiry"});
		return null;
	}

	@Override
	public JSONObject changeProfileId(JSONArray jsonArray)
	{
		try
		{
			LOGGER.log(Level.INFO, "Changing the profileIDs : + " + jsonArray);
			JSONObject respJSON = null;
			if (jsonArray == null || jsonArray.length() == 0)
			{
				respJSON = getStatusJSON(false, null, "No profile IDs present for changing", null);//No I18N
			}
			else
			{
				JSONArray failedProfiles = new JSONArray();

				for (int i = 0; i < jsonArray.length(); i++)
				{
					JSONObject jsonObj = jsonArray.getJSONObject(i);
					String zID = jsonObj.getString(ZStoreConstants.UNIQUE_ID);
					String zaaid = zID;
					try
					{
						String newProfileID = jsonObj.getString(ZStoreConstants.PROFILEID);
						LOGGER.log(Level.INFO, "Changing the profile id for zID : " + zID + " to : " + newProfileID);
						DataObject licDO = LicenseUtil.getLicenseDetailsDO(zaaid);
						licDO.set(IDMPODSUBSCRIPTIONS.TABLE, IDMPODSUBSCRIPTIONS.PROFILEID, newProfileID);
						DBUtils.getAAPersistence(zaaid).update(licDO);
						getJSONResponse(zID, true, ZStoreConstants.LicenseOperation.CHANGE_PROFILEID, null);
					}
					catch (Exception e)
					{
						LOGGER.log(Level.WARNING, "Unable to change the profile ID for zID " + zID, e);
						failedProfiles.put(zID);
					}
				}

				respJSON = getStatusJSON(failedProfiles.length() == 0, null, "Profile IDs changed", null);//No I18N
				respJSON.put(ZStoreConstants.FAILEDPROFILES, failedProfiles);
			}
			LOGGER.log(Level.INFO, "Status of change profile IDs : " + respJSON);
			return respJSON;

		}
		catch (JSONException e)
		{
			LOGGER.log(Level.SEVERE, "JSON Exception occured in changeProfileId", e);
			return getStatusJSON(false, null, "", null);//No I18N
		}
	}

	@Override
	public JSONObject addUserToService(JSONObject json) throws Exception
	{
		LOGGER.log(Level.INFO, "addUserToService " + json);
		JSONObject jsonObj = new JSONObject();

		String zuid = "" + json.get(ZStoreConstants.USER_ID);
		String companyName = json.getString(ZStoreConstants.COMPANY_NAME);
		User user = IAMCommunicator.getIAMUser(zuid);
		long zoid = user.getZOID();
		String statusMsg = "";
		OrgAPI orgApi = IAMProxy.getInstance().getOrgAPI();
		if (zoid == -1L)
		{
			// User not not part of IAM organization, so creating new organization
			zoid = IdmpodIAMUtil.checkAndCreateOrg(user, companyName);
		}
		if (zoid != -1L)
		{
			Org org = orgApi.getOrg(zoid);
			String orgName = org.getOrgName();
			String zaid = user.getZaid();
			String zaaid = IdmpodIAMUtil.checkAndCreateZaaid(user, org);
			CollaborationUtils.reserveSpace(zaaid);//reserve space for appAccount
			CollaborationUtils.associateName(zaaid, zaid);//associate the reserved space for zaid also
			CommonDBUtil.addOrgInCommonDb(zoid, orgName, zaid, zaaid);//Now add the org details in commondb
			IdmpodUtils.setOrgPreference(DBUtils.getAAPersistence(zaaid), "COUNTRY_CODE", user.getCountry());//NO I18N
			IdmpodUtils.setOrgPreference(DBUtils.getAAPersistence(zaaid), "STATUS", "OPEN");//NO I18N

			LicenseUtil.startTrial(zaaid);

			jsonObj.put(ZStoreConstants.RESULT, ZStoreConstants.SUCCESS);
			jsonObj.put(ZStoreConstants.UNIQUE_ID, zaaid);
			return jsonObj;
		}
		else
		{
			statusMsg = "Problem in creating IAM organization";//No I18N
		}
		return getStatusJSON(false, null, statusMsg, null);
	}

	@Override
	public JSONObject checkPortalName(String portalName, JSONObject jsonObject) throws Exception
	{
		LOGGER.log(Level.INFO, "checkPortalName: + " + portalName);
		return getStatusJSON(true, null, null, null);
	}

	private JSONObject getStatusJSON(boolean status, String zID, String statusMessage, Exception ex)
	{
		if (zID != null)
		{
			statusMessage = "ZID : " + zID + " - " + statusMessage;//No I18N
		}
		if (!status)
		{
			LOGGER.log(Level.WARNING, statusMessage, ex);
		}
		try
		{
			JSONObject json = new JSONObject();
			json.put(ZStoreConstants.RESULT, (status) ? ZStoreConstants.SUCCESS : ZStoreConstants.FAILURE);
			json.put(ZStoreConstants.MESSAGE, statusMessage);
			return json;
		}
		catch (JSONException e)
		{
			LOGGER.log(Level.SEVERE, "Exception occured in payment response JSON", e);
			return null;
		}
	}

	private JSONObject getJSONResponse(String id, boolean isSuccess, ZStoreConstants.LicenseOperation operation, JSONObject addOnRespJSON) throws JSONException
	{
		JSONObject statusJSON = new JSONObject();
		statusJSON.put(ZStoreConstants.UNIQUE_ID, id);
		statusJSON.put(ZStoreConstants.RESULT, (isSuccess) ? ZStoreConstants.SUCCESS : ZStoreConstants.FAILURE);
		if (addOnRespJSON != null)
		{
			statusJSON.put(ZStoreConstants.PROPAGATE, addOnRespJSON);
		}
		LOGGER.log(Level.INFO, "License status for ID : " + id + " and operation : " + operation + " is : " + statusJSON);
		return statusJSON;
	}
}
