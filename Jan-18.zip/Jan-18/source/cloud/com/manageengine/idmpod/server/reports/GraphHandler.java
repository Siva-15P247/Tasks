package com.manageengine.idmpod.server.reports;

import com.adventnet.db.api.RelationalAPI;
import com.adventnet.ds.query.*;
import com.adventnet.i18n.I18N;
import com.adventnet.iam.IAMException;
import com.adventnet.iam.IAMProxy;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.QueryConstructor;
import com.adventnet.persistence.Row;
import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.iam.IdmpodIAMUtil;
import com.manageengine.tables.idmpod.IDMPODAPPLICATIONACCESSAUDIT;
import com.manageengine.tables.idmpod.IDMPODCHARTFIELDS;
import com.manageengine.tables.idmpod.IDMPODCHARTS;
import org.json.JSONArray;
import org.json.JSONObject;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

public class GraphHandler
{
	private static final Logger LOGGER = Logger.getLogger(GraphHandler.class.getName());

	public static JSONObject getChart(JSONObject request)
	{
		final String TYPE = JsonApiHandler.ResourceType.CHART.getResType();
		JSONObject chartObject = new JSONObject();
		try
		{
			ArrayList tablesList = new ArrayList();
			tablesList.add(IDMPODCHARTS.TABLE);
			tablesList.add(IDMPODCHARTFIELDS.TABLE);

			boolean[] isLeftJoins = new boolean[tablesList.size()];
			Arrays.fill(isLeftJoins, true);

			Criteria crit = new Criteria(Column.getColumn(IDMPODCHARTS.TABLE, IDMPODCHARTS.CHART_ID), request.optLong(IDMPODCHARTS.CHART_ID), QueryConstants.EQUAL);

			SelectQuery chartDefQuery = QueryConstructor.get(tablesList, isLeftJoins, crit);

			DataObject chartDefDO = DBUtils.getOrgPersistence().get(chartDefQuery);
			if (!chartDefDO.isEmpty())
			{
				if (chartDefDO.containsTable(IDMPODCHARTS.TABLE))
				{
					Row chartsRow = chartDefDO.getFirstRow(IDMPODCHARTS.TABLE);
					JSONObject chartDef = DBUtils.rowToJson(chartsRow);

					JSONObject chartAttrs = new JSONObject();
					if (chartDefDO.containsTable(IDMPODCHARTFIELDS.TABLE))
					{
						chartDefDO.sortRows(IDMPODCHARTFIELDS.TABLE, new SortColumn(Column.getColumn(IDMPODCHARTFIELDS.TABLE, IDMPODCHARTFIELDS.FIELD_INDEX), true));
						Iterator<Row> chartFieldRows = chartDefDO.getRows(IDMPODCHARTFIELDS.TABLE);
						String baseTable = (String) chartDefDO.getFirstRow(IDMPODCHARTFIELDS.TABLE).get(IDMPODCHARTFIELDS.TABLE_NAME);
						SelectQuery query = new SelectQueryImpl(Table.getTable(baseTable));
						query.setRange(new Range(1, chartDef.optInt(IDMPODCHARTS.DEFAULT_ROW_LIMIT, 5)));

						List<Column> groupByCols = null;
						while (chartFieldRows.hasNext())
						{
							Row chartFieldRow = chartFieldRows.next();
							JSONObject chartFieldObj = DBUtils.rowToJson(chartFieldRow);

							Column chartField = Column.getColumn(chartFieldObj.getString(IDMPODCHARTFIELDS.TABLE_NAME), chartFieldObj.getString(IDMPODCHARTFIELDS.COLUMN_NAME));

							if (chartFieldObj.has(IDMPODCHARTFIELDS.FUNCTION))
							{
								String function = chartFieldObj.getString(IDMPODCHARTFIELDS.FUNCTION);
								if (function.equalsIgnoreCase("COUNT"))
								{
									chartField = chartField.count();
									chartField.setColumnAlias(chartFieldObj.getString(IDMPODCHARTFIELDS.TABLE_NAME) + "_" + chartFieldObj.getString(IDMPODCHARTFIELDS.COLUMN_NAME) + "_COUNT");
								}
								else if (function.equalsIgnoreCase("DISTINCT_COUNT"))
								{
									chartField = chartField.distinct();
									chartField = chartField.count();
									chartField.setColumnAlias(chartFieldObj.getString(IDMPODCHARTFIELDS.TABLE_NAME) + "_" + chartFieldObj.getString(IDMPODCHARTFIELDS.COLUMN_NAME) + "_COUNT");
								}
								else
								{
									chartField = Column.createFunction(function, chartField);
									chartField.setColumnAlias(chartFieldObj.getString(IDMPODCHARTFIELDS.TABLE_NAME) + "_" + chartFieldObj.getString(IDMPODCHARTFIELDS.COLUMN_NAME) + function.toUpperCase());
								}
							}

							if (chartFieldObj.optBoolean(IDMPODCHARTFIELDS.INCLUDE, true))
							{
								query.addSelectColumn(chartField);
							}

							if (chartFieldObj.optBoolean(IDMPODCHARTFIELDS.IS_GROUP_BY))
							{
								if (groupByCols == null)
								{
									groupByCols = new ArrayList<>();
								}
								groupByCols.add(chartField);
							}

							if (chartFieldObj.optBoolean(IDMPODCHARTFIELDS.IS_SORT_BY))
							{
								SortColumn sortColumn = new SortColumn(chartField, chartFieldObj.optBoolean(IDMPODCHARTFIELDS.IS_ASCENDING));
								query.addSortColumn(sortColumn);
							}
						}
						if (groupByCols != null)
						{
							GroupByClause gbc = new GroupByClause(groupByCols);
							query.setGroupByClause(gbc);
						}

						Connection connection = null;
						DataSet dataSet = null;
						try
						{
							RelationalAPI relationalAPI = DBUtils.getOrgRelationalApi();
							connection = relationalAPI.getConnection();
							dataSet = relationalAPI.executeQuery(query, connection);

							Criteria selFieldsCrit = new Criteria(Column.getColumn(IDMPODCHARTFIELDS.TABLE, IDMPODCHARTFIELDS.INCLUDE), true, QueryConstants.EQUAL);
							selFieldsCrit = selFieldsCrit.or(new Criteria(Column.getColumn(IDMPODCHARTFIELDS.TABLE, IDMPODCHARTFIELDS.INCLUDE), null, QueryConstants.EQUAL));

							Iterator<Row> selectRows = chartDefDO.getRows(IDMPODCHARTFIELDS.TABLE, selFieldsCrit);

							List<Row> selectedFields = new ArrayList<>();

							while (selectRows.hasNext())
							{
								Row selectRow = selectRows.next();
								selectedFields.add(selectRow);
							}

							JSONArray dataColumns = new JSONArray();
							JSONArray labels = new JSONArray();
							labels.put("Labels");
							JSONArray data = new JSONArray();

							while (dataSet.next())
							{
								for (int i = 1; i <= dataSet.getColumnCount(); i++)
								{
									Row selectedField = selectedFields.get(i - 1);
									if ((Long) selectedField.get(IDMPODCHARTFIELDS.FIELD_TYPE) == 2L)
									{
										labels.put(parseLabel((String) selectedField.get(IDMPODCHARTFIELDS.TABLE_NAME), (String) selectedField.get(IDMPODCHARTFIELDS.COLUMN_NAME), dataSet.getValue(i)));
									}
									else
									{
										JSONArray dataArray = null;
										if (data.isNull(i - 1))
										{
											dataArray = new JSONArray();
											dataArray.put(I18N.getMsg((String) selectedField.get(IDMPODCHARTFIELDS.FIELD_DISPLAY_NAME)));
										}
										else
										{
											dataArray = data.getJSONArray(i - 1);
										}
										dataArray.put(dataSet.getValue(i));
										data.put(i - 1, dataArray);
									}
								}
							}

							dataColumns.put(labels);
							for (int i = 0; i < data.length(); i++)
							{
								if (!data.isNull(i))
								{
									dataColumns.put(data.get(i));
								}
							}

							// LOGGER.info(relationalAPI.getSelectSQL(query));

							chartAttrs.put("CHART_OBJECT", getHighchartsObject(dataColumns, chartDef.optString(IDMPODCHARTS.DEFAULT_CHART_TYPE, "column"), I18N.getMsg(chartDef.optString(IDMPODCHARTS.Y_AXIS_TITLE, null))));
						}
						catch (Exception e)
						{
							LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
						}
						finally
						{
							DBUtils.safeClose(connection, dataSet);
						}
					}
					chartObject.put(JsonApiConstants.ID, request.optLong(IDMPODCHARTS.CHART_ID));
					chartObject.put(JsonApiConstants.TYPE, TYPE);
					chartObject.put(JsonApiConstants.ATTRIBUTES, chartAttrs);
				}
			}

		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return chartObject;
	}

	private static String parseLabel(String tableName, String columnName, Object value)
	{
		if (columnName.equalsIgnoreCase(IDMPODAPPLICATIONACCESSAUDIT.APPLICATION_ID))
		{
			try
			{
				return IAMProxy.getInstance().getOrgAPI().getSamlApp(IdmpodIAMUtil.getZAID(), value.toString()).getAppName();
			}
			catch (IAMException e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
		}
		else if (columnName.equalsIgnoreCase(IDMPODAPPLICATIONACCESSAUDIT.USER_ID))
		{
			try
			{
				return IAMProxy.getInstance().getUserAPI().getUser((Long) value).getDisplayName();
			}
			catch (IAMException e)
			{
				LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
			}
		}
		return value.toString();
	}

	private static JSONObject getHighchartsObject(JSONArray dataColumns, String chartType, String yAxisTitle)
	{
		JSONObject graphOptions = new JSONObject();

		JSONObject chart = new JSONObject();
		chart.put("type", chartType);

		if (chartType.equalsIgnoreCase("pie"))
		{
			JSONObject plotOptions = new JSONObject();
			JSONObject pie = new JSONObject();
			pie.put("allowPointSelect", true);
			pie.put("cursor", "pointer");
			JSONObject dL = new JSONObject();
			dL.put("enabled", true);
			dL.put("format", "<b>{point.name}</b>: {point.percentage:.2f} %");
			JSONObject style = new JSONObject();
			style.put("color", "black");
			style.put("width", "100px");
			String formatter = "function(){\n" + //NO I18N
					"                var tmp=this.point.name;\n" + //NO I18N
					"                tmp=tmp.replace(/\\./gi,'. ');           \n" + //NO I18N
					"                return tmp;\n" + //NO I18N
					"                }";
			dL.put("formatter", formatter);
			dL.put("style", style);
			pie.put("dataLabels", dL);
			plotOptions.put("pie", pie);

			graphOptions.put("plotOptions", plotOptions);
		}

		chart.put("height", 170);

		graphOptions.put("chart", chart);

		//		if (dataModel.has("isDateTime") && dataModel.getBoolean("isDateTime"))
		//		{
		//			JSONObject xAxis = new JSONObject();
		//			xAxis.put("type", "datetime");
		//			graphOptions.put("xAxis", xAxis);
		//			chart.put("zoomType", "x");
		//		}
		//		else
		{
			JSONObject xAxis = new JSONObject();
			xAxis.put("type", "category");
			graphOptions.put("xAxis", xAxis);
		}

		JSONObject exporting = new JSONObject();
		exporting.put("enabled", false);
		graphOptions.put("exporting", exporting);

		JSONObject title = new JSONObject();
		title.put("text", "");
		graphOptions.put("title", title);

		JSONObject yAxis = new JSONObject();
		JSONObject yAxisTitleObj = new JSONObject();
		if (yAxisTitle != null)
		{
			yAxisTitleObj.put("text", yAxisTitle);
		}
		else
		{
			yAxisTitleObj.put("text", "");
		}
		yAxisTitleObj.put("align", "middle");
		yAxis.put("title", yAxisTitleObj);
		graphOptions.put("yAxis", yAxis);

		JSONObject legend = new JSONObject();
		legend.put("maxHeight", 25);
		graphOptions.put("legend", legend);

		JSONObject credits = new JSONObject();
		credits.put("enabled", false);
		graphOptions.put("credits", credits);

		JSONObject data = new JSONObject();

		data.put("columns", dataColumns);

		graphOptions.put("data", data);

		JSONObject tooltip = new JSONObject();
		tooltip.put("useHTML", false);
		tooltip.put("headerFormat", "<span style=\"display:inline-block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:35em;font-size: 10px\">{point.key}</span><br>");

		graphOptions.put("tooltip", tooltip);

		JSONObject noData=new JSONObject();
		noData.put("useHTML", true);

		graphOptions.put("noData",noData);

		JSONObject lang=new JSONObject();
		lang.put("noData","<i class=\"idmp-inline-icon icn-nodata opacity-4 idmp-mr-5\"></i>No Data to display");
		graphOptions.put("lang",lang);

		return graphOptions;
	}

}
