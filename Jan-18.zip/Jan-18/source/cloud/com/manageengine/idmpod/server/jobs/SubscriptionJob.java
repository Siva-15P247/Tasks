package com.manageengine.idmpod.server.jobs;

import com.adventnet.ds.query.Criteria;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Persistence;
import com.adventnet.persistence.Row;
import com.manageengine.idmpod.server.utils.CommonDBUtil;
import com.manageengine.idmpod.server.zstore.LicenseUtil;
import com.manageengine.tables.idmpod.IDMPODORG;
import com.manageengine.tables.idmpod.IDMPODSUBSCRIPTIONS;
import com.zoho.scheduler.RunnableJob;

import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SubscriptionJob implements RunnableJob
{
	private static final Logger LOGGER = Logger.getLogger(SubscriptionJob.class.getName());

	@Override
	public void run(long jobid) throws Exception
	{
		LOGGER.log(Level.INFO, "Entering {0}.{1}", new Object[]{"SubscriptionJob", "run"});

		Persistence commonPers = CommonDBUtil.getPersistance();

		DataObject dataObject = commonPers.get(IDMPODORG.TABLE, (Criteria) null);
		if (dataObject.containsTable(IDMPODORG.TABLE))
		{
			Iterator<Row> rows = dataObject.getRows(IDMPODORG.TABLE);
			while (rows.hasNext())
			{
				Row row = rows.next();
				String zaaid = row.get(IDMPODORG.ZAAID).toString();
				if (LicenseUtil.isTrial(zaaid))
				{
					Row licRow = LicenseUtil.getLicenseDetailsRow(zaaid, true);
					Long expiryTime = (Long) licRow.get(IDMPODSUBSCRIPTIONS.EXPIRYTIME);
					if (expiryTime <= System.currentTimeMillis())
					{
						LicenseUtil.downgrade2Free(zaaid);
					}
				}
			}
		}

		LOGGER.log(Level.INFO, "Exiting {0}.{1}", new Object[]{"SubscriptionJob", "run"});
	}
}
