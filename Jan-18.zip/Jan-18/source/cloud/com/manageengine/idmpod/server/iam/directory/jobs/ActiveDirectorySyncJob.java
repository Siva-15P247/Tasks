package com.manageengine.idmpod.server.iam.directory.jobs;

import com.adventnet.ds.query.Column;
import com.adventnet.ds.query.Criteria;
import com.adventnet.ds.query.QueryConstants;
import com.adventnet.ds.query.SelectQuery;
import com.adventnet.iam.IAMProxy;
import com.adventnet.iam.UserAPI;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.Persistence;
import com.adventnet.persistence.QueryConstructor;
import com.adventnet.persistence.Row;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.iam.directory.DirectoryHandler;
import com.manageengine.idmpod.server.utils.CommonDBUtil;
import com.manageengine.idmpod.server.utils.IdmpodThreadLocal;
import com.manageengine.tables.idmpod.*;
import org.json.JSONArray;
import org.json.JSONObject;

import javax.naming.*;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import static com.manageengine.idmpod.server.iam.directory.DirectoryHandler.handleSyncDirectoryUser;


public class ActiveDirectorySyncJob extends DirectorySyncJob
{
	public static final Logger LOGGER = Logger.getLogger(ActiveDirectorySyncJob.class.getName());

	public ActiveDirectorySyncJob()
	{
		super();
	}

	public ActiveDirectorySyncJob(Long jobId)
	{
		super(jobId);
	}

	@Override
	public void run(long jobId) throws Exception
	{
		LOGGER.log(Level.INFO, "Starting ActiveDirectorySyncJob job {0}", jobId); // No I18N
		Row orgRow = CommonDBUtil.getOrgRowForJob(jobId);
		IdmpodThreadLocal.setAppId(orgRow.get(IDMPODORG.ZAAID).toString());

		ArrayList<String> tablesList = new ArrayList<String>();
		tablesList.add(IDMPODDIRECTORYJOBS.TABLE);
		tablesList.add(IDMPODDIRECTORIES.TABLE);
		tablesList.add(IDMPODDIRECTORYNODES.TABLE);
		tablesList.add(IDMPODDIRECTORYPARAMS.TABLE);


		boolean[] isLeftJoins = new boolean[tablesList.size()];
		Arrays.fill(isLeftJoins, true);

		SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, new Criteria(Column.getColumn(IDMPODDIRECTORYJOBS.TABLE, IDMPODDIRECTORYJOBS.JOB_ID), jobId, QueryConstants.EQUAL));

		Persistence orgPersistence = DBUtils.getOrgPersistence();

		DataObject syncDO = orgPersistence.get(query);

		Row jobRow = syncDO.getFirstRow(IDMPODDIRECTORYJOBS.TABLE);

		Boolean isFullFetch = ((Long) jobRow.get(IDMPODDIRECTORYJOBS.SYNC_TYPE)).equals(DirectoryHandler.SYNC_TYPE.FETCH_ONLY);

		LOGGER.info("Is full fetch:" + isFullFetch);

		if (syncDO.containsTable(IDMPODDIRECTORIES.TABLE))
		{
			Row directoryRow = syncDO.getFirstRow(IDMPODDIRECTORIES.TABLE);
			Long directoryId = (Long) directoryRow.get(IDMPODDIRECTORIES.DIRECTORY_ID);

			Row syncDetailsRow = new Row(IDMPODDIRECTORYSYNCDETAILS.TABLE);

			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.JOB_ID, jobId);
			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.DIRECTORY_ID, directoryId);
			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.SYNC_TYPE, jobRow.get(IDMPODDIRECTORYJOBS.SYNC_TYPE));
			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.SYNC_STATUS, DirectoryHandler.SYNC_STATUS.RUNNING);
			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.SYNC_START_TIME, System.currentTimeMillis());

			syncDO.addRow(syncDetailsRow);

			Criteria syncEnabledNodesCrit = isFullFetch ? null : new Criteria(Column.getColumn(IDMPODDIRECTORYNODES.TABLE, IDMPODDIRECTORYNODES.SYNC_ENABLED), Boolean.TRUE, QueryConstants.EQUAL);

			Iterator<Row> syncEnabledNodes = syncDO.getRows(IDMPODDIRECTORYNODES.TABLE, syncEnabledNodesCrit);

			JSONArray ous = new JSONArray();

			while (syncEnabledNodes.hasNext())
			{
				LOGGER.info("syncEnabledNode found");
				Row syncEnabledNode = syncEnabledNodes.next();

				if (syncEnabledNode.get(IDMPODDIRECTORYNODES.PARENT_NODE) == null)
				{
					ous.put(DBUtils.rowToJson(syncEnabledNode));
				}
				else
				{
					Row parentNode = syncDO.getRow(IDMPODDIRECTORYNODES.TABLE, new Criteria(Column.getColumn(IDMPODDIRECTORYNODES.TABLE, IDMPODDIRECTORYNODES.NODE_ID), syncEnabledNode.get(IDMPODDIRECTORYNODES.PARENT_NODE), QueryConstants.EQUAL));
					Boolean isParentEnabled = parentNode.get(IDMPODDIRECTORYNODES.SYNC_ENABLED) == null ? Boolean.FALSE : (Boolean) parentNode.get(IDMPODDIRECTORYNODES.SYNC_ENABLED);
					if (!isParentEnabled)
					{
						ous.put(DBUtils.rowToJson(syncEnabledNode));
					}
				}

				Row synchedNode = new Row(IDMPODSYNCHEDNODES.TABLE);
				synchedNode.set(IDMPODSYNCHEDNODES.DIRECTORY_ID, directoryId);
				synchedNode.set(IDMPODSYNCHEDNODES.SYNC_ID, syncDetailsRow.get(IDMPODDIRECTORYSYNCDETAILS.SYNC_ID));
				synchedNode.set(IDMPODSYNCHEDNODES.NODE_ID, syncEnabledNode.get(IDMPODDIRECTORYNODES.NODE_ID));

				syncDO.addRow(synchedNode);
			}
			orgPersistence.update(syncDO);

			// LOGGER.info("OUS:" + ous.toString(4));

			if (syncDO.containsTable(IDMPODDIRECTORYPARAMS.TABLE))
			{
				JSONObject directoryAttrs = new JSONObject();
				for (Iterator<Row> pit = syncDO.getRows(IDMPODDIRECTORYPARAMS.TABLE); pit.hasNext(); )
				{
					Row pr = pit.next();
					directoryAttrs.put((String) pr.get(IDMPODDIRECTORYPARAMS.PARAM_NAME), pr.get(IDMPODDIRECTORYPARAMS.ENCRYPTED_PARAM_VALUE));
				}

				Hashtable<String, String> env = new Hashtable<>();
				env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
				env.put(Context.PROVIDER_URL, directoryAttrs.getString("LDAP_CONNECTION_URL"));
				env.put(Context.SECURITY_AUTHENTICATION, "simple");
				env.put(Context.SECURITY_PRINCIPAL, directoryAttrs.getString("SERVICE_ACCOUNT_USERNAME")); // use DN
				env.put(Context.SECURITY_CREDENTIALS, directoryAttrs.getString("SERVICE_ACCOUNT_PASSWORD"));
				env.put(Context.REFERRAL, "follow");

				String baseDN = directoryAttrs.getString("BASE_DOMAIN_NAME");

				LdapContext ctx = null;
				try
				{
					ctx = new InitialLdapContext(env, null);
					LOGGER.info("OUs to sync:" + ous.length());
					for (int ouId = 0; ouId < ous.length(); ouId++)
					{
						JSONObject ouObj = ous.getJSONObject(ouId);
						String ou = ouObj.getString(IDMPODDIRECTORYNODES.NODE_IDENTIFIER);
						Long nodeId = ouObj.getLong(IDMPODDIRECTORYNODES.NODE_ID);
						// LOGGER.info(DirectoryHandler.calcCtxName(ou, baseDN));

						// Activate paged results
						int pageSize = 100;
						byte[] cookie = null;
						ctx.setRequestControls(new Control[]{new PagedResultsControl(pageSize, Control.CRITICAL)});
						SearchControls searchControls = new SearchControls();
						searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);

						do
						{
							DataObject dataObject = DBUtils.getOrgPersistence().constructDataObject();
							/* perform the search */
							NamingEnumeration results = ctx.search(DirectoryHandler.calcCtxName(ou, baseDN), "(&(objectClass=user)(objectCategory=person))", searchControls);// No I18N

							while (results != null && results.hasMore())
							{
								SearchResult entry = (SearchResult) results.next();

								Row userRow = new Row(IDMPODSYNCHEDUSERS.TABLE);
								userRow.set(IDMPODSYNCHEDUSERS.SYNC_ID, syncDetailsRow.get(IDMPODDIRECTORYSYNCDETAILS.SYNC_ID));
								userRow.set(IDMPODSYNCHEDUSERS.DIRECTORY_ID, directoryId);
								userRow.set(IDMPODSYNCHEDUSERS.NODE_ID, nodeId);
								if (entry.getAttributes().get("givenName") != null)
								{
									userRow.set(IDMPODSYNCHEDUSERS.FIRST_NAME, entry.getAttributes().get("givenName").get());// No I18N
								}
								if (entry.getAttributes().get("middleName") != null)
								{
									userRow.set(IDMPODSYNCHEDUSERS.MIDDLE_NAME, entry.getAttributes().get("middleName").get());// No I18N
								}
								if (entry.getAttributes().get("sn") != null)
								{
									userRow.set(IDMPODSYNCHEDUSERS.LAST_NAME, entry.getAttributes().get("sn").get());// No I18N
								}
								if (entry.getAttributes().get("displayName") != null)
								{
									userRow.set(IDMPODSYNCHEDUSERS.USER_DISPLAY_NAME, entry.getAttributes().get("displayName").get());// No I18N
								}
								if (entry.getAttributes().get("userPrincipalName") != null)
								{
									userRow.set(IDMPODSYNCHEDUSERS.USER_PRINCIPAL_NAME, entry.getAttributes().get("userPrincipalName").get());// No I18N
								}
								if (entry.getAttributes().get("mail") != null)
								{
									userRow.set(IDMPODSYNCHEDUSERS.USER_EMAIL, entry.getAttributes().get("mail").get());// No I18N
								}
								if (entry.getAttributes().get("distinguishedName") != null)
								{
									userRow.set(IDMPODSYNCHEDUSERS.DISTINGUISHED_NAME, entry.getAttributes().get("distinguishedName").get());// No I18N
								}

								dataObject.addRow(userRow);

							}

							AzureActiveDirectorySyncJob.handleFetchAndIAM(orgRow, jobRow, dataObject);
							// Examine the paged results control response
							Control[] controls = ctx.getResponseControls();
							if (controls != null)
							{
								for (int i = 0; i < controls.length; i++)
								{
									if (controls[i] instanceof PagedResultsResponseControl)
									{
										PagedResultsResponseControl prrc = (PagedResultsResponseControl) controls[i];
										cookie = prrc.getCookie();
									}
								}
							}
							// Re-activate paged results
							ctx.setRequestControls(new Control[]{new PagedResultsControl(pageSize, cookie, Control.CRITICAL)});

						} while (cookie != null);
					}
				}
				catch (AuthenticationException e)
				{
					LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
				}
				catch (NameNotFoundException e)
				{
					LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
				}
				catch (NamingException e)
				{
					LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
				}
				catch (Exception e)
				{
					LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
				}
				finally
				{
					if (ctx != null)
					{
						try
						{
							ctx.close();
						}
						catch (NamingException e)
						{
							LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
						}
					}
				}
			}

			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.SYNC_END_TIME, System.currentTimeMillis());
			syncDetailsRow.set(IDMPODDIRECTORYSYNCDETAILS.SYNC_STATUS, DirectoryHandler.SYNC_STATUS.SUCCESS);
			syncDO.updateRow(syncDetailsRow);
			orgPersistence.update(syncDO);
		}

		LOGGER.log(Level.INFO, "Finishing ActiveDirectorySyncJob job {0}", jobId); // No I18N
	}
}
