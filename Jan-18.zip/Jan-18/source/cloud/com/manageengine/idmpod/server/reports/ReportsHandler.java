package com.manageengine.idmpod.server.reports;

import com.adventnet.ds.query.*;
import com.adventnet.iam.IAMException;
import com.adventnet.persistence.DataAccessException;
import com.adventnet.persistence.DataObject;
import com.adventnet.persistence.QueryConstructor;
import com.adventnet.persistence.Row;
import com.manageengine.idmpod.server.api.json.JsonApiConstants;
import com.manageengine.idmpod.server.api.json.JsonApiHandler;
import com.manageengine.idmpod.server.db.DBUtils;
import com.manageengine.idmpod.server.iam.AppAccountUtils;
import com.manageengine.idmpod.server.iam.samlapps.SamlAppsHandler;
import com.manageengine.tables.idmpod.IDMPODDATAMODELFIELDS;
import com.manageengine.tables.idmpod.IDMPODDATAMODELS;
import com.manageengine.tables.idmpod.IDMPODREPORTINPUTS;
import com.manageengine.tables.idmpod.IDMPODREPORTS;
import com.zoho.accounts.AccountsProto;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;

public class ReportsHandler
{
	private static final Logger LOGGER = Logger.getLogger(ReportsHandler.class.getName());

	enum FIELD_TYPE
	{
		DEFAULT, DATA, LABEL, TIMESTAMP, ATTRIBUTES, MODEL_ID, UNDEFINED_B, ERRORS_OR_REMARKS
	}

	public static JSONObject getReports()
	{
		final String TYPE = JsonApiHandler.ResourceType.REPORT.getResType();
		JSONObject resp = new JSONObject();
		JSONArray reports = new JSONArray();
		JSONArray included = null;
		try
		{
			ArrayList tablesList = new ArrayList();
			tablesList.add(IDMPODREPORTS.TABLE);
			tablesList.add(IDMPODREPORTINPUTS.TABLE);
			tablesList.add(IDMPODDATAMODELS.TABLE);

			boolean[] isLeftJoins = new boolean[tablesList.size()];
			Arrays.fill(isLeftJoins, true);

			String[] acceptableRole = AppAccountUtils.getAccepatableRolesForCurrentUser();
			Criteria roleCrit = new Criteria(Column.getColumn(IDMPODREPORTS.TABLE, IDMPODREPORTS.AA_MEMBER_ROLE), acceptableRole, QueryConstants.IN, false);
			roleCrit = roleCrit.or(new Criteria(Column.getColumn(IDMPODREPORTS.TABLE, IDMPODREPORTS.AA_MEMBER_ROLE), null, QueryConstants.EQUAL));

			SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, roleCrit);

			DataObject reportsDO = DBUtils.getOrgPersistence().get(query);
			reportsDO.sortRows(IDMPODREPORTS.TABLE, new SortColumn(Column.getColumn(IDMPODREPORTS.TABLE, IDMPODREPORTS.INDEX), true));
			reportsDO.sortRows(IDMPODREPORTINPUTS.TABLE, new SortColumn(Column.getColumn(IDMPODREPORTINPUTS.TABLE, IDMPODREPORTINPUTS.INDEX), true));
			if (!reportsDO.isEmpty())
			{
				if (reportsDO.containsTable(IDMPODREPORTS.TABLE))
				{
					for (Iterator<Row> it = reportsDO.getRows(IDMPODREPORTS.TABLE); it.hasNext(); )
					{
						Row r = it.next();
						JSONObject reportsAttrs = DBUtils.rowToJson(r);
						if (reportsDO.containsTable(IDMPODDATAMODELS.TABLE))
						{
							Row modelRow = reportsDO.getRow(IDMPODDATAMODELS.TABLE, new Criteria(Column.getColumn(IDMPODDATAMODELS.TABLE, IDMPODDATAMODELS.MODEL_ID), r.get(IDMPODREPORTS.REPORT_MODEL), QueryConstants.EQUAL));
							if (modelRow != null)
							{
								DBUtils.rowToJson(modelRow, reportsAttrs);
							}
						}
						JSONObject report = new JSONObject();
						JSONObject relationship = null;
						JSONArray reportInputs = null;

						if (reportsAttrs.has(IDMPODREPORTS.CHART_ID))
						{
							if (relationship == null)
							{
								relationship = new JSONObject();
							}
							relationship.put("chart", JsonApiHandler.getResourceObject(JsonApiHandler.getResourceIdentifierObject("charts", reportsAttrs.get(IDMPODREPORTS.CHART_ID).toString())));
						}

						if (reportsDO.containsTable(IDMPODREPORTINPUTS.TABLE))
						{
							Iterator<Row> inputRows = reportsDO.getRows(IDMPODREPORTINPUTS.TABLE, new Criteria(Column.getColumn(IDMPODREPORTINPUTS.TABLE, IDMPODREPORTINPUTS.REPORT_ID), reportsAttrs.get(IDMPODREPORTS.REPORT_ID), QueryConstants.EQUAL));
							while (inputRows.hasNext())
							{
								if (reportInputs == null)
								{
									reportInputs = new JSONArray();
								}
								Row inputRow = inputRows.next();
								JSONObject reportInputObject = getReportInputObject(inputRow, reportsDO);
								reportInputs.put(reportInputObject);
								if (included == null)
								{
									included = new JSONArray();
								}
								included.put(reportInputObject);
							}
						}

						if (reportInputs != null)
						{
							if (relationship == null)
							{
								relationship = new JSONObject();
							}
							relationship.put("inputs", JsonApiHandler.getResourceObject(reportInputs));
						}

						if (relationship != null)
						{
							report.put(JsonApiConstants.RELATIONSHIPS, relationship);
						}
						report.put(JsonApiConstants.ID, reportsAttrs.get(IDMPODREPORTS.REPORT_ID));
						report.put(JsonApiConstants.TYPE, TYPE);
						report.put(JsonApiConstants.ATTRIBUTES, reportsAttrs);

						reports.put(report);
					}
				}
			}

		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		resp.put(JsonApiConstants.DATA, reports);
		if (included != null)
		{
			resp.put(JsonApiConstants.INCLUDED, included);
		}

		return resp;
	}

	private static JSONObject getReportInputObject(Row inputRow, DataObject dobj) throws DataAccessException, IAMException
	{
		final String TYPE = JsonApiHandler.ResourceType.REPORT_INPUT.getResType();
		JSONObject repInputObj = new JSONObject();
		JSONObject inputAttrs = DBUtils.rowToJson(inputRow);

		if (inputAttrs.has(IDMPODREPORTINPUTS.INPUT_MODEL))
		{
			Row modelRow = dobj.getRow(IDMPODDATAMODELS.TABLE, new Criteria(Column.getColumn(IDMPODDATAMODELS.TABLE, IDMPODDATAMODELS.MODEL_ID), inputAttrs.get(IDMPODREPORTINPUTS.INPUT_MODEL), QueryConstants.EQUAL));
			inputAttrs.put(IDMPODDATAMODELS.MODEL_NAME, modelRow.get(IDMPODDATAMODELS.MODEL_NAME));
			if (inputAttrs.getString(IDMPODREPORTINPUTS.UI_COMPONENT_TYPE).equalsIgnoreCase("select-input"))
			{
				JSONArray options = new JSONArray();
				if (inputAttrs.getString(IDMPODDATAMODELS.MODEL_NAME).equalsIgnoreCase("saml-app"))
				{
					List<AccountsProto.Account.SAMLApp> samlApps = SamlAppsHandler.getAllSAMLApps();
					for (AccountsProto.Account.SAMLApp samlApp : samlApps)
					{
						options.put(new JSONObject().put("SERVER_VALUE", samlApp.getAppId()).put("CLIENT_VALUE", samlApp.getAppName()));
					}
				}
				inputAttrs.put("OPTIONS", options);
			}
		}

		repInputObj.put(JsonApiConstants.ID, inputAttrs.get(IDMPODREPORTINPUTS.REPORT_INPUT_ID));
		repInputObj.put(JsonApiConstants.TYPE, TYPE);
		repInputObj.put(JsonApiConstants.ATTRIBUTES, inputAttrs);

		return repInputObj;
	}

	public static JSONArray getReportFields(Long reportId)
	{
		final String TYPE = JsonApiHandler.ResourceType.REPORT_FIELD.getResType();
		JSONArray reportFields = new JSONArray();
		try
		{
			ArrayList tablesList = new ArrayList();
			tablesList.add(IDMPODREPORTS.TABLE);
			tablesList.add(IDMPODDATAMODELS.TABLE);
			tablesList.add(IDMPODDATAMODELFIELDS.TABLE);

			boolean[] isLeftJoins = new boolean[tablesList.size()];
			Arrays.fill(isLeftJoins, true);

			Criteria reportCriteria = new Criteria(Column.getColumn(IDMPODREPORTS.TABLE, IDMPODREPORTS.REPORT_ID), reportId, QueryConstants.EQUAL);

			SelectQuery query = QueryConstructor.get(tablesList, isLeftJoins, reportCriteria);

			DataObject reportFieldsDO = DBUtils.getOrgPersistence().get(query);
			reportFieldsDO.sortRows(IDMPODDATAMODELFIELDS.TABLE, new SortColumn(Column.getColumn(IDMPODDATAMODELFIELDS.TABLE, IDMPODDATAMODELFIELDS.FIELD_INDEX), true));
			if (!reportFieldsDO.isEmpty())
			{
				if (reportFieldsDO.containsTable(IDMPODDATAMODELFIELDS.TABLE))
				{
					for (Iterator<Row> it = reportFieldsDO.getRows(IDMPODDATAMODELFIELDS.TABLE); it.hasNext(); )
					{
						Row r = it.next();
						JSONObject reportFiledAttrs = DBUtils.rowToJson(r);
						JSONObject reportField = new JSONObject();
						reportField.put(JsonApiConstants.ID, reportFiledAttrs.get(IDMPODDATAMODELFIELDS.FIELD_ID));
						reportField.put(JsonApiConstants.TYPE, TYPE);
						reportField.put(JsonApiConstants.ATTRIBUTES, reportFiledAttrs);
						reportFields.put(reportField);
					}
				}
			}
		}
		catch (Exception e)
		{
			LOGGER.log(java.util.logging.Level.SEVERE, e.getMessage(), e);
		}

		return reportFields;
	}
}
