package com.manageengine.idmpod.server.iam;

import com.adventnet.iam.*;
import com.adventnet.iam.security.LRUCacheMap;
import com.manageengine.idmpod.server.utils.IdmpodThreadLocal;
import com.zoho.accounts.AccountsConfiguration;
import com.zoho.accounts.AccountsConstants;
import com.zoho.accounts.AccountsProto;
import com.zoho.resource.ResourceException;
import com.zoho.sas.container.AppResources;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class IAMCommunicator
{


	private static final Logger LOGGER = Logger.getLogger(IAMCommunicator.class.getName());
	//	public static final String ZV_SERVICE_ADMIN_ROLE = AppResources.getProperty("zv.service.admin", "ZVServiceAdmin");//No I18N
	//	public static final String ZV_LEGAL_ADMIN_ROLE = "LegalAdmin";//No I18N
	private static String serviceName = AppResources.getProperty("service.name", "Idmpod");//No I18N
	private static int serviceId = -1;  // Will hold the service ID assigned by IAM
	//IAM Cache related constants
	public static final String KEY_VALIDATED_TIME = "ValidatedTime";//No I18N
	public static final int MAX_CACHE_ENTRIES = 1000;
	//	public static final int INITIAL_CACHE_ENTRIES = 1000;
	public static final long CACHE_VALIDITY_PERIOD = 10 * 60 * 1000;//10 minutes
	//Cache
	private static final LRUCacheMap<String, HashMap<String, Object>> APP_ACC_CACHE =
			//new LRUCacheMap<String, HashMap<String, Object>>(INITIAL_CACHE_ENTRIES, MAX_CACHE_ENTRIES, 0.75f, false, true);
			new LRUCacheMap<String, HashMap<String, Object>>(MAX_CACHE_ENTRIES, 50, 1, java.util.concurrent.TimeUnit.HOURS);
	/*private static final LRUCacheMap<String, HashMap<String, Object>> IP_PREFRENCE =
			//new LRUCacheMap<String, HashMap<String, Object>>(INITIAL_CACHE_ENTRIES, MAX_CACHE_ENTRIES, 0.75f, false, true);
			new LRUCacheMap<String, HashMap<String, Object>>(MAX_CACHE_ENTRIES, 50, 1, java.util.concurrent.TimeUnit.HOURS);*/
	//	private static final LRUCacheMap<String, HashMap<String, Object>> REPORT_SUMMARY_PREFERNCE = new LRUCacheMap<String, HashMap<String, Object>>(MAX_CACHE_ENTRIES, 50, 1, java.util.concurrent.TimeUnit.HOURS);

	public static Long addOrgInIAM(HttpServletRequest request, String orgName) throws IAMException
	{
		User user = IAMUtil.getCurrentUser();
		long zoid = user.getZOID();
		if (zoid == -1L)
		{
			OrgAPI orgApi = IAMProxy.getInstance().getOrgAPI();
			zoid = orgApi.addOrg(orgName, orgName, user.getZUID());
			LOGGER.log(Level.INFO, "Successfully added organization: {0}, ZOID:{1}", new Object[]{orgName, zoid});
		}
		// Clear the IAM Ticket Cache to update the current user details with the latest changes.
		// TicketManager.clearCache(IAMUtil.getCurrentTicket());
		IAMUtil.clearTicketCache(request, AppResources.getProperty("service.name"));
		return zoid;
	}

	public static Org getIAMOrg(Long zoid)
	{
		try
		{
			return IAMProxy.getInstance().getOrgAPI().getOrg(zoid);
		}
		catch (IAMException iamEx)
		{
			LOGGER.log(Level.SEVERE, "Problem in getting IAM Org. Exception trace:", iamEx);
		}
		return null;
	}

	public static Boolean updateOrgName(Long orgId, String orgName)
	{
		try
		{
			return IAMProxy.getInstance().getOrgAPI().updateOrgDisplayName(orgId, orgName);
		}
		catch (Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Problem in updating IAM Org name. Exception trace: ", ex);
			return false;
		}
	}

	public static Boolean deleteOrg(Long orgId)
	{
		try
		{
			//Should we do the same as deleteOrg in zviamhandler before doing this????
			return IAMProxy.getInstance().getOrgAPI().deleteOrg(orgId);
		}
		catch (Exception ex)
		{
			LOGGER.log(Level.SEVERE, "Problem in deleting IAM Org - " + orgId + ". Exception trace: ", ex);
			return false;
		}
	}

	/**
	 * To get the IAM User (instance of <code>com.adventnet.iam.User</code>) for the given ZUID.
	 *
	 * @param zuid ZUID corresponding to which IAM User needs to be returned
	 * @return Instance of <code>com.adventnet.iam.User</code>. In case of any problem, returns <code>null</code>.
	 */
	public static User getIAMUser(String zuid)
	{
		try
		{
			return IAMProxy.getInstance().getUserAPI().getUser(Long.valueOf(zuid));
		}
		catch (IAMException iamEx)
		{
			LOGGER.log(Level.SEVERE, "Problem in getting IAM user, returning null", iamEx);
		}
		return null;
	}

	/**
	 * To authenticate the current user. It make API call to IAM to authenticated the user.
	 *
	 * @param passwd Zoho account password of the current user
	 * @return <code>true</code> if the user is successfully authenticated, else <code>false</code>.
	 */
	public static boolean isAuthenticated(String passwd)
	{
		return isAuthenticated(IAMUtil.getCurrentUser().getZUID(), passwd);
	}

	/**
	 * To authenticate the given user. It make API call to IAM to authenticated the user.
	 *
	 * @param zuid   ZUID of the user to be authenticated. It should be as long
	 * @param passwd
	 * @return
	 */
	public static boolean isAuthenticated(Long zuid, String passwd)
	{
		try
		{
			AuthAPI authAPI = IAMProxy.getInstance().getAuthAPI();
			return authAPI.authenticate(null, null, null, null, null);//TODO: Fix as necessary
		}
		catch (IAMException iamEx)
		{
			LOGGER.log(Level.SEVERE, "Problem in authenticating user: {0}", zuid);
			LOGGER.log(Level.SEVERE, "Exception trace:", iamEx);
		}
		return false;
	}

	/**
	 * To get the <code>ZAID</code> when <code>ZAAID</code> is known.
	 *
	 * @param zaaid ZAAID for which ZAID in to be fetched
	 * @return ZAAID as <code>String</code>
	 * @throws ResourceException, NullPointerException <requested appaccount not >
	 */
	//	public static String getZAID(String zaaid) throws ResourceException, NullPointerException
	//	{
	//		String aaPath = Accounts.RESOURCE.ACCOUNT.table() + "." + Accounts.RESOURCE.APPACCOUNT.table();
	//		URI uri = Accounts.setPath(aaPath, zaaid);
	//		com.zoho.protobuf.Message msg = uri.GET();
	//		return ((AccountsProto.Account) msg).getZaid();
	//	}

	/**
	 * To get ZAAID for the given IAM user.
	 *
	 * @param user Instance of <code>com.adventnet.iam.User</code>
	 * @return ZAAID, if exists, else <code>null</code>
	 */
	public static String getZAAID(User user)
	{
		String zaaId = null;
		if (user != null)
		{
			AccountsProto.Account.AppAccount appAccount = getAppAccFromCache(user.getZaid());
			if (appAccount == null)
			{
				appAccount = setAppAccToCache(user.getZaid());
			}

			if (appAccount != null)
			{
				zaaId = appAccount.getZaaid();
			}
		}
		return zaaId;
	}

	/**
	 * To get the service ID assigned by IAM
	 *
	 * @return Service ID
	 */
	public static int getServiceID()
	{
		if (serviceId == -1)
		{
			Service zvService = IAMProxy.getInstance().getServiceAPI().getService(getServiceName());
			if (zvService != null)
			{
				serviceId = zvService.getServiceId();
				LOGGER.log(Level.INFO, "Service Name:{0}, Service ID: {1}", new Object[]{zvService.getServiceName(), serviceId});
			}
		}

		return serviceId;
	}

	/**
	 * To get the service name registered in IAM. Default is <i>ZohoIdmpod</i>.
	 *
	 * @return Service name
	 */
	public static String getServiceName()
	{
		return serviceName;
	}

	/**
	 * To get the company name as per IAM records.
	 *
	 * @return Company name
	 */
	public static String getCompanyName()
	{
		return IAMUtil.getCurrentUserOrg().getDisplayName();
	}

	/**
	 * To enable/activate the specified user in IAM.
	 * This method just sets the user status as active for the given App Account.
	 *
	 * @param zuId <code>ZUID</code> of the user to be enabled
	 * @throws ResourceException
	 */
	public static void enableUserInIAM(String zaId, String zaaId, String zuId) throws IAMException
	{
		AppAccountUtils.updateIdmpodAppAccountMemberStatus(zaaId, zuId, AppAccountUtils.STATUS_ACTIVE);
	}

	/**
	 * To disable/deactivate the specified user in IAM.
	 * This method just sets the user status as inactive for the given App Account.
	 *
	 * @param zuId <code>ZUID</code> of the user to be disabled
	 * @throws ResourceException
	 */
	public static void disableUserInIAM(String zaId, String zaaId, String zuId) throws IAMException
	{
		if (AppAccountUtils.updateIdmpodAppAccountMemberStatus(zaaId, zuId, AppAccountUtils.STATUS_INACTIVE))
		{
			return;
			//com.zoho.vault.User.updateUserStatus(zuId, com.zoho.vault.User.USER_STATUS_INACTIVE);
		}
	}

	/**
	 * To get the App Account members.
	 * This method returns the array of either active or inactive <code>AppAccountMember</code> for the given <code>zaaid</code>.
	 *
	 * @param zaaid ZAAID for which the App Account members are to be fetched
	 * @param status Status of the users - <b>0</b> means inactive, and <b>1</b> means active.
	 * @return Array of <code>AppAccountMember</code>
	 * @throws ResourceException
	 */
   /* public static AppAccountMember[] getAppAccountMembers(String zaaid, int status) throws ResourceException {
		return getAppAccountMembers(getZAID(zaaid), zaaid, status);
    }*/

	/**
	 * To get the App Account members. This method can be used if <code>ZAID</code> is also known.
	 * It returns the array of either active or inactive <code>AppAccountMember</code> for the given <code>zaaid</code>.
	 *
	 * @param zaid ZAID for which the App Account members are to be fetched
	 * @param zaaid ZAAID for which the App Account members are to be fetched
	 * @param status Status of the users - <b>0</b> means inactive, and <b>1</b> means active.
	 * @return Array of <code>AppAccountMember</code>
	 * @throws ResourceException
	 * @see IAMCommunicator#getAppAccountMembers(java.lang.String, int)
	 */
   /* public static AppAccountMember[] getAppAccountMembers(String zaid, String zaaid, int status) throws ResourceException {

    	Accounts.AppAccountMemberURI memberURI = Accounts.getAppAccountMemberURI(zaid, zaaid);
        Criteria criteria = new Criteria(Accounts.RESOURCE.APPACCOUNTMEMBER.IS_ACTIVE, Comparator.EQUALS, status);
        memberURI.getQueryString().setCriteria(criteria).setOrderBy(Accounts.RESOURCE.APPACCOUNTMEMBER.CREATED_TIME.name(), false);
        return memberURI.GETS();

    }*/

	/**
	 * To set the TFA preference at <b>Account</b> level.
	 * Once set, TFA will be enforced to all the Account users, by default.
	 * On reset, the enforcement will be revoked for all users of the Account.
	 *
	 * @param zaid   ZAID of the Account for which TFA to be configured
	 * @param status <code>true</code> will enforce TFA across the organization whereas <code>false</code> will remove the enforcement
	 * @throws IAMException
	 */
	public static boolean setTFAPreference(String zaid, boolean status) throws IAMException
	{
		Long zaidLong = Long.valueOf(zaid);
		OrgAPI orgAPI = IAMProxy.getInstance().getOrgAPI();
		OrgPolicy orgPolicy = orgAPI.getOrgPolicy(zaidLong);
		if (orgPolicy == null)
		{
			orgPolicy = new OrgPolicy();
		}
		orgPolicy.setTFAPrefOptionEnabled(status);
		return orgAPI.updateOrgPolicy(zaidLong, orgPolicy);
	}

	/**
	 * To change user's TFA status. This method should be used when Org Admin enables/disables TFA for a user.
	 *
	 * @param currUserPasswd Zoho account password of the current user - required by the API to change user TFA status.
	 * @param zuid           ZUID of the user whose TFA status to be changed
	 * @param tfaStatus      <code>String</code> value specifying to enable or disable TFA
	 * @return <code>true</code> if successfully configured, else <code>false</code>
	 * @throws IAMException
	 */
	public static boolean changeUserTFAStatus(String currUserPasswd, long zuid, String tfaStatus) throws IAMException
	{
		if ("Enable".equals(tfaStatus))
		{
			return IAMProxy.getInstance().getUserAPI().changeUserTFAStatus(zuid, currUserPasswd, AccountsConstants.UserTFAStatus.ENABLE_TFA);
		}
		else
		{
			return IAMProxy.getInstance().getUserAPI().changeUserTFAStatus(zuid, currUserPasswd, AccountsConstants.UserTFAStatus.DISABLE_TFA);
		}
	}

	/**
	 * To reset the given user's TFA settings.
	 *
	 * @param currUserPasswd Zoho account password of the current user - required by the API to reset user's TFA.
	 * @param zuid           ZUID of the user whose TFA status to be changed
	 * @return <code>true</code> if successfully reset the TFA, else <code>false</code>
	 * @throws IAMException
	 */
	public static boolean resetUserTFA(String currUserPasswd, long zuid) throws IAMException
	{
		return IAMProxy.getInstance().getUserAPI().resetTFAByAdmin(zuid, currUserPasswd);
	}

	/**
	 * To check whether TFA is enabled for the given account.
	 * This method also checks and verifies whether TFA configuration is enabled for the given account or not.
	 *
	 * @param zaid ZAID of the Account for which TFA configuration to be checked
	 * @return <code>true</code> if TFA is enabled, else <code>false</code>
	 * @throws IAMException
	 */
	public static boolean isTFAEnabled(String zaid) throws IAMException
	{
		Long zaidLong = Long.valueOf(zaid);
		if (isTFAConfigurationEnabled(zaidLong))
		{
			OrgPolicy orgPolicy = IAMProxy.getInstance().getOrgAPI().getOrgPolicy(zaidLong);
			return (orgPolicy != null && orgPolicy.isTFAPrefOptionEnabled());
		}
		return false;
	}

	/**
	 * To check whether TFA is enabled (or enforced) for the given user.
	 *
	 * @param zaid ZAID of the Account under which the user comes
	 * @param zuid ZUID of the user for whom TFA configuration to be checked
	 * @return <code>true</code> if TFA is enabled (or enforce), else <code>false</code>
	 * @throws IAMException
	 */
	public static boolean isTFAEnabled(String zaid, String zuid) throws IAMException
	{
		UserPreference userPref = IAMProxy.getInstance().getUserAPI().getUserPreference(Long.valueOf(zuid));
		if (isTFAEnabled(zaid))
		{
			if (userPref != null)
			{
				return (userPref.getUserTFAStatus() != AccountsConstants.UserTFAStatus.DISABLE_TFA_BY_ADMIN);
			}
			else
			{
				return true;    //User level TFA preference is not yet changed by admin.
			}
		}
		else
		{
			if (userPref != null)
			{
				return userPref.isTFAEnabled();
			}
			else
			{
				return false;
			}
		}
	}

	/**
	 * To check whether TFA configuration is enabled for the given ZAID or not.
	 * <p><b>NOTE:</b> This method might be removed in future once TFA is fully implemented and opened for all by IAM.</p>
	 *
	 * @param zaid ZAID of the organization for which TFA configuration is to be checked.
	 *             Since both - ZAID and ZOID are same values, it can even be ZOID as <code>String</code>.
	 * @return <code>true</code> if TFA is configured as enabled for the given organization, else <code>false</code>.
	 * @see IAMCommunicator#isTFAConfigurationEnabled(java.lang.Long)
	 */
	public static boolean isTFAConfigurationEnabled(String zaid)
	{
		return isTFAConfigurationEnabled(Long.parseLong(zaid));
	}

	/**
	 * To check whether TFA configuration is enabled for the given organization/account or not.
	 * <p><b>NOTE:</b>
	 * <ol><li>This method might be removed in future once TFA is fully implemented and opened for all by IAM.</li>
	 * <li>This method accepts a parameter <code>userZoid</code> which can either be ZOID or ZAID as <code>long</code>.<br>
	 * Here, it is important to note that ZOID and ZAID are same values in IAM.</li></ol></p>
	 *
	 * @param userZoid ZOID of the organization for which TFA configuration is to be checked.
	 *                 Since both - ZOID and ZAID are same values, it can even be ZOID as <code>String</code>.
	 * @return <code>true</code> if TFA is configured as enabled for the given organization, else <code>false</code>.
	 */
	public static boolean isTFAConfigurationEnabled(Long userZoid)
	{
		boolean isBeta = Boolean.parseBoolean(AccountsConfiguration.getConfiguration("enable.tfa.beta", "false")); //No I18N
		if (isBeta)
		{
			String zoids = AccountsConfiguration.getConfiguration("enable.tfa.zoids", "");//No I18N
			if (zoids != null && zoids.trim().length() > 0)
			{
				try
				{
					String[] zoidArray = zoids.split(",");
					for (String zoid : zoidArray)
					{
						if (Long.parseLong(zoid) == userZoid)
						{
							return true;
						}
					}
				}
				catch (Exception ex)
				{
					LOGGER.log(Level.SEVERE, "Problem in checking if TFA Configuration is enabled. Exception trace:", ex);
					return false;
				}
			}
		}
		else
		{
			return "true".equals(AccountsConfiguration.getConfiguration("enable.tfa", "false")); //No I18n
		}
		return false;
	}

	/**
	 * To check whether TFA for the given user is disabled by Admin.
	 * <P><b>This method should be used only when you are sure that TFA is already enabled at Account level.</b></P>
	 * <P>This method checks for only one thing -
	 * whether the user TFA preference has been explicitly <b>disabled</b> by Admin or not.<br>
	 * If no user TFA preference is configured, i.e., <code>UserPreference</code> is found <code>null</code>,
	 * assuming that TFA is enabled for the account and NOT explicitly disabled for this user, it return <code>false</code>.
	 *
	 * @param zuid ZUID of the user for whom TFA configuration to be checked
	 * @return <code>true</code> if Admin has explicitly disabled TFA for given user, else <code>false</code>.
	 * @throws IAMException
	 */
	public static boolean isUserTFAPrefDisabled(String zuid) throws IAMException
	{
		UserPreference userPref = IAMProxy.getInstance().getUserAPI().getUserPreference(Long.valueOf(zuid));
		return ((userPref != null) && (userPref.getUserTFAStatus() == AccountsConstants.UserTFAStatus.DISABLE_TFA_BY_ADMIN));
	}

	/**
	 * To get the active/enabled users count.
	 *
	 * @return Active users count
	 * @throws ResourceException
	 */
	public static int getActiveUsersCount() throws IAMException
	{
		return AppAccountUtils.getAppAccountMemberCount(IdmpodThreadLocal.getAppId(), AppAccountUtils.STATUS_ACTIVE);
	}

	public static String getSignUpURL() throws UnsupportedEncodingException
	{

		String serviceName = AppResources.getProperty("service.name");
		String iam = IAMProxy.getIAMServerURL();
		String serviceurl = "/online/main";//No I18N
		iam = iam + "/register" + "?servicename=" + serviceName;//No I18N
		//If registration is to be disabled set this flag
		//iam= iam+ "&hide_signup=true";
		//To hide the Forgot password link
		//iam= iam+ "&hide_fp=true";
		//if (serviceurl != null && serviceurl.length() > 0) {//Unnecessary check - variable "serviceurl" is assigned just above
		iam = iam + "&serviceurl="//No I18N
				+ java.net.URLEncoder.encode(serviceurl, "UTF-8");//No I18N
		//}
		return iam;
	}

	public static String getLoginURL() throws UnsupportedEncodingException
	{

		String serviceName = AppResources.getProperty("service.name");
		String iam = IAMProxy.getIAMServerURL();
		String serviceurl = "/online/main";//No I18N
		iam = iam + "/login" + "?servicename=" + serviceName;//No I18N
		//If registration is to be disabled set this flag
		//iam= iam+ "&hide_signup=true";
		//To hide the Forgot password link
		//iam= iam+ "&hide_fp=true";
		//To add css
		iam = iam + "&css=" + AppResources.getProperty("serviceurl") + "/css/signup.css";//NO I18N
		//if (serviceurl != null && serviceurl.length() > 0) {//Unnecessary check - variable "serviceurl" is assigned just above
		iam = iam + "&serviceurl="//No I18N
				+ java.net.URLEncoder.encode(serviceurl, "UTF-8");//No I18N
		//}
		return iam;
	}

	/**
	 * To get the AppAccount from the cache for a given ZAID.
	 * If the cached AppAccount instance is expired, i.e., older than the CACHE_VALIDITY_PERIOD then
	 * it removes that entry from the cache and returns <code>null</code>.
	 * The calling method should check whether the returned AppAccount is <code>null</code>.
	 * In that case, you should again call <code>IAMCommunicator.setAppAccToCache(String zaid)</code> method to get
	 * the corresponding AppAccount, if exists.
	 *
	 * @param zaid ZAID for which AppAccount to be obtained
	 * @return Instance of <code>AppAccount </code>, if it is present in the cache, else <code>null</code>
	 */
	public static AccountsProto.Account.AppAccount getAppAccFromCache(String zaid)
	{
		AccountsProto.Account.AppAccount appAccount = null;
		if (zaid != null && zaid.trim().length() > 0)
		{
			HashMap<String, Object> appAccMap = APP_ACC_CACHE.get(zaid);
			if (appAccMap != null)
			{
				Long currTime = System.currentTimeMillis();
				Long validatedTime = (Long) appAccMap.get(KEY_VALIDATED_TIME);
				if (currTime > (validatedTime + CACHE_VALIDITY_PERIOD))
				{
					appAccMap.remove(zaid);
				}
				else
				{
					appAccount = (AccountsProto.Account.AppAccount) appAccMap.get("AppAccount");
				}
			}
		}
		return appAccount;
	}

	/**
	 * This method fetches the AppAccount from IAM for the given ZAID.
	 * If corresponding AppAccount exists, it sets it to the cache and returns the same.
	 *
	 * @param zaid ZAID for which AppAccount to be set
	 * @return Instance of <code>AppAccount </code>, if it exists in IAM.
	 */
	public static AccountsProto.Account.AppAccount setAppAccToCache(String zaid)
	{
		AccountsProto.Account.AppAccount appAccount = AppAccountUtils.getIdmpodAppAccount(zaid);
		if (appAccount != null)
		{
			HashMap<String, Object> appAccMap = new HashMap<String, Object>();
			appAccMap.put(KEY_VALIDATED_TIME, System.currentTimeMillis());
			appAccMap.put("AppAccount", appAccount);
			APP_ACC_CACHE.put(zaid, appAccMap);
		}
		return appAccount;
	}

	//	public static void setIPprefrence(String lastModifiedTime, boolean accessToIdmpod, String ipAddress)
	//	{
	//		HashMap<String, Object> userIPprefrence = new HashMap<String, Object>();
	//		userIPprefrence.put(KEY_VALIDATED_TIME, System.currentTimeMillis());
	//		userIPprefrence.put("username", IdmpodUtils.getDisplayName());
	//		userIPprefrence.put("lastModifiedTime", lastModifiedTime);
	//		userIPprefrence.put("accessToIdmpod", accessToIdmpod);
	//		userIPprefrence.put("ipAddress", ipAddress);
	//		IP_PREFRENCE.put(IdmpodUtils.getUserId().toString(), userIPprefrence);
	//	}
	//
	//	public static HashMap<String, Object> getIPprefrence()
	//	{
	//		Long userId = IdmpodUtils.getUserId();
	//		if (IP_PREFRENCE.containsKey(userId.toString()))
	//		{
	//			HashMap<String, Object> userIPprefrence = IP_PREFRENCE.get(userId.toString());
	//			Long currTime = System.currentTimeMillis();
	//			Long savedTime = (Long) userIPprefrence.get(KEY_VALIDATED_TIME);
	//			if (currTime > (savedTime + CACHE_VALIDITY_PERIOD))
	//			{
	//				IP_PREFRENCE.remove(IdmpodUtils.getUserId().toString());
	//				return null;
	//			}
	//			return userIPprefrence;
	//		}
	//		return null;
	//	}
	//
	//	public static void setReportSummaryPreference(String auditId)
	//	{
	//		HashMap<String, Object> reportSummaryPref = new HashMap();
	//		reportSummaryPref.put(KEY_VALIDATED_TIME, System.currentTimeMillis());
	//		reportSummaryPref.put("auditId", auditId);
	//		REPORT_SUMMARY_PREFERNCE.put(IdmpodUtils.getUserId().toString(), reportSummaryPref);
	//	}
	//
	//	public static HashMap<String, Object> getReportSummaryPreference()
	//	{
	//		if (REPORT_SUMMARY_PREFERNCE.containsKey(IdmpodUtils.getUserId().toString()))
	//		{
	//			HashMap<String, Object> reportSummaryPre = REPORT_SUMMARY_PREFERNCE.get(IdmpodUtils.getUserId().toString());
	//			Long currTime = System.currentTimeMillis();
	//			Long savedTime = (Long) reportSummaryPre.get(KEY_VALIDATED_TIME);
	//			if (currTime > (savedTime + CACHE_VALIDITY_PERIOD))
	//			{
	//				REPORT_SUMMARY_PREFERNCE.remove(IdmpodUtils.getUserId().toString());
	//				return null;
	//			}
	//			return reportSummaryPre;
	//		}
	//		return null;
	//	}
	//
	//	public static void removeReportSummaryPreference()
	//	{
	//		if (REPORT_SUMMARY_PREFERNCE.containsKey(IdmpodUtils.getUserId().toString()))
	//		{
	//			REPORT_SUMMARY_PREFERNCE.remove(IdmpodUtils.getUserId().toString());
	//		}
	//	}
}
