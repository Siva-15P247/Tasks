package com.zoho.scheduler;

import org.json.JSONObject;

import java.util.Map;

public class IdmpodCalendarRepetition extends CalendarRepetition
{
	private CalendarRepetition calendarRepetition = null;

	public IdmpodCalendarRepetition(String scheduleName)
	{
		super(scheduleName);
	}

	IdmpodCalendarRepetition(Map<String, Object> map)
	{
		super(map);
	}

	public IdmpodCalendarRepetition(CalendarRepetition calendarRepetition)
	{
		super(calendarRepetition.valueStore.values);
		this.calendarRepetition = calendarRepetition;
	}

	public JSONObject getExecutionTimeInfo()
	{
		JSONObject execTime = new JSONObject();
		Time1 executionTime = super.getExecutionTime();
		execTime.put("HOURS", executionTime.hours());
		execTime.put("MINUTES", executionTime.minutes());
		return execTime;
	}
}
